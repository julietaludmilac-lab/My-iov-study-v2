import express from 'express';
import cookieParser from 'cookie-parser';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { createServer as createViteServer } from 'vite';
import { getDb, queryAll } from './server/db.js';
import { seedDatabase } from './server/seed.js';
import {
  handleLogin,
  handleLogout,
  handleRegister,
  lookupEmail,
  getRegisteredAccounts,
  requireAuth,
  requireRole,
  requireCsrf,
  getStudentProfile,
  updateStudentProfile,
  handleChangePassword,
} from './server/auth.js';

import {
  getNotices,
  getNoticeById,
  saveNoticeDraft,
  previewNotice,
  publishNotice,
  publishDirectNotice,
  deleteNotice,
  restoreNoticeVersion,
  manageExpiredNotice,
  getStudentNotifications,
  markNotificationAsRead,
  markAllNotificationsAsRead,
} from './server/notices.js';

import {
  getSchedule,
  getCalendarEvents,
  getAgendaItems,
  createAgendaItem,
  deleteAgendaItem,
  getStudyPlan,
  getAttendance,
  getEvaluations,
  getGrades,
  getExams,
  enrollExam,
  withdrawExam,
  getFinance,
  getCertificates,
  requestCertificate,
  getAcademicDocuments,
} from './server/academic.js';

import {
  getPaymentMethods,
  addPaymentMethod,
  deletePaymentMethod,
  getHealthRecord,
  updateHealthRecord,
  getSpecialProcedures,
  startSpecialProcedure,
  getSurveys,
  submitSurvey,
  adminReallocateClassroom,
  adminResolveCertificate,
} from './server/stage6.js';

import {
  getStudentProgressAnalytics,
  getBedeliaKPIs,
  getAdminFinanceKPIs,
  getActasOficiales,
  generarActaOficial,
  firmarActaOficial,
  verifyDocumentoPublico,
  exportDataHandler,
  getUserPreferences,
  updateUserPreferences,
} from './server/stage7.js';

import {
  getSupportTickets,
  createSupportTicket,
  respondSupportTicket,
  getRepositoryDocuments,
  downloadRepositoryDocument,
  changeUserPassword,
  getSystemHealthMetrics,
} from './server/stage8.js';

import {
  getCarreras,
  createCarrera,
  deleteCarrera,
  addMateriaManual,
  parsePlanDocumentHandler,
  importPlanHandler,
  getBedeliaComisiones,
  createBedeliaComision,
  updateBedeliaComision,
  toggleComisionInscripcion,
  deleteBedeliaComision,
  getAdminStudents,
  createAdminStudent,
  createBedeliaExamen,
  deleteBedeliaExamen,
  toggleBedeliaExamen,
  createBedeliaCalendarEvent,
  deleteBedeliaCalendarEvent,
  getBedeliaComisionAsistencia,
  getAdminUsers,
  toggleAdminUserStatus,
  resetAdminUserPassword,
  getAdminArancelesSummary,
  getAdminAuditoria,
} from './server/adminCareers.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const isProduction = process.env.NODE_ENV === 'production';

// Puerto oficial del entorno AI Studio: el servidor Node siempre debe escuchar en el puerto 3000
// Nginx escucha en el puerto 8080 y redirige a localhost:3000.
function resolveServerPort(): number {
  const portArgIdx = process.argv.indexOf('--port');
  if (portArgIdx !== -1 && process.argv[portArgIdx + 1]) {
    const val = parseInt(process.argv[portArgIdx + 1], 10);
    if (!isNaN(val)) return val;
  }
  if (!isProduction || process.env.PORT === '8080') {
    return 3000;
  }
  return process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
}

const PORT = resolveServerPort();

async function startServer() {
  const app = express();

  app.use(express.json());
  app.use(cookieParser());

  // Inicializar Base de Datos SQLite y Semilla sintética
  console.log('[SERVER] Initializing SQLite database and synthetic seed...');
  await getDb();
  await seedDatabase();

  // Middleware de Seguridad Básico y Headers
  app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    next();
  });

  // Endpoints de salud y observabilidad de la base técnica
  app.get('/api/health', (req, res) => {
    try {
      const tables = queryAll<{ name: string }>(
        "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
      );
      res.json({
        status: 'ok',
        app: 'My IOV Study v2',
        version: '0.8.0',
        stage: 8,
        module: 'M8 Mesa de Ayuda Digital, Repositorio Documental, Seguridad Integral y Observabilidad',
        etapa4Aprobada: true,
        etapa5Aprobada: true,
        etapa6Aprobada: true,
        etapa7Aprobada: true,
        etapa8Iniciada: true,
        synthetic: true,
        database: {
          engine: 'SQLite (sql.js persistent)',
          initialized: true,
          tablesCount: tables.length,
          tables: tables.map((t) => t.name),
        },
      });
    } catch (err: unknown) {
      const error = err as Error;
      res.status(500).json({ status: 'error', message: error.message });
    }
  });

  // Endpoints de Autenticación y Sesión (M2)
  app.post('/api/auth/login', handleLogin);
  app.post('/api/auth/logout', handleLogout);
  app.post('/api/auth/register', handleRegister);
  app.get('/api/auth/lookup-email', lookupEmail);
  app.get('/api/auth/registered-accounts', getRegisteredAccounts);
  
  app.get('/api/auth/me', requireAuth, (req, res) => {
    const session = (req as any).session;
    res.json({
      ok: true,
      user: {
        id: session.userId,
        matricula: session.matricula,
        rol: session.rol,
        nombre: session.nombre,
      },
      csrfToken: session.csrfToken,
    });
  });

  app.post('/api/auth/change-password', requireAuth, requireCsrf, handleChangePassword);

  // Perfil del Estudiante
  app.get('/api/student/profile', requireAuth, requireRole('ESTUDIANTE'), getStudentProfile);
  app.put('/api/student/profile', requireAuth, requireRole('ESTUDIANTE'), requireCsrf, updateStudentProfile);

  // Endpoint de prueba administrativa protegida (para verificar 403 de alumnos)
  app.get('/api/admin/metrics', requireAuth, requireRole('BEDELIA', 'ADMINISTRACION'), (req, res) => {
    res.json({ ok: true, metrics: { status: 'operational', timestamp: new Date().toISOString() } });
  });

  // Endpoints de Avisos e Historial (M3)
  app.get('/api/notices', requireAuth, getNotices);
  app.get('/api/notices/:id', requireAuth, getNoticeById);
  app.post('/api/notices/draft', requireAuth, requireRole('BEDELIA'), requireCsrf, saveNoticeDraft);
  app.post('/api/notices/preview', requireAuth, requireRole('BEDELIA'), requireCsrf, previewNotice);
  app.post('/api/notices/:id/preview', requireAuth, requireRole('BEDELIA'), requireCsrf, previewNotice);
  app.post('/api/notices/publish', requireAuth, requireRole('BEDELIA'), requireCsrf, publishNotice);
  app.post('/api/notices/:id/publish', requireAuth, requireRole('BEDELIA'), requireCsrf, publishNotice);
  app.post('/api/notices/publish-direct', requireAuth, requireRole('BEDELIA'), requireCsrf, publishDirectNotice);
  app.delete('/api/notices/:id', requireAuth, requireRole('BEDELIA'), requireCsrf, deleteNotice);
  app.post('/api/notices/:id/restore-version/:versionNumber', requireAuth, requireRole('BEDELIA'), requireCsrf, restoreNoticeVersion);
  app.post('/api/notices/:id/manage-expired', requireAuth, requireRole('BEDELIA'), requireCsrf, manageExpiredNotice);

  // Endpoints de Notificaciones
  app.get('/api/notifications', requireAuth, requireRole('ESTUDIANTE'), getStudentNotifications);
  app.patch('/api/notifications/:id/read', requireAuth, requireRole('ESTUDIANTE'), requireCsrf, markNotificationAsRead);
  app.post('/api/notifications/mark-all-read', requireAuth, requireRole('ESTUDIANTE'), requireCsrf, markAllNotificationsAsRead);

  // Endpoints Académicos, Horarios, Calendario y Autogestión (M4/M5)
  app.get('/api/academic/schedule', requireAuth, getSchedule);
  app.get('/api/academic/calendar', requireAuth, getCalendarEvents);
  app.get('/api/academic/agenda', requireAuth, requireRole('ESTUDIANTE'), getAgendaItems);
  app.post('/api/academic/agenda', requireAuth, requireRole('ESTUDIANTE'), requireCsrf, createAgendaItem);
  app.delete('/api/academic/agenda/:id', requireAuth, requireRole('ESTUDIANTE'), requireCsrf, deleteAgendaItem);
  app.get('/api/academic/study-plan', requireAuth, getStudyPlan);
  app.get('/api/academic/attendance', requireAuth, getAttendance);
  app.get('/api/academic/evaluations', requireAuth, getEvaluations);
  app.get('/api/academic/grades', requireAuth, getGrades);
  app.get('/api/academic/exams', requireAuth, getExams);
  app.post('/api/academic/exams/enroll', requireAuth, requireRole('ESTUDIANTE'), requireCsrf, enrollExam);
  app.delete('/api/academic/exams/withdraw/:examenId', requireAuth, requireRole('ESTUDIANTE'), requireCsrf, withdrawExam);
  app.get('/api/finance/fees', requireAuth, getFinance);
  app.get('/api/academic/certificates', requireAuth, getCertificates);
  app.post('/api/academic/certificates/request', requireAuth, requireRole('ESTUDIANTE'), requireCsrf, requestCertificate);
  app.get('/api/academic/documents', requireAuth, getAcademicDocuments);

  // Endpoints Etapa 6: Trámites Especiales, Salud, Medios de Pago y Acciones Bedelía
  app.get('/api/student/payment-methods', requireAuth, requireRole('ESTUDIANTE'), getPaymentMethods);
  app.post('/api/student/payment-methods', requireAuth, requireRole('ESTUDIANTE'), requireCsrf, addPaymentMethod);
  app.delete('/api/student/payment-methods/:id', requireAuth, requireRole('ESTUDIANTE'), requireCsrf, deletePaymentMethod);

  app.get('/api/student/health-record', requireAuth, requireRole('ESTUDIANTE'), getHealthRecord);
  app.put('/api/student/health-record', requireAuth, requireRole('ESTUDIANTE'), requireCsrf, updateHealthRecord);

  app.get('/api/student/special-procedures', requireAuth, requireRole('ESTUDIANTE'), getSpecialProcedures);
  app.post('/api/student/special-procedures', requireAuth, requireRole('ESTUDIANTE'), requireCsrf, startSpecialProcedure);

  app.get('/api/student/surveys', requireAuth, requireRole('ESTUDIANTE'), getSurveys);
  app.post('/api/student/surveys/:id', requireAuth, requireRole('ESTUDIANTE'), requireCsrf, submitSurvey);

  app.post('/api/admin/reallocate-classroom', requireAuth, requireRole('BEDELIA'), requireCsrf, adminReallocateClassroom);
  app.patch('/api/admin/certificates/:id/resolve', requireAuth, requireRole('BEDELIA', 'ADMINISTRACION'), requireCsrf, adminResolveCertificate);

  // Endpoints Etapa 7: Analytics, Actas Oficiales, Verificación Digital y Preferencias (M7)
  app.get('/api/analytics/student-progress', requireAuth, requireRole('ESTUDIANTE'), getStudentProgressAnalytics);
  app.get('/api/analytics/bedelia-kpis', requireAuth, requireRole('BEDELIA', 'ADMINISTRACION'), getBedeliaKPIs);
  app.get('/api/analytics/admin-finance-kpis', requireAuth, requireRole('ADMINISTRACION'), getAdminFinanceKPIs);
  app.get('/api/records/actas', requireAuth, requireRole('BEDELIA', 'ADMINISTRACION'), getActasOficiales);
  app.post('/api/records/actas/generar', requireAuth, requireRole('BEDELIA'), requireCsrf, generarActaOficial);
  app.post('/api/records/actas/:id/firmar', requireAuth, requireRole('BEDELIA'), requireCsrf, firmarActaOficial);
  app.get('/api/records/export/:tipo', requireAuth, requireRole('BEDELIA', 'ADMINISTRACION'), exportDataHandler);
  app.get('/api/verify/:codigo', verifyDocumentoPublico);
  app.get('/api/user/preferences', requireAuth, getUserPreferences);
  app.put('/api/user/preferences', requireAuth, requireCsrf, updateUserPreferences);

  // Endpoints Etapa 8: Mesa de Ayuda Digital, Repositorio Documental, Cambio de Clave y Observabilidad (M8)
  app.get('/api/support/tickets', requireAuth, getSupportTickets);
  app.post('/api/support/tickets', requireAuth, requireRole('ESTUDIANTE'), requireCsrf, createSupportTicket);
  app.patch('/api/support/tickets/:id/respond', requireAuth, requireRole('BEDELIA', 'ADMINISTRACION'), requireCsrf, respondSupportTicket);
  app.get('/api/repository/documents', getRepositoryDocuments);
  app.get('/api/repository/documents/:id/download', downloadRepositoryDocument);
  app.post('/api/user/change-password', requireAuth, requireCsrf, changeUserPassword);
  app.post('/api/auth/change-password', requireAuth, requireCsrf, changeUserPassword);
  app.get('/api/system/health-metrics', getSystemHealthMetrics);

  // Endpoints Carreras y Planes (Público y Administración)
  app.get('/api/carreras', getCarreras);
  app.post('/api/admin/carreras', requireAuth, requireRole('ADMINISTRACION'), requireCsrf, createCarrera);
  app.delete('/api/admin/carreras/:id', requireAuth, requireRole('ADMINISTRACION'), requireCsrf, deleteCarrera);
  app.post('/api/admin/carreras/:carreraId/materias', requireAuth, requireRole('ADMINISTRACION'), requireCsrf, addMateriaManual);
  app.post('/api/admin/carreras/:carreraId/parse-plan', requireAuth, requireRole('ADMINISTRACION'), requireCsrf, parsePlanDocumentHandler);
  app.post('/api/admin/carreras/:carreraId/import-plan', requireAuth, requireRole('ADMINISTRACION'), requireCsrf, importPlanHandler);
  app.get('/api/admin/estudiantes', requireAuth, requireRole('ADMINISTRACION', 'BEDELIA'), getAdminStudents);
  app.post('/api/admin/estudiantes', requireAuth, requireRole('ADMINISTRACION'), requireCsrf, createAdminStudent);

  // Endpoints Gestión de Comisiones, Mesas, Calendario y Asistencia (Bedelía)
  app.get('/api/bedelia/comisiones', requireAuth, requireRole('BEDELIA', 'ADMINISTRACION'), getBedeliaComisiones);
  app.post('/api/bedelia/comisiones', requireAuth, requireRole('BEDELIA'), requireCsrf, createBedeliaComision);
  app.put('/api/bedelia/comisiones/:id', requireAuth, requireRole('BEDELIA'), requireCsrf, updateBedeliaComision);
  app.patch('/api/bedelia/comisiones/:id/toggle-estado', requireAuth, requireRole('BEDELIA'), requireCsrf, toggleComisionInscripcion);
  app.delete('/api/bedelia/comisiones/:id', requireAuth, requireRole('BEDELIA'), requireCsrf, deleteBedeliaComision);
  app.post('/api/bedelia/exams', requireAuth, requireRole('BEDELIA'), requireCsrf, createBedeliaExamen);
  app.delete('/api/bedelia/exams/:id', requireAuth, requireRole('BEDELIA'), requireCsrf, deleteBedeliaExamen);
  app.patch('/api/bedelia/exams/:id/toggle-estado', requireAuth, requireRole('BEDELIA'), requireCsrf, toggleBedeliaExamen);
  app.post('/api/bedelia/calendar', requireAuth, requireRole('BEDELIA'), requireCsrf, createBedeliaCalendarEvent);
  app.delete('/api/bedelia/calendar/:id', requireAuth, requireRole('BEDELIA'), requireCsrf, deleteBedeliaCalendarEvent);
  app.get('/api/bedelia/comisiones/:id/asistencia', requireAuth, requireRole('BEDELIA', 'ADMINISTRACION'), getBedeliaComisionAsistencia);

  // Endpoints Gestión de Usuarios, Aranceles y Auditoría (Administración)
  app.get('/api/admin/users', requireAuth, requireRole('ADMINISTRACION'), getAdminUsers);
  app.patch('/api/admin/users/:id/toggle-status', requireAuth, requireRole('ADMINISTRACION'), requireCsrf, toggleAdminUserStatus);
  app.post('/api/admin/users/:id/reset-password', requireAuth, requireRole('ADMINISTRACION'), requireCsrf, resetAdminUserPassword);
  app.get('/api/admin/aranceles-summary', requireAuth, requireRole('ADMINISTRACION'), getAdminArancelesSummary);
  app.get('/api/admin/auditoria', requireAuth, requireRole('ADMINISTRACION'), getAdminAuditoria);

  // API de información del sistema y rutas registradas
  app.get('/api/system/info', (req, res) => {
    res.json({
      name: 'My IOV Study v2',
      institution: 'Universidad Católica de Santa Fe (UCSF)',
      environment: isProduction ? 'production' : 'development',
      syntheticNotice: 'Todos los datos presentados son sintéticos y se utilizan con fines de demostración académica.',
    });
  });

  // Captura 404 estricta para cualquier ruta /api/* no coincidente
  // Previene que Vite devuelva HTML index.html (<!doctype...) ante endpoints API
  app.all('/api/*', (req, res) => {
    res.status(404).json({
      error: `Ruta de API no encontrada: ${req.method} ${req.originalUrl}`,
      code: 'API_ROUTE_NOT_FOUND',
    });
  });

  // Integración con Vite / Servidor Estático
  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: process.env.DISABLE_HMR !== 'true' },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    if (fs.existsSync(distPath)) {
      app.use(express.static(distPath));
      app.get('*', (req, res) => {
        res.sendFile(path.join(distPath, 'index.html'));
      });
    }
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[SERVER] My IOV Study v2 running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('[SERVER] Fatal startup error:', err);
  process.exit(1);
});
