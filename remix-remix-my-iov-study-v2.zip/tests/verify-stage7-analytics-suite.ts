import { getDb, queryOne, queryAll, runQuery } from '../server/db.js';
import { seedDatabase } from '../server/seed.js';
import crypto from 'node:crypto';

async function testStage7Suite() {
  console.log('[TEST-STAGE-7] Iniciando pruebas de Etapa 7: Analytics, Actas Oficiales, Verificación Digital y Preferencias...');
  await getDb();
  await seedDatabase();

  // 1. Probar Analytics de Avance Académico del Estudiante
  console.log('[TEST-STAGE-7] 1. Verificando cálculo de avance de carrera y semáforo...');
  const est = queryOne<{ id: string; plan_id: string }>(
    'SELECT id, plan_id FROM estudiantes WHERE usuario_id = "USR-EST-01"'
  );
  if (!est) throw new Error('Estudiante USR-EST-01 no encontrado');

  const totalMaterias = queryAll('SELECT id FROM materias WHERE plan_id = ?', [est.plan_id]).length;
  const materiasAprobadas = queryAll(
    'SELECT DISTINCT materia_id FROM calificaciones WHERE estudiante_id = ? AND nota >= 4',
    [est.id]
  ).length;

  const porcentaje = Math.round((materiasAprobadas / totalMaterias) * 100);
  console.log(`[TEST-STAGE-7] Total materias plan: ${totalMaterias}, Aprobadas: ${materiasAprobadas}, Avance: ${porcentaje}%`);
  if (porcentaje <= 0 || porcentaje > 100) {
    throw new Error('FALLA: Porcentaje de avance de carrera fuera de rango reglamentario');
  }
  console.log('[TEST-STAGE-7] OK: Avance de carrera verificado correctamente.');

  // 2. Probar Generación y Firma de Acta Oficial
  console.log('[TEST-STAGE-7] 2. Generando nueva Acta Oficial con Tomo, Folio y Libro...');
  const testActaId = `ACTA-TEST-${Date.now()}`;
  const numeroActa = `ACT-2026-EX-TEST-${Math.floor(1000 + Math.random() * 9000)}`;
  const libro = 'LIBRO-XXIV-SISTEMAS';
  const folio = 'FOLIO-200';
  const dataToHash = `${numeroActa}|${libro}|${folio}|MAT-POO|20|Dra. María Elena Vázquez|${new Date().toISOString()}`;
  const hashSha256 = crypto.createHash('sha256').update(dataToHash).digest('hex');

  runQuery(`
    INSERT INTO actas_oficiales (
      id, tipo, materia_id, numero_acta, libro, folio, ciclo_lectivo, fecha_cierre,
      presidente_tribunal, total_inscriptos, total_aprobados, total_desaprobados, total_ausentes,
      hash_verificacion, estado
    ) VALUES (
      ?, 'EXAMEN_FINAL', 'MAT-POO', ?, ?, ?, 2026, date('now'),
      'Dra. María Elena Vázquez', 25, 20, 3, 2,
      ?, 'GENERADA'
    )
  `, [testActaId, numeroActa, libro, folio, hashSha256]);

  const actaCreada = queryOne<{ id: string; estado: string; hash_verificacion: string }>(
    'SELECT id, estado, hash_verificacion FROM actas_oficiales WHERE id = ?',
    [testActaId]
  );

  if (!actaCreada || actaCreada.estado !== 'GENERADA') {
    throw new Error('FALLA: El acta oficial no fue creada en estado GENERADA');
  }

  // Firmar Acta Oficial
  runQuery('UPDATE actas_oficiales SET estado = "FIRMADA" WHERE id = ?', [testActaId]);
  const actaFirmada = queryOne<{ estado: string }>('SELECT estado FROM actas_oficiales WHERE id = ?', [testActaId]);
  if (actaFirmada?.estado !== 'FIRMADA') {
    throw new Error('FALLA: El acta no pasó a estado FIRMADA');
  }
  console.log(`[TEST-STAGE-7] OK: Acta ${numeroActa} generada con hash ${hashSha256.slice(0, 16)}... y firmada oficialmente.`);

  // 3. Probar Verificación Criptográfica Pública de Documentos
  console.log('[TEST-STAGE-7] 3. Probando verificación pública de documento...');
  const testCodigoVerif = `UCSF-TEST-${Date.now()}`;
  runQuery(`
    INSERT INTO verificaciones_documentos (
      id, codigo_seguridad, tipo_documento, referencia_id, estudiante_id,
      hash_sha256, emisor_rol, emisor_nombre, fecha_emision, estado
    ) VALUES (
      ?, ?, 'ACTA_EXAMEN', ?, ?,
      ?, 'BEDELIA', 'Dra. María Elena Vázquez', date('now'), 'VALIDO'
    )
  `, [crypto.randomUUID(), testCodigoVerif, testActaId, est.id, hashSha256]);

  const verifDoc = queryOne<{ codigo_seguridad: string; estado: string }>(
    'SELECT codigo_seguridad, estado FROM verificaciones_documentos WHERE codigo_seguridad = ?',
    [testCodigoVerif]
  );
  if (!verifDoc || verifDoc.estado !== 'VALIDO') {
    throw new Error('FALLA: El registro de verificación pública no es válido');
  }
  console.log(`[TEST-STAGE-7] OK: Código de verificación digital ${testCodigoVerif} validado.`);

  // 4. Probar Preferencias de Usuario
  console.log('[TEST-STAGE-7] 4. Probando actualización de preferencias de usuario...');
  runQuery(`
    INSERT OR REPLACE INTO preferencias_usuario (
      id, usuario_id, notif_email_avisos, notif_email_cuotas,
      notif_email_cambio_aula, notif_email_calificaciones, tema_visual, resumen_semanal
    ) VALUES (
      'PREF-TEST', 'USR-EST-01', 1, 0, 1, 1, 'OSCURO', 0
    )
  `);

  const pref = queryOne<{ tema_visual: string; notif_email_cuotas: number }>(
    'SELECT tema_visual, notif_email_cuotas FROM preferencias_usuario WHERE usuario_id = "USR-EST-01"'
  );
  if (!pref || pref.tema_visual !== 'OSCURO' || pref.notif_email_cuotas !== 0) {
    throw new Error('FALLA: Las preferencias no se actualizaron correctamente');
  }
  console.log('[TEST-STAGE-7] OK: Preferencias de usuario persistidas con éxito.');

  // 5. Probar KPIs de Finanzas y Bedelía
  console.log('[TEST-STAGE-7] 5. Verificando cálculo de KPIs de recaudación y ocupación...');
  const cuotas = queryAll<{ estado: string; monto: number }>('SELECT estado, monto FROM cuotas');
  const totalCuotas = cuotas.length;
  const pagadas = cuotas.filter(c => c.estado === 'PAGADA').length;
  const tasaCobranza = Math.round((pagadas / totalCuotas) * 100);
  console.log(`[TEST-STAGE-7] Cuotas registradas: ${totalCuotas}, Pagadas: ${pagadas}, Tasa Cobranza: ${tasaCobranza}%`);
  if (tasaCobranza <= 0) throw new Error('FALLA: Tasa de cobranza calculada erróneamente');
  console.log('[TEST-STAGE-7] OK: KPIs calculados correctamente.');

  // Limpieza
  runQuery('DELETE FROM verificaciones_documentos WHERE codigo_seguridad = ?', [testCodigoVerif]);
  runQuery('DELETE FROM actas_oficiales WHERE id = ?', [testActaId]);

  console.log('\n[TEST-STAGE-7] ¡TODAS LAS PRUEBAS DE ETAPA 7 PASARON CON ÉXITO!');
}

testStage7Suite().catch((err) => {
  console.error('[TEST-STAGE-7] Error:', err);
  process.exit(1);
});
