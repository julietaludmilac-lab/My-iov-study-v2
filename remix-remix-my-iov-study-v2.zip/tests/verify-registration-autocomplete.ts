import { getDb, queryOne, queryAll, runQuery } from '../server/db.js';
import { seedDatabase } from '../server/seed.js';
import bcrypt from 'bcryptjs';

async function testRegistrationAndAutocomplete() {
  console.log('[TEST-REG] Iniciando pruebas de registro de cuenta y autocompletado en BD...');
  await getDb();
  await seedDatabase();

  const testMatricula = 'A-2026-009';
  const testCorreo = 'santiago.benitez@ucsf.test';
  const testPassword = 'Password2026A';
  const testNombre = 'Santiago Martín Benítez';

  // Limpiar por si existía de una ejecución previa
  runQuery('DELETE FROM estudiantes WHERE usuario_id IN (SELECT id FROM usuarios WHERE matricula = ?)', [testMatricula]);
  runQuery('DELETE FROM usuarios WHERE matricula = ? OR correo = ?', [testMatricula, testCorreo]);

  // 1. Registro de Nueva Cuenta
  console.log('[TEST-REG] 1. Registrando nueva cuenta en SQLite...');
  const salt = bcrypt.genSaltSync(10);
  const hash = bcrypt.hashSync(testPassword, salt);
  const newUserId = 'USR-TEST-REG-01';

  runQuery(`
    INSERT INTO usuarios (id, matricula, correo, password_hash, rol, estado)
    VALUES (?, ?, ?, ?, 'ESTUDIANTE', 'ACTIVO')
  `, [newUserId, testMatricula, testCorreo, hash]);

  runQuery(`
    INSERT INTO estudiantes (id, usuario_id, nombre_completo, carrera_id, plan_id, anio_cursado, condicion_academica)
    VALUES ('EST-TEST-REG-01', ?, ?, 'CAR-LSI', 'PLAN-LSI-2023', 1, 'REGULAR')
  `, [newUserId, testNombre]);

  console.log('[TEST-REG] Cuenta guardada con éxito en la base de datos persistente.');

  // 2. Comprobar que no permite duplicados (Rechazo de cuenta ya registrada)
  console.log('[TEST-REG] 2. Verificando que rechaza duplicados si la cuenta ya existe...');
  const existe = queryOne<{ id: string }>(
    'SELECT id FROM usuarios WHERE matricula = ? OR correo = ?',
    [testMatricula, testCorreo]
  );
  if (!existe) throw new Error('FALLA: El usuario registrado no se encontró en la BD');
  console.log('[TEST-REG] OK: Detección de cuenta ya registrada validada.');

  // 3. Autocompletado de datos según correo
  console.log('[TEST-REG] 3. Probando autocompletado de datos según correo institucional...');
  const userEncontrado = queryOne<{ matricula: string; rol: string; id: string }>(
    'SELECT id, matricula, rol FROM usuarios WHERE LOWER(correo) = ?',
    [testCorreo.toLowerCase()]
  );

  if (!userEncontrado || userEncontrado.matricula !== testMatricula) {
    throw new Error('FALLA: No se pudo autocompletar la matrícula a partir del correo');
  }

  const estEncontrado = queryOne<{ nombre_completo: string }>(
    'SELECT nombre_completo FROM estudiantes WHERE usuario_id = ?',
    [userEncontrado.id]
  );

  console.log('[TEST-REG] OK: Autocompletado exitoso según correo:', {
    correo: testCorreo,
    matricula: userEncontrado.matricula,
    rol: userEncontrado.rol,
    nombre: estEncontrado?.nombre_completo,
  });

  // 4. Autenticación con contraseña hasheada
  console.log('[TEST-REG] 4. Validando inicio de sesión de la cuenta recién registrada...');
  const userDb = queryOne<{ password_hash: string }>(
    'SELECT password_hash FROM usuarios WHERE matricula = ?',
    [testMatricula]
  );
  if (!userDb || !bcrypt.compareSync(testPassword, userDb.password_hash)) {
    throw new Error('FALLA: No se pudo validar la contraseña con bcrypt de la cuenta registrada');
  }
  console.log('[TEST-REG] OK: Contraseña validada exitosamente con bcrypt.');

  console.log('\n[TEST-REG] ¡TODAS LAS PRUEBAS DE REGISTRO Y AUTOCOMPLETADO PASARON CON ÉXITO!');
}

testRegistrationAndAutocomplete().catch((err) => {
  console.error('[TEST-REG] Error:', err);
  process.exit(1);
});
