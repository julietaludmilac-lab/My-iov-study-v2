import { getDb, queryAll, queryOne } from '../server/db.js';
import { seedDatabase } from '../server/seed.js';

async function verify() {
  console.log('[TEST-E2] Verificando Base de Datos SQLite y Persistencia...');
  await getDb();
  await seedDatabase();

  const tables = queryAll<{ name: string }>(
    "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
  );
  console.log(`[TEST-E2] Tablas creadas (${tables.length}):`, tables.map((t) => t.name).join(', '));

  if (tables.length < 25) {
    throw new Error(`Se esperaban al menos 25 tablas, se encontraron ${tables.length}`);
  }

  const users = queryAll('SELECT id, matricula, correo, rol, estado FROM usuarios');
  console.log('[TEST-E2] Usuarios en semilla:', users);

  const student = queryOne('SELECT s.id, s.nombre_completo, c.nombre as carrera FROM estudiantes s JOIN carreras c ON s.carrera_id = c.id');
  console.log('[TEST-E2] Estudiante verificado:', student);

  const schedules = queryAll('SELECT h.id, m.nombre as materia, h.dia_semana, h.hora_inicio, h.hora_fin, a.nombre as aula, h.estado_aula FROM horarios h JOIN comisiones c ON h.comision_id = c.id JOIN materias m ON c.materia_id = m.id LEFT JOIN aulas a ON h.aula_id = a.id');
  console.log(`[TEST-E2] Horarios asignados (${schedules.length}):`, schedules);

  console.log('[TEST-E2] ¡Todas las verificaciones de M1 Fundaciones pasaron con éxito!');
}

verify().catch((err) => {
  console.error('[TEST-E2] Error en verificación:', err);
  process.exit(1);
});
