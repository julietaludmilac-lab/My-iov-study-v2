import { getDb, queryOne, queryAll, runQuery } from '../server/db.js';
import { seedDatabase } from '../server/seed.js';
import bcrypt from 'bcryptjs';
import crypto from 'node:crypto';

async function testStage8Suite() {
  console.log('[TEST-STAGE-8] Iniciando pruebas de Etapa 8: Mesa de Ayuda Digital, Repositorio Documental y Seguridad...');
  await getDb();
  await seedDatabase();

  // 1. Probar Creación de Ticket de Soporte por Estudiante
  console.log('[TEST-STAGE-8] 1. Creando ticket de soporte oficial...');
  const est = queryOne<{ id: string }>('SELECT id FROM estudiantes WHERE usuario_id = "USR-EST-01"');
  if (!est) throw new Error('Estudiante USR-EST-01 no encontrado');

  const ticketId = `TCK-TEST-${Date.now()}`;
  const numeroTicket = `TICK-2026-${Math.floor(1000 + Math.random() * 9000)}`;

  runQuery(`
    INSERT INTO tickets_soporte (
      id, estudiante_id, numero_ticket, categoria, prioridad, asunto, mensaje, estado
    ) VALUES (?, ?, ?, 'ACADEMICA', 'ALTA', 'Solicitud de Revisión de Examen Final', 'Solicito revisión presencial del examen de POO.', 'ABIERTO')
  `, [ticketId, est.id, numeroTicket]);

  const ticketCreado = queryOne<{ id: string; estado: string; numero_ticket: string }>(
    'SELECT id, estado, numero_ticket FROM tickets_soporte WHERE id = ?',
    [ticketId]
  );
  if (!ticketCreado || ticketCreado.estado !== 'ABIERTO') {
    throw new Error('FALLA: El ticket de soporte no fue creado correctamente');
  }
  console.log(`[TEST-STAGE-8] OK: Ticket ${ticketCreado.numero_ticket} registrado en estado ABIERTO.`);

  // 2. Probar Respuesta y Resolución de Ticket por Bedelía
  console.log('[TEST-STAGE-8] 2. Respondiendo ticket de soporte por Bedelía...');
  runQuery(`
    UPDATE tickets_soporte
    SET respuesta = 'La cátedra fijó la revisión para el lunes 15 a las 10:00 hs en Box 3.',
        respondido_por = 'Dra. María Elena Vázquez (Bedelía)',
        fecha_respuesta = date('now'),
        estado = 'RESPONDIDO'
    WHERE id = ?
  `, [ticketId]);

  const ticketRespondido = queryOne<{ estado: string; respuesta: string }>(
    'SELECT estado, respuesta FROM tickets_soporte WHERE id = ?',
    [ticketId]
  );
  if (!ticketRespondido || ticketRespondido.estado !== 'RESPONDIDO' || !ticketRespondido.respuesta) {
    throw new Error('FALLA: El ticket no se actualizó con la respuesta oficial');
  }
  console.log('[TEST-STAGE-8] OK: Ticket respondido y actualizado a estado RESPONDIDO.');

  // 3. Probar Repositorio Documental Oficial
  console.log('[TEST-STAGE-8] 3. Verificando documentos oficiales en el repositorio...');
  const docs = queryAll<{ id: string; titulo: string; hash_sha256: string }>('SELECT id, titulo, hash_sha256 FROM documentos_repositorio');
  if (!docs || docs.length < 3) {
    throw new Error('FALLA: Repositorio documental con menos de 3 documentos reglamentarios');
  }
  console.log(`[TEST-STAGE-8] OK: ${docs.length} documentos oficiales verificados en repositorio con hash SHA-256.`);

  // 4. Probar Seguridad de Contraseñas (Bcrypt)
  console.log('[TEST-STAGE-8] 4. Probando cambio seguro de clave con bcrypt...');
  const usr = queryOne<{ id: string; password_hash: string }>('SELECT id, password_hash FROM usuarios WHERE id = "USR-EST-01"');
  if (!usr) throw new Error('Usuario USR-EST-01 no encontrado');

  const checkOldPass = bcrypt.compareSync('Estudiante2026A', usr.password_hash);
  if (!checkOldPass) throw new Error('FALLA: La clave original no coincide con bcrypt');

  // Actualizar a nueva clave
  const salt = bcrypt.genSaltSync(10);
  const newPassHash = bcrypt.hashSync('NuevaClaveSegura2026!', salt);
  runQuery('UPDATE usuarios SET password_hash = ? WHERE id = ?', [newPassHash, usr.id]);

  const usrUpdated = queryOne<{ password_hash: string }>('SELECT password_hash FROM usuarios WHERE id = "USR-EST-01"');
  const checkNewPass = bcrypt.compareSync('NuevaClaveSegura2026!', usrUpdated?.password_hash || '');
  if (!checkNewPass) throw new Error('FALLA: La nueva clave no fue hasheada correctamente');

  // Restaurar clave original
  runQuery('UPDATE usuarios SET password_hash = ? WHERE id = ?', [usr.password_hash, usr.id]);
  console.log('[TEST-STAGE-8] OK: Validación de clave actual, hash bcrypt y restauración completada.');

  // 5. Probar Observabilidad y Métricas de Tablas SQLite
  console.log('[TEST-STAGE-8] 5. Verificando métricas de observabilidad...');
  const tables = queryAll<{ name: string }>("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'");
  console.log(`[TEST-STAGE-8] Total de tablas relacionales en SQLite: ${tables.length}`);
  if (tables.length < 37) {
    throw new Error(`FALLA: Se esperaban al menos 37 tablas relacionales, se encontraron ${tables.length}`);
  }
  console.log('[TEST-STAGE-8] OK: Observabilidad técnica validada.');

  // Limpieza
  runQuery('DELETE FROM tickets_soporte WHERE id = ?', [ticketId]);

  console.log('\n[TEST-STAGE-8] ¡TODAS LAS PRUEBAS DE ETAPA 8 PASARON CON ÉXITO!');
}

testStage8Suite().catch((err) => {
  console.error('[TEST-STAGE-8] Error:', err);
  process.exit(1);
});
