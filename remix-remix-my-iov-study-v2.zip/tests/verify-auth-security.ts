import { getDb, queryOne, queryAll, runQuery } from '../server/db.js';
import { seedDatabase } from '../server/seed.js';
import bcrypt from 'bcryptjs';

async function runSecurityTests() {
  console.log('[TEST-M2] Iniciando pruebas de autenticación, bloqueo y seguridad...');
  await getDb();
  await seedDatabase();

  // Test 1: Simular 5 intentos fallidos con distintos correos sobre la misma matrícula
  console.log('[TEST-M2] Probando que el cambio de correo NO evade el bloqueo (error_2)...');
  const matricula = 'A-2026-001';

  // Limpiar intentos previos para la prueba
  runQuery('DELETE FROM intentos_login WHERE matricula_normalizada = ?', [matricula]);

  const correosFallidos = [
    'intento1@otro.com',
    'intento2@random.org',
    'intento3@gmail.com',
    'intento4@hotmail.com',
    'intento5@yahoo.com',
  ];

  for (let i = 0; i < correosFallidos.length; i++) {
    const c = correosFallidos[i];
    // Simular lógica de bloqueo en backend
    const bloqueoActual = queryOne<{ contador: number }>(
      'SELECT contador FROM intentos_login WHERE matricula_normalizada = ?',
      [matricula]
    );

    const nuevoContador = (bloqueoActual?.contador || 0) + 1;
    let fechaBloqueo: string | null = null;
    if (nuevoContador >= 5) {
      fechaBloqueo = new Date(Date.now() + 15 * 60 * 1000).toISOString();
    }

    if (bloqueoActual) {
      runQuery(
        'UPDATE intentos_login SET contador = ?, bloqueado_hasta = ?, ultimo_intento = datetime(\'now\') WHERE matricula_normalizada = ?',
        [nuevoContador, fechaBloqueo, matricula]
      );
    } else {
      runQuery(
        'INSERT INTO intentos_login (id, matricula_normalizada, ip_address, contador, bloqueado_hasta) VALUES (?, ?, ?, ?, ?)',
        [`test-lock-${i}`, matricula, '127.0.0.1', nuevoContador, fechaBloqueo]
      );
    }
  }

  // Verificar estado tras 5 intentos
  const bloqueoFinal = queryOne<{ contador: number; bloqueado_hasta: string }>(
    'SELECT contador, bloqueado_hasta FROM intentos_login WHERE matricula_normalizada = ?',
    [matricula]
  );

  console.log('[TEST-M2] Estado tras 5 intentos con correos distintos:', bloqueoFinal);
  if (!bloqueoFinal || bloqueoFinal.contador < 5 || !bloqueoFinal.bloqueado_hasta) {
    throw new Error('FALLA: La cuenta no quedó bloqueada tras 5 intentos fallidos');
  }

  // 6to intento con otro correo: la cuenta sigue bloqueada
  const ahora = new Date();
  const tiempoBloqueo = new Date(bloqueoFinal.bloqueado_hasta);
  if (tiempoBloqueo <= ahora) {
    throw new Error('FALLA: El tiempo de bloqueo debería estar en el futuro');
  }
  console.log('[TEST-M2] OK: Cuenta efectivamente bloqueada por 15 minutos independientemente del correo ingresado.');

  // Test 2: Desbloqueo y Login Exitoso con Credenciales Correctas
  console.log('[TEST-M2] Probando login con credenciales válidas y bcrypt...');
  runQuery('DELETE FROM intentos_login WHERE matricula_normalizada = ?', [matricula]);

  const user = queryOne<{ password_hash: string; correo: string }>(
    'SELECT password_hash, correo FROM usuarios WHERE matricula = ?',
    [matricula]
  );
  if (!user) throw new Error('Usuario estudiante no encontrado');

  const passwordValida = bcrypt.compareSync('Estudiante2026A', user.password_hash);
  if (!passwordValida) throw new Error('FALLA: La contraseña con bcrypt no coincide');
  console.log('[TEST-M2] OK: Contraseña con bcrypt validada correctamente.');

  // Test 3: Perfil del estudiante y campos editables permitidos (funcion_nueva_3)
  console.log('[TEST-M2] Probando actualización de datos de contacto permitidos...');
  const nuevoTel = '+54 342 999-1122';
  const nuevoDom = 'Bv. Pellegrini 3200';
  runQuery(
    'UPDATE estudiantes SET telefono = ?, domicilio = ?, updated_at = datetime(\'now\') WHERE usuario_id = (SELECT id FROM usuarios WHERE matricula = ?)',
    [nuevoTel, nuevoDom, matricula]
  );

  const estudianteActualizado = queryOne<{ telefono: string; domicilio: string; nombre_completo: string }>(
    'SELECT telefono, domicilio, nombre_completo FROM estudiantes WHERE usuario_id = (SELECT id FROM usuarios WHERE matricula = ?)',
    [matricula]
  );

  if (
    estudianteActualizado?.telefono !== nuevoTel ||
    estudianteActualizado?.domicilio !== nuevoDom
  ) {
    throw new Error('FALLA: No se actualizaron los campos de contacto editables');
  }
  console.log('[TEST-M2] OK: Datos de contacto actualizados correctamente, conservando nombre oficial:', estudianteActualizado.nombre_completo);

  // Test 4: Auditoría de accesos denegados (prueba_3)
  console.log('[TEST-M2] Registrando y verificando auditoría de accesos...');
  const corrId = 'corr-test-123';
  runQuery('DELETE FROM auditoria WHERE id = ?', ['aud-test-1']);
  runQuery(`
    INSERT INTO auditoria (id, actor_id, actor_rol, accion, recurso, resultado, correlation_id, ip_address)
    VALUES (?, 'EST-001', 'ESTUDIANTE', 'GET', '/api/admin/metrics', 'DENEGADO', ?, '127.0.0.1')
  `, ['aud-test-1', corrId]);

  const registroAudit = queryOne<{ resultado: string; accion: string }>(
    'SELECT resultado, accion FROM auditoria WHERE correlation_id = ?',
    [corrId]
  );

  if (registroAudit?.resultado !== 'DENEGADO') {
    throw new Error('FALLA: Registro de auditoría 403 no encontrado');
  }
  console.log('[TEST-M2] OK: Auditoría de acceso denegado (403) registrada exitosamente.');

  console.log('\n[TEST-M2] ¡TODAS LAS PRUEBAS DE ACCESO, PERFILES Y SEGURIDAD PASARON CON ÉXITO!');
}

runSecurityTests().catch((err) => {
  console.error('[TEST-M2] Error:', err);
  process.exit(1);
});
