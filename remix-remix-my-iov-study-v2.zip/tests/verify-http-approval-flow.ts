import express from 'express';
import cookieParser from 'cookie-parser';
import { getDb } from '../server/db.js';
import { seedDatabase } from '../server/seed.js';
import {
  handleLogin,
  requireAuth,
  requireRole,
  requireCsrf,
} from '../server/auth.js';
import {
  saveNoticeDraft,
  previewNotice,
  publishNotice,
  publishDirectNotice,
  deleteNotice,
  getNotices,
} from '../server/notices.js';

async function testHttpFlow() {
  await getDb();
  await seedDatabase();

  const app = express();
  app.use(express.json());
  app.use(cookieParser());

  app.post('/api/auth/login', handleLogin);
  app.get('/api/notices', requireAuth, getNotices);
  app.post('/api/notices/draft', requireAuth, requireRole('BEDELIA'), requireCsrf, saveNoticeDraft);
  app.post('/api/notices/:id/preview', requireAuth, requireRole('BEDELIA'), requireCsrf, previewNotice);
  app.post('/api/notices/:id/publish', requireAuth, requireRole('BEDELIA'), requireCsrf, publishNotice);
  app.post('/api/notices/publish-direct', requireAuth, requireRole('BEDELIA'), requireCsrf, publishDirectNotice);
  app.delete('/api/notices/:id', requireAuth, requireRole('BEDELIA'), requireCsrf, deleteNotice);

  const server = app.listen(3099);

  try {
    console.log('[TEST] 1. Logging in as Bedelia...');
    const loginRes = await fetch('http://localhost:3099/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        matricula: 'B-ADMIN-001',
        correo: 'bedelia.demo@ucsf.test',
        password: 'Bedelia2026A',
        rol: 'BEDELIA',
      }),
    });

    const loginData = await loginRes.json();
    if (!loginRes.ok || !loginData.sessionId) {
      throw new Error(`Login failed: ${JSON.stringify(loginData)}`);
    }
    console.log('[TEST] Login OK! SessionId:', loginData.sessionId);
    const { sessionId, csrfToken } = loginData;

    const authHeaders = {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${sessionId}`,
      'x-session-id': sessionId,
      'x-csrf-token': csrfToken,
    };

    console.log('[TEST] 2. Saving notice draft...');
    const draftRes = await fetch('http://localhost:3099/api/notices/draft', {
      method: 'POST',
      headers: authHeaders,
      body: JSON.stringify({
        titulo: 'Aviso Test Aprobación',
        contenido: 'Contenido de prueba para verificación de aprobación',
        categoria: 'ACADEMICO',
        destinatarios: 'TODOS',
        carreraId: 'CAR-LSI',
        anioCarrera: 2,
        fechaVencimiento: '2026-12-31',
      }),
    });

    const draftData = await draftRes.json();
    if (!draftRes.ok) throw new Error(`Draft failed: ${JSON.stringify(draftData)}`);
    console.log('[TEST] Draft OK! NoticeId:', draftData.noticeId);
    const noticeId = draftData.noticeId;

    console.log('[TEST] 3. Previewing notice (putting in EN_REVISION)...');
    const prevRes = await fetch(`http://localhost:3099/api/notices/${noticeId}/preview`, {
      method: 'POST',
      headers: authHeaders,
    });
    const prevData = await prevRes.json();
    if (!prevRes.ok) throw new Error(`Preview failed: ${JSON.stringify(prevData)}`);
    console.log('[TEST] Preview OK!');

    console.log('[TEST] 4. Confirming and publishing notice (Aprobar función)...');
    const pubRes = await fetch(`http://localhost:3099/api/notices/${noticeId}/publish`, {
      method: 'POST',
      headers: authHeaders,
    });
    const pubData = await pubRes.json();
    if (!pubRes.ok) throw new Error(`Publish failed: ${JSON.stringify(pubData)}`);
    console.log('[TEST] Publish OK! Version:', pubData.version);

    console.log('[TEST] 5. Direct publishing a notice...');
    const dirRes = await fetch('http://localhost:3099/api/notices/publish-direct', {
      method: 'POST',
      headers: authHeaders,
      body: JSON.stringify({
        titulo: 'Aviso Publicación Directa',
        contenido: 'Contenido directo',
        categoria: 'INSTITUCIONAL',
        destinatarios: 'TODOS',
        fechaVencimiento: '2026-11-30',
      }),
    });
    const dirData = await dirRes.json();
    if (!dirRes.ok) throw new Error(`Direct publish failed: ${JSON.stringify(dirData)}`);
    console.log('[TEST] Direct publish OK! NoticeId:', dirData.noticeId);

    console.log('[TEST] 6. Deleting notice...');
    const delRes = await fetch(`http://localhost:3099/api/notices/${dirData.noticeId}`, {
      method: 'DELETE',
      headers: authHeaders,
    });
    const delData = await delRes.json();
    if (!delRes.ok) throw new Error(`Delete failed: ${JSON.stringify(delData)}`);
    console.log('[TEST] Delete OK! Message:', delData.message);

    console.log('[TEST] >>> ALL APPROVAL AND NOTICE FLOWS PASSED WITH 0 ERRORS! <<<');
  } finally {
    server.close();
  }
}

testHttpFlow().catch((err) => {
  console.error('[HTTP TEST FAILED]', err);
  process.exit(1);
});
