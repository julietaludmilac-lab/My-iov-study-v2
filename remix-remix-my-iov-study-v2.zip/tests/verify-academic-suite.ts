import { getDb, queryOne, queryAll, runQuery } from '../server/db.js';
import { seedDatabase } from '../server/seed.js';

async function runAcademicSuiteTests() {
  console.log('[TEST-ACADEMIC] Iniciando pruebas de la Suite Académica, Horarios, Calendario y Trámites...');
  await getDb();
  await seedDatabase();

  // 1. Verificación de Horarios de cursado y detección de aulas modificadas
  console.log('[TEST-ACADEMIC] 1. Verificando horarios y estado de asignación de aulas...');
  const schedules = queryAll<{ id: string; estado_aula: string; aula_nombre: string }>(`
    SELECT h.id, h.estado_aula, a.nombre as aula_nombre
    FROM horarios h
    JOIN comisiones c ON h.comision_id = c.id
    LEFT JOIN aulas a ON h.aula_id = a.id
    WHERE c.codigo_comision IN ('COM-A', 'COM-U')
  `);

  if (schedules.length === 0) {
    throw new Error('FALLA: No se encontraron horarios para las comisiones asignadas');
  }

  const modificadas = schedules.filter((s) => s.estado_aula === 'MODIFICADA');
  if (modificadas.length === 0) {
    throw new Error('FALLA: Debe existir al menos un horario con estado MODIFICADA (ej. Lab 1 por obras)');
  }
  console.log(`[TEST-ACADEMIC] OK: ${schedules.length} horarios verificados (${modificadas.length} reubicaciones transitorias detectadas).`);

  // 2. Verificación de Calendario y creación/borrado de elementos en Agenda
  console.log('[TEST-ACADEMIC] 2. Verificando persistencia y ciclo de vida en agenda_items...');
  const testAgendaId = `AGD-TEST-${Date.now()}`;
  runQuery(`
    INSERT INTO agenda_items (id, estudiante_id, origen, referencia_id, titulo, fecha, hora, nota, color)
    VALUES (?, 'EST-001', 'PERSONAL', NULL, 'Entrega TP Sistemas', '2026-06-01', '14:00', 'Verificar commits', 'VERDE')
  `, [testAgendaId]);

  const insertedAgenda = queryOne<{ id: string; titulo: string }>(
    'SELECT id, titulo FROM agenda_items WHERE id = ?',
    [testAgendaId]
  );
  if (!insertedAgenda || insertedAgenda.titulo !== 'Entrega TP Sistemas') {
    throw new Error('FALLA: No se pudo registrar el item en la agenda personal');
  }

  runQuery('DELETE FROM agenda_items WHERE id = ?', [testAgendaId]);
  const deletedAgenda = queryOne('SELECT id FROM agenda_items WHERE id = ?', [testAgendaId]);
  if (deletedAgenda) {
    throw new Error('FALLA: No se eliminó el item de la agenda personal');
  }
  console.log('[TEST-ACADEMIC] OK: Ciclo de creación y borrado en agenda validado.');

  // 3. Verificación de Plan de Estudio y cálculo de correlatividades
  console.log('[TEST-ACADEMIC] 3. Verificando materias y correlatividades del Plan LSI 2023...');
  const materias = queryAll('SELECT id, codigo, nombre FROM materias WHERE plan_id = "PLAN-LSI-2023"');
  if (materias.length !== 12) {
    throw new Error(`FALLA: Se esperaban 12 materias en el plan, se hallaron ${materias.length}`);
  }

  const correlatividades = queryAll('SELECT id, materia_id, tipo FROM correlatividades');
  if (correlatividades.length === 0) {
    throw new Error('FALLA: No se registraron correlatividades en el plan');
  }
  console.log(`[TEST-ACADEMIC] OK: Plan verificado con ${materias.length} materias y ${correlatividades.length} correlatividades.`);

  // 4. Verificación de Asistencia y cómputo de límite de faltas (25%)
  console.log('[TEST-ACADEMIC] 4. Verificando cómputo reglamentario de inasistencias...');
  const asistenciasPOO = queryAll<{ estado: string }>(
    'SELECT estado FROM asistencia WHERE estudiante_id = "EST-001" AND comision_id = "COM-POO-A"'
  );
  const totalClasesPOO = asistenciasPOO.length;
  const ausentesPOO = asistenciasPOO.filter((a) => a.estado === 'AUSENTE').length;
  const pctInasistencias = (ausentesPOO / totalClasesPOO) * 100;

  console.log(`[TEST-ACADEMIC] Clases registradas POO: ${totalClasesPOO}, Inasistencias: ${ausentesPOO} (${pctInasistencias.toFixed(1)}%).`);
  if (pctInasistencias > 25.0) {
    console.log('[TEST-ACADEMIC] Alerta de límite reglamentario detectada correctamente.');
  }

  // 5. Verificación de Calificaciones y Promedio
  console.log('[TEST-ACADEMIC] 5. Verificando cálculo aritmético de promedio analítico...');
  const notas = queryAll<{ nota: number }>('SELECT nota FROM calificaciones WHERE estudiante_id = "EST-001"');
  const sumaNotas = notas.reduce((acc, curr) => acc + curr.nota, 0);
  const promedio = notas.length > 0 ? sumaNotas / notas.length : 0;

  if (promedio < 7.0 || promedio > 10.0) {
    throw new Error(`FALLA: Promedio fuera de rango coherente: ${promedio}`);
  }
  console.log(`[TEST-ACADEMIC] OK: ${notas.length} notas analíticas con promedio oficial de ${promedio.toFixed(2)}.`);

  // 6. Verificación de Inscripción a Mesas de Examen
  console.log('[TEST-ACADEMIC] 6. Verificando flujo de inscripción a examen final...');
  const examenTestId = 'EXA-LSI-201-1';
  const inscripcionExamenId = `INS-TEST-${Date.now()}`;

  runQuery('DELETE FROM inscripciones WHERE examen_id = ? AND estudiante_id = "EST-001"', [examenTestId]);
  runQuery(`
    INSERT INTO inscripciones (id, estudiante_id, comision_id, examen_id, tipo, fecha_inscripcion, estado)
    VALUES (?, 'EST-001', NULL, ?, 'EXAMEN', datetime('now'), 'CONFIRMADA')
  `, [inscripcionExamenId, examenTestId]);

  const inscripcionConfirmada = queryOne<{ id: string; estado: string }>(
    'SELECT id, estado FROM inscripciones WHERE id = ?',
    [inscripcionExamenId]
  );
  if (inscripcionConfirmada?.estado !== 'CONFIRMADA') {
    throw new Error('FALLA: La inscripción al examen no quedó confirmada');
  }

  runQuery('DELETE FROM inscripciones WHERE id = ?', [inscripcionExamenId]);
  console.log('[TEST-ACADEMIC] OK: Inscripción y desinscripción a mesa de examen completadas.');

  // 7. Verificación de Solicitud de Certificado
  console.log('[TEST-ACADEMIC] 7. Verificando ingreso de solicitud de certificado...');
  const solTestId = `SOL-TEST-${Date.now()}`;
  runQuery(`
    INSERT INTO solicitudes_certificado (id, estudiante_id, tipo_certificado, lugar_presentacion, observacion, estado, responsable_id)
    VALUES (?, 'EST-001', 'ALUMNO_REGULAR', 'Boleto Estudiantil Gratuito', 'Trámite 2026', 'RECIBIDA', 'USR-ADM-01')
  `, [solTestId]);

  const sol = queryOne<{ id: string; estado: string }>(
    'SELECT id, estado FROM solicitudes_certificado WHERE id = ?',
    [solTestId]
  );
  if (!sol || sol.estado !== 'RECIBIDA') {
    throw new Error('FALLA: No se registró la solicitud de certificado');
  }
  runQuery('DELETE FROM solicitudes_certificado WHERE id = ?', [solTestId]);
  console.log('[TEST-ACADEMIC] OK: Solicitud de certificado validada.');

  console.log('\n[TEST-ACADEMIC] ¡TODAS LAS PRUEBAS DE LA SUITE ACADÉMICA Y TRÁMITES PASARON CON ÉXITO!');
}

runAcademicSuiteTests().catch((err) => {
  console.error('[TEST-ACADEMIC] Error en pruebas:', err);
  process.exit(1);
});
