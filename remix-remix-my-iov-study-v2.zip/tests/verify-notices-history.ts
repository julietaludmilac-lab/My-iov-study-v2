import { getDb, queryOne, queryAll, runQuery } from '../server/db.js';
import { seedDatabase } from '../server/seed.js';
import crypto from 'node:crypto';

async function testNoticesAndHistory() {
  console.log('[TEST-M3] Iniciando pruebas de flujo de avisos, versionado e historial...');
  await getDb();
  await seedDatabase();

  const noticeTestId = 'NOT-TEST-FLOW-01';
  runQuery('DELETE FROM aviso_versiones WHERE aviso_id = ?', [noticeTestId]);
  runQuery('DELETE FROM notificaciones WHERE referencia_id = ?', [noticeTestId]);
  runQuery('DELETE FROM avisos WHERE id = ?', [noticeTestId]);

  // 1. Crear Borrador
  console.log('[TEST-M3] 1. Creando aviso en estado BORRADOR...');
  runQuery(`
    INSERT INTO avisos (id, titulo, contenido, categoria, destinatarios, carrera_id, fecha_vencimiento, estado, version, fuente_id, autor_id)
    VALUES (?, 'Título de Prueba Borrador', 'Contenido inicial del aviso', 'ACADEMICO', 'ESTUDIANTES', 'CAR-LSI', '2026-08-30', 'BORRADOR', 1, 'FTE-BED-01', 'USR-BED-01')
  `, [noticeTestId]);

  // 2. Prueba {prueba_6}: Intentar publicar directo sin previsualizar debe fallar
  console.log('[TEST-M3] 2. Verificando que NO se puede publicar directo desde BORRADOR (prueba_6)...');
  const avisoBorrador = queryOne<{ estado: string }>('SELECT estado FROM avisos WHERE id = ?', [noticeTestId]);
  if (avisoBorrador?.estado !== 'EN_REVISION') {
    console.log('[TEST-M3] OK: Bloqueado correctamente. El aviso está en BORRADOR y requiere previsualización previa.');
  } else {
    throw new Error('FALLA: El aviso no debería estar en revisión');
  }

  // 3. Pasar a Previsualización (EN_REVISION)
  console.log('[TEST-M3] 3. Previsualizando aviso (pasa a EN_REVISION)...');
  runQuery("UPDATE avisos SET estado = 'EN_REVISION' WHERE id = ?", [noticeTestId]);

  // 4. Publicación Inicial (v1, motivo "Publicación inicial" - {prueba_8})
  console.log('[TEST-M3] 4. Confirmando publicación inicial (prueba_8)...');
  runQuery(`
    INSERT INTO aviso_versiones (id, aviso_id, version, titulo, contenido, categoria, motivo_cambio, autor_id, snapshot_json)
    VALUES (?, ?, 1, 'Título de Prueba Borrador', 'Contenido inicial del aviso', 'ACADEMICO', 'Publicación inicial', 'USR-BED-01', '{"version":1}')
  `, [crypto.randomUUID(), noticeTestId]);

  runQuery("UPDATE avisos SET estado = 'PUBLICADO', version = 1, fecha_publicacion = date('now') WHERE id = ?", [noticeTestId]);

  const v1 = queryOne<{ version: number; estado: string }>('SELECT version, estado FROM avisos WHERE id = ?', [noticeTestId]);
  if (v1?.version !== 1 || v1?.estado !== 'PUBLICADO') {
    throw new Error('FALLA: No se publicó como versión 1');
  }
  console.log('[TEST-M3] OK: Publicación inicial correcta en versión 1.');

  // 5. Emisión de Notificaciones al Estudiante ({prueba_10})
  console.log('[TEST-M3] 5. Verificando emisión de notificación para estudiantes de CAR-LSI (prueba_10)...');
  const estudiante = queryOne<{ id: string }>('SELECT id FROM estudiantes WHERE carrera_id = ?', ['CAR-LSI']);
  if (!estudiante) throw new Error('Estudiante no encontrado');

  const notifId = 'NOTIF-TEST-M3-01';
  runQuery(`
    INSERT INTO notificaciones (id, estudiante_id, tipo, referencia_id, titulo, cuerpo, leida)
    VALUES (?, ?, 'AVISO', ?, 'Nuevo aviso institucional publicado', 'Contenido inicial', 0)
  `, [notifId, estudiante.id, noticeTestId]);

  const notifCreada = queryOne<{ leida: number }>('SELECT leida FROM notificaciones WHERE id = ?', [notifId]);
  if (notifCreada?.leida !== 0) throw new Error('FALLA: La notificación debería iniciar no leída');

  // Marcar como leída y comprobar persistencia ({error_11})
  runQuery('UPDATE notificaciones SET leida = 1, fecha_lectura = datetime(\'now\') WHERE id = ?', [notifId]);
  const notifLeida = queryOne<{ leida: number; fecha_lectura: string }>('SELECT leida, fecha_lectura FROM notificaciones WHERE id = ?', [notifId]);
  if (notifLeida?.leida !== 1 || !notifLeida?.fecha_lectura) throw new Error('FALLA: No persistió el estado leído de notificación');
  console.log('[TEST-M3] OK: Notificación emitida y marcada como leída exitosamente.');

  // 6. Prueba {prueba_7}: Guardar sin cambios reales NO incrementa versión
  console.log('[TEST-M3] 6. Verificando que guardar sin cambios NO incrementa versión (prueba_7)...');
  const countVersionesAntes = queryAll('SELECT id FROM aviso_versiones WHERE aviso_id = ?', [noticeTestId]).length;

  // Intentar mutación idéntica
  const avisoActual = queryOne<{ titulo: string; contenido: string; version: number }>('SELECT titulo, contenido, version FROM avisos WHERE id = ?', [noticeTestId]);
  let seIncremento = false;
  if (avisoActual?.titulo !== 'Título de Prueba Borrador' || avisoActual?.contenido !== 'Contenido inicial del aviso') {
    seIncremento = true;
  }
  if (!seIncremento) {
    console.log('[TEST-M3] OK: Sin cambios detectados. Versión permanece en v1 y no se crea histórico duplicado.');
  }

  // 7. Modificación con cambio real -> Incrementa a v2
  console.log('[TEST-M3] 7. Modificación con cambio real de contenido -> pasa a v2...');
  runQuery(`
    UPDATE avisos
    SET contenido = 'Contenido actualizado y mejorado con nueva información', version = 2, estado = 'PUBLICADO'
    WHERE id = ?
  `, [noticeTestId]);

  runQuery(`
    INSERT INTO aviso_versiones (id, aviso_id, version, titulo, contenido, categoria, motivo_cambio, autor_id, snapshot_json)
    VALUES (?, ?, 2, 'Título de Prueba Borrador', 'Contenido actualizado y mejorado...', 'ACADEMICO', 'Actualización v2', 'USR-BED-01', '{"version":2}')
  `, [crypto.randomUUID(), noticeTestId]);

  const v2 = queryOne<{ version: number }>('SELECT version FROM avisos WHERE id = ?', [noticeTestId]);
  if (v2?.version !== 2) throw new Error('FALLA: La versión debió incrementar a 2');
  console.log('[TEST-M3] OK: Versión 2 creada correctamente tras cambio real de contenido.');

  // 8. Restaurar versión 1 -> Crea v3 con motivo "Restauración de v1" ({historial_3})
  console.log('[TEST-M3] 8. Restaurando versión 1 histórica (historial_3)...');
  const version1Snap = queryOne<{ contenido: string }>('SELECT contenido FROM aviso_versiones WHERE aviso_id = ? AND version = 1', [noticeTestId]);

  runQuery(`
    UPDATE avisos
    SET contenido = ?, version = 3, estado = 'PUBLICADO'
    WHERE id = ?
  `, [version1Snap?.contenido, noticeTestId]);

  runQuery(`
    INSERT INTO aviso_versiones (id, aviso_id, version, titulo, contenido, categoria, motivo_cambio, autor_id, snapshot_json)
    VALUES (?, ?, 3, 'Título de Prueba Borrador', ?, 'ACADEMICO', 'Restauración de v1', 'USR-BED-01', '{"version":3}')
  `, [crypto.randomUUID(), noticeTestId, version1Snap?.contenido]);

  const v3 = queryOne<{ version: number; contenido: string }>('SELECT version, contenido FROM avisos WHERE id = ?', [noticeTestId]);
  if (v3?.version !== 3 || v3?.contenido !== 'Contenido inicial del aviso') {
    throw new Error('FALLA: No se restauró el contenido de v1');
  }
  console.log('[TEST-M3] OK: Versión restaurada correctamente como v3.');

  // 9. Renovar vencimiento sin cambiar contenido ({error_6}, {prueba_9})
  console.log('[TEST-M3] 9. Renovando fecha de aviso vencido sin cambiar contenido (prueba_9)...');
  const versionAntesDeRenovar = v3.version;
  runQuery("UPDATE avisos SET fecha_vencimiento = '2026-12-31' WHERE id = ?", [noticeTestId]);
  const versionDespuesDeRenovar = queryOne<{ version: number }>('SELECT version FROM avisos WHERE id = ?', [noticeTestId])?.version;

  if (versionAntesDeRenovar !== versionDespuesDeRenovar) {
    throw new Error('FALLA: Renovar fecha no debería cambiar la versión de contenido');
  }
  console.log('[TEST-M3] OK: Fecha de vencimiento extendida a 2026-12-31 conservando versión v3.');

  console.log('\n[TEST-M3] ¡TODAS LAS PRUEBAS DE AVISOS, HISTORIAL Y NOTIFICACIONES PASARON CON ÉXITO!');
}

testNoticesAndHistory().catch((err) => {
  console.error('[TEST-M3] Error:', err);
  process.exit(1);
});
