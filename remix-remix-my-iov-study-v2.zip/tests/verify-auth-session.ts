import { getDb, queryOne, queryAll } from '../server/db.js';
import { seedDatabase } from '../server/seed.js';
import { createSession, getSession, handleLogin } from '../server/auth.js';

async function testSessionFlow() {
  console.log('[TEST] Initializing DB and seed...');
  await getDb();
  await seedDatabase();

  console.log('[TEST] Checking Bedelía user...');
  const bedelia = queryOne<any>('SELECT * FROM usuarios WHERE matricula = ?', ['B-ADMIN-001']);
  if (!bedelia) throw new Error('Bedelía user not found');
  console.log('Bedelia user:', bedelia.matricula, bedelia.rol);

  console.log('[TEST] Creating session for Bedelia...');
  const { sessionId, csrfToken } = createSession({
    id: bedelia.id,
    matricula: bedelia.matricula,
    rol: bedelia.rol,
    nombre: 'Dra. María Elena Vázquez (Bedelía)',
  });

  console.log('Created sessionId:', sessionId);
  console.log('Created csrfToken:', csrfToken);

  console.log('[TEST] Retrieving session from memory...');
  const session1 = getSession(sessionId);
  if (!session1 || session1.userId !== bedelia.id) {
    throw new Error('Failed to retrieve session from memory');
  }
  console.log('Session from memory retrieved successfully:', session1.nombre);

  console.log('[TEST] Checking session in SQLite table...');
  const row = queryOne<any>('SELECT * FROM sesiones WHERE session_id = ?', [sessionId]);
  if (!row) throw new Error('Session not found in SQLite table');
  console.log('Session row in SQLite:', row.matricula, row.rol, 'expires_at:', row.expires_at);

  console.log('[TEST] ALL SESSION CHECKS PASSED.');
}

testSessionFlow().catch((err) => {
  console.error('[TEST FAILED]', err);
  process.exit(1);
});
