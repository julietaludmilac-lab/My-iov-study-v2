import { getDb, queryOne, queryAll, runQuery } from '../server/db.js';
import { seedDatabase } from '../server/seed.js';

async function runStage6Verification() {
  console.log('[TEST-STAGE-6] Iniciando pruebas de Etapa 6: Trámites Especiales, Salud, Medios de Pago y Acciones Bedelía...');
  await getDb();
  await seedDatabase();

  const estudianteId = 'EST-001';

  // 1. Medios de Pago
  console.log('[TEST-STAGE-6] 1. Probando alta y baja de medio de pago...');
  const payId = `PAY-TEST-${Date.now()}`;
  runQuery(`
    INSERT INTO formas_pago (id, estudiante_id, tipo, titular, detalle, cbu_alias, estado)
    VALUES (?, ?, 'TARJETA_CREDITO', 'Lucía Belén Gómez', 'Mastercard Black 9912', 'ALIAS.PAGO.TEST', 'ACTIVO')
  `, [payId, estudianteId]);

  const insertedPay = queryOne<{ id: string; detalle: string }>(
    'SELECT id, detalle FROM formas_pago WHERE id = ?',
    [payId]
  );
  if (!insertedPay || insertedPay.detalle !== 'Mastercard Black 9912') {
    throw new Error('FALLA: No se guardó el medio de pago');
  }

  runQuery('DELETE FROM formas_pago WHERE id = ?', [payId]);
  console.log('[TEST-STAGE-6] OK: Medios de pago validados.');

  // 2. Ficha de Salud
  console.log('[TEST-STAGE-6] 2. Probando actualización de ficha médica...');
  runQuery(`
    INSERT OR REPLACE INTO fichas_salud (id, estudiante_id, grupo_sanguineo, obra_social, numero_afiliado, contacto_emergencia, telefono_emergencia, apto_fisico, observaciones)
    VALUES ('SAL-TEST', ?, 'A+', 'Swiss Medical', '998877-01', 'Papá Gómez', '+54 342 555-1234', 'VIGENTE', 'Sin alergias conocidas')
  `, [estudianteId]);

  const ficha = queryOne<{ grupo_sanguineo: string; obra_social: string }>(
    'SELECT grupo_sanguineo, obra_social FROM fichas_salud WHERE estudiante_id = ?',
    [estudianteId]
  );
  if (ficha?.grupo_sanguineo !== 'A+' || ficha?.obra_social !== 'Swiss Medical') {
    throw new Error('FALLA: Datos de ficha médica no persistidos correctamente');
  }
  console.log('[TEST-STAGE-6] OK: Ficha médica persistida correctamente.');

  // 3. Trámites Especiales (TAV y Título)
  console.log('[TEST-STAGE-6] 3. Probando trámite TAV...');
  const tavId = `TAV-TEST-${Date.now()}`;
  runQuery(`
    INSERT INTO tramites_especiales (id, estudiante_id, tipo, titulo, descripcion, estado)
    VALUES (?, ?, 'TAV', 'Certificado Hackathon Litoral 2026', 'Acreditación 40 horas', 'INICIADO')
  `, [tavId, estudianteId]);

  const tav = queryOne<{ id: string; estado: string }>(
    'SELECT id, estado FROM tramites_especiales WHERE id = ?',
    [tavId]
  );
  if (!tav || tav.estado !== 'INICIADO') {
    throw new Error('FALLA: No se registró el trámite TAV');
  }
  runQuery('DELETE FROM tramites_especiales WHERE id = ?', [tavId]);
  console.log('[TEST-STAGE-6] OK: Trámites especiales TAV validados.');

  // 4. Encuestas Docentes
  console.log('[TEST-STAGE-6] 4. Probando evaluación docente anónima...');
  const encId = `ENC-TEST-${Date.now()}`;
  runQuery(`
    INSERT INTO encuestas_docentes (id, estudiante_id, comision_id, docente_nombre, materia_nombre, puntaje_pedagogico, puntaje_puntualidad, puntaje_material, comentarios, completada)
    VALUES (?, ?, 'COM-POO-A', 'Ing. Roberto Rossi', 'POO', 5, 5, 5, 'Excelente cátedra', 1)
  `, [encId, estudianteId]);

  const enc = queryOne<{ completada: number; puntaje_pedagogico: number }>(
    'SELECT completada, puntaje_pedagogico FROM encuestas_docentes WHERE id = ?',
    [encId]
  );
  if (!enc || enc.completada !== 1 || enc.puntaje_pedagogico !== 5) {
    throw new Error('FALLA: La encuesta docente no registró las calificaciones');
  }
  runQuery('DELETE FROM encuestas_docentes WHERE id = ?', [encId]);
  console.log('[TEST-STAGE-6] OK: Encuestas docentes validadas.');

  // 5. Reubicación de Aula por Bedelía
  console.log('[TEST-STAGE-6] 5. Probando reubicación de aula por Bedelía...');
  const testHorario = queryOne<{ id: string }>('SELECT id FROM horarios LIMIT 1');
  if (testHorario) {
    runQuery(`
      UPDATE horarios
      SET estado_aula = 'MODIFICADA', observaciones = 'Prueba automatizada de reubicación'
      WHERE id = ?
    `, [testHorario.id]);

    const hMod = queryOne<{ estado_aula: string }>(
      'SELECT estado_aula FROM horarios WHERE id = ?',
      [testHorario.id]
    );
    if (hMod?.estado_aula !== 'MODIFICADA') {
      throw new Error('FALLA: La reubicación de aula no cambió el estado');
    }
  }
  console.log('[TEST-STAGE-6] OK: Reubicación administrativa de aulas validada.');

  // 6. Resolución de Certificados
  console.log('[TEST-STAGE-6] 6. Probando resolución de certificados por Bedelía/Administración...');
  const certId = `SOL-TEST-${Date.now()}`;
  runQuery(`
    INSERT INTO solicitudes_certificado (id, estudiante_id, tipo_certificado, lugar_presentacion, estado, responsable_id)
    VALUES (?, ?, 'ALUMNO_REGULAR', 'Banco Central', 'RECIBIDA', 'USR-ADM-01')
  `, [certId, estudianteId]);

  runQuery(`
    UPDATE solicitudes_certificado
    SET estado = 'LISTA', fecha_resolucion = datetime('now')
    WHERE id = ?
  `, [certId]);

  const certResuelto = queryOne<{ estado: string }>(
    'SELECT estado FROM solicitudes_certificado WHERE id = ?',
    [certId]
  );
  if (certResuelto?.estado !== 'LISTA') {
    throw new Error('FALLA: El certificado no se marcó como LISTA');
  }
  runQuery('DELETE FROM solicitudes_certificado WHERE id = ?', [certId]);
  console.log('[TEST-STAGE-6] OK: Firma y resolución de certificados validada.');

  console.log('\n[TEST-STAGE-6] ¡TODAS LAS PRUEBAS DE ETAPA 6 PASARON CON ÉXITO!');
}

runStage6Verification().catch((err) => {
  console.error('[TEST-STAGE-6] Error:', err);
  process.exit(1);
});
