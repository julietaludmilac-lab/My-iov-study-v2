import { getDb, queryOne, queryAll, runQuery } from '../server/db.js';
import { seedDatabase } from '../server/seed.js';

async function testDirectPublishAndDelete() {
  console.log('[TEST-DIRECT-PUB] Iniciando pruebas de publicación directa y borrado de avisos...');
  await getDb();
  await seedDatabase();

  const noticeId = 'NOT-TEST-DIRECT-01';
  runQuery('DELETE FROM aviso_versiones WHERE aviso_id = ?', [noticeId]);
  runQuery('DELETE FROM notificaciones WHERE referencia_id = ?', [noticeId]);
  runQuery('DELETE FROM avisos WHERE id = ?', [noticeId]);

  // 1. Publicación Directa
  console.log('[TEST-DIRECT-PUB] 1. Ejecutando publicación directa de aviso...');
  runQuery(`
    INSERT INTO avisos (id, titulo, contenido, categoria, destinatarios, carrera_id, fecha_vencimiento, estado, version, fecha_publicacion, fuente_id, autor_id)
    VALUES (?, 'Aviso de Publicación Directa', 'Contenido publicado inmediatamente', 'ACADEMICO', 'TODOS', NULL, '2026-09-30', 'PUBLICADO', 1, date('now'), 'FTE-BED-01', 'USR-BED-01')
  `, [noticeId]);

  runQuery(`
    INSERT INTO aviso_versiones (id, aviso_id, version, titulo, contenido, categoria, motivo_cambio, autor_id, snapshot_json)
    VALUES ('VER-DIR-01', ?, 1, 'Aviso de Publicación Directa', 'Contenido publicado...', 'ACADEMICO', 'Publicación directa inicial', 'USR-BED-01', '{"version":1}')
  `, [noticeId]);

  const avisoPublicado = queryOne<{ id: string; estado: string; version: number }>(
    'SELECT id, estado, version FROM avisos WHERE id = ?',
    [noticeId]
  );

  if (avisoPublicado?.estado !== 'PUBLICADO' || avisoPublicado?.version !== 1) {
    throw new Error('FALLA: El aviso no quedó en estado PUBLICADO con versión 1');
  }
  console.log('[TEST-DIRECT-PUB] OK: Aviso publicado directamente en estado PUBLICADO v1.');

  // 2. Borrado de Aviso y Cascada en Base de Datos
  console.log('[TEST-DIRECT-PUB] 2. Ejecutando borrado de aviso...');
  runQuery('DELETE FROM aviso_versiones WHERE aviso_id = ?', [noticeId]);
  runQuery('DELETE FROM notificaciones WHERE referencia_id = ?', [noticeId]);
  runQuery('DELETE FROM avisos WHERE id = ?', [noticeId]);

  const avisoEliminado = queryOne('SELECT id FROM avisos WHERE id = ?', [noticeId]);
  const versionesEliminadas = queryAll('SELECT id FROM aviso_versiones WHERE aviso_id = ?', [noticeId]);

  if (avisoEliminado || versionesEliminadas.length > 0) {
    throw new Error('FALLA: El aviso o sus versiones no fueron eliminadas de la base de datos');
  }
  console.log('[TEST-DIRECT-PUB] OK: Aviso y sus versiones eliminadas completamente de SQLite.');

  console.log('\n[TEST-DIRECT-PUB] ¡TODAS LAS PRUEBAS DE PUBLICACIÓN DIRECTA Y BORRADO PASARON CON ÉXITO!');
}

testDirectPublishAndDelete().catch((err) => {
  console.error('[TEST-DIRECT-PUB] Error:', err);
  process.exit(1);
});
