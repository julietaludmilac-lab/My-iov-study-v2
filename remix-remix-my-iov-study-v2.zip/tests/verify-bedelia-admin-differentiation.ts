import { getDb, queryOne, queryAll, runQuery } from '../server/db.js';
import { seedDatabase } from '../server/seed.js';
import { parseStudyPlanDocument } from '../server/adminCareers.js';

async function testBedeliaAdminDifferentiation() {
  console.log('[TEST-ROLES] Iniciando verificación de diferenciación de roles: Bedelía vs Administración...');
  await getDb();
  await seedDatabase();

  // 1. Administración: Crear Carrera y Plan de Estudio
  console.log('[TEST-ROLES] 1. Administración crea nueva carrera de prueba (TEST-BIO)...');
  const carId = 'CAR-TEST-BIO';
  const planId = 'PLAN-TEST-BIO-2026';

  runQuery('DELETE FROM carreras WHERE id = ? OR codigo = ?', [carId, 'BIO']);
  runQuery('DELETE FROM planes_estudio WHERE id = ? OR codigo_plan = ?', [planId, 'PLAN-BIO-2026']);

  runQuery(`
    INSERT INTO carreras (id, codigo, nombre, sede, estado)
    VALUES (?, 'BIO', 'Licenciatura en Bioinformática', 'Sede Santa Fe - Campus San José', 'ACTIVA')
  `, [carId]);

  runQuery(`
    INSERT INTO planes_estudio (id, carrera_id, codigo_plan, version, anio_validez, resolucion, estado)
    VALUES (?, ?, 'PLAN-BIO-2026', 'v1.0', 2026, 'Res. CS N° 55/2026', 'VIGENTE')
  `, [planId, carId]);

  const carCreada = queryOne<{ id: string; nombre: string }>(
    'SELECT id, nombre FROM carreras WHERE id = ?',
    [carId]
  );
  if (!carCreada) throw new Error('FALLA: La carrera no fue creada en la BD');
  console.log('[TEST-ROLES] OK: Carrera y Plan creados por Administración.');

  // 2. Parsear Documento de Plan de Estudios y Cargar Materias
  console.log('[TEST-ROLES] 2. Administración interpreta documento de plan de estudios con materias por año y correlatividades...');
  const docText = `
# PLAN OFICIAL BIOINFORMÁTICA
Año 1
BIO-101 | Biología Celular y Molecular | 1C | 96 | OBLIGATORIA | -
BIO-102 | Programación en Python y Algoritmos | 1C | 96 | OBLIGATORIA | -
BIO-103 | Genómica Computacional I | 2C | 80 | OBLIGATORIA | BIO-101,BIO-102
BIO-104 | Álgebra y Cálculo Aplicado | 2C | 96 | OBLIGATORIA | -

Año 2
BIO-201 | Bioestadística y Modelado | 1C | 80 | OBLIGATORIA | BIO-104
BIO-202 | Minería de Datos Biológicos | 1C | 96 | OBLIGATORIA | BIO-102
BIO-203 | Simulación Estructural de Proteínas | 2C | 96 | OBLIGATORIA | BIO-103
`;

  const parsed = parseStudyPlanDocument(docText, 'BIO');
  console.log(`[TEST-ROLES] Parser extrajo: ${parsed.materias.length} materias distribuidas en ${parsed.totalAnios} años.`);

  if (parsed.materias.length !== 7 || parsed.totalAnios !== 2) {
    throw new Error(`FALLA: Se esperaban 7 materias en 2 años, detectadas: ${parsed.materias.length}`);
  }

  // Insertar las materias parseadas en la base de datos
  for (const m of parsed.materias) {
    const matId = `MAT-${m.codigo}`;
    runQuery(`
      INSERT OR REPLACE INTO materias (id, plan_id, codigo, nombre, anio_carrera, regimen, carga_horaria, condicion)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `, [matId, planId, m.codigo, m.nombre, m.anio, m.regimen, m.cargaHoraria, m.condicion]);
  }

  const materiasGuardadas = queryAll('SELECT id FROM materias WHERE plan_id = ?', [planId]);
  if (materiasGuardadas.length !== 7) {
    throw new Error('FALLA: No se guardaron todas las materias en la BD');
  }
  console.log('[TEST-ROLES] OK: Materias importadas y persistidas en SQLite para el plan de Bioinformática.');

  // 3. Simular Registro de Estudiante en la nueva carrera
  console.log('[TEST-ROLES] 3. Verificando que nuevo estudiante puede registrarse en la carrera creada...');
  const newUserId = `USR-BIO-TEST-${Date.now()}`;
  const newStudentId = `EST-BIO-TEST-${Date.now()}`;

  runQuery('DELETE FROM estudiantes WHERE usuario_id IN (SELECT id FROM usuarios WHERE correo = ? OR matricula = ?)', ['alumno.bio@ucsf.test', 'BIO-2026-001']);
  runQuery('DELETE FROM usuarios WHERE correo = ? OR matricula = ?', ['alumno.bio@ucsf.test', 'BIO-2026-001']);

  runQuery(`
    INSERT INTO usuarios (id, matricula, correo, password_hash, rol, estado)
    VALUES (?, 'BIO-2026-001', 'alumno.bio@ucsf.test', 'hash123', 'ESTUDIANTE', 'ACTIVO')
  `, [newUserId]);

  runQuery(`
    INSERT INTO estudiantes (id, usuario_id, nombre_completo, carrera_id, plan_id, anio_cursado)
    VALUES (?, ?, 'Mateo Silva (Bioinformática)', ?, ?, 1)
  `, [newStudentId, newUserId, carId, planId]);

  const countBioStudents = queryOne<{ total: number }>(
    'SELECT COUNT(*) as total FROM estudiantes WHERE carrera_id = ?',
    [carId]
  )?.total || 0;

  if (countBioStudents !== 1) {
    throw new Error('FALLA: El estudiante no quedó registrado en la carrera');
  }
  console.log(`[TEST-ROLES] OK: Alumno registrado en carrera BIO. Métrica de alumnos en la carrera: ${countBioStudents}.`);

  // 4. Bedelía: Operación de Cursadas sobre la carrera y materias cargadas
  console.log('[TEST-ROLES] 4. Bedelía crea comisión para "BIO-101", dimensionando cupo según alumnos registrados...');
  const comId = `COM-TEST-BIO101-A`;
  runQuery('DELETE FROM horarios WHERE comision_id = ?', [comId]);
  runQuery('DELETE FROM comisiones WHERE id = ?', [comId]);

  runQuery(`
    INSERT INTO comisiones (id, materia_id, codigo_comision, ciclo_lectivo, cuatrimestre, docente_titular, turno, cupo_maximo, inscripcion_desde, inscripcion_hasta, estado)
    VALUES (?, 'MAT-BIO-101', 'COM-A', 2026, '1C', 'Dra. Florencia Bianchi', 'MANANA', 30, '2026-02-15', '2026-03-20', 'ABIERTA')
  `, [comId]);

  runQuery(`
    INSERT INTO horarios (id, comision_id, dia_semana, hora_inicio, hora_fin, aula_id, estado_aula, observaciones)
    VALUES ('HOR-TEST-BIO-01', ?, 1, '08:00', '11:00', 'LAB-01', 'OFICIAL', 'Laboratorio de Genómica')
  `, [comId]);

  const comisionCreada = queryOne<{ id: string; estado: string; cupo_maximo: number }>(
    'SELECT id, estado, cupo_maximo FROM comisiones WHERE id = ?',
    [comId]
  );
  if (!comisionCreada || comisionCreada.cupo_maximo !== 30) {
    throw new Error('FALLA: Bedelía no pudo crear la comisión');
  }
  console.log('[TEST-ROLES] OK: Comisión creada con aula LAB-01 y cupo de 30.');

  // 5. Bedelía: Cerrar / Abrir Inscripción
  console.log('[TEST-ROLES] 5. Bedelía cierra y luego abre inscripciones de la comisión...');
  runQuery('UPDATE comisiones SET estado = "CERRADA" WHERE id = ?', [comId]);
  let comEstado = queryOne<{ estado: string }>('SELECT estado FROM comisiones WHERE id = ?', [comId])?.estado;
  if (comEstado !== 'CERRADA') throw new Error('FALLA: No se cerró la inscripción');

  runQuery('UPDATE comisiones SET estado = "ABIERTA" WHERE id = ?', [comId]);
  comEstado = queryOne<{ estado: string }>('SELECT estado FROM comisiones WHERE id = ?', [comId])?.estado;
  if (comEstado !== 'ABIERTA') throw new Error('FALLA: No se reabrió la inscripción');
  console.log('[TEST-ROLES] OK: Alternancia de estado de inscripciones (ABIERTA/CERRADA) validada.');

  // 6. Bedelía: Reubicar Aula (estado MODIFICADA)
  console.log('[TEST-ROLES] 6. Bedelía reubica aula temporalmente...');
  runQuery(`
    UPDATE horarios
    SET aula_id = 'AULA-204', estado_aula = 'MODIFICADA', observaciones = 'Reubicado por calibración de microscopios'
    WHERE comision_id = ?
  `, [comId]);

  const horarioModificado = queryOne<{ estado_aula: string; aula_id: string }>(
    'SELECT estado_aula, aula_id FROM horarios WHERE comision_id = ?',
    [comId]
  );
  if (horarioModificado?.estado_aula !== 'MODIFICADA' || horarioModificado?.aula_id !== 'AULA-204') {
    throw new Error('FALLA: No se aplicó la reubicación a MODIFICADA');
  }
  console.log('[TEST-ROLES] OK: Reubicación de aula aplicada con aviso oficial MODIFICADA.');

  // Limpieza de datos de prueba
  runQuery('DELETE FROM horarios WHERE comision_id = ?', [comId]);
  runQuery('DELETE FROM comisiones WHERE id = ?', [comId]);
  runQuery('DELETE FROM estudiantes WHERE id = ?', [newStudentId]);
  runQuery('DELETE FROM usuarios WHERE id = ?', [newUserId]);
  runQuery('DELETE FROM materias WHERE plan_id = ?', [planId]);
  runQuery('DELETE FROM planes_estudio WHERE id = ?', [planId]);
  runQuery('DELETE FROM carreras WHERE id = ?', [carId]);

  console.log('\n[TEST-ROLES] ¡TODAS LAS PRUEBAS DE DIFERENCIACIÓN DE ROLES PASARON CON ÉXITO!');
}

testBedeliaAdminDifferentiation().catch((err) => {
  console.error('[TEST-ROLES] Error:', err);
  process.exit(1);
});
