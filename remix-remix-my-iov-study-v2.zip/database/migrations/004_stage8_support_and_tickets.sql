-- Stage 8: Mesa de Ayuda Digital, Tickets de Soporte, Repositorio Documental y Seguridad Integral

CREATE TABLE IF NOT EXISTS tickets_soporte (
  id TEXT PRIMARY KEY,
  estudiante_id TEXT NOT NULL,
  numero_ticket TEXT NOT NULL UNIQUE,
  categoria TEXT NOT NULL CHECK(categoria IN ('ACADEMICA', 'ARANCELES', 'BEDELIA', 'SOPORTE_TECNICO', 'TITULACION')),
  prioridad TEXT NOT NULL DEFAULT 'MEDIA' CHECK(prioridad IN ('BAJA', 'MEDIA', 'ALTA', 'URGENTE')),
  asunto TEXT NOT NULL,
  mensaje TEXT NOT NULL,
  estado TEXT NOT NULL DEFAULT 'ABIERTO' CHECK(estado IN ('ABIERTO', 'EN_ANALISIS', 'RESPONDIDO', 'CERRADO')),
  respuesta TEXT,
  respondido_por TEXT,
  fecha_respuesta TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (estudiante_id) REFERENCES estudiantes(id)
);

CREATE TABLE IF NOT EXISTS documentos_repositorio (
  id TEXT PRIMARY KEY,
  titulo TEXT NOT NULL,
  categoria TEXT NOT NULL CHECK(categoria IN ('RESOLUCION', 'PROGRAMA_MATERIA', 'REGLAMENTO', 'FORMULARIO')),
  carrera_id TEXT,
  materia_id TEXT,
  archivo_nombre TEXT NOT NULL,
  tamanio_kb INTEGER NOT NULL DEFAULT 180,
  hash_sha256 TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (carrera_id) REFERENCES carreras(id),
  FOREIGN KEY (materia_id) REFERENCES materias(id)
);
