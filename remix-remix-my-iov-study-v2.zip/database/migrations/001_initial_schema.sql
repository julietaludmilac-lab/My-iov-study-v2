-- Database Schema for My IOV Study v2 (SQLite)
-- Version 0.1.0 - Foundation Migration

CREATE TABLE IF NOT EXISTS fuentes (
  id TEXT PRIMARY KEY,
  nombre TEXT NOT NULL,
  tipo TEXT NOT NULL,
  responsable TEXT NOT NULL,
  estado_verificacion TEXT NOT NULL DEFAULT 'OFICIAL',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS usuarios (
  id TEXT PRIMARY KEY,
  matricula TEXT UNIQUE NOT NULL,
  correo TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  rol TEXT NOT NULL CHECK(rol IN ('ESTUDIANTE', 'BEDELIA', 'ADMINISTRACION')),
  estado TEXT NOT NULL DEFAULT 'ACTIVO' CHECK(estado IN ('ACTIVO', 'BLOQUEADO', 'INACTIVO')),
  intentos_fallidos INTEGER NOT NULL DEFAULT 0,
  bloqueado_hasta TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS estudiantes (
  id TEXT PRIMARY KEY,
  usuario_id TEXT UNIQUE NOT NULL,
  nombre_completo TEXT NOT NULL,
  carrera_id TEXT NOT NULL,
  plan_id TEXT NOT NULL,
  anio_cursado INTEGER NOT NULL DEFAULT 1,
  telefono TEXT,
  domicilio TEXT,
  ciudad TEXT,
  correo_personal TEXT,
  condicion_academica TEXT NOT NULL DEFAULT 'REGULAR',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

CREATE TABLE IF NOT EXISTS carreras (
  id TEXT PRIMARY KEY,
  codigo TEXT UNIQUE NOT NULL,
  nombre TEXT NOT NULL,
  sede TEXT NOT NULL DEFAULT 'Santa Fe',
  estado TEXT NOT NULL DEFAULT 'ACTIVA',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS planes_estudio (
  id TEXT PRIMARY KEY,
  carrera_id TEXT NOT NULL,
  codigo_plan TEXT NOT NULL,
  version TEXT NOT NULL,
  anio_validez INTEGER NOT NULL,
  resolucion TEXT,
  estado TEXT NOT NULL DEFAULT 'VIGENTE',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (carrera_id) REFERENCES carreras(id)
);

CREATE TABLE IF NOT EXISTS materias (
  id TEXT PRIMARY KEY,
  plan_id TEXT NOT NULL,
  codigo TEXT NOT NULL,
  nombre TEXT NOT NULL,
  anio_carrera INTEGER NOT NULL,
  regimen TEXT NOT NULL CHECK(regimen IN ('1C', '2C', 'ANUAL')),
  carga_horaria INTEGER NOT NULL,
  condicion TEXT NOT NULL DEFAULT 'OBLIGATORIA',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (plan_id) REFERENCES planes_estudio(id)
);

CREATE TABLE IF NOT EXISTS correlatividades (
  id TEXT PRIMARY KEY,
  materia_id TEXT NOT NULL,
  materia_requisito_id TEXT NOT NULL,
  tipo TEXT NOT NULL CHECK(tipo IN ('PARA_CURSAR_REGULAR', 'PARA_CURSAR_APROBADA', 'PARA_RENDIR_APROBADA')),
  fuente_id TEXT,
  resolucion TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (materia_id) REFERENCES materias(id),
  FOREIGN KEY (materia_requisito_id) REFERENCES materias(id),
  FOREIGN KEY (fuente_id) REFERENCES fuentes(id)
);

CREATE TABLE IF NOT EXISTS equivalencias (
  id TEXT PRIMARY KEY,
  materia_id TEXT NOT NULL,
  materia_origen TEXT NOT NULL,
  institucion_origen TEXT NOT NULL,
  resolucion TEXT NOT NULL,
  porcentaje_reconocido INTEGER NOT NULL DEFAULT 100,
  fuente_id TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (materia_id) REFERENCES materias(id),
  FOREIGN KEY (fuente_id) REFERENCES fuentes(id)
);

CREATE TABLE IF NOT EXISTS aulas (
  id TEXT PRIMARY KEY,
  nombre TEXT NOT NULL,
  edificio TEXT NOT NULL,
  piso TEXT NOT NULL,
  capacidad INTEGER NOT NULL DEFAULT 40,
  tipo TEXT NOT NULL DEFAULT 'AULA_COMUN',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS comisiones (
  id TEXT PRIMARY KEY,
  materia_id TEXT NOT NULL,
  codigo_comision TEXT NOT NULL,
  ciclo_lectivo INTEGER NOT NULL DEFAULT 2026,
  cuatrimestre TEXT NOT NULL DEFAULT '1C',
  docente_titular TEXT NOT NULL,
  turno TEXT NOT NULL CHECK(turno IN ('MANANA', 'TARDE', 'NOCHE')),
  cupo_maximo INTEGER NOT NULL DEFAULT 40,
  inscripcion_desde TEXT NOT NULL,
  inscripcion_hasta TEXT NOT NULL,
  estado TEXT NOT NULL DEFAULT 'ABIERTA',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (materia_id) REFERENCES materias(id)
);

CREATE TABLE IF NOT EXISTS horarios (
  id TEXT PRIMARY KEY,
  comision_id TEXT NOT NULL,
  dia_semana INTEGER NOT NULL CHECK(dia_semana BETWEEN 1 AND 6), -- 1 Lunes, 6 Sabado
  hora_inicio TEXT NOT NULL,
  hora_fin TEXT NOT NULL,
  aula_id TEXT,
  estado_aula TEXT NOT NULL DEFAULT 'OFICIAL' CHECK(estado_aula IN ('OFICIAL', 'MODIFICADA', 'SIN_INFORMAR')),
  observaciones TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (comision_id) REFERENCES comisiones(id),
  FOREIGN KEY (aula_id) REFERENCES aulas(id)
);

CREATE TABLE IF NOT EXISTS inscripciones (
  id TEXT PRIMARY KEY,
  estudiante_id TEXT NOT NULL,
  comision_id TEXT,
  examen_id TEXT,
  tipo TEXT NOT NULL CHECK(tipo IN ('COMISION', 'EXAMEN')),
  fecha_inscripcion TEXT NOT NULL DEFAULT (datetime('now')),
  estado TEXT NOT NULL DEFAULT 'CONFIRMADA' CHECK(estado IN ('CONFIRMADA', 'PENDIENTE', 'DADA_DE_BAJA')),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (estudiante_id) REFERENCES estudiantes(id)
);

CREATE TABLE IF NOT EXISTS reglas_asistencia (
  id TEXT PRIMARY KEY,
  materia_id TEXT NOT NULL,
  porcentaje_maximo_inasistencias REAL NOT NULL DEFAULT 25.0,
  limite_faltas_directo INTEGER,
  fuente_id TEXT,
  resolucion TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (materia_id) REFERENCES materias(id),
  FOREIGN KEY (fuente_id) REFERENCES fuentes(id)
);

CREATE TABLE IF NOT EXISTS asistencia (
  id TEXT PRIMARY KEY,
  estudiante_id TEXT NOT NULL,
  comision_id TEXT NOT NULL,
  fecha TEXT NOT NULL,
  estado TEXT NOT NULL CHECK(estado IN ('PRESENTE', 'AUSENTE', 'JUSTIFICADA')),
  observacion TEXT,
  cargado_por TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (estudiante_id) REFERENCES estudiantes(id),
  FOREIGN KEY (comision_id) REFERENCES comisiones(id)
);

CREATE TABLE IF NOT EXISTS evaluaciones (
  id TEXT PRIMARY KEY,
  comision_id TEXT NOT NULL,
  tipo TEXT NOT NULL CHECK(tipo IN ('PARCIAL_1', 'PARCIAL_2', 'RECUPERATORIO', 'TRABAJO_PRACTICO')),
  titulo TEXT NOT NULL,
  fecha TEXT NOT NULL,
  hora TEXT NOT NULL,
  aula_id TEXT,
  estado TEXT NOT NULL DEFAULT 'BORRADOR' CHECK(estado IN ('BORRADOR', 'PUBLICADO')),
  fuente_id TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (comision_id) REFERENCES comisiones(id),
  FOREIGN KEY (aula_id) REFERENCES aulas(id),
  FOREIGN KEY (fuente_id) REFERENCES fuentes(id)
);

CREATE TABLE IF NOT EXISTS contenidos_evaluacion (
  id TEXT PRIMARY KEY,
  evaluacion_id TEXT NOT NULL,
  tema TEXT NOT NULL,
  bibliografia TEXT,
  orden INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (evaluacion_id) REFERENCES evaluaciones(id)
);

CREATE TABLE IF NOT EXISTS calificaciones (
  id TEXT PRIMARY KEY,
  estudiante_id TEXT NOT NULL,
  evaluacion_id TEXT,
  materia_id TEXT NOT NULL,
  tipo_instancia TEXT NOT NULL CHECK(tipo_instancia IN ('PARCIAL', 'RECUPERATORIO', 'FINAL', 'EQUIVALENCIA')),
  nota REAL,
  condicion TEXT NOT NULL DEFAULT 'APROBADO',
  fecha TEXT NOT NULL,
  tomo TEXT,
  folio TEXT,
  acta TEXT,
  cargado_por TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (estudiante_id) REFERENCES estudiantes(id),
  FOREIGN KEY (materia_id) REFERENCES materias(id)
);

CREATE TABLE IF NOT EXISTS examenes (
  id TEXT PRIMARY KEY,
  materia_id TEXT NOT NULL,
  fecha TEXT NOT NULL,
  hora TEXT NOT NULL,
  turno_examen TEXT NOT NULL,
  llamado INTEGER NOT NULL DEFAULT 1,
  aula_id TEXT,
  tribunal TEXT NOT NULL,
  periodo_inscripcion_desde TEXT NOT NULL,
  periodo_inscripcion_hasta TEXT NOT NULL,
  estado TEXT NOT NULL DEFAULT 'ABIERTO',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (materia_id) REFERENCES materias(id),
  FOREIGN KEY (aula_id) REFERENCES aulas(id)
);

CREATE TABLE IF NOT EXISTS eventos_calendario (
  id TEXT PRIMARY KEY,
  titulo TEXT NOT NULL,
  descripcion TEXT,
  tipo TEXT NOT NULL CHECK(tipo IN ('FERIADO', 'PARCIAL', 'FINAL', 'INSCRIPCION', 'ACADEMICO', 'ASUETO')),
  fecha_inicio TEXT NOT NULL,
  fecha_fin TEXT NOT NULL,
  carrera_id TEXT,
  fuente_id TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (carrera_id) REFERENCES carreras(id),
  FOREIGN KEY (fuente_id) REFERENCES fuentes(id)
);

CREATE TABLE IF NOT EXISTS avisos (
  id TEXT PRIMARY KEY,
  titulo TEXT NOT NULL,
  contenido TEXT NOT NULL,
  categoria TEXT NOT NULL CHECK(categoria IN ('ACADEMICO', 'ADMINISTRATIVO', 'INSTITUCIONAL', 'URGENTE')),
  destinatarios TEXT NOT NULL DEFAULT 'TODOS',
  carrera_id TEXT,
  anio_carrera INTEGER,
  materia_id TEXT,
  comision_id TEXT,
  fecha_publicacion TEXT,
  fecha_vencimiento TEXT NOT NULL,
  estado TEXT NOT NULL DEFAULT 'BORRADOR' CHECK(estado IN ('BORRADOR', 'EN_REVISION', 'PUBLICADO', 'VENCIDO', 'RETIRADO')),
  version INTEGER NOT NULL DEFAULT 1,
  fuente_id TEXT,
  documento_adjunto_nombre TEXT,
  documento_adjunto_url TEXT,
  autor_id TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (carrera_id) REFERENCES carreras(id),
  FOREIGN KEY (materia_id) REFERENCES materias(id),
  FOREIGN KEY (fuente_id) REFERENCES fuentes(id),
  FOREIGN KEY (autor_id) REFERENCES usuarios(id)
);

CREATE TABLE IF NOT EXISTS aviso_versiones (
  id TEXT PRIMARY KEY,
  aviso_id TEXT NOT NULL,
  version INTEGER NOT NULL,
  titulo TEXT NOT NULL,
  contenido TEXT NOT NULL,
  categoria TEXT NOT NULL,
  motivo_cambio TEXT NOT NULL,
  autor_id TEXT NOT NULL,
  snapshot_json TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (aviso_id) REFERENCES avisos(id),
  FOREIGN KEY (autor_id) REFERENCES usuarios(id)
);

CREATE TABLE IF NOT EXISTS notificaciones (
  id TEXT PRIMARY KEY,
  estudiante_id TEXT NOT NULL,
  tipo TEXT NOT NULL CHECK(tipo IN ('AVISO', 'PARCIAL', 'HORARIO', 'CUOTA', 'SOLICITUD', 'SISTEMA')),
  referencia_id TEXT,
  titulo TEXT NOT NULL,
  cuerpo TEXT NOT NULL,
  leida INTEGER NOT NULL DEFAULT 0,
  fecha_lectura TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (estudiante_id) REFERENCES estudiantes(id)
);

CREATE TABLE IF NOT EXISTS documentos (
  id TEXT PRIMARY KEY,
  aviso_id TEXT,
  materia_id TEXT,
  nombre TEXT NOT NULL,
  categoria TEXT NOT NULL CHECK(categoria IN ('PROGRAMA', 'GUIA', 'REGLAMENTO', 'FORMULARIO', 'ADJUNTO_AVISO')),
  mime_type TEXT NOT NULL DEFAULT 'application/pdf',
  tamano_bytes INTEGER NOT NULL,
  contenido_sintetico TEXT NOT NULL,
  fuente_id TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (aviso_id) REFERENCES avisos(id),
  FOREIGN KEY (materia_id) REFERENCES materias(id)
);

CREATE TABLE IF NOT EXISTS cuotas (
  id TEXT PRIMARY KEY,
  estudiante_id TEXT NOT NULL,
  periodo TEXT NOT NULL, -- ej. '2026-03'
  concepto TEXT NOT NULL,
  monto REAL NOT NULL,
  fecha_vencimiento TEXT NOT NULL,
  estado TEXT NOT NULL CHECK(estado IN ('PENDIENTE', 'PAGADA', 'VENCIDA')),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (estudiante_id) REFERENCES estudiantes(id)
);

CREATE TABLE IF NOT EXISTS comprobantes (
  id TEXT PRIMARY KEY,
  cuota_id TEXT UNIQUE NOT NULL,
  numero_comprobante TEXT UNIQUE NOT NULL,
  fecha_pago TEXT NOT NULL,
  medio_pago TEXT NOT NULL,
  monto_abonado REAL NOT NULL,
  archivo_nombre TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (cuota_id) REFERENCES cuotas(id)
);

CREATE TABLE IF NOT EXISTS solicitudes_certificado (
  id TEXT PRIMARY KEY,
  estudiante_id TEXT NOT NULL,
  tipo_certificado TEXT NOT NULL CHECK(tipo_certificado IN ('ALUMNO_REGULAR', 'ANALITICO_PARCIAL', 'EXAMEN_RENDIDO', 'CONSTANCIA_MATRICULA')),
  lugar_presentacion TEXT NOT NULL,
  observacion TEXT,
  estado TEXT NOT NULL DEFAULT 'RECIBIDA' CHECK(estado IN ('RECIBIDA', 'EN_PROCESO', 'LISTA', 'RECHAZADA')),
  motivo_rechazo TEXT,
  responsable_id TEXT,
  fecha_resolucion TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (estudiante_id) REFERENCES estudiantes(id),
  FOREIGN KEY (responsable_id) REFERENCES usuarios(id)
);

CREATE TABLE IF NOT EXISTS agenda_items (
  id TEXT PRIMARY KEY,
  estudiante_id TEXT NOT NULL,
  origen TEXT NOT NULL CHECK(origen IN ('HORARIO', 'PARCIAL', 'EVENTO', 'PERSONAL')),
  referencia_id TEXT,
  titulo TEXT NOT NULL,
  fecha TEXT NOT NULL,
  hora TEXT,
  nota TEXT,
  color TEXT DEFAULT 'AZUL',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (estudiante_id) REFERENCES estudiantes(id)
);

CREATE TABLE IF NOT EXISTS auditoria (
  id TEXT PRIMARY KEY,
  actor_id TEXT,
  actor_rol TEXT,
  accion TEXT NOT NULL,
  recurso TEXT NOT NULL,
  recurso_id TEXT,
  resultado TEXT NOT NULL CHECK(resultado IN ('EXITO', 'DENEGADO', 'FALLO')),
  detalles_json TEXT,
  correlation_id TEXT NOT NULL,
  ip_address TEXT,
  user_agent TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS intentos_login (
  id TEXT PRIMARY KEY,
  matricula_normalizada TEXT NOT NULL,
  ip_address TEXT NOT NULL,
  contador INTEGER NOT NULL DEFAULT 1,
  bloqueado_hasta TEXT,
  ultimo_intento TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS sesiones (
  session_id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  matricula TEXT NOT NULL,
  rol TEXT NOT NULL,
  nombre TEXT NOT NULL,
  csrf_token TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL
);
