-- Stage 6: Procedimientos Especiales, Salud, Medios de Pago y Trámites

CREATE TABLE IF NOT EXISTS formas_pago (
  id TEXT PRIMARY KEY,
  estudiante_id TEXT NOT NULL,
  tipo TEXT NOT NULL CHECK(tipo IN ('DEBITO_AUTOMATICO', 'TARJETA_CREDITO', 'TRANSFERENCIA_CBU')),
  titular TEXT NOT NULL,
  detalle TEXT NOT NULL,
  cbu_alias TEXT,
  estado TEXT NOT NULL DEFAULT 'ACTIVO' CHECK(estado IN ('ACTIVO', 'INACTIVO')),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (estudiante_id) REFERENCES estudiantes(id)
);

CREATE TABLE IF NOT EXISTS fichas_salud (
  id TEXT PRIMARY KEY,
  estudiante_id TEXT UNIQUE NOT NULL,
  grupo_sanguineo TEXT NOT NULL,
  obra_social TEXT NOT NULL,
  numero_afiliado TEXT NOT NULL,
  contacto_emergencia TEXT NOT NULL,
  telefono_emergencia TEXT NOT NULL,
  apto_fisico TEXT NOT NULL DEFAULT 'VIGENTE' CHECK(apto_fisico IN ('VIGENTE', 'VENCIDO', 'PENDIENTE')),
  observaciones TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (estudiante_id) REFERENCES estudiantes(id)
);

CREATE TABLE IF NOT EXISTS tramites_especiales (
  id TEXT PRIMARY KEY,
  estudiante_id TEXT NOT NULL,
  tipo TEXT NOT NULL CHECK(tipo IN ('TAV', 'TITULO', 'EQUIVALENCIA_EXTERNA')),
  titulo TEXT NOT NULL,
  descripcion TEXT,
  documentacion_adjunta TEXT,
  estado TEXT NOT NULL DEFAULT 'INICIADO' CHECK(estado IN ('INICIADO', 'EN_REVISION', 'DICTAMEN_FAVORABLE', 'FINALIZADO', 'OBSERVADO')),
  resolucion_numero TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (estudiante_id) REFERENCES estudiantes(id)
);

CREATE TABLE IF NOT EXISTS encuestas_docentes (
  id TEXT PRIMARY KEY,
  estudiante_id TEXT NOT NULL,
  comision_id TEXT NOT NULL,
  docente_nombre TEXT NOT NULL,
  materia_nombre TEXT NOT NULL,
  puntaje_pedagogico INTEGER NOT NULL DEFAULT 5 CHECK(puntaje_pedagogico BETWEEN 1 AND 5),
  puntaje_puntualidad INTEGER NOT NULL DEFAULT 5 CHECK(puntaje_puntualidad BETWEEN 1 AND 5),
  puntaje_material INTEGER NOT NULL DEFAULT 5 CHECK(puntaje_material BETWEEN 1 AND 5),
  comentarios TEXT,
  completada INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (estudiante_id) REFERENCES estudiantes(id),
  FOREIGN KEY (comision_id) REFERENCES comisiones(id)
);
