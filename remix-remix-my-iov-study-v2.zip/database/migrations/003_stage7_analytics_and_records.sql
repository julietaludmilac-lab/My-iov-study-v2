-- Stage 7: Reportes Analíticos, Actas Oficiales (Libro/Folio), Verificación Digital y Preferencias

CREATE TABLE IF NOT EXISTS actas_oficiales (
  id TEXT PRIMARY KEY,
  tipo TEXT NOT NULL CHECK(tipo IN ('EXAMEN_FINAL', 'REGULARIDAD_CURSADA')),
  materia_id TEXT NOT NULL,
  comision_id TEXT,
  examen_id TEXT,
  numero_acta TEXT NOT NULL UNIQUE,
  libro TEXT NOT NULL,
  folio TEXT NOT NULL,
  ciclo_lectivo INTEGER NOT NULL,
  fecha_cierre TEXT NOT NULL,
  presidente_tribunal TEXT NOT NULL,
  vocal_1 TEXT,
  vocal_2 TEXT,
  total_inscriptos INTEGER NOT NULL DEFAULT 0,
  total_aprobados INTEGER NOT NULL DEFAULT 0,
  total_desaprobados INTEGER NOT NULL DEFAULT 0,
  total_ausentes INTEGER NOT NULL DEFAULT 0,
  hash_verificacion TEXT NOT NULL,
  estado TEXT NOT NULL DEFAULT 'GENERADA' CHECK(estado IN ('GENERADA', 'FIRMADA', 'CERRADA')),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (materia_id) REFERENCES materias(id)
);

CREATE TABLE IF NOT EXISTS verificaciones_documentos (
  id TEXT PRIMARY KEY,
  codigo_seguridad TEXT NOT NULL UNIQUE,
  tipo_documento TEXT NOT NULL CHECK(tipo_documento IN ('CERTIFICADO_REGULAR', 'CERTIFICADO_ANALITICO', 'ACTA_EXAMEN', 'TRAMITE_TAV')),
  referencia_id TEXT NOT NULL,
  estudiante_id TEXT,
  hash_sha256 TEXT NOT NULL,
  emisor_rol TEXT NOT NULL,
  emisor_nombre TEXT NOT NULL,
  fecha_emision TEXT NOT NULL,
  valido_hasta TEXT,
  estado TEXT NOT NULL DEFAULT 'VALIDO' CHECK(estado IN ('VALIDO', 'REVOCADO', 'EXPIRADO')),
  detalles_json TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (estudiante_id) REFERENCES estudiantes(id)
);

CREATE TABLE IF NOT EXISTS preferencias_usuario (
  id TEXT PRIMARY KEY,
  usuario_id TEXT UNIQUE NOT NULL,
  notif_email_avisos INTEGER NOT NULL DEFAULT 1,
  notif_email_cuotas INTEGER NOT NULL DEFAULT 1,
  notif_email_cambio_aula INTEGER NOT NULL DEFAULT 1,
  notif_email_calificaciones INTEGER NOT NULL DEFAULT 1,
  tema_visual TEXT NOT NULL DEFAULT 'SISTEMA' CHECK(tema_visual IN ('CLARO', 'OSCURO', 'SISTEMA')),
  resumen_semanal INTEGER NOT NULL DEFAULT 1,
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);
