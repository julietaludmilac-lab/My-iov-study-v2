import { Request, Response } from 'express';
import { queryAll, queryOne, runQuery } from './db.js';

// Helper para obtener estudiante_id del usuario en sesión
function getEstudianteId(usuarioId: string): string | null {
  const row = queryOne<{ id: string }>('SELECT id FROM estudiantes WHERE usuario_id = ?', [usuarioId]);
  return row?.id || null;
}

/**
 * Horarios y Aulas de Cursado
 */
export async function getSchedule(req: Request, res: Response): Promise<void> {
  const session = (req as any).session;
  const estudianteId = getEstudianteId(session.userId);

  // Si es estudiante, traer horarios de sus comisiones inscriptas
  let query = `
    SELECT 
      h.id,
      h.comision_id,
      m.codigo as materia_codigo,
      m.nombre as materia_nombre,
      m.anio_carrera,
      c.codigo_comision,
      c.docente_titular,
      c.turno,
      h.dia_semana,
      h.hora_inicio,
      h.hora_fin,
      a.id as aula_id,
      a.nombre as aula_nombre,
      a.edificio as aula_edificio,
      a.piso as aula_piso,
      a.tipo as aula_tipo,
      h.estado_aula,
      h.observaciones
    FROM horarios h
    JOIN comisiones c ON h.comision_id = c.id
    JOIN materias m ON c.materia_id = m.id
    LEFT JOIN aulas a ON h.aula_id = a.id
  `;

  const params: any[] = [];
  if (session.rol === 'ESTUDIANTE' && estudianteId) {
    query += `
      JOIN inscripciones i ON i.comision_id = c.id AND i.estudiante_id = ? AND i.tipo = 'COMISION' AND i.estado = 'CONFIRMADA'
    `;
    params.push(estudianteId);
  }

  query += ' ORDER BY h.dia_semana ASC, h.hora_inicio ASC';

  const schedules = queryAll(query, params);
  res.json({ ok: true, schedules });
}

/**
 * Eventos del Calendario Institucional y de Carrera
 */
export async function getCalendarEvents(req: Request, res: Response): Promise<void> {
  const events = queryAll(`
    SELECT 
      e.id,
      e.titulo,
      e.descripcion,
      e.tipo,
      e.fecha_inicio,
      e.fecha_fin,
      e.carrera_id,
      c.nombre as carrera_nombre,
      f.nombre as fuente_nombre
    FROM eventos_calendario e
    LEFT JOIN carreras c ON e.carrera_id = c.id
    LEFT JOIN fuentes f ON e.fuente_id = f.id
    ORDER BY e.fecha_inicio ASC
  `);

  res.json({ ok: true, events });
}

/**
 * Items de Agenda Personal del Estudiante
 */
export async function getAgendaItems(req: Request, res: Response): Promise<void> {
  const session = (req as any).session;
  const estudianteId = getEstudianteId(session.userId) || 'EST-001';

  const items = queryAll(`
    SELECT id, origen, referencia_id, titulo, fecha, hora, nota, color, created_at
    FROM agenda_items
    WHERE estudiante_id = ?
    ORDER BY fecha ASC, hora ASC
  `, [estudianteId]);

  res.json({ ok: true, items });
}

export async function createAgendaItem(req: Request, res: Response): Promise<void> {
  const session = (req as any).session;
  const estudianteId = getEstudianteId(session.userId) || 'EST-001';
  const { titulo, fecha, hora, nota, color, origen, referenciaId } = req.body;

  if (!titulo || !fecha) {
    res.status(400).json({ ok: false, message: 'Título y fecha son requeridos' });
    return;
  }

  const id = `AGD-${Date.now().toString(36).toUpperCase()}`;
  runQuery(`
    INSERT INTO agenda_items (id, estudiante_id, origen, referencia_id, titulo, fecha, hora, nota, color)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `, [
    id,
    estudianteId,
    origen || 'PERSONAL',
    referenciaId || null,
    titulo,
    fecha,
    hora || '08:00',
    nota || '',
    color || 'AZUL',
  ]);

  res.json({ ok: true, id, message: 'Elemento agregado a tu agenda con éxito' });
}

export async function deleteAgendaItem(req: Request, res: Response): Promise<void> {
  const session = (req as any).session;
  const estudianteId = getEstudianteId(session.userId) || 'EST-001';
  const { id } = req.params;

  runQuery('DELETE FROM agenda_items WHERE id = ? AND estudiante_id = ?', [id, estudianteId]);
  res.json({ ok: true, message: 'Elemento eliminado de la agenda' });
}

/**
 * Plan de Estudio, Materias, Correlatividades y Equivalencias
 */
export async function getStudyPlan(req: Request, res: Response): Promise<void> {
  const session = (req as any).session;
  const estudianteId = getEstudianteId(session.userId) || 'EST-001';

  // Información del estudiante y su plan
  const estudiante = queryOne<{
    id: string;
    nombre_completo: string;
    anio_cursado: number;
    condicion_academica: string;
    carrera_nombre: string;
    carrera_sede: string;
    plan_codigo: string;
    plan_version: string;
    plan_resolucion: string;
  }>(`
    SELECT 
      e.id,
      e.nombre_completo,
      e.anio_cursado,
      e.condicion_academica,
      c.nombre as carrera_nombre,
      c.sede as carrera_sede,
      p.codigo_plan as plan_codigo,
      p.version as plan_version,
      p.resolucion as plan_resolucion
    FROM estudiantes e
    JOIN carreras c ON e.carrera_id = c.id
    JOIN planes_estudio p ON e.plan_id = p.id
    WHERE e.id = ?
  `, [estudianteId]);

  // Todas las materias del plan
  const materias = queryAll<{
    id: string;
    codigo: string;
    nombre: string;
    anio_carrera: number;
    regimen: string;
    carga_horaria: number;
    condicion: string;
  }>(`
    SELECT id, codigo, nombre, anio_carrera, regimen, carga_horaria, condicion
    FROM materias
    WHERE plan_id = 'PLAN-LSI-2023'
    ORDER BY anio_carrera ASC, codigo ASC
  `);

  // Calificaciones históricas del estudiante
  const calificaciones = queryAll<{
    materia_id: string;
    tipo_instancia: string;
    nota: number;
    condicion: string;
    fecha: string;
    acta: string;
    tomo: string;
    folio: string;
  }>(`
    SELECT materia_id, tipo_instancia, nota, condicion, fecha, acta, tomo, folio
    FROM calificaciones
    WHERE estudiante_id = ?
  `, [estudianteId]);

  // Inscripciones activas a comisiones
  const inscripcionesActivas = queryAll<{ materia_id: string; codigo_comision: string }>(`
    SELECT c.materia_id, c.codigo_comision
    FROM inscripciones i
    JOIN comisiones c ON i.comision_id = c.id
    WHERE i.estudiante_id = ? AND i.tipo = 'COMISION' AND i.estado = 'CONFIRMADA'
  `, [estudianteId]);

  // Correlatividades oficiales
  const correlatividades = queryAll<{
    id: string;
    materia_id: string;
    materia_requisito_id: string;
    materia_requisito_nombre: string;
    materia_requisito_codigo: string;
    tipo: string;
    resolucion: string;
  }>(`
    SELECT 
      corr.id,
      corr.materia_id,
      corr.materia_requisito_id,
      mr.nombre as materia_requisito_nombre,
      mr.codigo as materia_requisito_codigo,
      corr.tipo,
      corr.resolucion
    FROM correlatividades corr
    JOIN materias mr ON corr.materia_requisito_id = mr.id
  `);

  // Equivalencias
  const equivalencias = queryAll<{
    id: string;
    materia_id: string;
    materia_nombre: string;
    materia_origen: string;
    institucion_origen: string;
    resolucion: string;
    porcentaje_reconocido: number;
  }>(`
    SELECT 
      eq.id,
      eq.materia_id,
      m.nombre as materia_nombre,
      eq.materia_origen,
      eq.institucion_origen,
      eq.resolucion,
      eq.porcentaje_reconocido
    FROM equivalencias eq
    JOIN materias m ON eq.materia_id = m.id
  `);

  // Determinar estado de cada materia para el estudiante
  const materiasConEstado = materias.map((mat) => {
    const cal = calificaciones.find((c) => c.materia_id === mat.id);
    const cursando = inscripcionesActivas.find((i) => i.materia_id === mat.id);
    const corr = correlatividades.filter((c) => c.materia_id === mat.id);

    let estado = 'PENDIENTE';
    if (cal) {
      if (cal.condicion.includes('APROBADO') || cal.condicion.includes('PROMOCION') || cal.condicion.includes('EQUIVALENCIA')) {
        estado = 'APROBADA';
      } else if (cal.condicion.includes('REGULAR')) {
        estado = 'REGULAR';
      }
    } else if (cursando) {
      estado = 'CURSANDO';
    }

    return {
      ...mat,
      estado,
      calificacion: cal || null,
      cursandoComision: cursando?.codigo_comision || null,
      requisitos: corr,
    };
  });

  res.json({
    ok: true,
    estudiante,
    materias: materiasConEstado,
    correlatividades,
    equivalencias,
  });
}

/**
 * Control de Asistencia y Faltas
 */
export async function getAttendance(req: Request, res: Response): Promise<void> {
  const session = (req as any).session;
  const estudianteId = getEstudianteId(session.userId) || 'EST-001';

  // Obtener comisiones inscriptas
  const comisiones = queryAll<{
    comision_id: string;
    materia_id: string;
    materia_nombre: string;
    materia_codigo: string;
    codigo_comision: string;
    docente_titular: string;
  }>(`
    SELECT 
      c.id as comision_id,
      m.id as materia_id,
      m.nombre as materia_nombre,
      m.codigo as materia_codigo,
      c.codigo_comision,
      c.docente_titular
    FROM inscripciones i
    JOIN comisiones c ON i.comision_id = c.id
    JOIN materias m ON c.materia_id = m.id
    WHERE i.estudiante_id = ? AND i.tipo = 'COMISION' AND i.estado = 'CONFIRMADA'
  `, [estudianteId]);

  // Resumen y detalles de asistencia por comisión
  const resumenPorComision = comisiones.map((com) => {
    // Regla de asistencia
    const regla = queryOne<{
      porcentaje_maximo_inasistencias: number;
      limite_faltas_directo: number;
      resolucion: string;
    }>(`
      SELECT porcentaje_maximo_inasistencias, limite_faltas_directo, resolucion
      FROM reglas_asistencia
      WHERE materia_id = ?
    `, [com.materia_id]) || {
      porcentaje_maximo_inasistencias: 25.0,
      limite_faltas_directo: 6,
      resolucion: 'Reglamento General UCSF Art. 44',
    };

    // Registros
    const registros = queryAll<{
      id: string;
      fecha: string;
      estado: string;
      observacion: string;
      cargado_por: string;
    }>(`
      SELECT id, fecha, estado, observacion, cargado_por
      FROM asistencia
      WHERE estudiante_id = ? AND comision_id = ?
      ORDER BY fecha DESC
    `, [estudianteId, com.comision_id]);

    const totalClases = registros.length;
    const presentes = registros.filter((r) => r.estado === 'PRESENTE').length;
    const ausentes = registros.filter((r) => r.estado === 'AUSENTE').length;
    const justificadas = registros.filter((r) => r.estado === 'JUSTIFICADA').length;

    // Inasistencias computables
    const faltasComputables = ausentes;
    const porcentajeInasistencias = totalClases > 0 ? (faltasComputables / totalClases) * 100 : 0;
    const faltasRestantes = regla.limite_faltas_directo - faltasComputables;

    let condicionAlerta = 'NORMAL';
    if (faltasComputables >= regla.limite_faltas_directo || porcentajeInasistencias > regla.porcentaje_maximo_inasistencias) {
      condicionAlerta = 'LIMITE_EXCEDIDO';
    } else if (faltasRestantes <= 2) {
      condicionAlerta = 'RIESGO';
    }

    return {
      ...com,
      regla,
      totalClases,
      presentes,
      ausentes,
      justificadas,
      faltasComputables,
      porcentajeInasistencias: parseFloat(porcentajeInasistencias.toFixed(1)),
      faltasRestantes: Math.max(0, faltasRestantes),
      condicionAlerta,
      registros,
    };
  });

  res.json({ ok: true, resumen: resumenPorComision });
}

/**
 * Parciales y Contenidos Temáticos
 */
export async function getEvaluations(req: Request, res: Response): Promise<void> {
  const session = (req as any).session;
  const estudianteId = getEstudianteId(session.userId) || 'EST-001';

  const evaluaciones = queryAll<{
    id: string;
    materia_nombre: string;
    materia_codigo: string;
    codigo_comision: string;
    tipo: string;
    titulo: string;
    fecha: string;
    hora: string;
    aula_nombre: string;
    aula_edificio: string;
    estado: string;
    fuente_nombre: string;
  }>(`
    SELECT 
      e.id,
      m.nombre as materia_nombre,
      m.codigo as materia_codigo,
      c.codigo_comision,
      e.tipo,
      e.titulo,
      e.fecha,
      e.hora,
      a.nombre as aula_nombre,
      a.edificio as aula_edificio,
      e.estado,
      f.nombre as fuente_nombre
    FROM evaluaciones e
    JOIN comisiones c ON e.comision_id = c.id
    JOIN materias m ON c.materia_id = m.id
    LEFT JOIN aulas a ON e.aula_id = a.id
    LEFT JOIN fuentes f ON e.fuente_id = f.id
    WHERE e.estado = 'PUBLICADO' OR ? = 'BEDELIA'
    ORDER BY e.fecha ASC
  `, [session.rol]);

  // Contenidos y bibliografía por evaluación
  const evaluacionIds = evaluaciones.map((e) => e.id);
  const contenidos = queryAll<{
    id: string;
    evaluacion_id: string;
    tema: string;
    bibliografia: string;
    orden: number;
  }>(`
    SELECT id, evaluacion_id, tema, bibliografia, orden
    FROM contenidos_evaluacion
    ORDER BY orden ASC
  `);

  const listado = evaluaciones.map((ev) => ({
    ...ev,
    temas: contenidos.filter((c) => c.evaluacion_id === ev.id),
  }));

  res.json({ ok: true, evaluaciones: listado });
}

/**
 * Calificaciones Históricas y Promedio Aritmético
 */
export async function getGrades(req: Request, res: Response): Promise<void> {
  const session = (req as any).session;
  const estudianteId = getEstudianteId(session.userId) || 'EST-001';

  const notas = queryAll<{
    id: string;
    materia_codigo: string;
    materia_nombre: string;
    anio_carrera: number;
    carga_horaria: number;
    tipo_instancia: string;
    nota: number;
    condicion: string;
    fecha: string;
    tomo: string;
    folio: string;
    acta: string;
    cargado_por: string;
  }>(`
    SELECT 
      c.id,
      m.codigo as materia_codigo,
      m.nombre as materia_nombre,
      m.anio_carrera,
      m.carga_horaria,
      c.tipo_instancia,
      c.nota,
      c.condicion,
      c.fecha,
      c.tomo,
      c.folio,
      c.acta,
      c.cargado_por
    FROM calificaciones c
    JOIN materias m ON c.materia_id = m.id
    WHERE c.estudiante_id = ?
    ORDER BY c.fecha DESC
  `, [estudianteId]);

  // Cálculo aritmético oficial
  const notasNumericas = notas.filter((n) => typeof n.nota === 'number' && !isNaN(n.nota));
  const suma = notasNumericas.reduce((acc, curr) => acc + curr.nota, 0);
  const promedioGeneral = notasNumericas.length > 0 ? suma / notasNumericas.length : 0;

  // Promedio ponderado por carga horaria
  const sumaPonderada = notasNumericas.reduce((acc, curr) => acc + curr.nota * curr.carga_horaria, 0);
  const totalHoras = notasNumericas.reduce((acc, curr) => acc + curr.carga_horaria, 0);
  const promedioPonderado = totalHoras > 0 ? sumaPonderada / totalHoras : 0;

  res.json({
    ok: true,
    calificaciones: notas,
    resumen: {
      materiasAprobadas: notas.length,
      promedioGeneral: parseFloat(promedioGeneral.toFixed(2)),
      promedioPonderado: parseFloat(promedioPonderado.toFixed(2)),
      totalHorasAcreditadas: totalHoras,
    },
  });
}

/**
 * Mesas de Examen Final
 */
export async function getExams(req: Request, res: Response): Promise<void> {
  const session = (req as any).session;
  const estudianteId = getEstudianteId(session.userId) || 'EST-001';

  // Todas las mesas disponibles
  const mesas = queryAll<{
    id: string;
    materia_id: string;
    materia_codigo: string;
    materia_nombre: string;
    anio_carrera: number;
    fecha: string;
    hora: string;
    turno_examen: string;
    llamado: number;
    aula_nombre: string;
    tribunal: string;
    periodo_inscripcion_desde: string;
    periodo_inscripcion_hasta: string;
    estado: string;
  }>(`
    SELECT 
      e.id,
      m.id as materia_id,
      m.codigo as materia_codigo,
      m.nombre as materia_nombre,
      m.anio_carrera,
      e.fecha,
      e.hora,
      e.turno_examen,
      e.llamado,
      a.nombre as aula_nombre,
      e.tribunal,
      e.periodo_inscripcion_desde,
      e.periodo_inscripcion_hasta,
      e.estado
    FROM examenes e
    JOIN materias m ON e.materia_id = m.id
    LEFT JOIN aulas a ON e.aula_id = a.id
    ORDER BY e.fecha ASC
  `);

  // Inscripciones del estudiante a exámenes
  const misInscripciones = queryAll<{
    examen_id: string;
    fecha_inscripcion: string;
    estado: string;
  }>(`
    SELECT examen_id, fecha_inscripcion, estado
    FROM inscripciones
    WHERE estudiante_id = ? AND tipo = 'EXAMEN' AND estado = 'CONFIRMADA'
  `, [estudianteId]);

  const listado = mesas.map((m) => {
    const miInsc = misInscripciones.find((i) => i.examen_id === m.id);
    return {
      ...m,
      inscripto: !!miInsc,
      fechaInscripcion: miInsc?.fecha_inscripcion || null,
    };
  });

  res.json({ ok: true, examenes: listado });
}

/**
 * Inscribirse a Examen Final
 */
export async function enrollExam(req: Request, res: Response): Promise<void> {
  const session = (req as any).session;
  const estudianteId = getEstudianteId(session.userId) || 'EST-001';
  const { examenId } = req.body;

  if (!examenId) {
    res.status(400).json({ ok: false, message: 'ID de examen requerido' });
    return;
  }

  // Verificar si ya está inscripto
  const yaInscripto = queryOne(
    "SELECT id FROM inscripciones WHERE estudiante_id = ? AND examen_id = ? AND tipo = 'EXAMEN' AND estado = 'CONFIRMADA'",
    [estudianteId, examenId]
  );

  if (yaInscripto) {
    res.status(400).json({ ok: false, message: 'Ya te encuentras inscripto/a en esta mesa de examen' });
    return;
  }

  const id = `INS-EXA-${Date.now().toString(36).toUpperCase()}`;
  runQuery(`
    INSERT INTO inscripciones (id, estudiante_id, comision_id, examen_id, tipo, fecha_inscripcion, estado)
    VALUES (?, ?, NULL, ?, 'EXAMEN', datetime('now'), 'CONFIRMADA')
  `, [id, estudianteId, examenId]);

  res.json({ ok: true, id, message: 'Inscripción a mesa de examen confirmada con éxito' });
}

/**
 * Anular Inscripción a Examen Final
 */
export async function withdrawExam(req: Request, res: Response): Promise<void> {
  const session = (req as any).session;
  const estudianteId = getEstudianteId(session.userId) || 'EST-001';
  const { examenId } = req.params;

  runQuery(`
    UPDATE inscripciones 
    SET estado = 'DADA_DE_BAJA', updated_at = datetime('now')
    WHERE estudiante_id = ? AND examen_id = ? AND tipo = 'EXAMEN'
  `, [estudianteId, examenId]);

  res.json({ ok: true, message: 'Inscripción dada de baja correctamente' });
}

/**
 * Cuotas y Aranceles
 */
export async function getFinance(req: Request, res: Response): Promise<void> {
  const session = (req as any).session;
  const estudianteId = getEstudianteId(session.userId) || 'EST-001';

  const cuotas = queryAll<{
    id: string;
    periodo: string;
    concepto: string;
    monto: number;
    fecha_vencimiento: string;
    estado: string;
    numero_comprobante: string;
    fecha_pago: string;
    medio_pago: string;
    monto_abonado: number;
    archivo_nombre: string;
  }>(`
    SELECT 
      c.id,
      c.periodo,
      c.concepto,
      c.monto,
      c.fecha_vencimiento,
      c.estado,
      cmp.numero_comprobante,
      cmp.fecha_pago,
      cmp.medio_pago,
      cmp.monto_abonado,
      cmp.archivo_nombre
    FROM cuotas c
    LEFT JOIN comprobantes cmp ON c.id = cmp.cuota_id
    WHERE c.estudiante_id = ?
    ORDER BY c.fecha_vencimiento ASC
  `, [estudianteId]);

  const totalPendiente = cuotas
    .filter((c) => c.estado === 'PENDIENTE' || c.estado === 'VENCIDA')
    .reduce((acc, curr) => acc + curr.monto, 0);

  const totalAbonado = cuotas
    .filter((c) => c.estado === 'PAGADA')
    .reduce((acc, curr) => acc + curr.monto, 0);

  res.json({
    ok: true,
    cuotas,
    resumen: {
      totalPendiente,
      totalAbonado,
      alDia: totalPendiente === 0,
    },
  });
}

/**
 * Solicitudes de Certificados
 */
export async function getCertificates(req: Request, res: Response): Promise<void> {
  const session = (req as any).session;
  const estudianteId = getEstudianteId(session.userId) || 'EST-001';

  const solicitudes = queryAll<{
    id: string;
    tipo_certificado: string;
    lugar_presentacion: string;
    observacion: string;
    estado: string;
    created_at: string;
    responsable_nombre: string;
  }>(`
    SELECT 
      s.id,
      s.tipo_certificado,
      s.lugar_presentacion,
      s.observacion,
      s.estado,
      s.created_at,
      u.correo as responsable_nombre
    FROM solicitudes_certificado s
    LEFT JOIN usuarios u ON s.responsable_id = u.id
    WHERE s.estudiante_id = ?
    ORDER BY s.created_at DESC
  `, [estudianteId]);

  res.json({ ok: true, solicitudes });
}

export async function requestCertificate(req: Request, res: Response): Promise<void> {
  const session = (req as any).session;
  const estudianteId = getEstudianteId(session.userId) || 'EST-001';
  const { tipoCertificado, lugarPresentacion, observacion } = req.body;

  if (!tipoCertificado || !lugarPresentacion) {
    res.status(400).json({ ok: false, message: 'Tipo de certificado y lugar de presentación son obligatorios' });
    return;
  }

  const id = `SOL-${Date.now().toString(36).toUpperCase()}`;
  runQuery(`
    INSERT INTO solicitudes_certificado (id, estudiante_id, tipo_certificado, lugar_presentacion, observacion, estado, responsable_id)
    VALUES (?, ?, ?, ?, ?, 'RECIBIDA', 'USR-ADM-01')
  `, [id, estudianteId, tipoCertificado, lugarPresentacion, observacion || '']);

  res.json({ ok: true, id, message: 'Solicitud de certificado ingresada con éxito' });
}

/**
 * Programas Analíticos y Documentación
 */
export async function getAcademicDocuments(req: Request, res: Response): Promise<void> {
  const docs = queryAll<{
    id: string;
    materia_id: string;
    materia_nombre: string;
    materia_codigo: string;
    nombre: string;
    categoria: string;
    mime_type: string;
    tamano_bytes: number;
    contenido_sintetico: string;
    fuente_nombre: string;
  }>(`
    SELECT 
      d.id,
      d.materia_id,
      m.nombre as materia_nombre,
      m.codigo as materia_codigo,
      d.nombre,
      d.categoria,
      d.mime_type,
      d.tamano_bytes,
      d.contenido_sintetico,
      f.nombre as fuente_nombre
    FROM documentos d
    LEFT JOIN materias m ON d.materia_id = m.id
    LEFT JOIN fuentes f ON d.fuente_id = f.id
    ORDER BY d.nombre ASC
  `);

  res.json({ ok: true, documentos: docs });
}
