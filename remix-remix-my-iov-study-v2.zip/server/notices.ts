import { Request, Response } from 'express';
import crypto from 'node:crypto';
import { queryOne, queryAll, runQuery } from './db.js';

// Listar avisos (Estudiante: filtrados por pertinencia; Bedelía: todos)
export function getNotices(req: Request, res: Response): void {
  const session = (req as any).session;
  const { categoria, vigencia, carrera } = req.query;

  if (session.rol === 'ESTUDIANTE') {
    // Resolver perfil del estudiante
    const est = queryOne<{ carrera_id: string; anio_cursado: number }>(
      'SELECT carrera_id, anio_cursado FROM estudiantes WHERE usuario_id = ?',
      [session.userId]
    );

    const carreraId = est?.carrera_id || 'CAR-LSI';
    const anio = est?.anio_cursado || 1;

    let sql = `
      SELECT 
        a.id, a.titulo, a.contenido, a.categoria, a.destinatarios,
        a.carrera_id, a.anio_carrera, a.fecha_publicacion, a.fecha_vencimiento,
        a.estado, a.version, a.fuente_id, a.documento_adjunto_nombre,
        f.nombre as fuente_nombre,
        CASE WHEN date(a.fecha_vencimiento) >= date('now') THEN 1 ELSE 0 END as es_vigente
      FROM avisos a
      LEFT JOIN fuentes f ON a.fuente_id = f.id
      WHERE a.estado IN ('PUBLICADO', 'VENCIDO')
        AND (a.carrera_id IS NULL OR a.carrera_id = ?)
        AND (a.anio_carrera IS NULL OR a.anio_carrera = ?)
    `;

    const params: any[] = [carreraId, anio];

    if (categoria) {
      sql += ' AND a.categoria = ?';
      params.push(String(categoria));
    }

    if (vigencia === 'vigente') {
      sql += " AND date(a.fecha_vencimiento) >= date('now')";
    } else if (vigencia === 'vencido') {
      sql += " AND date(a.fecha_vencimiento) < date('now')";
    }

    sql += ' ORDER BY a.fecha_publicacion DESC, a.created_at DESC';

    const notices = queryAll(sql, params);
    res.json({ notices });
  } else {
    // Bedelía y Administración: ven todos los estados
    let sql = `
      SELECT 
        a.id, a.titulo, a.contenido, a.categoria, a.destinatarios,
        a.carrera_id, a.anio_carrera, a.fecha_publicacion, a.fecha_vencimiento,
        a.estado, a.version, a.fuente_id, a.documento_adjunto_nombre,
        f.nombre as fuente_nombre,
        u.matricula as autor_matricula,
        CASE WHEN date(a.fecha_vencimiento) >= date('now') THEN 1 ELSE 0 END as es_vigente
      FROM avisos a
      LEFT JOIN fuentes f ON a.fuente_id = f.id
      LEFT JOIN usuarios u ON a.autor_id = u.id
      WHERE 1=1
    `;
    const params: any[] = [];

    if (categoria) {
      sql += ' AND a.categoria = ?';
      params.push(String(categoria));
    }

    sql += ' ORDER BY a.created_at DESC';
    const notices = queryAll(sql, params);
    res.json({ notices });
  }
}

// Detalle de un aviso
export function getNoticeById(req: Request, res: Response): void {
  const { id } = req.params;
  const notice = queryOne(`
    SELECT a.*, f.nombre as fuente_nombre, f.responsable as fuente_responsable
    FROM avisos a
    LEFT JOIN fuentes f ON a.fuente_id = f.id
    WHERE a.id = ?
  `, [id]);

  if (!notice) {
    res.status(404).json({ error: 'Aviso no encontrado.' });
    return;
  }

  const versions = queryAll(`
    SELECT v.*, u.matricula as autor_matricula
    FROM aviso_versiones v
    LEFT JOIN usuarios u ON v.autor_id = u.id
    WHERE v.aviso_id = ?
    ORDER BY v.version DESC
  `, [id]);

  res.json({ notice, versions });
}

// Guardar o Actualizar Borrador
export function saveNoticeDraft(req: Request, res: Response): void {
  const session = (req as any).session;
  const { id, titulo, contenido, categoria, destinatarios, carreraId, anioCarrera, fechaVencimiento, fuenteId, documentoAdjuntoNombre } = req.body || {};

  if (!titulo || !contenido || !categoria || !fechaVencimiento) {
    res.status(400).json({ error: 'Título, contenido, categoría y fecha de vencimiento son obligatorios.' });
    return;
  }

  const noticeId = id || `NOT-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
  const existing = queryOne<{ id: string; version: number }>('SELECT id, version FROM avisos WHERE id = ?', [noticeId]);

  if (existing) {
    runQuery(`
      UPDATE avisos
      SET titulo = ?, contenido = ?, categoria = ?, destinatarios = ?,
          carrera_id = ?, anio_carrera = ?, fecha_vencimiento = ?,
          fuente_id = ?, documento_adjunto_nombre = ?, estado = 'BORRADOR',
          updated_at = datetime('now')
      WHERE id = ?
    `, [
      titulo, contenido, categoria, destinatarios || 'TODOS',
      carreraId || null, anioCarrera || null, fechaVencimiento,
      fuenteId || 'FTE-BED-01', documentoAdjuntoNombre || null, noticeId
    ]);
  } else {
    runQuery(`
      INSERT INTO avisos (
        id, titulo, contenido, categoria, destinatarios, carrera_id, anio_carrera,
        fecha_vencimiento, estado, version, fuente_id, documento_adjunto_nombre, autor_id
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'BORRADOR', 1, ?, ?, ?)
    `, [
      noticeId, titulo, contenido, categoria, destinatarios || 'TODOS',
      carreraId || null, anioCarrera || null, fechaVencimiento,
      fuenteId || 'FTE-BED-01', documentoAdjuntoNombre || null, session.userId
    ]);
  }

  res.json({ ok: true, noticeId, message: 'Borrador guardado exitosamente.' });
}

// Paso 1: Previsualizar (Pasa a estado EN_REVISION)
export function previewNotice(req: Request, res: Response): void {
  const id = req.params.id || req.body?.id || req.body?.noticeId;
  if (!id) {
    res.status(400).json({ error: 'Identificador de aviso requerido para previsualización.' });
    return;
  }
  const notice = queryOne<{ id: string; estado: string }>('SELECT id, estado FROM avisos WHERE id = ?', [id]);

  if (!notice) {
    res.status(404).json({ error: 'Aviso no encontrado para previsualización.' });
    return;
  }

  runQuery("UPDATE avisos SET estado = 'EN_REVISION', updated_at = datetime('now') WHERE id = ?", [id]);

  res.json({ ok: true, message: 'Aviso en estado de revisión. Previsualización habilitada.' });
}

// Paso 2: Publicar Oficialmente (Flujo obligatorio: solo si está EN_REVISION)
export function publishNotice(req: Request, res: Response): void {
  const session = (req as any).session;
  const id = req.params.id || req.body?.id || req.body?.noticeId;
  if (!id) {
    res.status(400).json({ error: 'Identificador de aviso requerido para publicación.' });
    return;
  }

  const notice = queryOne<{
    id: string;
    titulo: string;
    contenido: string;
    categoria: string;
    estado: string;
    version: number;
    fecha_publicacion: string | null;
    carrera_id: string | null;
  }>('SELECT * FROM avisos WHERE id = ?', [id]);

  if (!notice) {
    res.status(404).json({ error: 'Aviso no encontrado.' });
    return;
  }

  // Regla estricta: NO se puede publicar sin pasar por revisión ({funcion_nueva_5}, {prueba_6})
  if (notice.estado !== 'EN_REVISION') {
    res.status(400).json({
      error: 'Flujo de revisión obligatorio: el aviso debe ser previsualizado y puesto en revisión antes de publicarse.',
      code: 'PREVIEW_REQUIRED',
    });
    return;
  }

  const esPublicacionInicial = !notice.fecha_publicacion;
  let nuevaVersion = notice.version;
  let motivoVersion = 'Publicación inicial';

  // Si ya estaba publicado anteriormente, verificar si hubo cambio real ({funcion_nueva_6}, {error_6})
  if (!esPublicacionInicial) {
    const ultimaVersion = queryOne<{ snapshot_json: string }>(`
      SELECT snapshot_json FROM aviso_versiones
      WHERE aviso_id = ?
      ORDER BY version DESC LIMIT 1
    `, [id]);

    let huboCambioReal = true;
    if (ultimaVersion) {
      try {
        const snap = JSON.parse(ultimaVersion.snapshot_json);
        if (snap.titulo === notice.titulo && snap.contenido === notice.contenido && snap.categoria === notice.categoria) {
          huboCambioReal = false;
        }
      } catch {}
    }

    if (huboCambioReal) {
      nuevaVersion = notice.version + 1;
      motivoVersion = `Actualización v${nuevaVersion}`;
    }
  }

  // Guardar en tabla aviso_versiones solo si es publicación inicial o hubo cambio real
  const snapshotJson = JSON.stringify({
    titulo: notice.titulo,
    contenido: notice.contenido,
    categoria: notice.categoria,
    version: nuevaVersion,
  });

  runQuery(`
    INSERT INTO aviso_versiones (id, aviso_id, version, titulo, contenido, categoria, motivo_cambio, autor_id, snapshot_json)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `, [
    crypto.randomUUID(), id, nuevaVersion, notice.titulo, notice.contenido, notice.categoria,
    motivoVersion, session.userId, snapshotJson
  ]);

  // Actualizar aviso como PUBLICADO
  runQuery(`
    UPDATE avisos
    SET estado = 'PUBLICADO',
        version = ?,
        fecha_publicacion = COALESCE(fecha_publicacion, date('now')),
        updated_at = datetime('now')
    WHERE id = ?
  `, [nuevaVersion, id]);

  // Generar notificaciones para los estudiantes destinatarios ({funcion_nueva_7}, {prueba_10})
  const estudiantes = queryAll<{ id: string }>(`
    SELECT id FROM estudiantes
    WHERE (? IS NULL OR carrera_id = ?)
  `, [notice.carrera_id, notice.carrera_id]);

  for (const est of estudiantes) {
    runQuery(`
      INSERT INTO notificaciones (id, estudiante_id, tipo, referencia_id, titulo, cuerpo, leida)
      VALUES (?, ?, 'AVISO', ?, ?, ?, 0)
    `, [
      crypto.randomUUID(),
      est.id,
      id,
      `Aviso Institucional: ${notice.titulo.slice(0, 45)}`,
      notice.contenido.slice(0, 120),
    ]);
  }

  res.json({
    ok: true,
    version: nuevaVersion,
    motivo: motivoVersion,
    message: 'Aviso publicado oficialmente y notificaciones emitidas.',
  });
}

// Restaurar versión histórica de un aviso ({historial_3})
export function restoreNoticeVersion(req: Request, res: Response): void {
  const session = (req as any).session;
  const { id, versionNumber } = req.params;

  const versionData = queryOne<{ snapshot_json: string }>(`
    SELECT snapshot_json FROM aviso_versiones
    WHERE aviso_id = ? AND version = ?
  `, [id, versionNumber]);

  if (!versionData) {
    res.status(404).json({ error: 'Versión histórica no encontrada.' });
    return;
  }

  const currentNotice = queryOne<{ version: number }>('SELECT version FROM avisos WHERE id = ?', [id]);
  const newVersion = (currentNotice?.version || 1) + 1;
  const snap = JSON.parse(versionData.snapshot_json);

  // Restaurar contenido y crear nueva versión explicativa
  runQuery(`
    UPDATE avisos
    SET titulo = ?, contenido = ?, categoria = ?, version = ?,
        estado = 'PUBLICADO', updated_at = datetime('now')
    WHERE id = ?
  `, [snap.titulo, snap.contenido, snap.categoria, newVersion, id]);

  runQuery(`
    INSERT INTO aviso_versiones (id, aviso_id, version, titulo, contenido, categoria, motivo_cambio, autor_id, snapshot_json)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `, [
    crypto.randomUUID(), id, newVersion, snap.titulo, snap.contenido, snap.categoria,
    `Restauración de v${versionNumber}`, session.userId, versionData.snapshot_json
  ]);

  res.json({ ok: true, version: newVersion, message: `Aviso restaurado exitosamente a partir de la versión v${versionNumber}.` });
}

// Renovar o Retirar aviso vencido ({error_6}, {prueba_9})
export function manageExpiredNotice(req: Request, res: Response): void {
  const { id } = req.params;
  const { accion, nuevaFechaVencimiento } = req.body || {};

  const notice = queryOne<{ id: string; version: number }>('SELECT id, version FROM avisos WHERE id = ?', [id]);
  if (!notice) {
    res.status(404).json({ error: 'Aviso no encontrado.' });
    return;
  }

  if (accion === 'RETIRAR') {
    runQuery("UPDATE avisos SET estado = 'RETIRADO', updated_at = datetime('now') WHERE id = ?", [id]);
    res.json({ ok: true, message: 'Aviso retirado de la cartelera.' });
    return;
  }

  if (accion === 'RENOVAR') {
    if (!nuevaFechaVencimiento) {
      res.status(400).json({ error: 'Debe especificar una nueva fecha de vencimiento.' });
      return;
    }

    // Renovar fecha de vencimiento sin mutar contenido NO incrementa versión ({error_6}, {prueba_9})
    runQuery(`
      UPDATE avisos
      SET fecha_vencimiento = ?, estado = 'PUBLICADO', updated_at = datetime('now')
      WHERE id = ?
    `, [nuevaFechaVencimiento, id]);

    res.json({ ok: true, version: notice.version, message: 'Aviso renovado sin cambio de versión de contenido.' });
    return;
  }

  res.status(400).json({ error: 'Acción no reconocida.' });
}

// --- NOTIFICACIONES ---

// Listar notificaciones del estudiante
export function getStudentNotifications(req: Request, res: Response): void {
  const session = (req as any).session;
  const est = queryOne<{ id: string }>('SELECT id FROM estudiantes WHERE usuario_id = ?', [session.userId]);

  if (!est) {
    res.json({ notifications: [], unreadCount: 0 });
    return;
  }

  const notifications = queryAll(`
    SELECT id, tipo, referencia_id, titulo, cuerpo, leida, created_at, fecha_lectura
    FROM notificaciones
    WHERE estudiante_id = ?
    ORDER BY created_at DESC
  `, [est.id]);

  const unreadCount = queryOne<{ count: number }>(`
    SELECT COUNT(*) as count FROM notificaciones
    WHERE estudiante_id = ? AND leida = 0
  `, [est.id])?.count || 0;

  res.json({ notifications, unreadCount });
}

// Marcar notificación como leída
export function markNotificationAsRead(req: Request, res: Response): void {
  const session = (req as any).session;
  const { id } = req.params;

  const est = queryOne<{ id: string }>('SELECT id FROM estudiantes WHERE usuario_id = ?', [session.userId]);
  if (!est) {
    res.status(404).json({ error: 'Estudiante no encontrado.' });
    return;
  }

  runQuery(`
    UPDATE notificaciones
    SET leida = 1, fecha_lectura = datetime('now')
    WHERE id = ? AND estudiante_id = ?
  `, [id, est.id]);

  const unreadCount = queryOne<{ count: number }>(`
    SELECT COUNT(*) as count FROM notificaciones
    WHERE estudiante_id = ? AND leida = 0
  `, [est.id])?.count || 0;

  res.json({ ok: true, unreadCount });
}

// Marcar todas como leídas
export function markAllNotificationsAsRead(req: Request, res: Response): void {
  const session = (req as any).session;
  const est = queryOne<{ id: string }>('SELECT id FROM estudiantes WHERE usuario_id = ?', [session.userId]);

  if (!est) {
    res.status(404).json({ error: 'Estudiante no encontrado.' });
    return;
  }

  runQuery(`
    UPDATE notificaciones
    SET leida = 1, fecha_lectura = datetime('now')
    WHERE estudiante_id = ? AND leida = 0
  `, [est.id]);

  res.json({ ok: true, unreadCount: 0 });
}

// Publicación Directa de Aviso (solicitado por el usuario)
export function publishDirectNotice(req: Request, res: Response): void {
  const session = (req as any).session;
  const {
    id,
    titulo,
    contenido,
    categoria,
    destinatarios,
    carreraId,
    anioCarrera,
    fechaVencimiento,
    fuenteId,
    documentoAdjuntoNombre,
  } = req.body || {};

  if (!titulo || !contenido || !categoria || !fechaVencimiento) {
    res.status(400).json({ error: 'Título, contenido, categoría y fecha de vencimiento son requeridos.' });
    return;
  }

  const noticeId = id || `NOT-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
  const existing = queryOne<{ id: string; version: number; fecha_publicacion: string | null }>(
    'SELECT id, version, fecha_publicacion FROM avisos WHERE id = ?',
    [noticeId]
  );

  const esInicial = !existing || !existing.fecha_publicacion;
  const nuevaVersion = esInicial ? 1 : existing.version + 1;
  const motivoVersion = esInicial ? 'Publicación directa inicial' : `Actualización directa v${nuevaVersion}`;

  if (existing) {
    runQuery(`
      UPDATE avisos
      SET titulo = ?, contenido = ?, categoria = ?, destinatarios = ?,
          carrera_id = ?, anio_carrera = ?, fecha_vencimiento = ?,
          fuente_id = ?, documento_adjunto_nombre = ?, estado = 'PUBLICADO',
          version = ?, fecha_publicacion = COALESCE(fecha_publicacion, date('now')),
          updated_at = datetime('now')
      WHERE id = ?
    `, [
      titulo.trim(), contenido.trim(), categoria, destinatarios || 'TODOS',
      carreraId || null, anioCarrera ? parseInt(anioCarrera, 10) : null,
      fechaVencimiento, fuenteId || 'FTE-BED-01', documentoAdjuntoNombre || null,
      nuevaVersion, noticeId,
    ]);
  } else {
    runQuery(`
      INSERT INTO avisos (
        id, titulo, contenido, categoria, destinatarios, carrera_id, anio_carrera,
        fecha_publicacion, fecha_vencimiento, estado, version, fuente_id,
        documento_adjunto_nombre, autor_id
      ) VALUES (?, ?, ?, ?, ?, ?, ?, date('now'), ?, 'PUBLICADO', 1, ?, ?, ?)
    `, [
      noticeId, titulo.trim(), contenido.trim(), categoria, destinatarios || 'TODOS',
      carreraId || null, anioCarrera ? parseInt(anioCarrera, 10) : null,
      fechaVencimiento, fuenteId || 'FTE-BED-01', documentoAdjuntoNombre || null, session.userId,
    ]);
  }

  // Guardar snapshot de versión
  const snapshotJson = JSON.stringify({
    titulo: titulo.trim(),
    contenido: contenido.trim(),
    categoria,
    version: nuevaVersion,
  });

  runQuery(`
    INSERT INTO aviso_versiones (id, aviso_id, version, titulo, contenido, categoria, motivo_cambio, autor_id, snapshot_json)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `, [
    crypto.randomUUID(), noticeId, nuevaVersion, titulo.trim(), contenido.trim(),
    categoria, motivoVersion, session.userId, snapshotJson,
  ]);

  // Emitir notificaciones a los estudiantes destinatarios
  const estudiantes = queryAll<{ id: string }>(`
    SELECT id FROM estudiantes
    WHERE (? IS NULL OR carrera_id = ?)
  `, [carreraId || null, carreraId || null]);

  for (const est of estudiantes) {
    runQuery(`
      INSERT INTO notificaciones (id, estudiante_id, tipo, referencia_id, titulo, cuerpo, leida)
      VALUES (?, ?, 'AVISO', ?, ?, ?, 0)
    `, [
      crypto.randomUUID(),
      est.id,
      noticeId,
      `Nuevo Aviso: ${titulo.slice(0, 45)}`,
      contenido.slice(0, 120),
    ]);
  }

  res.json({
    ok: true,
    noticeId,
    version: nuevaVersion,
    message: 'Aviso publicado directamente y notificaciones emitidas.',
  });
}

// Borrar Aviso Definitivamente
export function deleteNotice(req: Request, res: Response): void {
  const session = (req as any).session;
  const { id } = req.params;

  const existing = queryOne<{ id: string; titulo: string }>('SELECT id, titulo FROM avisos WHERE id = ?', [id]);
  if (!existing) {
    res.status(404).json({ error: 'Aviso no encontrado para eliminar.' });
    return;
  }

  // Eliminar referencias dependientes
  runQuery('DELETE FROM aviso_versiones WHERE aviso_id = ?', [id]);
  runQuery('DELETE FROM notificaciones WHERE referencia_id = ?', [id]);
  runQuery('DELETE FROM documentos WHERE aviso_id = ?', [id]);
  runQuery('DELETE FROM avisos WHERE id = ?', [id]);

  runQuery(`
    INSERT INTO auditoria (id, actor_id, actor_rol, accion, recurso, recurso_id, resultado, correlation_id)
    VALUES (?, ?, 'BEDELIA', 'DELETE', 'avisos', ?, 'EXITO', ?)
  `, [crypto.randomUUID(), session.userId, id, crypto.randomUUID()]);

  res.json({ ok: true, message: `Aviso "${existing.titulo}" eliminado correctamente.` });
}

