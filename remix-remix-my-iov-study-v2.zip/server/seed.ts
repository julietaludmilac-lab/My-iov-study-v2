import bcrypt from 'bcryptjs';
import { getDb, queryOne, queryAll, runQuery } from './db.js';

export async function seedDatabase(): Promise<void> {
  await getDb();

  console.log('[SEED] Validando y restableciendo datos íntegros para My IOV Study v2...');

  // 1. Fuentes Oficiales
  runQuery(`
    INSERT OR REPLACE INTO fuentes (id, nombre, tipo, responsable, estado_verificacion) VALUES
    ('FTE-BED-01', 'Bedelía Central - Sede Santa Fe', 'BEDELIA', 'Dra. María Elena Vázquez', 'OFICIAL'),
    ('FTE-ADM-01', 'Secretaría de Administración y Aranceles', 'ADMINISTRACION', 'Cdor. Carlos Alberto Méndez', 'OFICIAL'),
    ('FTE-CON-01', 'Consejo Directivo - Resolución Académica 142/2025', 'RESOLUCION', 'Secretaría Académica UCSF', 'OFICIAL')
  `);

  // 2. Usuarios y Roles (bcrypt hasheado)
  const salt = bcrypt.genSaltSync(10);
  const hashEstudiante = bcrypt.hashSync('Estudiante2026A', salt);
  const hashSantiago = bcrypt.hashSync('Password2026A', salt);
  const hashBedelia = bcrypt.hashSync('Bedelia2026A', salt);
  const hashAdmin = bcrypt.hashSync('Admin2026A', salt);

  runQuery(`
    INSERT OR REPLACE INTO usuarios (id, matricula, correo, password_hash, rol, estado) VALUES
    ('USR-EST-01', 'A-2026-001', 'estudiante.demo@ucsf.test', ?, 'ESTUDIANTE', 'ACTIVO'),
    ('USR-TEST-REG-01', 'A-2026-009', 'santiago.benitez@ucsf.test', ?, 'ESTUDIANTE', 'ACTIVO'),
    ('USR-BIO-01', 'BIO-2026-001', 'alumno.bio@ucsf.test', ?, 'ESTUDIANTE', 'ACTIVO'),
    ('USR-DER-01', 'DER-2026-015', 'valentina.rossi@ucsf.test', ?, 'ESTUDIANTE', 'ACTIVO'),
    ('USR-BED-01', 'B-ADMIN-001', 'bedelia.demo@ucsf.test', ?, 'BEDELIA', 'ACTIVO'),
    ('USR-BED-02', 'B-ADMIN-002', 'bedelia.operativa@ucsf.test', ?, 'BEDELIA', 'ACTIVO'),
    ('USR-ADM-01', 'C-ADMIN-002', 'admin.demo@ucsf.test', ?, 'ADMINISTRACION', 'ACTIVO'),
    ('USR-ADM-02', 'C-ADMIN-003', 'admin.institucional@ucsf.test', ?, 'ADMINISTRACION', 'ACTIVO')
  `, [
    hashEstudiante,
    hashSantiago,
    hashEstudiante,
    hashEstudiante,
    hashBedelia,
    hashBedelia,
    hashAdmin,
    hashAdmin,
  ]);

  // 3. Carreras (LSI, Abogacía, Bioinformática)
  runQuery(`
    INSERT OR REPLACE INTO carreras (id, codigo, nombre, sede, estado) VALUES
    ('CAR-LSI', 'LSI', 'Licenciatura en Sistemas de Información', 'Sede Santa Fe - Campus San José', 'ACTIVA'),
    ('CAR-DER', 'ABOG', 'Abogacía', 'Sede Santa Fe - Edificio Central', 'ACTIVA'),
    ('CAR-BIO', 'BIO', 'Licenciatura en Bioinformática', 'Sede Santa Fe - Campus San José', 'ACTIVA')
  `);

  // 4. Planes de Estudio Vigentes
  runQuery(`
    INSERT OR REPLACE INTO planes_estudio (id, carrera_id, codigo_plan, version, anio_validez, resolucion, estado) VALUES
    ('PLAN-LSI-2023', 'CAR-LSI', 'PLAN-2023-LSI', 'v2.1', 2023, 'Res. CS N° 108/2022', 'VIGENTE'),
    ('PLAN-DER-2024', 'CAR-DER', 'PLAN-2024-DER', 'v1.0', 2024, 'Res. CS N° 72/2023', 'VIGENTE'),
    ('PLAN-BIO-2026', 'CAR-BIO', 'PLAN-2026-BIO', 'v1.0', 2026, 'Res. CS N° 55/2026', 'VIGENTE')
  `);

  // 5. Estudiantes Registrados
  runQuery(`
    INSERT OR REPLACE INTO estudiantes (id, usuario_id, nombre_completo, carrera_id, plan_id, anio_cursado, telefono, domicilio, ciudad, correo_personal, condicion_academica) VALUES
    ('EST-001', 'USR-EST-01', 'Lucía Belén Gómez', 'CAR-LSI', 'PLAN-LSI-2023', 2, '+54 342 455-8900', 'San Martín 1845, Piso 4 B', 'Santa Fe', 'lucia.gomez.sintetica@correo.test', 'REGULAR'),
    ('EST-TEST-REG-01', 'USR-TEST-REG-01', 'Santiago Martín Benítez', 'CAR-LSI', 'PLAN-LSI-2023', 1, '+54 342 490-1122', 'Bv. Pellegrini 2840', 'Santa Fe', 'santiago.benitez@correo.test', 'REGULAR'),
    ('EST-BIO-01', 'USR-BIO-01', 'Mateo Silva (Bioinformática)', 'CAR-BIO', 'PLAN-BIO-2026', 1, '+54 342 511-3344', 'Cándido Pujato 920', 'Santa Fe', 'mateo.silva@correo.test', 'REGULAR'),
    ('EST-DER-01', 'USR-DER-01', 'Valentina Rossi (Abogacía)', 'CAR-DER', 'PLAN-DER-2024', 1, '+54 342 588-7711', 'Urquiza 2130, Piso 2 A', 'Santa Fe', 'valentina.rossi@correo.test', 'REGULAR')
  `);

  // 6. Materias del Plan LSI (12 Materias)
  runQuery(`
    INSERT OR REPLACE INTO materias (id, plan_id, codigo, nombre, anio_carrera, regimen, carga_horaria, condicion) VALUES
    ('MAT-LSI-101', 'PLAN-LSI-2023', 'LSI-101', 'Algoritmos y Estructuras de Datos I', 1, '1C', 96, 'OBLIGATORIA'),
    ('MAT-LSI-102', 'PLAN-LSI-2023', 'LSI-102', 'Álgebra y Geometría Analítica', 1, '1C', 80, 'OBLIGATORIA'),
    ('MAT-LSI-103', 'PLAN-LSI-2023', 'LSI-103', 'Análisis Matemático I', 1, '2C', 96, 'OBLIGATORIA'),
    ('MAT-LSI-104', 'PLAN-LSI-2023', 'LSI-104', 'Arquitectura de Computadoras', 1, '2C', 80, 'OBLIGATORIA'),
    ('MAT-LSI-201', 'PLAN-LSI-2023', 'LSI-201', 'Programación Orientada a Objetos', 2, '1C', 96, 'OBLIGATORIA'),
    ('MAT-LSI-202', 'PLAN-LSI-2023', 'LSI-202', 'Base de Datos I', 2, '1C', 80, 'OBLIGATORIA'),
    ('MAT-LSI-203', 'PLAN-LSI-2023', 'LSI-203', 'Análisis Matemático II', 2, '2C', 80, 'OBLIGATORIA'),
    ('MAT-LSI-204', 'PLAN-LSI-2023', 'LSI-204', 'Sistemas Operativos', 2, '2C', 96, 'OBLIGATORIA'),
    ('MAT-LSI-301', 'PLAN-LSI-2023', 'LSI-301', 'Ingeniería de Software I', 3, '1C', 96, 'OBLIGATORIA'),
    ('MAT-LSI-302', 'PLAN-LSI-2023', 'LSI-302', 'Redes de Información', 3, '2C', 80, 'OBLIGATORIA'),
    ('MAT-LSI-401', 'PLAN-LSI-2023', 'LSI-401', 'Seguridad y Privacidad de la Información', 4, '1C', 64, 'OBLIGATORIA'),
    ('MAT-LSI-402', 'PLAN-LSI-2023', 'LSI-402', 'Práctica Profesional Supervisada', 4, 'ANUAL', 120, 'OBLIGATORIA')
  `);

  // 7. Materias del Plan Abogacía (8 Materias)
  runQuery(`
    INSERT OR REPLACE INTO materias (id, plan_id, codigo, nombre, anio_carrera, regimen, carga_horaria, condicion) VALUES
    ('MAT-DER-101', 'PLAN-DER-2024', 'DER-101', 'Introducción al Derecho', 1, '1C', 96, 'OBLIGATORIA'),
    ('MAT-DER-102', 'PLAN-DER-2024', 'DER-102', 'Historia del Derecho y de las Instituciones', 1, '1C', 80, 'OBLIGATORIA'),
    ('MAT-DER-103', 'PLAN-DER-2024', 'DER-103', 'Derecho Romano', 1, '2C', 80, 'OBLIGATORIA'),
    ('MAT-DER-104', 'PLAN-DER-2024', 'DER-104', 'Derecho Constitucional I', 1, '2C', 96, 'OBLIGATORIA'),
    ('MAT-DER-201', 'PLAN-DER-2024', 'DER-201', 'Derecho Civil - Parte General', 2, '1C', 96, 'OBLIGATORIA'),
    ('MAT-DER-202', 'PLAN-DER-2024', 'DER-202', 'Derecho Penal I (Parte General)', 2, '1C', 96, 'OBLIGATORIA'),
    ('MAT-DER-203', 'PLAN-DER-2024', 'DER-203', 'Derecho de las Obligaciones', 2, '2C', 96, 'OBLIGATORIA'),
    ('MAT-DER-204', 'PLAN-DER-2024', 'DER-204', 'Derecho Constitucional II', 2, '2C', 80, 'OBLIGATORIA')
  `);

  // 8. Materias del Plan Bioinformática (7 Materias)
  runQuery(`
    INSERT OR REPLACE INTO materias (id, plan_id, codigo, nombre, anio_carrera, regimen, carga_horaria, condicion) VALUES
    ('MAT-BIO-101', 'PLAN-BIO-2026', 'BIO-101', 'Biología Celular y Molecular', 1, '1C', 96, 'OBLIGATORIA'),
    ('MAT-BIO-102', 'PLAN-BIO-2026', 'BIO-102', 'Programación en Python y Algoritmos', 1, '1C', 96, 'OBLIGATORIA'),
    ('MAT-BIO-103', 'PLAN-BIO-2026', 'BIO-103', 'Genómica Computacional I', 1, '2C', 80, 'OBLIGATORIA'),
    ('MAT-BIO-104', 'PLAN-BIO-2026', 'BIO-104', 'Álgebra y Cálculo Aplicado', 1, '2C', 96, 'OBLIGATORIA'),
    ('MAT-BIO-201', 'PLAN-BIO-2026', 'BIO-201', 'Bioestadística y Modelado', 2, '1C', 80, 'OBLIGATORIA'),
    ('MAT-BIO-202', 'PLAN-BIO-2026', 'BIO-202', 'Minería de Datos Biológicos', 2, '1C', 96, 'OBLIGATORIA'),
    ('MAT-BIO-203', 'PLAN-BIO-2026', 'BIO-203', 'Simulación Estructural de Proteínas', 2, '2C', 96, 'OBLIGATORIA')
  `);

  // 9. Correlatividades Oficiales
  runQuery(`
    INSERT OR REPLACE INTO correlatividades (id, materia_id, materia_requisito_id, tipo, fuente_id, resolucion) VALUES
    ('CORR-LSI-01', 'MAT-LSI-201', 'MAT-LSI-101', 'PARA_CURSAR_APROBADA', 'FTE-CON-01', 'Plan LSI 2023'),
    ('CORR-LSI-02', 'MAT-LSI-202', 'MAT-LSI-101', 'PARA_CURSAR_REGULAR', 'FTE-CON-01', 'Plan LSI 2023'),
    ('CORR-LSI-03', 'MAT-LSI-203', 'MAT-LSI-103', 'PARA_CURSAR_APROBADA', 'FTE-CON-01', 'Plan LSI 2023'),
    ('CORR-LSI-04', 'MAT-LSI-204', 'MAT-LSI-104', 'PARA_CURSAR_APROBADA', 'FTE-CON-01', 'Plan LSI 2023'),
    ('CORR-LSI-05', 'MAT-LSI-301', 'MAT-LSI-201', 'PARA_CURSAR_APROBADA', 'FTE-CON-01', 'Plan LSI 2023'),
    ('CORR-DER-01', 'MAT-DER-201', 'MAT-DER-101', 'PARA_CURSAR_APROBADA', 'FTE-CON-01', 'Plan Abogacía 2024'),
    ('CORR-DER-02', 'MAT-DER-203', 'MAT-DER-201', 'PARA_CURSAR_REGULAR', 'FTE-CON-01', 'Plan Abogacía 2024'),
    ('CORR-BIO-01', 'MAT-BIO-103', 'MAT-BIO-101', 'PARA_CURSAR_APROBADA', 'FTE-CON-01', 'Plan Bioinformática 2026'),
    ('CORR-BIO-02', 'MAT-BIO-103', 'MAT-BIO-102', 'PARA_CURSAR_APROBADA', 'FTE-CON-01', 'Plan Bioinformática 2026'),
    ('CORR-BIO-03', 'MAT-BIO-201', 'MAT-BIO-104', 'PARA_CURSAR_APROBADA', 'FTE-CON-01', 'Plan Bioinformática 2026')
  `);

  // 10. Aulas
  runQuery(`
    INSERT OR REPLACE INTO aulas (id, nombre, edificio, piso, capacidad, tipo) VALUES
    ('AULA-101', 'Aula 101', 'Edificio Central', '1er Piso', 45, 'AULA_COMUN'),
    ('AULA-204', 'Aula 204', 'Edificio Central', '2do Piso', 35, 'AULA_COMUN'),
    ('LAB-01', 'Laboratorio de Informática 1', 'Edificio de Tecnología', 'Planta Baja', 30, 'LABORATORIO'),
    ('AUD-01', 'Aula Magna San José', 'Edificio Central', 'Planta Baja', 120, 'AUDITORIO')
  `);

  // 11. Comisiones Habilitadas y Operativas por Bedelía
  runQuery(`
    INSERT OR REPLACE INTO comisiones (id, materia_id, codigo_comision, ciclo_lectivo, cuatrimestre, docente_titular, turno, cupo_maximo, inscripcion_desde, inscripcion_hasta, estado) VALUES
    ('COM-POO-A', 'MAT-LSI-201', 'COM-A', 2026, '1C', 'Ing. Roberto Rossi', 'MANANA', 35, '2026-02-15', '2026-03-30', 'ABIERTA'),
    ('COM-BD1-U', 'MAT-LSI-202', 'COM-U', 2026, '1C', 'Lic. Mariana Peralta', 'MANANA', 40, '2026-02-15', '2026-03-30', 'ABIERTA'),
    ('COM-AM2-A', 'MAT-LSI-203', 'COM-A', 2026, '2C', 'Dr. Gustavo Fontanarrosa', 'TARDE', 30, '2026-06-15', '2026-07-20', 'ABIERTA'),
    ('COM-BIO101-A', 'MAT-BIO-101', 'COM-A', 2026, '1C', 'Dra. Florencia Bianchi', 'MANANA', 30, '2026-02-15', '2026-03-30', 'ABIERTA'),
    ('COM-DER101-A', 'MAT-DER-101', 'COM-A', 2026, '1C', 'Dr. Alejandro Morales', 'TARDE', 50, '2026-02-15', '2026-03-30', 'ABIERTA')
  `);

  // 12. Horarios Asignados
  runQuery(`
    INSERT OR REPLACE INTO horarios (id, comision_id, dia_semana, hora_inicio, hora_fin, aula_id, estado_aula, observaciones) VALUES
    ('HOR-POO-1', 'COM-POO-A', 1, '08:00', '11:00', 'AULA-204', 'OFICIAL', 'Clase Teórico-Práctica'),
    ('HOR-POO-2', 'COM-POO-A', 3, '08:00', '10:00', 'LAB-01', 'OFICIAL', 'Práctica de Laboratorio en Java'),
    ('HOR-BD1-1', 'COM-BD1-U', 2, '10:00', '13:00', 'AULA-101', 'OFICIAL', 'Modelado Relacional y Normalización'),
    ('HOR-BD1-2', 'COM-BD1-U', 4, '10:00', '12:00', 'LAB-01', 'MODIFICADA', 'Taller SQL - Reubicado a Lab 1 por obras'),
    ('HOR-BIO-1', 'COM-BIO101-A', 1, '08:00', '11:00', 'LAB-01', 'OFICIAL', 'Laboratorio de Genómica y Células'),
    ('HOR-DER-1', 'COM-DER101-A', 2, '14:00', '17:00', 'AUD-01', 'OFICIAL', 'Cátedra Magistral de Introducción')
  `);

  // 13. Inscripciones de Estudiantes a Comisiones
  runQuery(`
    INSERT OR REPLACE INTO inscripciones (id, estudiante_id, comision_id, examen_id, tipo, fecha_inscripcion, estado) VALUES
    ('INS-EST-01', 'EST-001', 'COM-POO-A', NULL, 'COMISION', '2026-03-01 09:30:00', 'CONFIRMADA'),
    ('INS-EST-02', 'EST-001', 'COM-BD1-U', NULL, 'COMISION', '2026-03-01 09:32:00', 'CONFIRMADA'),
    ('INS-BIO-01', 'EST-BIO-01', 'COM-BIO101-A', NULL, 'COMISION', '2026-03-02 10:15:00', 'CONFIRMADA'),
    ('INS-DER-01', 'EST-DER-01', 'COM-DER101-A', NULL, 'COMISION', '2026-03-02 11:00:00', 'CONFIRMADA')
  `);

  // 14. Asistencia
  runQuery(`
    INSERT OR REPLACE INTO asistencia (id, estudiante_id, comision_id, fecha, estado, observacion, cargado_por) VALUES
    ('ASI-01', 'EST-001', 'COM-POO-A', '2026-03-16', 'PRESENTE', NULL, 'Ing. Roberto Rossi'),
    ('ASI-02', 'EST-001', 'COM-POO-A', '2026-03-23', 'PRESENTE', NULL, 'Ing. Roberto Rossi'),
    ('ASI-03', 'EST-001', 'COM-POO-A', '2026-03-30', 'AUSENTE', 'Inasistencia injustificada', 'Ing. Roberto Rossi'),
    ('ASI-04', 'EST-001', 'COM-POO-A', '2026-04-06', 'PRESENTE', NULL, 'Ing. Roberto Rossi'),
    ('ASI-05', 'EST-001', 'COM-POO-A', '2026-04-13', 'PRESENTE', NULL, 'Ing. Roberto Rossi'),
    ('ASI-06', 'EST-001', 'COM-POO-A', '2026-04-20', 'AUSENTE', 'Certificado médico presentado', 'Ing. Roberto Rossi'),
    ('ASI-07', 'EST-001', 'COM-POO-A', '2026-04-27', 'PRESENTE', NULL, 'Ing. Roberto Rossi'),
    ('ASI-08', 'EST-001', 'COM-POO-A', '2026-05-04', 'PRESENTE', NULL, 'Ing. Roberto Rossi'),
    ('ASI-09', 'EST-001', 'COM-BD1-U', '2026-03-17', 'PRESENTE', NULL, 'Lic. Mariana Peralta'),
    ('ASI-10', 'EST-001', 'COM-BD1-U', '2026-03-24', 'PRESENTE', NULL, 'Lic. Mariana Peralta'),
    ('ASI-11', 'EST-001', 'COM-BD1-U', '2026-03-31', 'PRESENTE', NULL, 'Lic. Mariana Peralta'),
    ('ASI-12', 'EST-001', 'COM-BD1-U', '2026-04-07', 'AUSENTE', NULL, 'Lic. Mariana Peralta')
  `);

  // 15. Mesas de Examen Final
  runQuery(`
    INSERT OR REPLACE INTO examenes (id, materia_id, fecha, hora, turno_examen, llamado, aula_id, tribunal, periodo_inscripcion_desde, periodo_inscripcion_hasta, estado) VALUES
    ('EXA-LSI-201-1', 'MAT-LSI-201', '2026-07-06', '09:00', 'Turno Julio 2026', 1, 'AULA-204', 'Rossi (Pres.), Peralta (Voc. 1), Méndez (Voc. 2)', '2026-06-20', '2026-07-02', 'ABIERTO'),
    ('EXA-LSI-202-1', 'MAT-LSI-202', '2026-07-09', '14:00', 'Turno Julio 2026', 1, 'AULA-101', 'Peralta (Pres.), Rossi (Voc. 1), Fontanarrosa (Voc. 2)', '2026-06-20', '2026-07-05', 'ABIERTO'),
    ('EXA-LSI-203-1', 'MAT-LSI-203', '2026-07-13', '08:30', 'Turno Julio 2026', 1, 'AUD-01', 'Fontanarrosa (Pres.), Méndez (Voc. 1), Rossi (Voc. 2)', '2026-06-20', '2026-07-09', 'ABIERTO'),
    ('EXA-DER-101-1', 'MAT-DER-101', '2026-07-10', '10:00', 'Turno Julio 2026', 1, 'AUD-01', 'Morales (Pres.), Vázquez (Voc. 1)', '2026-06-20', '2026-07-07', 'ABIERTO'),
    ('EXA-BIO-101-1', 'MAT-BIO-101', '2026-07-15', '08:30', 'Turno Julio 2026', 1, 'LAB-01', 'Bianchi (Pres.), Rossi (Voc. 1)', '2026-06-20', '2026-07-11', 'ABIERTO')
  `);

  // 16. Eventos de Calendario Institucional
  runQuery(`
    INSERT OR REPLACE INTO eventos_calendario (id, titulo, descripcion, tipo, fecha_inicio, fecha_fin, carrera_id, fuente_id) VALUES
    ('EVT-01', 'Día Internacional de los Trabajadores', 'Feriado Nacional inamovible', 'FERIADO', '2026-05-01', '2026-05-01', NULL, 'FTE-CON-01'),
    ('EVT-02', 'Día de la Revolución de Mayo', 'Feriado Nacional inamovible', 'FERIADO', '2026-05-25', '2026-05-25', NULL, 'FTE-CON-01'),
    ('EVT-03', 'Período de Primeros Parciales del 1C', 'Semana de evaluaciones parciales y entrega de trabajos prácticos', 'PARCIAL', '2026-05-18', '2026-05-29', 'CAR-LSI', 'FTE-BED-01'),
    ('EVT-04', 'Inscripción a Mesas de Examen Turno Julio', 'Habilitación del sistema de autogestión para exámenes finales', 'INSCRIPCION', '2026-06-20', '2026-07-02', 'CAR-LSI', 'FTE-BED-01'),
    ('EVT-05', 'Receso Invernal Académico', 'Suspensión de actividades docentes y administrativas ordinarias', 'ACADEMICO', '2026-07-13', '2026-07-24', NULL, 'FTE-CON-01'),
    ('EVT-06', 'Turno Ordinario de Exámenes Finales de Julio', 'Llamados generales para todas las carreras y facultades', 'FINAL', '2026-07-06', '2026-07-18', NULL, 'FTE-BED-01')
  `);

  // 17. Limpieza de avisos basura de test anteriores
  runQuery("DELETE FROM avisos WHERE titulo LIKE '%Aviso Test%' OR titulo LIKE '%Título de Prueba%'");
  runQuery("DELETE FROM aviso_versiones WHERE titulo LIKE '%Aviso Test%' OR titulo LIKE '%Título de Prueba%'");

  // 18. Avisos Institucionales Oficiales
  runQuery(`
    INSERT OR REPLACE INTO avisos (id, titulo, contenido, categoria, destinatarios, carrera_id, anio_carrera, fecha_publicacion, fecha_vencimiento, estado, version, fuente_id, documento_adjunto_nombre, autor_id) VALUES
    ('NOT-01', 'Cronograma Oficial de Mesas de Examen Turno Mayo 2026', 'Se informa a la comunidad estudiantil que se encuentra publicado el cronograma oficial de mesas de exámenes finales correspondientes al turno especial de mayo. Las inscripciones se realizan exclusivamente a través del módulo Exámenes hasta 48 horas hábiles antes de cada fecha fijada.', 'ACADEMICO', 'TODOS', 'CAR-LSI', NULL, '2026-04-10', '2026-05-30', 'PUBLICADO', 1, 'FTE-BED-01', 'cronograma-examenes-mayo-2026.pdf', 'USR-BED-01'),
    ('NOT-02', 'Reubicación temporal de clases prácticas en Laboratorio 1', 'Debido a tareas de actualización del cableado estructurado y servidores en el Laboratorio 2, las clases prácticas de Programación Orientada a Objetos y Base de Datos I se dictarán en el Laboratorio 1 en los horarios habituales durante las próximas dos semanas.', 'ACADEMICO', 'ESTUDIANTES', 'CAR-LSI', 2, '2026-04-15', '2026-05-20', 'PUBLICADO', 1, 'FTE-BED-01', NULL, 'USR-BED-01'),
    ('NOT-03', 'Convocatoria a Pasantías de Desarrollo de Software 2026', 'La Secretaría de Vinculación Tecnológica convoca a estudiantes de 2° año en adelante para pasantías formativas en el Parque Tecnológico del Litoral. Requisitos: tener aprobado 1° año completo y regularizadas materias troncales.', 'INSTITUCIONAL', 'ESTUDIANTES', 'CAR-LSI', 2, '2026-04-22', '2026-05-15', 'PUBLICADO', 1, 'FTE-BED-01', 'bases-pasantias-2026.pdf', 'USR-BED-01'),
    ('NOT-04', 'Período de Solicitud de Ayuda Económica 2025 (Cerrado)', 'Convocatoria finalizada para presentación de antecedentes y documentación socioeconómica del ciclo 2025.', 'ADMINISTRATIVO', 'TODOS', NULL, NULL, '2025-03-01', '2025-04-15', 'VENCIDO', 1, 'FTE-ADM-01', NULL, 'USR-BED-01'),
    ('NOT-05', 'Apertura de Inscripciones a Comisiones del 2° Cuatrimestre 2026', 'Bedelía informa que del 15 de junio al 10 de julio permanecerá habilitada la selección de comisiones y turnos para las asignaturas del segundo ciclo lectivo.', 'ACADEMICO', 'ESTUDIANTES', NULL, NULL, '2026-05-01', '2026-07-15', 'PUBLICADO', 1, 'FTE-BED-01', NULL, 'USR-BED-01'),
    ('NOT-06', 'Resolución CS N° 55/2026: Homologación del Plan de Bioinformática', 'El Consejo Superior de la UCSF aprobó la creación y puesta en marcha del nuevo Plan de Estudios para la Licenciatura en Bioinformática con validez ministerial.', 'INSTITUCIONAL', 'TODOS', 'CAR-BIO', 1, '2026-03-10', '2026-12-31', 'PUBLICADO', 1, 'FTE-ADM-01', 'resolucion-cs-55-2026.pdf', 'USR-ADM-01'),
    ('NOT-07', 'Actualización Arancelaria y Cronograma de Vencimientos Ciclo 2026', 'Secretaría Administrativa recuerda las fechas límite de pago para evitar recargos administrativos y los canales de débito automático y transferencias habilitados.', 'ADMINISTRATIVO', 'TODOS', NULL, NULL, '2026-04-01', '2026-08-30', 'PUBLICADO', 1, 'FTE-ADM-01', NULL, 'USR-ADM-01')
  `);

  // 19. Versiones de Avisos
  runQuery(`
    INSERT OR REPLACE INTO aviso_versiones (id, aviso_id, version, titulo, contenido, categoria, motivo_cambio, autor_id, snapshot_json) VALUES
    ('VER-01', 'NOT-01', 1, 'Cronograma Oficial de Mesas de Examen Turno Mayo 2026', 'Se informa a la comunidad estudiantil que se encuentra publicado el cronograma...', 'ACADEMICO', 'Publicación inicial oficial', 'USR-BED-01', '{"version":1,"estado":"PUBLICADO"}'),
    ('VER-02', 'NOT-02', 1, 'Reubicación temporal de clases prácticas en Laboratorio 1', 'Debido a tareas de actualización del cableado estructurado...', 'ACADEMICO', 'Publicación de cambio transitorio', 'USR-BED-01', '{"version":1,"estado":"PUBLICADO"}'),
    ('VER-03', 'NOT-03', 1, 'Convocatoria a Pasantías de Desarrollo de Software 2026', 'La Secretaría de Vinculación convoca a estudiantes...', 'INSTITUCIONAL', 'Lanzamiento oficial', 'USR-BED-01', '{"version":1,"estado":"PUBLICADO"}'),
    ('VER-05', 'NOT-05', 1, 'Apertura de Inscripciones a Comisiones del 2° Cuatrimestre 2026', 'Bedelía informa que del 15 de junio al 10 de julio...', 'ACADEMICO', 'Publicación operativa de comisiones', 'USR-BED-01', '{"version":1,"estado":"PUBLICADO"}'),
    ('VER-06', 'NOT-06', 1, 'Resolución CS N° 55/2026: Homologación del Plan de Bioinformática', 'El Consejo Superior de la UCSF aprobó la creación...', 'INSTITUCIONAL', 'Aprobación oficial', 'USR-ADM-01', '{"version":1,"estado":"PUBLICADO"}'),
    ('VER-07', 'NOT-07', 1, 'Actualización Arancelaria y Cronograma de Vencimientos Ciclo 2026', 'Secretaría Administrativa recuerda las fechas límite...', 'ADMINISTRATIVO', 'Calendario de aranceles', 'USR-ADM-01', '{"version":1,"estado":"PUBLICADO"}')
  `);

  // 20. Cuotas y Finanzas
  runQuery(`
    INSERT OR REPLACE INTO cuotas (id, estudiante_id, periodo, concepto, monto, fecha_vencimiento, estado) VALUES
    ('CUO-EST1-03', 'EST-001', '2026-03', 'Arancel Mensual Ciclo 2026 - Cuota 1', 85000.0, '2026-03-15', 'PAGADA'),
    ('CUO-EST1-04', 'EST-001', '2026-04', 'Arancel Mensual Ciclo 2026 - Cuota 2', 85000.0, '2026-04-15', 'PAGADA'),
    ('CUO-EST1-05', 'EST-001', '2026-05', 'Arancel Mensual Ciclo 2026 - Cuota 3', 89500.0, '2026-05-15', 'PENDIENTE'),
    ('CUO-EST1-06', 'EST-001', '2026-06', 'Arancel Mensual Ciclo 2026 - Cuota 4', 89500.0, '2026-06-15', 'PENDIENTE'),
    ('CUO-EST2-03', 'EST-TEST-REG-01', '2026-03', 'Arancel Mensual Ciclo 2026 - Cuota 1', 85000.0, '2026-03-15', 'PAGADA'),
    ('CUO-EST2-04', 'EST-TEST-REG-01', '2026-04', 'Arancel Mensual Ciclo 2026 - Cuota 2', 85000.0, '2026-04-15', 'PENDIENTE'),
    ('CUO-EST3-03', 'EST-BIO-01', '2026-03', 'Arancel Mensual Ciclo 2026 - Cuota 1', 85000.0, '2026-03-15', 'PAGADA'),
    ('CUO-EST3-04', 'EST-BIO-01', '2026-04', 'Arancel Mensual Ciclo 2026 - Cuota 2', 85000.0, '2026-04-15', 'PENDIENTE'),
    ('CUO-EST4-03', 'EST-DER-01', '2026-03', 'Arancel Mensual Ciclo 2026 - Cuota 1', 85000.0, '2026-03-15', 'PAGADA'),
    ('CUO-EST4-04', 'EST-DER-01', '2026-04', 'Arancel Mensual Ciclo 2026 - Cuota 2', 85000.0, '2026-04-15', 'PENDIENTE')
  `);

  // 21. Solicitudes de Certificados
  runQuery(`
    INSERT OR REPLACE INTO solicitudes_certificado (id, estudiante_id, tipo_certificado, lugar_presentacion, observacion, estado, responsable_id) VALUES
    ('SOL-01', 'EST-001', 'ALUMNO_REGULAR', 'Empresa de Transporte Interurbano', 'Para renovación de abono estudiantil 2026', 'EN_PROCESO', 'USR-ADM-01'),
    ('SOL-02', 'EST-TEST-REG-01', 'EXAMEN_RENDIDO', 'Obra Social y Empleador', 'Constancia de examen parcial rendido', 'LISTA', 'USR-BED-01')
  `);

  // 22. Actas Oficiales (Stage 7)
  runQuery(`
    INSERT OR REPLACE INTO actas_oficiales (
      id, tipo, materia_id, comision_id, examen_id, numero_acta, libro, folio,
      ciclo_lectivo, fecha_cierre, presidente_tribunal, vocal_1, vocal_2,
      total_inscriptos, total_aprobados, total_desaprobados, total_ausentes,
      hash_verificacion, estado
    ) VALUES
    (
      'ACTA-2026-001', 'EXAMEN_FINAL', 'MAT-POO', NULL, 'EXA-POO-1',
      'ACT-2026-EX-0089', 'LIBRO-XXIV-SISTEMAS', 'FOLIO-142',
      2026, '2026-05-18', 'Ing. Martín Berro', 'Dra. Florencia Bianchi', 'Lic. Andrea Toledo',
      25, 20, 3, 2,
      'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855', 'FIRMADA'
    ),
    (
      'ACTA-2026-002', 'REGULARIDAD_CURSADA', 'MAT-BD1', 'COM-BD1-A', NULL,
      'ACT-2026-REG-0112', 'LIBRO-XXIV-SISTEMAS', 'FOLIO-143',
      2026, '2026-06-30', 'Lic. Laura Benítez', 'Ing. Martín Berro', NULL,
      30, 26, 4, 0,
      'a591a6d40bf420404a011733cfb7b190d62c65bf0bcda32b57b277d9ad9f146e', 'CERRADA'
    )
  `);

  // 23. Verificaciones Criptográficas de Documentos (Stage 7)
  runQuery(`
    INSERT OR REPLACE INTO verificaciones_documentos (
      id, codigo_seguridad, tipo_documento, referencia_id, estudiante_id,
      hash_sha256, emisor_rol, emisor_nombre, fecha_emision, valido_hasta,
      estado, detalles_json
    ) VALUES
    (
      'VERIF-001', 'UCSF-CERT-2026-8841', 'CERTIFICADO_REGULAR', 'SOL-01', 'EST-001',
      '7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069',
      'ADMINISTRACION', 'Cdor. Carlos Alberto Méndez', '2026-03-20', '2026-06-30',
      'VALIDO', '{"estudiante":"Lucía Belén Gómez","matricula":"A-2026-001","carrera":"Licenciatura en Sistemas de Información"}'
    ),
    (
      'VERIF-002', 'UCSF-ACTA-2026-1049', 'ACTA_EXAMEN', 'ACTA-2026-001', NULL,
      'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
      'BEDELIA', 'Dra. María Elena Vázquez', '2026-05-18', NULL,
      'VALIDO', '{"acta":"ACT-2026-EX-0089","libro":"LIBRO-XXIV-SISTEMAS","folio":"FOLIO-142","materia":"Programación Orientada a Objetos"}'
    )
  `);

  // 24. Preferencias de Usuario (Stage 7)
  runQuery(`
    INSERT OR REPLACE INTO preferencias_usuario (
      id, usuario_id, notif_email_avisos, notif_email_cuotas,
      notif_email_cambio_aula, notif_email_calificaciones, tema_visual, resumen_semanal
    ) VALUES
    ('PREF-EST-01', 'USR-EST-01', 1, 1, 1, 1, 'SISTEMA', 1),
    ('PREF-BED-01', 'USR-BED-01', 1, 0, 1, 0, 'SISTEMA', 1),
    ('PREF-ADM-01', 'USR-ADM-01', 0, 1, 0, 0, 'SISTEMA', 0)
  `);

  // 25. Tickets de Soporte y Mesa de Entradas (Stage 8)
  runQuery(`
    INSERT OR REPLACE INTO tickets_soporte (
      id, estudiante_id, numero_ticket, categoria, prioridad, asunto, mensaje,
      estado, respuesta, respondido_por, fecha_respuesta
    ) VALUES
    (
      'TCK-001', 'EST-001', 'TICK-2026-8812', 'ACADEMICA', 'MEDIA',
      'Consulta sobre correlatividad de Bases de Datos I con Programación II',
      'Buenas tardes, quisiera consultar si habiendo regularizado Algoritmos puedo inscribirme en la comisión de BD1 del 2° cuatrimestre.',
      'RESPONDIDO',
      'Estimada Lucía, según el Plan 2023 vigente de LSI, habiendo obtenido la regularidad de Algoritmos puedes inscribirte a cursar BD1. Saludos cordiales.',
      'Dra. María Elena Vázquez (Bedelía)', '2026-04-12'
    ),
    (
      'TCK-002', 'EST-001', 'TICK-2026-9041', 'ARANCELES', 'ALTA',
      'Acreditación de pago de arancel cuota 2 por transferencia CBU',
      'Adjunto comprobante de pago de la cuota 2 realizado el día 14/04. Aún figura pendiente en el portal.',
      'ABIERTO', NULL, NULL, NULL
    )
  `);

  // 26. Repositorio Documental Oficial (Stage 8)
  runQuery(`
    INSERT OR REPLACE INTO documentos_repositorio (
      id, titulo, categoria, carrera_id, materia_id, archivo_nombre, tamanio_kb, hash_sha256
    ) VALUES
    (
      'DOC-REP-01', 'Reglamento Académico General UCSF 2026', 'REGLAMENTO', NULL, NULL,
      'Reglamento_Academico_General_UCSF_2026.pdf', 340,
      'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
    ),
    (
      'DOC-REP-02', 'Programa de Cátedra: Programación Orientada a Objetos 2026', 'PROGRAMA_MATERIA', 'CAR-LSI', 'MAT-POO',
      'Programa_Oficial_POO_2026_LSI.pdf', 220,
      '5d41402abc4b2a76b9719d911017c592b0c44298fc1c149afbf4c8996fb92427'
    ),
    (
      'DOC-REP-03', 'Resolución Rectoral N° 108/2022: Plan de Estudios LSI', 'RESOLUCION', 'CAR-LSI', NULL,
      'Resolucion_Rectoral_108_2022_Plan_LSI.pdf', 510,
      'a591a6d40bf420404a011733cfb7b190d62c65bf0bcda32b57b277d9ad9f146e'
    ),
    (
      'DOC-REP-04', 'Formulario Oficial de Solicitud de Excepción de Correlatividad', 'FORMULARIO', NULL, NULL,
      'Formulario_Excepcion_Correlatividades_UCSF.pdf', 120,
      '7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069'
    )
  `);

  console.log('[SEED] Base de datos persistente restaurada e integrada con éxito.');
}
