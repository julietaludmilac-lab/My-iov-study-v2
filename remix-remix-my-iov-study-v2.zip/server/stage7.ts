import { Request, Response } from 'express';
import crypto from 'node:crypto';
import { queryOne, queryAll, runQuery } from './db.js';

// --- 1. ANALYTICS & MÉTRICAS ---

// Avance Académico del Estudiante (M7)
export function getStudentProgressAnalytics(req: Request, res: Response): void {
  const session = (req as any).session;

  const est = queryOne<{
    id: string;
    nombre_completo: string;
    carrera_id: string;
    plan_id: string;
    anio_cursado: number;
    carrera_nombre: string;
  }>(`
    SELECT e.id, e.nombre_completo, e.carrera_id, e.plan_id, e.anio_cursado, c.nombre as carrera_nombre
    FROM estudiantes e
    JOIN carreras c ON e.carrera_id = c.id
    WHERE e.usuario_id = ?
  `, [session.userId]);

  if (!est) {
    res.status(404).json({ error: 'Estudiante no encontrado.' });
    return;
  }

  // Materias del plan oficial
  const materiasPlan = queryAll<{
    id: string;
    codigo: string;
    nombre: string;
    anio: number;
    cuatrimestre: string;
    carga_horaria: number;
  }>('SELECT id, codigo, nombre, anio, cuatrimestre, carga_horaria FROM materias WHERE plan_id = ? ORDER BY anio, cuatrimestre', [est.plan_id]);

  // Calificaciones finales aprobadas (nota >= 4)
  const notasFinales = queryAll<{
    materia_id: string;
    nota: number;
    fecha: string;
    condicion: string;
  }>('SELECT materia_id, nota, fecha, condicion FROM calificaciones WHERE estudiante_id = ?', [est.id]);

  // Inscripciones a comisiones cursando actualmente
  const inscripcionesCursando = queryAll<{
    materia_id: string;
    estado: string;
  }>(`
    SELECT c.materia_id, i.estado
    FROM inscripciones i
    JOIN comisiones c ON i.comision_id = c.id
    WHERE i.estudiante_id = ? AND i.estado = 'CONFIRMADA'
  `, [est.id]);

  const materiasAprobadasIds = new Set(notasFinales.filter(n => (n.nota || 0) >= 4).map(n => n.materia_id));
  const materiasCursandoIds = new Set(inscripcionesCursando.map(i => i.materia_id));

  const totalMaterias = materiasPlan.length || 1;
  const cantidadAprobadas = materiasAprobadasIds.size;
  const cantidadCursando = materiasCursandoIds.size;
  const cantidadPendientes = Math.max(0, totalMaterias - cantidadAprobadas - cantidadCursando);

  const porcentajeAvance = Math.round((cantidadAprobadas / totalMaterias) * 100);

  // Cálculo de promedio oficial
  const sumaNotas = notasFinales.reduce((acc, curr) => acc + (curr.nota || 0), 0);
  const promedioGeneral = notasFinales.length > 0 ? parseFloat((sumaNotas / notasFinales.length).toFixed(2)) : 0;

  // Semáforo académico institucional
  let estadoSemaforo: 'OPTIMO' | 'REGULAR' | 'ATENCION' = 'OPTIMO';
  let mensajeSemaforo = 'Tu trayectoria académica avanza dentro de los plazos reglamentarios previstos.';

  if (porcentajeAvance < 25 && est.anio_cursado > 1) {
    estadoSemaforo = 'ATENCION';
    mensajeSemaforo = 'Se recomienda solicitar tutoría académica para regularizar materias correlativas pendientes.';
  } else if (porcentajeAvance < 50 && est.anio_cursado > 2) {
    estadoSemaforo = 'REGULAR';
    mensajeSemaforo = 'Buen avance. Recuerda planificar mesas de examen final para materias regulares.';
  }

  // Desglose por Año de Cursada
  const aniosAgrupados: Record<number, { anio: number; total: number; aprobadas: number; cursando: number; pendientes: number }> = {};
  for (const mat of materiasPlan) {
    if (!aniosAgrupados[mat.anio]) {
      aniosAgrupados[mat.anio] = { anio: mat.anio, total: 0, aprobadas: 0, cursando: 0, pendientes: 0 };
    }
    aniosAgrupados[mat.anio].total++;
    if (materiasAprobadasIds.has(mat.id)) {
      aniosAgrupados[mat.anio].aprobadas++;
    } else if (materiasCursandoIds.has(mat.id)) {
      aniosAgrupados[mat.anio].cursando++;
    } else {
      aniosAgrupados[mat.anio].pendientes++;
    }
  }

  res.json({
    ok: true,
    estudiante: {
      id: est.id,
      nombre: est.nombre_completo,
      carrera: est.carrera_nombre,
      anioCursado: est.anio_cursado,
    },
    resumen: {
      totalMaterias,
      cantidadAprobadas,
      cantidadCursando,
      cantidadPendientes,
      porcentajeAvance,
      promedioGeneral,
      estadoSemaforo,
      mensajeSemaforo,
      cuatrimestresEstimadosRestantes: Math.ceil((totalMaterias - cantidadAprobadas) / 3),
    },
    desgloseAnios: Object.values(aniosAgrupados),
  });
}

// Métricas y KPIs de Bedelía (Ocupación, Inasistencias y Mesas)
export function getBedeliaKPIs(req: Request, res: Response): void {
  // 1. Ocupación de Comisiones
  const comisiones = queryAll<{
    id: string;
    materia_nombre: string;
    codigo_comision: string;
    cupo_maximo: number;
    turno: string;
  }>(`
    SELECT c.id, m.nombre as materia_nombre, c.codigo_comision, c.cupo_maximo, c.turno
    FROM comisiones c
    JOIN materias m ON c.materia_id = m.id
  `);

  const totalComisiones = comisiones.length;
  let totalCupos = 0;
  let totalInscriptos = 0;

  const comisionesDetalle = comisiones.map((com) => {
    const inscriptos = queryOne<{ count: number }>(
      "SELECT COUNT(*) as count FROM inscripciones WHERE comision_id = ? AND estado = 'CONFIRMADA'",
      [com.id]
    )?.count || 0;

    totalCupos += com.cupo_maximo;
    totalInscriptos += inscriptos;

    const porcentajeOcupacion = com.cupo_maximo > 0 ? Math.round((inscriptos / com.cupo_maximo) * 100) : 0;
    return {
      id: com.id,
      materia: com.materia_nombre,
      comision: com.codigo_comision,
      turno: com.turno,
      cupoMaximo: com.cupo_maximo,
      inscriptos,
      porcentajeOcupacion,
      estadoCupo: porcentajeOcupacion >= 90 ? 'ALTA_DEMANDA' : porcentajeOcupacion <= 30 ? 'BAJA_OCUPACION' : 'NORMAL',
    };
  });

  const ocupacionPromedioGlobal = totalCupos > 0 ? Math.round((totalInscriptos / totalCupos) * 100) : 0;

  // 2. Alumnos en Riesgo por Asistencia (< 75%)
  const estudiantesAsistencia = queryAll<{
    estudiante_id: string;
    estudiante_nombre: string;
    comision_id: string;
    materia_nombre: string;
    total_clases: number;
    presentes: number;
    ausentes: number;
  }>(`
    SELECT 
      e.id as estudiante_id,
      e.nombre_completo as estudiante_nombre,
      c.id as comision_id,
      m.nombre as materia_nombre,
      COUNT(a.id) as total_clases,
      SUM(CASE WHEN a.estado = 'PRESENTE' THEN 1 ELSE 0 END) as presentes,
      SUM(CASE WHEN a.estado = 'AUSENTE' THEN 1 ELSE 0 END) as ausentes
    FROM asistencia a
    JOIN estudiantes e ON a.estudiante_id = e.id
    JOIN comisiones c ON a.comision_id = c.id
    JOIN materias m ON c.materia_id = m.id
    GROUP BY e.id, c.id
  `);

  const alumnosEnRiesgo = estudiantesAsistencia
    .map((r) => {
      const porcentajeInasistencia = r.total_clases > 0 ? (r.ausentes / r.total_clases) * 100 : 0;
      return {
        ...r,
        porcentajeInasistencia: parseFloat(porcentajeInasistencia.toFixed(1)),
        enRiesgo: porcentajeInasistencia > 25.0,
      };
    })
    .filter((r) => r.enRiesgo);

  // 3. Resumen de Actas y Mesas de Examen
  const totalActas = queryOne<{ count: number }>('SELECT COUNT(*) as count FROM actas_oficiales')?.count || 0;
  const actasFirmadas = queryOne<{ count: number }>("SELECT COUNT(*) as count FROM actas_oficiales WHERE estado IN ('FIRMADA', 'CERRADA')")?.count || 0;

  res.json({
    ok: true,
    resumen: {
      totalComisiones,
      totalCupos,
      totalInscriptos,
      ocupacionPromedioGlobal,
      cantidadAlumnosEnRiesgo: alumnosEnRiesgo.length,
      totalActas,
      actasFirmadas,
    },
    comisiones: comisionesDetalle,
    alumnosEnRiesgo,
  });
}

// Métricas y KPIs de Administración (Aranceles, Recaudación y Cobranzas)
export function getAdminFinanceKPIs(req: Request, res: Response): void {
  const cuotas = queryAll<{
    id: string;
    estado: string;
    monto: number;
    periodo: string;
  }>('SELECT id, estado, monto, periodo FROM cuotas');

  let recaudacionTotal = 0;
  let montoEnMora = 0;
  let pagadasCount = 0;
  let pendientesCount = 0;

  for (const c of cuotas) {
    if (c.estado === 'PAGADA') {
      recaudacionTotal += c.monto;
      pagadasCount++;
    } else {
      montoEnMora += c.monto;
      pendientesCount++;
    }
  }

  const totalCuotas = cuotas.length || 1;
  const tasaCobranza = Math.round((pagadasCount / totalCuotas) * 100);

  // Distribución por Período
  const porPeriodo: Record<string, { periodo: string; recaudado: number; pendiente: number }> = {};
  for (const c of cuotas) {
    if (!porPeriodo[c.periodo]) {
      porPeriodo[c.periodo] = { periodo: c.periodo, recaudado: 0, pendiente: 0 };
    }
    if (c.estado === 'PAGADA') {
      porPeriodo[c.periodo].recaudado += c.monto;
    } else {
      porPeriodo[c.periodo].pendiente += c.monto;
    }
  }

  res.json({
    ok: true,
    kpis: {
      totalCuotas: cuotas.length,
      pagadasCount,
      pendientesCount,
      recaudacionTotal,
      montoEnMora,
      tasaCobranza,
    },
    distribucionPeriodo: Object.values(porPeriodo),
  });
}

// --- 2. ACTAS OFICIALES (LIBRO / FOLIO / HASH CRIPTOGRÁFICO) ---

// Listado de Actas Oficiales
export function getActasOficiales(req: Request, res: Response): void {
  const { tipo, estado } = req.query;

  let sql = `
    SELECT 
      a.*,
      m.nombre as materia_nombre,
      m.codigo as materia_codigo
    FROM actas_oficiales a
    JOIN materias m ON a.materia_id = m.id
    WHERE 1=1
  `;
  const params: any[] = [];

  if (tipo) {
    sql += ' AND a.tipo = ?';
    params.push(String(tipo));
  }
  if (estado) {
    sql += ' AND a.estado = ?';
    params.push(String(estado));
  }

  sql += ' ORDER BY a.created_at DESC';
  const actas = queryAll(sql, params);

  res.json({ ok: true, actas });
}

// Generación de Acta Oficial con Tomo, Folio y Libro
export function generarActaOficial(req: Request, res: Response): void {
  const session = (req as any).session;
  const {
    tipo,
    materiaId,
    comisionId,
    examenId,
    libro,
    folio,
    presidenteTribunal,
    vocal1,
    vocal2,
    totalInscriptos,
    totalAprobados,
    totalDesaprobados,
    totalAusentes,
  } = req.body || {};

  if (!tipo || !materiaId || !libro || !folio || !presidenteTribunal) {
    res.status(400).json({ error: 'Tipo, materia, libro, folio y presidente del tribunal son obligatorios.' });
    return;
  }

  const materia = queryOne<{ codigo: string; nombre: string }>('SELECT codigo, nombre FROM materias WHERE id = ?', [materiaId]);
  if (!materia) {
    res.status(404).json({ error: 'Materia no encontrada.' });
    return;
  }

  const anio = new Date().getFullYear();
  const sufijo = tipo === 'EXAMEN_FINAL' ? 'EX' : 'REG';
  const randomCorrelativo = Math.floor(1000 + Math.random() * 9000);
  const numeroActa = `ACT-${anio}-${sufijo}-${randomCorrelativo}`;
  const actaId = `ACTA-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;

  // Generar hash criptográfico de integridad SHA-256
  const dataToHash = `${numeroActa}|${libro}|${folio}|${materiaId}|${totalAprobados || 0}|${presidenteTribunal}|${new Date().toISOString()}`;
  const hashVerificacion = crypto.createHash('sha256').update(dataToHash).digest('hex');

  runQuery(`
    INSERT INTO actas_oficiales (
      id, tipo, materia_id, comision_id, examen_id, numero_acta, libro, folio,
      ciclo_lectivo, fecha_cierre, presidente_tribunal, vocal_1, vocal_2,
      total_inscriptos, total_aprobados, total_desaprobados, total_ausentes,
      hash_verificacion, estado
    ) VALUES (
      ?, ?, ?, ?, ?, ?, ?, ?,
      ?, date('now'), ?, ?, ?,
      ?, ?, ?, ?,
      ?, 'GENERADA'
    )
  `, [
    actaId, tipo, materiaId, comisionId || null, examenId || null, numeroActa, libro.trim(), folio.trim(),
    anio, presidenteTribunal.trim(), vocal1?.trim() || null, vocal2?.trim() || null,
    totalInscriptos || 0, totalAprobados || 0, totalDesaprobados || 0, totalAusentes || 0,
    hashVerificacion,
  ]);

  // Registro en Verificaciones Públicas
  const codigoSeguridad = `UCSF-ACT-${anio}-${randomCorrelativo}`;
  runQuery(`
    INSERT INTO verificaciones_documentos (
      id, codigo_seguridad, tipo_documento, referencia_id, estudiante_id,
      hash_sha256, emisor_rol, emisor_nombre, fecha_emision, valido_hasta,
      estado, detalles_json
    ) VALUES (?, ?, 'ACTA_EXAMEN', ?, NULL, ?, 'BEDELIA', ?, date('now'), NULL, 'VALIDO', ?)
  `, [
    crypto.randomUUID(),
    codigoSeguridad,
    actaId,
    hashVerificacion,
    session.nombre,
    JSON.stringify({
      numeroActa,
      materia: materia.nombre,
      libro,
      folio,
      presidenteTribunal,
      aprobados: totalAprobados || 0,
    }),
  ]);

  // Auditoría
  runQuery(`
    INSERT INTO auditoria (id, actor_id, actor_rol, accion, recurso, recurso_id, resultado, correlation_id)
    VALUES (?, ?, 'BEDELIA', 'CREATE', 'actas_oficiales', ?, 'EXITO', ?)
  `, [crypto.randomUUID(), session.userId, actaId, crypto.randomUUID()]);

  res.json({
    ok: true,
    actaId,
    numeroActa,
    codigoSeguridad,
    hashVerificacion,
    message: `Acta oficial ${numeroActa} generada con Libro ${libro} y Folio ${folio}.`,
  });
}

// Cierre y Firma Digital de Acta Oficial
export function firmarActaOficial(req: Request, res: Response): void {
  const session = (req as any).session;
  const { id } = req.params;

  const acta = queryOne<{ id: string; numero_acta: string; estado: string }>('SELECT id, numero_acta, estado FROM actas_oficiales WHERE id = ?', [id]);
  if (!acta) {
    res.status(404).json({ error: 'Acta no encontrada.' });
    return;
  }

  if (acta.estado === 'CERRADA') {
    res.status(400).json({ error: 'El acta ya se encuentra cerrada y no admite modificaciones.' });
    return;
  }

  runQuery("UPDATE actas_oficiales SET estado = 'FIRMADA', updated_at = datetime('now') WHERE id = ?", [id]);

  res.json({
    ok: true,
    message: `Acta ${acta.numero_acta} firmada oficialmente y asentada en el libro reglamentario.`,
  });
}

// --- 3. VERIFICACIÓN CRIPTOGRÁFICA PÚBLICA DE DOCUMENTOS (QR / HASH) ---

export function verifyDocumentoPublico(req: Request, res: Response): void {
  const { codigo } = req.params;

  if (!codigo || codigo.trim().length === 0) {
    res.status(400).json({ error: 'Código o hash de verificación requerido.' });
    return;
  }

  const term = codigo.trim();
  const verif = queryOne<{
    id: string;
    codigo_seguridad: string;
    tipo_documento: string;
    hash_sha256: string;
    emisor_rol: string;
    emisor_nombre: string;
    fecha_emision: string;
    valido_hasta: string | null;
    estado: string;
    detalles_json: string;
  }>(`
    SELECT * FROM verificaciones_documentos
    WHERE codigo_seguridad = ? OR hash_sha256 = ?
  `, [term, term]);

  if (!verif) {
    res.status(404).json({
      autentico: false,
      error: 'El código de seguridad o hash proporcionado no figura en el registro oficial de la Universidad Católica de Santa Fe.',
    });
    return;
  }

  let detalles: any = {};
  try {
    detalles = JSON.parse(verif.detalles_json);
  } catch {}

  res.json({
    autentico: true,
    codigoSeguridad: verif.codigo_seguridad,
    tipoDocumento: verif.tipo_documento,
    emisor: {
      rol: verif.emisor_rol,
      nombre: verif.emisor_nombre,
    },
    fechaEmision: verif.fecha_emision,
    validoHasta: verif.valido_hasta || 'Sin caducidad',
    estado: verif.estado,
    hashSha256: verif.hash_sha256,
    detalles,
    institucion: 'Universidad Católica de Santa Fe (UCSF)',
  });
}

// --- 4. EXPORTACIÓN SEGURA (CSV CON PROTECCIÓN DE FORMULAS / JSON) ---

export function exportDataHandler(req: Request, res: Response): void {
  const { tipo } = req.params;
  const { formato } = req.query; // 'csv' o 'json'

  // Función de sanitización contra inyección de fórmulas CSV (CWE-1236)
  const sanitizeCsvValue = (val: any): string => {
    if (val === null || val === undefined) return '';
    let str = String(val).trim();
    if (/^[=+\-@\t\r]/.test(str)) {
      str = "'" + str; // Prefijo de comilla simple para neutralizar ejecución
    }
    if (str.includes(',') || str.includes('"') || str.includes('\n')) {
      str = `"${str.replace(/"/g, '""')}"`;
    }
    return str;
  };

  if (tipo === 'actas') {
    const actas = queryAll(`
      SELECT a.numero_acta, a.tipo, m.nombre as materia, a.libro, a.folio,
             a.ciclo_lectivo, a.fecha_cierre, a.presidente_tribunal,
             a.total_inscriptos, a.total_aprobados, a.total_desaprobados, a.estado
      FROM actas_oficiales a
      JOIN materias m ON a.materia_id = m.id
      ORDER BY a.numero_acta DESC
    `);

    if (formato === 'json') {
      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', 'attachment; filename="actas_oficiales_ucsf.json"');
      res.json({ actas });
      return;
    }

    const headers = ['Numero_Acta', 'Tipo', 'Materia', 'Libro', 'Folio', 'Ciclo', 'Fecha_Cierre', 'Presidente', 'Inscriptos', 'Aprobados', 'Desaprobados', 'Estado'];
    const rows = actas.map((a: any) => [
      sanitizeCsvValue(a.numero_acta),
      sanitizeCsvValue(a.tipo),
      sanitizeCsvValue(a.materia),
      sanitizeCsvValue(a.libro),
      sanitizeCsvValue(a.folio),
      sanitizeCsvValue(a.ciclo_lectivo),
      sanitizeCsvValue(a.fecha_cierre),
      sanitizeCsvValue(a.presidente_tribunal),
      sanitizeCsvValue(a.total_inscriptos),
      sanitizeCsvValue(a.total_aprobados),
      sanitizeCsvValue(a.total_desaprobados),
      sanitizeCsvValue(a.estado),
    ].join(','));

    const csvContent = [headers.join(','), ...rows].join('\n');
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="actas_oficiales_ucsf.csv"');
    res.send(csvContent);
    return;
  }

  if (tipo === 'estudiantes') {
    const estudiantes = queryAll(`
      SELECT e.nombre_completo, u.matricula, u.correo, c.nombre as carrera, e.anio_cursado, u.estado
      FROM estudiantes e
      JOIN usuarios u ON e.usuario_id = u.id
      JOIN carreras c ON e.carrera_id = c.id
      ORDER BY e.nombre_completo ASC
    `);

    if (formato === 'json') {
      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', 'attachment; filename="padron_estudiantes_ucsf.json"');
      res.json({ estudiantes });
      return;
    }

    const headers = ['Nombre_Completo', 'Matricula', 'Correo', 'Carrera', 'Anio_Cursado', 'Estado'];
    const rows = estudiantes.map((e: any) => [
      sanitizeCsvValue(e.nombre_completo),
      sanitizeCsvValue(e.matricula),
      sanitizeCsvValue(e.correo),
      sanitizeCsvValue(e.carrera),
      sanitizeCsvValue(e.anio_cursado),
      sanitizeCsvValue(e.estado),
    ].join(','));

    const csvContent = [headers.join(','), ...rows].join('\n');
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="padron_estudiantes_ucsf.csv"');
    res.send(csvContent);
    return;
  }

  if (tipo === 'aranceles') {
    const cuotas = queryAll(`
      SELECT c.periodo, c.concepto, c.monto, c.fecha_vencimiento, c.estado,
             e.nombre_completo as estudiante, u.matricula
      FROM cuotas c
      JOIN estudiantes e ON c.estudiante_id = e.id
      JOIN usuarios u ON e.usuario_id = u.id
      ORDER BY c.periodo DESC, c.fecha_vencimiento ASC
    `);

    if (formato === 'json') {
      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', 'attachment; filename="reporte_aranceles_ucsf.json"');
      res.json({ cuotas });
      return;
    }

    const headers = ['Periodo', 'Concepto', 'Monto', 'Vencimiento', 'Estado', 'Estudiante', 'Matricula'];
    const rows = cuotas.map((c: any) => [
      sanitizeCsvValue(c.periodo),
      sanitizeCsvValue(c.concepto),
      sanitizeCsvValue(c.monto),
      sanitizeCsvValue(c.fecha_vencimiento),
      sanitizeCsvValue(c.estado),
      sanitizeCsvValue(c.estudiante),
      sanitizeCsvValue(c.matricula),
    ].join(','));

    const csvContent = [headers.join(','), ...rows].join('\n');
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="reporte_aranceles_ucsf.csv"');
    res.send(csvContent);
    return;
  }

  res.status(400).json({ error: 'Tipo de exportación no soportado. Tipos válidos: actas, estudiantes, aranceles.' });
}

// --- 5. PREFERENCIAS DEL USUARIO ---

export function getUserPreferences(req: Request, res: Response): void {
  const session = (req as any).session;
  let pref = queryOne<{
    notif_email_avisos: number;
    notif_email_cuotas: number;
    notif_email_cambio_aula: number;
    notif_email_calificaciones: number;
    tema_visual: string;
    resumen_semanal: number;
  }>('SELECT * FROM preferencias_usuario WHERE usuario_id = ?', [session.userId]);

  if (!pref) {
    // Valores por defecto
    pref = {
      notif_email_avisos: 1,
      notif_email_cuotas: 1,
      notif_email_cambio_aula: 1,
      notif_email_calificaciones: 1,
      tema_visual: 'SISTEMA',
      resumen_semanal: 1,
    };
  }

  res.json({ ok: true, preferencias: pref });
}

export function updateUserPreferences(req: Request, res: Response): void {
  const session = (req as any).session;
  const {
    notifEmailAvisos,
    notifEmailCuotas,
    notifEmailCambioAula,
    notifEmailCalificaciones,
    temaVisual,
    resumenSemanal,
  } = req.body || {};

  const existing = queryOne('SELECT id FROM preferencias_usuario WHERE usuario_id = ?', [session.userId]);

  if (existing) {
    runQuery(`
      UPDATE preferencias_usuario
      SET notif_email_avisos = ?,
          notif_email_cuotas = ?,
          notif_email_cambio_aula = ?,
          notif_email_calificaciones = ?,
          tema_visual = ?,
          resumen_semanal = ?,
          updated_at = datetime('now')
      WHERE usuario_id = ?
    `, [
      notifEmailAvisos ? 1 : 0,
      notifEmailCuotas ? 1 : 0,
      notifEmailCambioAula ? 1 : 0,
      notifEmailCalificaciones ? 1 : 0,
      temaVisual || 'SISTEMA',
      resumenSemanal ? 1 : 0,
      session.userId,
    ]);
  } else {
    runQuery(`
      INSERT INTO preferencias_usuario (
        id, usuario_id, notif_email_avisos, notif_email_cuotas,
        notif_email_cambio_aula, notif_email_calificaciones, tema_visual, resumen_semanal
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      crypto.randomUUID(),
      session.userId,
      notifEmailAvisos ? 1 : 0,
      notifEmailCuotas ? 1 : 0,
      notifEmailCambioAula ? 1 : 0,
      notifEmailCalificaciones ? 1 : 0,
      temaVisual || 'SISTEMA',
      resumenSemanal ? 1 : 0,
    ]);
  }

  res.json({ ok: true, message: 'Preferencias guardadas exitosamente.' });
}
