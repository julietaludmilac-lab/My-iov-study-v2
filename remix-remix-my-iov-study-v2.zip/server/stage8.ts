import { Request, Response } from 'express';
import crypto from 'node:crypto';
import bcrypt from 'bcryptjs';
import { queryOne, queryAll, runQuery } from './db.js';

// --- 1. MESA DE AYUDA DIGITAL Y TICKETS DE SOPORTE ---

// Listado de tickets
export function getSupportTickets(req: Request, res: Response): void {
  const session = (req as any).session;
  const { estado, categoria } = req.query;

  if (session.rol === 'ESTUDIANTE') {
    const estudiante = queryOne<{ id: string }>('SELECT id FROM estudiantes WHERE usuario_id = ?', [session.userId]);
    if (!estudiante) {
      res.json({ ok: true, tickets: [] });
      return;
    }

    let sql = 'SELECT * FROM tickets_soporte WHERE estudiante_id = ?';
    const params: any[] = [estudiante.id];

    if (estado) {
      sql += ' AND estado = ?';
      params.push(String(estado));
    }

    sql += ' ORDER BY created_at DESC';
    const tickets = queryAll(sql, params);
    res.json({ ok: true, tickets });
    return;
  }

  // Para Bedelía y Administración: ver todos los tickets con datos del estudiante
  let sql = `
    SELECT 
      t.*,
      e.nombre_completo as estudiante_nombre,
      u.matricula as estudiante_matricula,
      u.correo as estudiante_correo,
      c.nombre as carrera_nombre
    FROM tickets_soporte t
    JOIN estudiantes e ON t.estudiante_id = e.id
    JOIN usuarios u ON e.usuario_id = u.id
    JOIN carreras c ON e.carrera_id = c.id
    WHERE 1=1
  `;
  const params: any[] = [];

  if (estado) {
    sql += ' AND t.estado = ?';
    params.push(String(estado));
  }
  if (categoria) {
    sql += ' AND t.categoria = ?';
    params.push(String(categoria));
  }

  sql += ' ORDER BY t.created_at DESC';
  const tickets = queryAll(sql, params);
  res.json({ ok: true, tickets });
}

// Crear nuevo ticket de soporte
export function createSupportTicket(req: Request, res: Response): void {
  const session = (req as any).session;
  const { categoria, prioridad, asunto, mensaje } = req.body || {};

  if (!categoria || !asunto?.trim() || !mensaje?.trim()) {
    res.status(400).json({ error: 'Categoría, asunto y descripción detallada son obligatorios.' });
    return;
  }

  const estudiante = queryOne<{ id: string }>('SELECT id FROM estudiantes WHERE usuario_id = ?', [session.userId]);
  if (!estudiante) {
    res.status(404).json({ error: 'Estudiante no encontrado en el padrón.' });
    return;
  }

  const randomNum = Math.floor(1000 + Math.random() * 9000);
  const numeroTicket = `TICK-${new Date().getFullYear()}-${randomNum}`;
  const ticketId = `TCK-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;

  runQuery(`
    INSERT INTO tickets_soporte (
      id, estudiante_id, numero_ticket, categoria, prioridad, asunto, mensaje, estado
    ) VALUES (
      ?, ?, ?, ?, ?, ?, ?, 'ABIERTO'
    )
  `, [
    ticketId,
    estudiante.id,
    numeroTicket,
    categoria,
    prioridad || 'MEDIA',
    asunto.trim(),
    mensaje.trim(),
  ]);

  // Auditoría
  runQuery(`
    INSERT INTO auditoria (id, actor_id, actor_rol, accion, recurso, recurso_id, resultado, correlation_id)
    VALUES (?, ?, 'ESTUDIANTE', 'CREATE', 'tickets_soporte', ?, 'EXITO', ?)
  `, [crypto.randomUUID(), session.userId, ticketId, crypto.randomUUID()]);

  res.json({
    ok: true,
    ticketId,
    numeroTicket,
    message: `Ticket oficial ${numeroTicket} registrado exitosamente. Nuestro equipo te responderá a la brevedad.`,
  });
}

// Responder y resolver ticket (Bedelía y Administración)
export function respondSupportTicket(req: Request, res: Response): void {
  const session = (req as any).session;
  const { id } = req.params;
  const { respuesta, nuevoEstado } = req.body || {};

  if (!respuesta?.trim()) {
    res.status(400).json({ error: 'Debe ingresar el texto de respuesta oficial.' });
    return;
  }

  const ticket = queryOne<{ id: string; numero_ticket: string }>('SELECT id, numero_ticket FROM tickets_soporte WHERE id = ?', [id]);
  if (!ticket) {
    res.status(404).json({ error: 'Ticket no encontrado.' });
    return;
  }

  const estadoFinal = nuevoEstado || 'RESPONDIDO';

  runQuery(`
    UPDATE tickets_soporte
    SET respuesta = ?,
        respondido_por = ?,
        fecha_respuesta = date('now'),
        estado = ?,
        updated_at = datetime('now')
    WHERE id = ?
  `, [
    respuesta.trim(),
    session.nombre,
    estadoFinal,
    id,
  ]);

  // Auditoría
  runQuery(`
    INSERT INTO auditoria (id, actor_id, actor_rol, accion, recurso, recurso_id, resultado, correlation_id)
    VALUES (?, ?, ?, 'UPDATE', 'tickets_soporte', ?, 'EXITO', ?)
  `, [crypto.randomUUID(), session.userId, session.rol, id, crypto.randomUUID()]);

  res.json({
    ok: true,
    message: `Ticket ${ticket.numero_ticket} respondido y actualizado a estado ${estadoFinal}.`,
  });
}

// --- 2. REPOSITORIO DOCUMENTAL OFICIAL ---

export function getRepositoryDocuments(req: Request, res: Response): void {
  const { categoria } = req.query;

  let sql = 'SELECT * FROM documentos_repositorio WHERE 1=1';
  const params: any[] = [];

  if (categoria) {
    sql += ' AND categoria = ?';
    params.push(String(categoria));
  }

  sql += ' ORDER BY created_at DESC';
  const documentos = queryAll(sql, params);

  res.json({ ok: true, documentos });
}

export function downloadRepositoryDocument(req: Request, res: Response): void {
  const { id } = req.params;

  const doc = queryOne<{
    id: string;
    titulo: string;
    archivo_nombre: string;
    categoria: string;
    hash_sha256: string;
  }>('SELECT * FROM documentos_repositorio WHERE id = ?', [id]);

  if (!doc) {
    res.status(404).json({ error: 'Documento no encontrado en el repositorio oficial.' });
    return;
  }

  // Generar contenido oficial simulado en texto/PDF plano
  const content = `UNIVERSIDAD CATÓLICA DE SANTA FE (UCSF)
DOCUMENTO REGLAMENTARIO OFICIAL
--------------------------------------------------
Título: ${doc.titulo}
Archivo: ${doc.archivo_nombre}
Categoría: ${doc.categoria}
Identificador Digital: ${doc.id}
Sello Criptográfico SHA-256: ${doc.hash_sha256}
Fecha de Emisión: 2026-03-01
Estado: VIGENTE Y HOMOLOGADO
--------------------------------------------------
Este documento cuenta con certificación electrónica institucional.
Para verificar su autenticidad consulte el portal oficial en /#exportaciones.`;

  res.setHeader('Content-Type', 'application/octet-stream');
  res.setHeader('Content-Disposition', `attachment; filename="${doc.archivo_nombre}"`);
  res.send(content);
}

// --- 3. SEGURIDAD DE CUENTA Y CAMBIO DE CLAVE CON BCRYPT ---

export function changeUserPassword(req: Request, res: Response): void {
  const session = (req as any).session;
  const { passwordActual, nuevaPassword, passwordNueva, confirmarPassword, passwordConfirmacion } = req.body || {};

  const actual = passwordActual;
  const nueva = nuevaPassword || passwordNueva;
  const confirmacion = confirmarPassword || passwordConfirmacion;

  if (!actual || !nueva || !confirmacion) {
    res.status(400).json({ error: 'Todos los campos son obligatorios.' });
    return;
  }

  if (nueva !== confirmacion) {
    res.status(400).json({ error: 'La nueva contraseña y su confirmación no coinciden.' });
    return;
  }

  if (nueva.length < 8) {
    res.status(400).json({ error: 'La nueva contraseña debe tener al menos 8 caracteres.' });
    return;
  }

  const usuario = queryOne<{ password_hash: string }>('SELECT password_hash FROM usuarios WHERE id = ?', [session.userId]);
  if (!usuario) {
    res.status(404).json({ error: 'Usuario no encontrado.' });
    return;
  }

  const coincideActual = bcrypt.compareSync(actual, usuario.password_hash);
  if (!coincideActual) {
    res.status(400).json({ error: 'La contraseña actual ingresada es incorrecta.' });
    return;
  }

  const salt = bcrypt.genSaltSync(10);
  const nuevoHash = bcrypt.hashSync(nueva, salt);

  runQuery("UPDATE usuarios SET password_hash = ?, updated_at = datetime('now') WHERE id = ?", [nuevoHash, session.userId]);

  // Auditoría
  runQuery(`
    INSERT INTO auditoria (id, actor_id, actor_rol, accion, recurso, resultado, detalles_json, correlation_id)
    VALUES (?, ?, ?, 'CHANGE_PASSWORD', 'usuarios', 'EXITO', '{"motivo":"Cambio voluntario de clave"}', ?)
  `, [crypto.randomUUID(), session.userId, session.rol, crypto.randomUUID()]);

  res.json({ ok: true, message: '¡Contraseña actualizada exitosamente!' });
}

// --- 4. OBSERVABILIDAD Y MÉTRICAS DE SALUD DEL SISTEMA (SLA & HEALTH) ---

export function getSystemHealthMetrics(req: Request, res: Response): void {
  const tables = queryAll<{ name: string }>(
    "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
  );

  const auditoriaCount = queryOne<{ count: number }>('SELECT COUNT(*) as count FROM auditoria')?.count || 0;
  const usuariosCount = queryOne<{ count: number }>('SELECT COUNT(*) as count FROM usuarios')?.count || 0;
  const avisosCount = queryOne<{ count: number }>('SELECT COUNT(*) as count FROM avisos')?.count || 0;
  const ticketsCount = queryOne<{ count: number }>('SELECT COUNT(*) as count FROM tickets_soporte')?.count || 0;
  const actasCount = queryOne<{ count: number }>('SELECT COUNT(*) as count FROM actas_oficiales')?.count || 0;

  res.json({
    ok: true,
    sistema: 'My IOV Study v2',
    version: '0.8.0',
    etapa: 8,
    uptimeSegundos: Math.floor(process.uptime()),
    slaGarantizado: '99.9%',
    estadoGeneral: 'OPTIMO',
    baseDeDatos: {
      motor: 'SQLite (sql.js persistent)',
      tablasTotales: tables.length,
      tablas: tables.map(t => t.name),
    },
    metricasOperativas: {
      totalUsuarios: usuariosCount,
      totalAvisos: avisosCount,
      totalTicketsSoporte: ticketsCount,
      totalActasProtocolizadas: actasCount,
      eventosAuditoriaRegistrados: auditoriaCount,
    },
  });
}
