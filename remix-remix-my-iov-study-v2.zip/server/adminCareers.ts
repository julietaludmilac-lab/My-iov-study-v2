import { Request, Response } from 'express';
import { queryAll, queryOne, runQuery } from './db.js';
import bcrypt from 'bcryptjs';

/**
 * 1. Obtener todas las carreras disponibles
 * Utilizado por el formulario de Registro de estudiantes, Bedelía y Administración
 */
export async function getCarreras(req: Request, res: Response): Promise<void> {
  const carreras = queryAll<{
    id: string;
    codigo: string;
    nombre: string;
    sede: string;
    estado: string;
    plan_id: string;
    codigo_plan: string;
    plan_version: string;
    total_estudiantes: number;
    total_materias: number;
  }>(`
    SELECT 
      c.id,
      c.codigo,
      c.nombre,
      c.sede,
      c.estado,
      p.id as plan_id,
      p.codigo_plan,
      p.version as plan_version,
      (SELECT COUNT(*) FROM estudiantes e WHERE e.carrera_id = c.id) as total_estudiantes,
      (SELECT COUNT(*) FROM materias m WHERE m.plan_id = p.id) as total_materias
    FROM carreras c
    LEFT JOIN planes_estudio p ON p.carrera_id = c.id AND p.estado = 'VIGENTE'
    WHERE c.estado = 'ACTIVA'
    ORDER BY c.nombre ASC
  `);

  res.json({ ok: true, carreras });
}

/**
 * 2. Administración: Crear nueva Carrera con su Plan de Estudio
 */
export async function createCarrera(req: Request, res: Response): Promise<void> {
  const { codigo, nombre, sede, codigoPlan, version, anioValidez, resolucion } = req.body;

  if (!codigo || !nombre) {
    res.status(400).json({ ok: false, message: 'Código y nombre de la carrera son obligatorios' });
    return;
  }

  const cleanCodigo = String(codigo).trim().toUpperCase();
  const cleanNombre = String(nombre).trim();
  const cleanSede = sede ? String(sede).trim() : 'Sede Santa Fe';

  // Verificar si ya existe carrera con ese código
  const existente = queryOne('SELECT id FROM carreras WHERE codigo = ?', [cleanCodigo]);
  if (existente) {
    res.status(409).json({ ok: false, message: `Ya existe una carrera con el código ${cleanCodigo}` });
    return;
  }

  const carreraId = `CAR-${cleanCodigo}`;
  const planId = `PLAN-${cleanCodigo}-${anioValidez || 2026}`;

  runQuery(`
    INSERT INTO carreras (id, codigo, nombre, sede, estado)
    VALUES (?, ?, ?, ?, 'ACTIVA')
  `, [carreraId, cleanCodigo, cleanNombre, cleanSede]);

  runQuery(`
    INSERT INTO planes_estudio (id, carrera_id, codigo_plan, version, anio_validez, resolucion, estado)
    VALUES (?, ?, ?, ?, ?, ?, 'VIGENTE')
  `, [
    planId,
    carreraId,
    codigoPlan || `PLAN-${cleanCodigo}-2026`,
    version || 'v1.0',
    anioValidez ? parseInt(anioValidez, 10) : 2026,
    resolucion || `Res. CS N° ${(Math.floor(Math.random() * 90) + 10)}/2026`,
  ]);

  res.json({
    ok: true,
    message: `Carrera "${cleanNombre}" y Plan de Estudio creados exitosamente. Ahora aparece como opción en el Registro de estudiantes y para Bedelía.`,
    carreraId,
    planId,
  });
}

/**
 * 3. Administración: Eliminar Carrera con sus Planes y Materias
 */
export async function deleteCarrera(req: Request, res: Response): Promise<void> {
  const { id } = req.params;

  // Verificar si tiene estudiantes asociados
  const estudiantesCount = queryOne<{ total: number }>(
    'SELECT COUNT(*) as total FROM estudiantes WHERE carrera_id = ?',
    [id]
  )?.total || 0;

  if (estudiantesCount > 0) {
    res.status(400).json({
      ok: false,
      message: `No se puede eliminar la carrera porque tiene ${estudiantesCount} estudiante(s) inscripto(s). Reubique a los estudiantes primero.`,
    });
    return;
  }

  // Eliminar en cascada materias, correlatividades y planes
  const planes = queryAll<{ id: string }>('SELECT id FROM planes_estudio WHERE carrera_id = ?', [id]);
  for (const p of planes) {
    const mats = queryAll<{ id: string }>('SELECT id FROM materias WHERE plan_id = ?', [p.id]);
    for (const m of mats) {
      runQuery('DELETE FROM correlatividades WHERE materia_id = ? OR materia_requisito_id = ?', [m.id, m.id]);
    }
    runQuery('DELETE FROM materias WHERE plan_id = ?', [p.id]);
  }
  runQuery('DELETE FROM planes_estudio WHERE carrera_id = ?', [id]);
  runQuery('DELETE FROM carreras WHERE id = ?', [id]);

  res.json({ ok: true, message: 'Carrera y planes de estudio eliminados correctamente' });
}

/**
 * 4. Parsear Documento de Plan de Estudios (Intérprete de Texto / Documento)
 * Lee el contenido textual de un plan de estudio y extrae materias por año y correlatividades
 */
export interface ParsedSubject {
  codigo: string;
  nombre: string;
  anio: number;
  regimen: '1C' | '2C' | 'ANUAL';
  cargaHoraria: number;
  condicion: 'OBLIGATORIA' | 'OPTATIVA';
  correlativas: string[];
}

export function parseStudyPlanDocument(content: string, carreraCodigo: string): {
  materias: ParsedSubject[];
  totalAnios: number;
} {
  const lines = content.split('\n');
  const materias: ParsedSubject[] = [];
  let currentAnio = 1;
  let counter = 1;

  for (const rawLine of lines) {
    const line = rawLine.trim();
    if (!line || line.startsWith('#') || line.toLowerCase().startsWith('plan') || line.toLowerCase().startsWith('resoluci')) continue;

    // Detectar encabezados de año
    const anioMatch = line.match(/(?:año|ano|nivel)\s*(\d+)/i) || line.match(/(\d+)[\s°ºª]*año/i);
    if (anioMatch && line.length < 30) {
      currentAnio = parseInt(anioMatch[1], 10);
      continue;
    }

    // Si la línea contiene un formato con separador "|" o ";" o "-" o comas
    // Ej: "LSI-101 | Algoritmos y Estructuras de Datos | 1C | 96 | OBLIGATORIA | -"
    if (line.includes('|') || line.includes(';')) {
      const parts = (line.includes('|') ? line.split('|') : line.split(';')).map((p) => p.trim());
      if (parts.length >= 2) {
        const codigo = parts[0].length > 2 && parts[0].includes('-') ? parts[0] : `${carreraCodigo}-${currentAnio}0${counter}`;
        const nombre = parts[1] || `Asignatura ${counter}`;
        const regimenRaw = (parts[2] || '1C').toUpperCase();
        const regimen = regimenRaw.includes('2') ? '2C' : regimenRaw.includes('ANUAL') ? 'ANUAL' : '1C';
        const carga = parts[3] ? parseInt(parts[3].replace(/\D/g, ''), 10) || 80 : 80;
        const corrList = parts[4] && parts[4] !== '-' && parts[4].toLowerCase() !== 'ninguna'
          ? parts[4].split(',').map((c) => c.trim())
          : [];

        materias.push({
          codigo,
          nombre,
          anio: currentAnio,
          regimen,
          cargaHoraria: carga,
          condicion: 'OBLIGATORIA',
          correlativas: corrList,
        });
        counter++;
        continue;
      }
    }

    // Líneas con formato libre: "1. Introducción al Derecho (1C, 80hs) - Correlativas: -"
    const cleanSubject = line.replace(/^\d+[\.\-\)]\s*/, '').trim();
    if (cleanSubject.length > 3 && !cleanSubject.toLowerCase().startsWith('plan') && !cleanSubject.toLowerCase().startsWith('resoluci')) {
      const codigo = `${carreraCodigo}-${currentAnio}0${counter}`;
      let regimen: '1C' | '2C' | 'ANUAL' = counter % 2 === 0 ? '2C' : '1C';
      if (cleanSubject.toLowerCase().includes('anual')) regimen = 'ANUAL';
      else if (cleanSubject.toLowerCase().includes('2c') || cleanSubject.toLowerCase().includes('segundo')) regimen = '2C';

      let cargaHoraria = 80;
      const hsMatch = cleanSubject.match(/(\d+)\s*(?:hs|horas)/i);
      if (hsMatch) cargaHoraria = parseInt(hsMatch[1], 10);

      // Limpiar nombre
      const nombreLimpio = cleanSubject
        .replace(/\(.*?\)/g, '')
        .replace(/\[.*?\]/g, '')
        .replace(/[-–].*?correlat.*$/i, '')
        .trim();

      materias.push({
        codigo,
        nombre: nombreLimpio,
        anio: currentAnio,
        regimen,
        cargaHoraria,
        condicion: 'OBLIGATORIA',
        correlativas: [],
      });
      counter++;
    }
  }

  const maxAnio = materias.reduce((max, m) => Math.max(max, m.anio), 1);
  return { materias, totalAnios: maxAnio };
}

export async function parsePlanDocumentHandler(req: Request, res: Response): Promise<void> {
  const { carreraId } = req.params;
  const { documentText } = req.body;

  if (!documentText || typeof documentText !== 'string') {
    res.status(400).json({ ok: false, message: 'Debe ingresar el texto o contenido del documento del plan de estudio' });
    return;
  }

  const carrera = queryOne<{ codigo: string; nombre: string }>('SELECT codigo, nombre FROM carreras WHERE id = ?', [carreraId]);
  if (!carrera) {
    res.status(404).json({ ok: false, message: 'Carrera no encontrada' });
    return;
  }

  const parsed = parseStudyPlanDocument(documentText, carrera.codigo);
  res.json({
    ok: true,
    carreraNombre: carrera.nombre,
    carreraCodigo: carrera.codigo,
    totalMaterias: parsed.materias.length,
    totalAnios: parsed.totalAnios,
    materias: parsed.materias,
  });
}

/**
 * 5. Importar y Guardar las Materias y Correlatividades Parseadas
 */
export async function importPlanHandler(req: Request, res: Response): Promise<void> {
  const { carreraId } = req.params;
  const { materias } = req.body as { materias: ParsedSubject[] };

  if (!Array.isArray(materias) || materias.length === 0) {
    res.status(400).json({ ok: false, message: 'No se enviaron materias para importar' });
    return;
  }

  const plan = queryOne<{ id: string }>('SELECT id FROM planes_estudio WHERE carrera_id = ? AND estado = "VIGENTE"', [carreraId]);
  if (!plan) {
    res.status(404).json({ ok: false, message: 'No se encontró un plan de estudio vigente para esta carrera' });
    return;
  }

  // Insertar materias
  const insertedMap = new Map<string, string>(); // codigo -> id
  for (const mat of materias) {
    const materiaId = `MAT-${mat.codigo.replace(/\s+/g, '')}`;
    runQuery(`
      INSERT OR REPLACE INTO materias (id, plan_id, codigo, nombre, anio_carrera, regimen, carga_horaria, condicion)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      materiaId,
      plan.id,
      mat.codigo,
      mat.nombre,
      mat.anio,
      mat.regimen,
      mat.cargaHoraria || 80,
      mat.condicion || 'OBLIGATORIA',
    ]);
    insertedMap.set(mat.codigo, materiaId);
  }

  // Insertar correlatividades si se especificaron
  for (const mat of materias) {
    const matId = insertedMap.get(mat.codigo);
    if (!matId || !mat.correlativas) continue;

    for (const corrCod of mat.correlativas) {
      const reqId = insertedMap.get(corrCod);
      if (reqId && reqId !== matId) {
        const corrId = `CORR-${mat.codigo}-${corrCod}`;
        runQuery(`
          INSERT OR REPLACE INTO correlatividades (id, materia_id, materia_requisito_id, tipo, fuente_id, resolucion)
          VALUES (?, ?, ?, 'PARA_CURSAR_APROBADA', 'FTE-CON-01', 'Plan Oficial Homologado')
        `, [corrId, matId, reqId]);
      }
    }
  }

  res.json({
    ok: true,
    message: `Se importaron exitosamente ${materias.length} materias con sus correlatividades para el plan de estudio.`,
    totalGuardadas: materias.length,
  });
}

/**
 * 6. Agregar Materia Individual Manualmente al Plan de Estudios
 */
export async function addMateriaManual(req: Request, res: Response): Promise<void> {
  const { carreraId } = req.params;
  const { codigo, nombre, anio, regimen, cargaHoraria, condicion, correlativaId } = req.body;

  if (!codigo || !nombre || !anio) {
    res.status(400).json({ ok: false, message: 'Código, nombre y año de carrera son requeridos' });
    return;
  }

  const plan = queryOne<{ id: string }>('SELECT id FROM planes_estudio WHERE carrera_id = ? AND estado = "VIGENTE"', [carreraId]);
  if (!plan) {
    res.status(404).json({ ok: false, message: 'Plan de estudio no encontrado para esta carrera' });
    return;
  }

  const matId = `MAT-${String(codigo).trim().toUpperCase()}`;
  runQuery(`
    INSERT INTO materias (id, plan_id, codigo, nombre, anio_carrera, regimen, carga_horaria, condicion)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `, [
    matId,
    plan.id,
    String(codigo).trim().toUpperCase(),
    String(nombre).trim(),
    parseInt(anio, 10),
    regimen || '1C',
    cargaHoraria ? parseInt(cargaHoraria, 10) : 80,
    condicion || 'OBLIGATORIA',
  ]);

  if (correlativaId) {
    const corrId = `CORR-${Date.now().toString(36).toUpperCase()}`;
    runQuery(`
      INSERT INTO correlatividades (id, materia_id, materia_requisito_id, tipo, resolucion)
      VALUES (?, ?, ?, 'PARA_CURSAR_APROBADA', 'Resolución Académica')
    `, [corrId, matId, correlativaId]);
  }

  res.json({ ok: true, message: 'Materia incorporada exitosamente al plan de estudios.' });
}

/**
 * 7. Bedelía: Obtener Comisiones con Métrica de Alumnos Registrados por Carrera
 */
export async function getBedeliaComisiones(req: Request, res: Response): Promise<void> {
  const { carreraId } = req.query;

  let query = `
    SELECT 
      c.id,
      c.materia_id,
      m.codigo as materia_codigo,
      m.nombre as materia_nombre,
      m.anio_carrera,
      car.id as carrera_id,
      car.nombre as carrera_nombre,
      c.codigo_comision,
      c.ciclo_lectivo,
      c.cuatrimestre,
      c.docente_titular,
      c.turno,
      c.cupo_maximo,
      c.inscripcion_desde,
      c.inscripcion_hasta,
      c.estado,
      (SELECT COUNT(*) FROM inscripciones i WHERE i.comision_id = c.id AND i.estado = 'CONFIRMADA') as estudiantes_inscriptos,
      (SELECT COUNT(*) FROM estudiantes e WHERE e.carrera_id = car.id) as total_estudiantes_carrera,
      h.id as horario_id,
      h.dia_semana,
      h.hora_inicio,
      h.hora_fin,
      h.aula_id,
      a.nombre as aula_nombre,
      a.edificio as aula_edificio,
      h.estado_aula,
      h.observaciones as horario_observaciones
    FROM comisiones c
    JOIN materias m ON c.materia_id = m.id
    JOIN planes_estudio p ON m.plan_id = p.id
    JOIN carreras car ON p.carrera_id = car.id
    LEFT JOIN horarios h ON h.comision_id = c.id
    LEFT JOIN aulas a ON h.aula_id = a.id
  `;

  const params: any[] = [];
  if (carreraId) {
    query += ' WHERE car.id = ?';
    params.push(carreraId);
  }

  query += ' ORDER BY car.nombre ASC, m.anio_carrera ASC, c.codigo_comision ASC';

  const comisiones = queryAll(query, params);
  res.json({ ok: true, comisiones });
}

/**
 * 8. Bedelía: Crear Comisión para una Materia con Horario y Aula
 */
export async function createBedeliaComision(req: Request, res: Response): Promise<void> {
  const {
    materiaId,
    codigoComision,
    cicloLectivo,
    cuatrimestre,
    docenteTitular,
    turno,
    cupoMaximo,
    diaSemana,
    horaInicio,
    horaFin,
    aulaId,
    observaciones,
  } = req.body;

  if (!materiaId || !codigoComision || !docenteTitular) {
    res.status(400).json({ ok: false, message: 'Materia, código de comisión y docente son obligatorios' });
    return;
  }

  const comisionId = `COM-${Date.now().toString(36).toUpperCase()}`;

  runQuery(`
    INSERT INTO comisiones (id, materia_id, codigo_comision, ciclo_lectivo, cuatrimestre, docente_titular, turno, cupo_maximo, inscripcion_desde, inscripcion_hasta, estado)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, '2026-02-15', '2026-03-30', 'ABIERTA')
  `, [
    comisionId,
    materiaId,
    codigoComision.toUpperCase(),
    cicloLectivo || 2026,
    cuatrimestre || '1C',
    docenteTitular,
    turno || 'MANANA',
    cupoMaximo ? parseInt(cupoMaximo, 10) : 40,
  ]);

  if (diaSemana && horaInicio && horaFin) {
    const horarioId = `HOR-${Date.now().toString(36).toUpperCase()}`;
    runQuery(`
      INSERT INTO horarios (id, comision_id, dia_semana, hora_inicio, hora_fin, aula_id, estado_aula, observaciones)
      VALUES (?, ?, ?, ?, ?, ?, 'OFICIAL', ?)
    `, [
      horarioId,
      comisionId,
      parseInt(diaSemana, 10),
      horaInicio,
      horaFin,
      aulaId || 'AULA-101',
      observaciones || null,
    ]);
  }

  res.json({ ok: true, message: 'Comisión creada con éxito y habilitada para cursado.', comisionId });
}

/**
 * 9. Bedelía: Editar Comisión y Horarios
 */
export async function updateBedeliaComision(req: Request, res: Response): Promise<void> {
  const { id } = req.params;
  const {
    codigoComision,
    docenteTitular,
    turno,
    cupoMaximo,
    estado,
    diaSemana,
    horaInicio,
    horaFin,
    aulaId,
    estadoAula,
    observaciones,
  } = req.body;

  runQuery(`
    UPDATE comisiones
    SET codigo_comision = COALESCE(?, codigo_comision),
        docente_titular = COALESCE(?, docente_titular),
        turno = COALESCE(?, turno),
        cupo_maximo = COALESCE(?, cupo_maximo),
        estado = COALESCE(?, estado),
        updated_at = datetime('now')
    WHERE id = ?
  `, [codigoComision, docenteTitular, turno, cupoMaximo, estado, id]);

  if (diaSemana || horaInicio || horaFin || aulaId || estadoAula) {
    const existingHorario = queryOne<{ id: string }>('SELECT id FROM horarios WHERE comision_id = ?', [id]);
    if (existingHorario) {
      runQuery(`
        UPDATE horarios
        SET dia_semana = COALESCE(?, dia_semana),
            hora_inicio = COALESCE(?, hora_inicio),
            hora_fin = COALESCE(?, hora_fin),
            aula_id = COALESCE(?, aula_id),
            estado_aula = COALESCE(?, estado_aula),
            observaciones = COALESCE(?, observaciones),
            updated_at = datetime('now')
        WHERE id = ?
      `, [diaSemana, horaInicio, horaFin, aulaId, estadoAula, observaciones, existingHorario.id]);
    } else if (diaSemana && horaInicio && horaFin) {
      runQuery(`
        INSERT INTO horarios (id, comision_id, dia_semana, hora_inicio, hora_fin, aula_id, estado_aula, observaciones)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        `HOR-${Date.now().toString(36).toUpperCase()}`,
        id,
        diaSemana,
        horaInicio,
        horaFin,
        aulaId || 'AULA-101',
        estadoAula || 'OFICIAL',
        observaciones || null,
      ]);
    }
  }

  res.json({ ok: true, message: 'Comisión y cronograma actualizados exitosamente' });
}

/**
 * 10. Bedelía: Abrir / Cerrar Inscripciones a Comisión
 */
export async function toggleComisionInscripcion(req: Request, res: Response): Promise<void> {
  const { id } = req.params;
  const current = queryOne<{ estado: string }>('SELECT estado FROM comisiones WHERE id = ?', [id]);

  if (!current) {
    res.status(404).json({ ok: false, message: 'Comisión no encontrada' });
    return;
  }

  const nuevoEstado = current.estado === 'ABIERTA' ? 'CERRADA' : 'ABIERTA';
  runQuery('UPDATE comisiones SET estado = ?, updated_at = datetime("now") WHERE id = ?', [nuevoEstado, id]);

  res.json({
    ok: true,
    nuevoEstado,
    message: `Inscripciones a la comisión ${nuevoEstado === 'ABIERTA' ? 'ABIERTAS' : 'CERRADAS'} correctamente.`,
  });
}

/**
 * 11. Bedelía: Eliminar Comisión
 */
export async function deleteBedeliaComision(req: Request, res: Response): Promise<void> {
  const { id } = req.params;

  runQuery('DELETE FROM horarios WHERE comision_id = ?', [id]);
  runQuery('DELETE FROM inscripciones WHERE comision_id = ?', [id]);
  runQuery('DELETE FROM comisiones WHERE id = ?', [id]);

  res.json({ ok: true, message: 'Comisión eliminada correctamente' });
}

/**
 * 12. Administración: Listar y Registrar Estudiantes
 */
export async function getAdminStudents(req: Request, res: Response): Promise<void> {
  const estudiantes = queryAll<{
    id: string;
    nombre_completo: string;
    matricula: string;
    correo: string;
    carrera_id: string;
    carrera_nombre: string;
    plan_version: string;
    anio_cursado: number;
    condicion_academica: string;
    cuotas_pendientes: number;
  }>(`
    SELECT 
      e.id,
      e.nombre_completo,
      u.matricula,
      u.correo,
      c.id as carrera_id,
      c.nombre as carrera_nombre,
      p.version as plan_version,
      e.anio_cursado,
      e.condicion_academica,
      (SELECT COUNT(*) FROM cuotas cu WHERE cu.estudiante_id = e.id AND cu.estado != 'PAGADA') as cuotas_pendientes
    FROM estudiantes e
    JOIN usuarios u ON e.usuario_id = u.id
    JOIN carreras c ON e.carrera_id = c.id
    LEFT JOIN planes_estudio p ON e.plan_id = p.id
    ORDER BY e.nombre_completo ASC
  `);

  res.json({ ok: true, estudiantes });
}

export async function createAdminStudent(req: Request, res: Response): Promise<void> {
  const { nombreCompleto, matricula, correo, password, carreraId } = req.body;

  if (!nombreCompleto || !matricula || !correo || !password || !carreraId) {
    res.status(400).json({ ok: false, message: 'Todos los campos son obligatorios' });
    return;
  }

  const matriculaNorm = String(matricula).trim().toUpperCase();
  const correoNorm = String(correo).trim().toLowerCase();

  const existe = queryOne('SELECT id FROM usuarios WHERE matricula = ? OR correo = ?', [matriculaNorm, correoNorm]);
  if (existe) {
    res.status(409).json({ ok: false, message: 'Ya existe un usuario con esa matrícula o correo' });
    return;
  }

  const plan = queryOne<{ id: string }>('SELECT id FROM planes_estudio WHERE carrera_id = ? AND estado = "VIGENTE" LIMIT 1', [carreraId]);
  const planId = plan?.id || 'PLAN-LSI-2023';

  const hash = bcrypt.hashSync(password, 10);
  const userId = `USR-${Date.now().toString(36).toUpperCase()}`;
  const studentId = `EST-${Date.now().toString(36).toUpperCase()}`;

  runQuery(`
    INSERT INTO usuarios (id, matricula, correo, password_hash, rol, estado)
    VALUES (?, ?, ?, ?, 'ESTUDIANTE', 'ACTIVO')
  `, [userId, matriculaNorm, correoNorm, hash]);

  runQuery(`
    INSERT INTO estudiantes (id, usuario_id, nombre_completo, carrera_id, plan_id, anio_cursado, condicion_academica)
    VALUES (?, ?, ?, ?, ?, 1, 'REGULAR')
  `, [studentId, userId, String(nombreCompleto).trim(), carreraId, planId]);

  res.json({ ok: true, message: `Estudiante ${nombreCompleto} registrado exitosamente en la carrera seleccionada.` });
}

/**
 * 13. Bedelía: Crear Mesa de Examen Final
 */
export async function createBedeliaExamen(req: Request, res: Response): Promise<void> {
  const { materiaId, fecha, hora, turnoExamen, llamado, aulaId, tribunal, periodoDesde, periodoHasta } = req.body;
  if (!materiaId || !fecha || !hora) {
    res.status(400).json({ ok: false, message: 'Materia, fecha y hora son obligatorios' });
    return;
  }
  const id = `EXA-${Date.now().toString(36).toUpperCase()}`;
  runQuery(`
    INSERT INTO examenes (id, materia_id, fecha, hora, turno_examen, llamado, aula_id, tribunal, periodo_inscripcion_desde, periodo_inscripcion_hasta, estado)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'ABIERTO')
  `, [
    id,
    materiaId,
    fecha,
    hora,
    turnoExamen || 'JULIO_AGOSTO_2026',
    llamado || 1,
    aulaId || 'AULA-204',
    tribunal || 'Prof. Titular y Adjuntos',
    periodoDesde || '2026-06-01',
    periodoHasta || '2026-06-30',
  ]);
  res.json({ ok: true, id, message: 'Mesa de examen programada exitosamente.' });
}

/**
 * 14. Bedelía: Eliminar Mesa de Examen Final
 */
export async function deleteBedeliaExamen(req: Request, res: Response): Promise<void> {
  const { id } = req.params;
  runQuery('DELETE FROM inscripciones WHERE examen_id = ?', [id]);
  runQuery('DELETE FROM examenes WHERE id = ?', [id]);
  res.json({ ok: true, message: 'Mesa de examen eliminada correctamente.' });
}

/**
 * 15. Bedelía: Abrir / Cerrar Inscripción a Mesa de Examen
 */
export async function toggleBedeliaExamen(req: Request, res: Response): Promise<void> {
  const { id } = req.params;
  const current = queryOne<{ estado: string }>('SELECT estado FROM examenes WHERE id = ?', [id]);
  if (!current) {
    res.status(404).json({ ok: false, message: 'Mesa no encontrada' });
    return;
  }
  const nuevoEstado = current.estado === 'ABIERTO' ? 'CERRADO' : 'ABIERTO';
  runQuery('UPDATE examenes SET estado = ?, updated_at = datetime("now") WHERE id = ?', [nuevoEstado, id]);
  res.json({
    ok: true,
    nuevoEstado,
    message: `Inscripción a mesa ${nuevoEstado === 'ABIERTO' ? 'ABIERTA' : 'CERRADA'} correctamente.`,
  });
}

/**
 * 16. Bedelía: Crear Evento en Calendario Institucional
 */
export async function createBedeliaCalendarEvent(req: Request, res: Response): Promise<void> {
  const { titulo, descripcion, tipo, fechaInicio, fechaFin, carreraId } = req.body;
  if (!titulo || !tipo || !fechaInicio) {
    res.status(400).json({ ok: false, message: 'Título, tipo y fecha de inicio son requeridos' });
    return;
  }
  const id = `CAL-${Date.now().toString(36).toUpperCase()}`;
  runQuery(`
    INSERT INTO eventos_calendario (id, titulo, descripcion, tipo, fecha_inicio, fecha_fin, carrera_id)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `, [
    id,
    titulo,
    descripcion || '',
    tipo,
    fechaInicio,
    fechaFin || fechaInicio,
    carreraId || null,
  ]);
  res.json({ ok: true, id, message: 'Evento de calendario oficial creado por Bedelía.' });
}

/**
 * 17. Bedelía: Eliminar Evento del Calendario Institucional
 */
export async function deleteBedeliaCalendarEvent(req: Request, res: Response): Promise<void> {
  const { id } = req.params;
  runQuery('DELETE FROM eventos_calendario WHERE id = ?', [id]);
  res.json({ ok: true, message: 'Evento del calendario institucional eliminado correctamente.' });
}

/**
 * 18. Bedelía: Supervisión de Asistencia por Comisión
 */
export async function getBedeliaComisionAsistencia(req: Request, res: Response): Promise<void> {
  const { id } = req.params;
  const comision = queryOne<{
    id: string;
    codigo_comision: string;
    materia_nombre: string;
    docente_titular: string;
    aula_nombre: string;
    cupo_maximo: number;
  }>(`
    SELECT c.id, c.codigo_comision, m.nombre as materia_nombre, c.docente_titular, a.nombre as aula_nombre, c.cupo_maximo
    FROM comisiones c
    JOIN materias m ON c.materia_id = m.id
    LEFT JOIN aulas a ON c.aula_id = a.id
    WHERE c.id = ?
  `, [id]);

  if (!comision) {
    res.status(404).json({ ok: false, message: 'Comisión no encontrada' });
    return;
  }

  const estudiantes = queryAll<{
    estudiante_id: string;
    nombre_completo: string;
    matricula: string;
    correo: string;
    condicion_academica: string;
  }>(`
    SELECT e.id as estudiante_id, e.nombre_completo, u.matricula, u.correo, e.condicion_academica
    FROM inscripciones i
    JOIN estudiantes e ON i.estudiante_id = e.id
    JOIN usuarios u ON e.usuario_id = u.id
    WHERE i.comision_id = ? AND i.tipo = 'COMISION' AND i.estado = 'CONFIRMADA'
    ORDER BY e.nombre_completo ASC
  `, [id]);

  const registros = queryAll<{
    estudiante_id: string;
    estado: string;
    fecha: string;
  }>('SELECT estudiante_id, estado, fecha FROM asistencia WHERE comision_id = ?', [id]);

  const totalClasesDistintas = Array.from(new Set(registros.map((r) => r.fecha))).length || 8;

  const estudiantesConAsistencia = estudiantes.map((est) => {
    const misRegs = registros.filter((r) => r.estudiante_id === est.estudiante_id);
    const faltas = misRegs.filter((r) => r.estado === 'AUSENTE').length;
    const presentes = misRegs.filter((r) => r.estado === 'PRESENTE').length;
    const porcentaje = totalClasesDistintas > 0 ? ((totalClasesDistintas - faltas) / totalClasesDistintas) * 100 : 100;
    let estadoCursada = 'REGULAR';
    if (faltas > 4) estadoCursada = 'LIBRE_POR_FALTAS';
    else if (faltas >= 3) estadoCursada = 'EN_RIESGO';

    return {
      ...est,
      totalClases: totalClasesDistintas,
      presentes,
      faltas,
      porcentajeAsistencia: parseFloat(porcentaje.toFixed(1)),
      estadoCursada,
    };
  });

  res.json({
    ok: true,
    comision,
    totalInscriptos: estudiantes.length,
    totalClases: totalClasesDistintas,
    estudiantes: estudiantesConAsistencia,
  });
}

/**
 * 19. Administración: Padrón y Gestión de Usuarios
 */
export async function getAdminUsers(req: Request, res: Response): Promise<void> {
  const usuarios = queryAll<{
    id: string;
    matricula: string;
    correo: string;
    rol: string;
    estado: string;
    created_at: string;
    nombre_completo: string | null;
    carrera_nombre: string | null;
  }>(`
    SELECT 
      u.id,
      u.matricula,
      u.correo,
      u.rol,
      u.estado,
      u.created_at,
      e.nombre_completo,
      c.nombre as carrera_nombre
    FROM usuarios u
    LEFT JOIN estudiantes e ON e.usuario_id = u.id
    LEFT JOIN carreras c ON e.carrera_id = c.id
    ORDER BY u.created_at DESC
  `);
  res.json({ ok: true, usuarios });
}

export async function toggleAdminUserStatus(req: Request, res: Response): Promise<void> {
  const { id } = req.params;
  const user = queryOne<{ estado: string }>('SELECT estado FROM usuarios WHERE id = ?', [id]);
  if (!user) {
    res.status(404).json({ ok: false, message: 'Usuario no encontrado' });
    return;
  }
  const nuevoEstado = user.estado === 'ACTIVO' ? 'SUSPENDIDO' : 'ACTIVO';
  runQuery('UPDATE usuarios SET estado = ? WHERE id = ?', [nuevoEstado, id]);
  res.json({ ok: true, nuevoEstado, message: `Usuario ${nuevoEstado === 'ACTIVO' ? 'reactivado' : 'suspendido'} exitosamente.` });
}

export async function resetAdminUserPassword(req: Request, res: Response): Promise<void> {
  const { id } = req.params;
  const { newPassword } = req.body;
  const pass = newPassword || 'Ucsf2026!';
  const hash = bcrypt.hashSync(pass, 10);
  runQuery('UPDATE usuarios SET password_hash = ? WHERE id = ?', [hash, id]);
  res.json({ ok: true, message: `Contraseña restablecida con éxito para el usuario.` });
}

/**
 * 20. Administración: Resumen Global de Aranceles y Cuotas
 */
export async function getAdminArancelesSummary(req: Request, res: Response): Promise<void> {
  const totalCuotas = queryOne<{ total: number }>('SELECT COUNT(*) as total FROM cuotas')?.total || 0;
  const pagadas = queryOne<{ total: number; monto: number }>('SELECT COUNT(*) as total, COALESCE(SUM(monto), 0) as monto FROM cuotas WHERE estado = "PAGADA"');
  const pendientes = queryOne<{ total: number; monto: number }>('SELECT COUNT(*) as total, COALESCE(SUM(monto), 0) as monto FROM cuotas WHERE estado != "PAGADA"');

  const cuotasPorPeriodo = queryAll<{
    periodo: string;
    concepto: string;
    total: number;
    pagadas: number;
    pendientes: number;
    monto_recaudado: number;
  }>(`
    SELECT 
      periodo,
      concepto,
      COUNT(*) as total,
      SUM(CASE WHEN estado = 'PAGADA' THEN 1 ELSE 0 END) as pagadas,
      SUM(CASE WHEN estado != 'PAGADA' THEN 1 ELSE 0 END) as pendientes,
      SUM(CASE WHEN estado = 'PAGADA' THEN monto ELSE 0 END) as monto_recaudado
    FROM cuotas
    GROUP BY periodo, concepto
    ORDER BY periodo DESC
  `);

  res.json({
    ok: true,
    resumen: {
      totalCuotas,
      totalPagadas: pagadas?.total || 0,
      montoRecaudado: pagadas?.monto || 0,
      totalPendientes: pendientes?.total || 0,
      montoPendiente: pendientes?.monto || 0,
    },
    periodos: cuotasPorPeriodo,
  });
}

/**
 * 21. Administración: Auditoría y Seguridad
 */
export async function getAdminAuditoria(req: Request, res: Response): Promise<void> {
  const logs = queryAll<{
    id: string;
    actor_id: string;
    actor_rol: string;
    accion: string;
    recurso: string;
    resultado: string;
    ip_origen: string;
    created_at: string;
  }>('SELECT * FROM auditoria ORDER BY created_at DESC LIMIT 50');

  const intentos = queryAll<{
    id: string;
    identificador_ingresado: string;
    ip_origen: string;
    exitoso: number;
    bloqueado: number;
    motivo: string;
    created_at: string;
  }>('SELECT * FROM intentos_login ORDER BY created_at DESC LIMIT 50');

  res.json({ ok: true, logs, intentos });
}

/**
 * 22. Obtener materias del plan de una carrera específica
 * Accesible por Bedelía, Administración y Estudiantes
 */
export async function getCarreraMaterias(req: Request, res: Response): Promise<void> {
  const { carreraId } = req.params;
  const carrera = queryOne<{ id: string; nombre: string; codigo: string }>('SELECT id, nombre, codigo FROM carreras WHERE id = ?', [carreraId]);
  if (!carrera) {
    res.status(404).json({ ok: false, message: 'Carrera no encontrada' });
    return;
  }

  const plan = queryOne<{ id: string; version: string; codigo_plan: string }>(
    'SELECT id, version, codigo_plan FROM planes_estudio WHERE carrera_id = ? AND estado = "VIGENTE" ORDER BY anio_validez DESC LIMIT 1',
    [carreraId]
  );

  const totalEstudiantes = queryOne<{ total: number }>(
    'SELECT COUNT(*) as total FROM estudiantes WHERE carrera_id = ?',
    [carreraId]
  )?.total || 0;

  if (!plan) {
    res.json({ ok: true, carrera, plan: null, materias: [], totalEstudiantes });
    return;
  }

  const materias = queryAll<{
    id: string;
    codigo: string;
    nombre: string;
    anio_carrera: number;
    regimen: string;
    carga_horaria: number;
    condicion: string;
  }>(`
    SELECT id, codigo, nombre, anio_carrera, regimen, carga_horaria, condicion
    FROM materias
    WHERE plan_id = ?
    ORDER BY anio_carrera ASC, codigo ASC
  `, [plan.id]);

  const correlatividades = queryAll<{
    materia_id: string;
    requisito_codigo: string;
    requisito_nombre: string;
    tipo: string;
  }>(`
    SELECT c.materia_id, mr.codigo as requisito_codigo, mr.nombre as requisito_nombre, c.tipo
    FROM correlatividades c
    JOIN materias mr ON c.materia_requisito_id = mr.id
    WHERE c.materia_id IN (SELECT id FROM materias WHERE plan_id = ?)
  `, [plan.id]);

  const materiasConCorr = materias.map((m) => ({
    ...m,
    correlatividades: correlatividades.filter((c) => c.materia_id === m.id),
  }));

  res.json({
    ok: true,
    carrera,
    plan,
    totalEstudiantes,
    materias: materiasConCorr,
  });
}

