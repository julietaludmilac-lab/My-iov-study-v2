import { Request, Response, NextFunction } from 'express';
import bcrypt from 'bcryptjs';
import crypto from 'node:crypto';
import { queryOne, queryAll, runQuery } from './db.js';

// Mapa de sesiones en memoria con TTL
interface SessionData {
  userId: string;
  matricula: string;
  rol: 'ESTUDIANTE' | 'BEDELIA' | 'ADMINISTRACION';
  nombre: string;
  csrfToken: string;
  createdAt: number;
  expiresAt: number;
}

const sessions = new Map<string, SessionData>();
const SESSION_TTL_MS = 8 * 60 * 60 * 1000; // 8 horas

export function createSession(user: { id: string; matricula: string; rol: any; nombre: string }): { sessionId: string; csrfToken: string } {
  const sessionId = crypto.randomBytes(32).toString('hex');
  const csrfToken = crypto.randomBytes(24).toString('hex');
  const now = Date.now();
  const expiresAt = now + SESSION_TTL_MS;

  const sessionObj: SessionData = {
    userId: user.id,
    matricula: user.matricula,
    rol: user.rol,
    nombre: user.nombre,
    csrfToken,
    createdAt: now,
    expiresAt,
  };

  sessions.set(sessionId, sessionObj);

  // Persistir en SQLite para resistir reinicios del servidor
  try {
    runQuery(`
      INSERT OR REPLACE INTO sesiones (session_id, user_id, matricula, rol, nombre, csrf_token, created_at, expires_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `, [sessionId, user.id, user.matricula, user.rol, user.nombre, csrfToken, now, expiresAt]);
  } catch (err) {
    console.error('Error al persistir sesión en SQLite:', err);
  }

  return { sessionId, csrfToken };
}

export function getSession(sessionId: string | null | undefined): SessionData | null {
  if (!sessionId) return null;

  // 1. Verificar en memoria
  const memorySession = sessions.get(sessionId);
  if (memorySession) {
    if (Date.now() > memorySession.expiresAt) {
      sessions.delete(sessionId);
      runQuery('DELETE FROM sesiones WHERE session_id = ?', [sessionId]);
      return null;
    }
    return memorySession;
  }

  // 2. Verificar en SQLite (recuperación tras reinicio)
  try {
    const row = queryOne<{
      session_id: string;
      user_id: string;
      matricula: string;
      rol: 'ESTUDIANTE' | 'BEDELIA' | 'ADMINISTRACION';
      nombre: string;
      csrf_token: string;
      created_at: number;
      expires_at: number;
    }>('SELECT * FROM sesiones WHERE session_id = ?', [sessionId]);

    if (row) {
      const expiresAtNum = Number(row.expires_at);
      if (Date.now() > expiresAtNum) {
        sessions.delete(sessionId);
        runQuery('DELETE FROM sesiones WHERE session_id = ?', [sessionId]);
        return null;
      }

      const restoredSession: SessionData = {
        userId: row.user_id,
        matricula: row.matricula,
        rol: row.rol,
        nombre: row.nombre,
        csrfToken: row.csrf_token,
        createdAt: Number(row.created_at),
        expiresAt: expiresAtNum,
      };

      sessions.set(sessionId, restoredSession);
      return restoredSession;
    }
  } catch (err) {
    console.error('Error al consultar sesión en SQLite:', err);
  }

  return null;
}

export function destroySession(sessionId: string): void {
  if (sessionId) {
    sessions.delete(sessionId);
    try {
      runQuery('DELETE FROM sesiones WHERE session_id = ?', [sessionId]);
    } catch {}
  }
}

// Middleware de Autenticación Multicanal (Headers Bearer + x-session-id + Cookies + Fallback)
export function requireAuth(req: Request, res: Response, next: NextFunction): void {
  const authHeader = req.headers['authorization'];
  const bearerToken = authHeader && authHeader.startsWith('Bearer ') ? authHeader.slice(7).trim() : null;
  const headerSessionId = (req.headers['x-session-id'] as string) || (req.headers['x-session'] as string);
  const cookieSessionId = req.cookies?.iov_session;
  const querySessionId = req.query?.__sessionId as string;
  const bodySessionId = req.body?.__sessionId as string;

  const sessionId = bearerToken || headerSessionId || cookieSessionId || querySessionId || bodySessionId;
  const session = getSession(sessionId);

  if (!session) {
    res.status(401).json({
      error: 'Sesión no válida o expirada. Por favor inicie sesión nuevamente.',
      code: 'UNAUTHENTICATED',
    });
    return;
  }

  (req as any).session = session;
  next();
}

// Middleware de Validación por Rol (RBAC)
export function requireRole(...roles: string[]) {
  return (req: Request, res: Response, next: NextFunction): void => {
    const session = (req as any).session as SessionData;
    if (!session || !roles.includes(session.rol)) {
      const correlationId = crypto.randomUUID();
      try {
        runQuery(`
          INSERT INTO auditoria (id, actor_id, actor_rol, accion, recurso, resultado, detalles_json, correlation_id, ip_address)
          VALUES (?, ?, ?, ?, ?, 'DENEGADO', ?, ?, ?)
        `, [
          crypto.randomUUID(),
          session?.userId || 'ANONIMO',
          session?.rol || 'DESCONOCIDO',
          req.method,
          req.originalUrl,
          JSON.stringify({ rolesRequeridos: roles, ip: req.ip }),
          correlationId,
          req.ip,
        ]);
      } catch (err) {
        console.error('Error al registrar auditoría 403:', err);
      }

      res.status(403).json({
        error: 'Acceso no autorizado. Este perfil no tiene permisos para realizar esta operación.',
        code: 'FORBIDDEN',
        correlationId,
      });
      return;
    }
    next();
  };
}

// Middleware de CSRF Flexible y Seguro
export function requireCsrf(req: Request, res: Response, next: NextFunction): void {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) {
    return next();
  }

  const session = (req as any).session as SessionData;
  const csrfHeader = req.headers['x-csrf-token'];
  const authHeader = req.headers['authorization'];
  const headerSessionId = req.headers['x-session-id'];

  // Si la petición ya está autenticada explícitamente mediante Bearer header o x-session-id propio,
  // la protección CORS/SOP del navegador ya previene ataques CSRF de origen cruzado.
  if (session && (authHeader || headerSessionId || csrfHeader === session.csrfToken)) {
    return next();
  }

  res.status(403).json({
    error: 'Token de seguridad CSRF inválido o faltante.',
    code: 'CSRF_INVALID',
  });
}

// Controlador de Login con Bloqueo Acumulativo no Evadible
export function handleLogin(req: Request, res: Response): void {
  const { matricula, correo, password, rol } = req.body || {};
  const ip = req.ip || req.socket.remoteAddress || '127.0.0.1';

  if (!matricula || !correo || !password) {
    res.status(400).json({
      error: 'Debe ingresar la matrícula, el correo institucional y la contraseña.',
    });
    return;
  }

  const matriculaNorm = String(matricula).trim().toUpperCase();
  const correoNorm = String(correo).trim().toLowerCase();

  // 1. Verificar Bloqueo por Matrícula Normalizada o IP
  const bloqueo = queryOne<{ contador: number; bloqueado_hasta: string | null }>(`
    SELECT contador, bloqueado_hasta
    FROM intentos_login
    WHERE matricula_normalizada = ?
  `, [matriculaNorm]);

  if (bloqueo && bloqueo.bloqueado_hasta) {
    const ahora = new Date();
    const tiempoBloqueo = new Date(bloqueo.bloqueado_hasta);

    if (tiempoBloqueo > ahora) {
      const minutosRestantes = Math.ceil((tiempoBloqueo.getTime() - ahora.getTime()) / (60 * 1000));
      res.status(429).json({
        error: `Cuenta temporalmente bloqueada por exceso de intentos fallidos. Intente nuevamente en ${minutosRestantes} minutos.`,
        code: 'ACCOUNT_LOCKED',
        minutosRestantes,
      });
      return;
    }
  }

  // 2. Buscar usuario por Matrícula
  const user = queryOne<{
    id: string;
    matricula: string;
    correo: string;
    password_hash: string;
    rol: string;
    estado: string;
  }>(`
    SELECT id, matricula, correo, password_hash, rol, estado
    FROM usuarios
    WHERE matricula = ?
  `, [matriculaNorm]);

  let credentialsValid = false;

  if (user && user.estado === 'ACTIVO') {
    // Validar contraseña con bcrypt y correo institucional
    const passwordMatch = bcrypt.compareSync(password, user.password_hash);
    const correoMatch = user.correo.toLowerCase() === correoNorm;
    const rolMatch = !rol || user.rol === rol;

    if (passwordMatch && correoMatch && rolMatch) {
      credentialsValid = true;
    }
  }

  if (!credentialsValid) {
    // Incrementar contador de intentos fallidos asociado a la matrícula (independiente del correo ingresado)
    let nuevoContador = 1;
    let nuevoBloqueoHasta: string | null = null;

    if (bloqueo) {
      nuevoContador = bloqueo.contador + 1;
      if (nuevoContador >= 5) {
        // Bloqueo por 15 minutos tras 5 fallos acumulados
        const fechaBloqueo = new Date(Date.now() + 15 * 60 * 1000);
        nuevoBloqueoHasta = fechaBloqueo.toISOString();
      }

      runQuery(`
        UPDATE intentos_login
        SET contador = ?, bloqueado_hasta = ?, ultimo_intento = datetime('now')
        WHERE matricula_normalizada = ?
      `, [nuevoContador, nuevoBloqueoHasta, matriculaNorm]);
    } else {
      runQuery(`
        INSERT INTO intentos_login (id, matricula_normalizada, ip_address, contador, bloqueado_hasta, ultimo_intento)
        VALUES (?, ?, ?, 1, NULL, datetime('now'))
      `, [crypto.randomUUID(), matriculaNorm, ip]);
    }

    // Registrar en auditoría
    runQuery(`
      INSERT INTO auditoria (id, actor_id, actor_rol, accion, recurso, resultado, detalles_json, correlation_id, ip_address)
      VALUES (?, ?, ?, 'LOGIN', 'auth', 'FALLO', ?, ?, ?)
    `, [
      crypto.randomUUID(),
      matriculaNorm,
      rol || 'DESCONOCIDO',
      JSON.stringify({ intentos: nuevoContador, bloqueado: !!nuevoBloqueoHasta }),
      crypto.randomUUID(),
      ip,
    ]);

    if (nuevoBloqueoHasta) {
      res.status(429).json({
        error: 'Cuenta bloqueada temporalmente por 15 minutos debido a 5 intentos fallidos consecutivos.',
        code: 'ACCOUNT_LOCKED',
        minutosRestantes: 15,
      });
      return;
    }

    res.status(401).json({
      error: 'Credenciales inválidas. Verifique matrícula, correo o contraseña.',
      code: 'INVALID_CREDENTIALS',
      intentosRestantes: Math.max(0, 5 - nuevoContador),
    });
    return;
  }

  // 3. Credenciales correctas: resetear contador
  runQuery(`
    DELETE FROM intentos_login WHERE matricula_normalizada = ?
  `, [matriculaNorm]);

  // Obtener nombre del perfil
  let nombreUsuario = user!.matricula;
  if (user!.rol === 'ESTUDIANTE') {
    const est = queryOne<{ nombre_completo: string }>(
      'SELECT nombre_completo FROM estudiantes WHERE usuario_id = ?',
      [user!.id]
    );
    if (est) nombreUsuario = est.nombre_completo;
  } else if (user!.rol === 'BEDELIA') {
    nombreUsuario = 'Dra. María Elena Vázquez (Bedelía)';
  } else {
    nombreUsuario = 'Cdor. Carlos Méndez (Administración)';
  }

  // Crear sesión
  const { sessionId, csrfToken } = createSession({
    id: user!.id,
    matricula: user!.matricula,
    rol: user!.rol,
    nombre: nombreUsuario,
  });

  // Emitir cookie HttpOnly
  const isHttps = req.secure || req.headers['x-forwarded-proto'] === 'https';
  res.cookie('iov_session', sessionId, {
    httpOnly: true,
    secure: isHttps,
    sameSite: isHttps ? 'none' : 'lax',
    maxAge: SESSION_TTL_MS,
    path: '/',
  });

  res.cookie('iov_csrf', csrfToken, {
    httpOnly: false, // Accesible al frontend para encabezado x-csrf-token
    secure: isHttps,
    sameSite: isHttps ? 'none' : 'lax',
    maxAge: SESSION_TTL_MS,
    path: '/',
  });

  // Auditoría login exitoso
  runQuery(`
    INSERT INTO auditoria (id, actor_id, actor_rol, accion, recurso, resultado, correlation_id, ip_address)
    VALUES (?, ?, ?, 'LOGIN', 'auth', 'EXITO', ?, ?)
  `, [
    crypto.randomUUID(),
    user!.id,
    user!.rol,
    crypto.randomUUID(),
    ip,
  ]);

  res.json({
    ok: true,
    sessionId,
    csrfToken,
    user: {
      id: user!.id,
      matricula: user!.matricula,
      correo: user!.correo,
      rol: user!.rol,
      nombre: nombreUsuario,
    },
  });
}

// Controlador de Logout
export function handleLogout(req: Request, res: Response): void {
  const authHeader = req.headers['authorization'];
  const bearerToken = authHeader && authHeader.startsWith('Bearer ') ? authHeader.slice(7).trim() : null;
  const headerSessionId = (req.headers['x-session-id'] as string) || (req.headers['x-session'] as string);
  const cookieSessionId = req.cookies?.iov_session;
  const sessionId = bearerToken || headerSessionId || cookieSessionId;

  if (sessionId) {
    destroySession(sessionId);
  }

  res.clearCookie('iov_session', { path: '/' });
  res.clearCookie('iov_csrf', { path: '/' });

  res.json({ ok: true, message: 'Sesión cerrada correctamente.' });
}

// Perfil del Estudiante
export function getStudentProfile(req: Request, res: Response): void {
  const session = (req as any).session as SessionData;
  const profile = queryOne<any>(`
    SELECT 
      e.id,
      e.nombre_completo,
      e.anio_cursado,
      e.telefono,
      e.domicilio,
      e.ciudad,
      e.correo_personal,
      e.condicion_academica,
      u.matricula,
      u.correo as correo_institucional,
      c.nombre as carrera_nombre,
      p.version as plan_version,
      p.codigo_plan
    FROM estudiantes e
    JOIN usuarios u ON e.usuario_id = u.id
    JOIN carreras c ON e.carrera_id = c.id
    JOIN planes_estudio p ON e.plan_id = p.id
    WHERE u.id = ?
  `, [session.userId]);

  if (!profile) {
    res.status(404).json({ error: 'Perfil de estudiante no encontrado.' });
    return;
  }

  res.json({ profile });
}

// Actualizar Perfil (Solo campos permitidos)
export function updateStudentProfile(req: Request, res: Response): void {
  const session = (req as any).session as SessionData;
  const { telefono, domicilio, ciudad, correo_personal } = req.body || {};

  // Validaciones de tipo y formato básico
  const cleanTel = telefono !== undefined ? String(telefono).trim() : null;
  const cleanDom = domicilio !== undefined ? String(domicilio).trim() : null;
  const cleanCiu = ciudad !== undefined ? String(ciudad).trim() : null;
  const cleanEmail = correo_personal !== undefined ? String(correo_personal).trim() : null;

  runQuery(`
    UPDATE estudiantes
    SET telefono = COALESCE(?, telefono),
        domicilio = COALESCE(?, domicilio),
        ciudad = COALESCE(?, ciudad),
        correo_personal = COALESCE(?, correo_personal),
        updated_at = datetime('now')
    WHERE usuario_id = ?
  `, [cleanTel, cleanDom, cleanCiu, cleanEmail, session.userId]);

  runQuery(`
    INSERT INTO auditoria (id, actor_id, actor_rol, accion, recurso, resultado, correlation_id)
    VALUES (?, ?, 'ESTUDIANTE', 'UPDATE_PROFILE', 'estudiantes', 'EXITO', ?)
  `, [crypto.randomUUID(), session.userId, crypto.randomUUID()]);

  res.json({ ok: true, message: 'Datos personales actualizados correctamente.' });
}

// Cambio de Contraseña
export function handleChangePassword(req: Request, res: Response): void {
  const session = (req as any).session as SessionData;
  const { passwordActual, passwordNueva, passwordConfirmacion } = req.body || {};

  if (!passwordActual || !passwordNueva || !passwordConfirmacion) {
    res.status(400).json({ error: 'Todos los campos de contraseña son requeridos.' });
    return;
  }

  if (passwordNueva !== passwordConfirmacion) {
    res.status(400).json({ error: 'La nueva contraseña y su confirmación no coinciden.' });
    return;
  }

  if (passwordNueva.length < 8) {
    res.status(400).json({ error: 'La nueva contraseña debe tener al menos 8 caracteres.' });
    return;
  }

  const user = queryOne<{ password_hash: string }>(
    'SELECT password_hash FROM usuarios WHERE id = ?',
    [session.userId]
  );

  if (!user || !bcrypt.compareSync(passwordActual, user.password_hash)) {
    res.status(400).json({ error: 'La contraseña actual ingresada es incorrecta.' });
    return;
  }

  const salt = bcrypt.genSaltSync(10);
  const newHash = bcrypt.hashSync(passwordNueva, salt);

  runQuery(
    'UPDATE usuarios SET password_hash = ?, updated_at = datetime(\'now\') WHERE id = ?',
    [newHash, session.userId]
  );

  runQuery(`
    INSERT INTO auditoria (id, actor_id, actor_rol, accion, recurso, resultado, correlation_id)
    VALUES (?, ?, ?, 'CHANGE_PASSWORD', 'usuarios', 'EXITO', ?)
  `, [crypto.randomUUID(), session.userId, session.rol, crypto.randomUUID()]);

  res.json({ ok: true, message: 'Contraseña actualizada correctamente.' });
}

// Registro de Nuevos Usuarios
export function handleRegister(req: Request, res: Response): void {
  const { matricula, correo, password, rol, nombreCompleto, carreraId } = req.body || {};

  if (!matricula || !correo || !password || !nombreCompleto) {
    res.status(400).json({ error: 'Todos los campos son obligatorios para el registro.' });
    return;
  }

  const matriculaNorm = String(matricula).trim().toUpperCase();
  const correoNorm = String(correo).trim().toLowerCase();
  const rolUser = rol === 'BEDELIA' || rol === 'ADMINISTRACION' ? rol : 'ESTUDIANTE';

  // Verificar si la cuenta ya existe
  const existente = queryOne<{ matricula: string; correo: string }>(
    'SELECT matricula, correo FROM usuarios WHERE matricula = ? OR LOWER(correo) = ?',
    [matriculaNorm, correoNorm]
  );

  if (existente) {
    res.status(409).json({
      error: 'La cuenta ya está registrada en la base de datos con esa matrícula o correo institucional.',
      code: 'ALREADY_EXISTS',
    });
    return;
  }

  if (password.length < 8) {
    res.status(400).json({ error: 'La contraseña debe tener al menos 8 caracteres.' });
    return;
  }

  const salt = bcrypt.genSaltSync(10);
  const hash = bcrypt.hashSync(password, salt);
  const newUserId = crypto.randomUUID();

  runQuery(`
    INSERT INTO usuarios (id, matricula, correo, password_hash, rol, estado)
    VALUES (?, ?, ?, ?, ?, 'ACTIVO')
  `, [newUserId, matriculaNorm, correoNorm, hash, rolUser]);

  if (rolUser === 'ESTUDIANTE') {
    const studentId = crypto.randomUUID();
    const carId = carreraId || 'CAR-LSI';
    const planRow = queryOne<{ id: string }>(
      'SELECT id FROM planes_estudio WHERE carrera_id = ? AND estado = "VIGENTE" ORDER BY anio_validez DESC LIMIT 1',
      [carId]
    );
    const assignedPlanId = planRow?.id || 'PLAN-LSI-2023';

    runQuery(`
      INSERT INTO estudiantes (id, usuario_id, nombre_completo, carrera_id, plan_id, anio_cursado, condicion_academica)
      VALUES (?, ?, ?, ?, ?, 1, 'REGULAR')
    `, [studentId, newUserId, String(nombreCompleto).trim(), carId, assignedPlanId]);
  }

  runQuery(`
    INSERT INTO auditoria (id, actor_id, actor_rol, accion, recurso, resultado, correlation_id)
    VALUES (?, ?, ?, 'REGISTER', 'usuarios', 'EXITO', ?)
  `, [crypto.randomUUID(), newUserId, rolUser, crypto.randomUUID()]);

  res.json({
    ok: true,
    message: 'Cuenta registrada exitosamente en la base de datos.',
    user: {
      matricula: matriculaNorm,
      correo: correoNorm,
      rol: rolUser,
      nombre: String(nombreCompleto).trim(),
    },
  });
}

// Autocompletar datos según correo institucional
export function lookupEmail(req: Request, res: Response): void {
  const correo = String(req.query.correo || '').trim().toLowerCase();

  if (!correo) {
    res.status(400).json({ error: 'Correo no especificado.' });
    return;
  }

  const user = queryOne<{ id: string; matricula: string; correo: string; rol: string }>(
    'SELECT id, matricula, correo, rol FROM usuarios WHERE LOWER(correo) = ?',
    [correo]
  );

  if (!user) {
    res.json({ exists: false });
    return;
  }

  let nombre = user.matricula;
  if (user.rol === 'ESTUDIANTE') {
    const est = queryOne<{ nombre_completo: string }>(
      'SELECT nombre_completo FROM estudiantes WHERE usuario_id = ?',
      [user.id]
    );
    if (est) nombre = est.nombre_completo;
  } else if (user.rol === 'BEDELIA') {
    nombre = 'Dra. María Elena Vázquez (Bedelía)';
  } else {
    nombre = 'Cdor. Carlos Méndez (Administración)';
  }

  res.json({
    exists: true,
    matricula: user.matricula,
    correo: user.correo,
    rol: user.rol,
    nombre,
  });
}

// Listado de cuentas registradas para autocompletado rápido
export function getRegisteredAccounts(req: Request, res: Response): void {
  const users = queryAll<{ id: string; matricula: string; correo: string; rol: string }>(
    'SELECT id, matricula, correo, rol FROM usuarios ORDER BY created_at ASC'
  );

  const result = users.map((u) => {
    let nombre = u.matricula;
    if (u.rol === 'ESTUDIANTE') {
      const est = queryOne<{ nombre_completo: string }>(
        'SELECT nombre_completo FROM estudiantes WHERE usuario_id = ?',
        [u.id]
      );
      if (est) nombre = est.nombre_completo;
    } else if (u.rol === 'BEDELIA') {
      nombre = 'Dra. María Elena Vázquez (Bedelía)';
    } else {
      nombre = 'Cdor. Carlos Méndez (Administración)';
    }
    return {
      matricula: u.matricula,
      correo: u.correo,
      rol: u.rol,
      nombre,
    };
  });

  res.json({ accounts: result });
}

