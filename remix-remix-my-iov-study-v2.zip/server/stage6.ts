import { Request, Response } from 'express';
import { queryAll, queryOne, runQuery } from './db.js';

function getEstudianteId(usuarioId: string): string {
  const row = queryOne<{ id: string }>('SELECT id FROM estudiantes WHERE usuario_id = ?', [usuarioId]);
  return row?.id || 'EST-001';
}

/**
 * 1. Formas de Pago
 */
export async function getPaymentMethods(req: Request, res: Response): Promise<void> {
  const session = (req as any).session;
  const estudianteId = getEstudianteId(session.userId);

  let methods = queryAll<{
    id: string;
    tipo: string;
    titular: string;
    detalle: string;
    cbu_alias: string;
    estado: string;
  }>('SELECT * FROM formas_pago WHERE estudiante_id = ?', [estudianteId]);

  // Si no hay ninguno, insertar semilla por defecto para Lucía
  if (methods.length === 0) {
    runQuery(`
      INSERT INTO formas_pago (id, estudiante_id, tipo, titular, detalle, cbu_alias, estado) VALUES
      ('PAY-01', ?, 'DEBITO_AUTOMATICO', 'Lucía Belén Gómez', 'Banco Santander Río · Caja de Ahorro en Pesos', 'LUCIA.GOMEZ.UCSF', 'ACTIVO'),
      ('PAY-02', ?, 'TARJETA_CREDITO', 'Lucía Belén Gómez', 'Visa Débito terminada en 4419', NULL, 'ACTIVO')
    `, [estudianteId, estudianteId]);

    methods = queryAll('SELECT * FROM formas_pago WHERE estudiante_id = ?', [estudianteId]);
  }

  res.json({ ok: true, methods });
}

export async function addPaymentMethod(req: Request, res: Response): Promise<void> {
  const session = (req as any).session;
  const estudianteId = getEstudianteId(session.userId);
  const { tipo, titular, detalle, cbu_alias } = req.body;

  if (!tipo || !titular || !detalle) {
    res.status(400).json({ ok: false, message: 'Tipo, titular y detalle son requeridos' });
    return;
  }

  const id = `PAY-${Date.now().toString(36).toUpperCase()}`;
  runQuery(`
    INSERT INTO formas_pago (id, estudiante_id, tipo, titular, detalle, cbu_alias, estado)
    VALUES (?, ?, ?, ?, ?, ?, 'ACTIVO')
  `, [id, estudianteId, tipo, titular, detalle, cbu_alias || null]);

  res.json({ ok: true, id, message: 'Medio de pago asociado correctamente' });
}

export async function deletePaymentMethod(req: Request, res: Response): Promise<void> {
  const session = (req as any).session;
  const estudianteId = getEstudianteId(session.userId);
  const { id } = req.params;

  runQuery('DELETE FROM formas_pago WHERE id = ? AND estudiante_id = ?', [id, estudianteId]);
  res.json({ ok: true, message: 'Medio de pago eliminado' });
}

/**
 * 2. Ficha de Salud Estudiantil
 */
export async function getHealthRecord(req: Request, res: Response): Promise<void> {
  const session = (req as any).session;
  const estudianteId = getEstudianteId(session.userId);

  let record = queryOne<{
    id: string;
    grupo_sanguineo: string;
    obra_social: string;
    numero_afiliado: string;
    contacto_emergencia: string;
    telefono_emergencia: string;
    apto_fisico: string;
    observaciones: string;
    updated_at: string;
  }>('SELECT * FROM fichas_salud WHERE estudiante_id = ?', [estudianteId]);

  if (!record) {
    runQuery(`
      INSERT INTO fichas_salud (id, estudiante_id, grupo_sanguineo, obra_social, numero_afiliado, contacto_emergencia, telefono_emergencia, apto_fisico, observaciones)
      VALUES ('SAL-001', ?, '0+', 'OSDE Plan 210', '120938491-01', 'Marta Elena Rossi (Madre)', '+54 342 455-8901', 'VIGENTE', 'Alergia leve a la penicilina informada en ficha de ingreso')
    `, [estudianteId]);

    record = queryOne('SELECT * FROM fichas_salud WHERE estudiante_id = ?', [estudianteId]);
  }

  res.json({ ok: true, record });
}

export async function updateHealthRecord(req: Request, res: Response): Promise<void> {
  const session = (req as any).session;
  const estudianteId = getEstudianteId(session.userId);
  const { grupo_sanguineo, obra_social, numero_afiliado, contacto_emergencia, telefono_emergencia, observaciones } = req.body;

  runQuery(`
    UPDATE fichas_salud
    SET grupo_sanguineo = ?, obra_social = ?, numero_afiliado = ?, contacto_emergencia = ?, telefono_emergencia = ?, observaciones = ?, updated_at = datetime('now')
    WHERE estudiante_id = ?
  `, [grupo_sanguineo, obra_social, numero_afiliado, contacto_emergencia, telefono_emergencia, observaciones, estudianteId]);

  res.json({ ok: true, message: 'Ficha de salud actualizada con éxito' });
}

/**
 * 3. Trámites Especiales (TAV y Título)
 */
export async function getSpecialProcedures(req: Request, res: Response): Promise<void> {
  const session = (req as any).session;
  const estudianteId = getEstudianteId(session.userId);

  let procedures = queryAll<{
    id: string;
    tipo: string;
    titulo: string;
    descripcion: string;
    documentacion_adjunta: string;
    estado: string;
    resolucion_numero: string;
    created_at: string;
  }>('SELECT * FROM tramites_especiales WHERE estudiante_id = ?', [estudianteId]);

  if (procedures.length === 0) {
    runQuery(`
      INSERT INTO tramites_especiales (id, estudiante_id, tipo, titulo, descripcion, documentacion_adjunta, estado, resolucion_numero) VALUES
      ('TRM-TAV-01', ?, 'TAV', 'Trámite Académico Vinculado - Reconocimiento de Créditos Extracurriculares', 'Certificado de Jornadas Internacionales de Informática 2025', 'certificado_jornadas_2025.pdf', 'DICTAMEN_FAVORABLE', 'Res. Decanal N° 88/2026'),
      ('TRM-TIT-01', ?, 'TITULO', 'Iniciación del Trámite de Diploma y Colación', 'Control de Libre Deuda de Biblioteca y Aranceles', 'constancia_libre_deuda.pdf', 'INICIADO', NULL)
    `, [estudianteId, estudianteId]);

    procedures = queryAll('SELECT * FROM tramites_especiales WHERE estudiante_id = ?', [estudianteId]);
  }

  res.json({ ok: true, procedures });
}

export async function startSpecialProcedure(req: Request, res: Response): Promise<void> {
  const session = (req as any).session;
  const estudianteId = getEstudianteId(session.userId);
  const { tipo, titulo, descripcion, documentacion_adjunta } = req.body;

  if (!tipo || !titulo) {
    res.status(400).json({ ok: false, message: 'Tipo y título son requeridos' });
    return;
  }

  const id = `TRM-${Date.now().toString(36).toUpperCase()}`;
  runQuery(`
    INSERT INTO tramites_especiales (id, estudiante_id, tipo, titulo, descripcion, documentacion_adjunta, estado)
    VALUES (?, ?, ?, ?, ?, ?, 'INICIADO')
  `, [id, estudianteId, tipo, titulo, descripcion || '', documentacion_adjunta || null]);

  res.json({ ok: true, id, message: 'Trámite especial iniciado formalmente ante Bedelía' });
}

/**
 * 4. Encuestas Docentes
 */
export async function getSurveys(req: Request, res: Response): Promise<void> {
  const session = (req as any).session;
  const estudianteId = getEstudianteId(session.userId);

  let surveys = queryAll<{
    id: string;
    comision_id: string;
    docente_nombre: string;
    materia_nombre: string;
    puntaje_pedagogico: number;
    puntaje_puntualidad: number;
    puntaje_material: number;
    comentarios: string;
    completada: number;
  }>('SELECT * FROM encuestas_docentes WHERE estudiante_id = ?', [estudianteId]);

  if (surveys.length === 0) {
    runQuery(`
      INSERT INTO encuestas_docentes (id, estudiante_id, comision_id, docente_nombre, materia_nombre, puntaje_pedagogico, puntaje_puntualidad, puntaje_material, completada) VALUES
      ('ENC-01', ?, 'COM-POO-A', 'Ing. Roberto Rossi', 'Programación Orientada a Objetos', 5, 5, 4, 1),
      ('ENC-02', ?, 'COM-BD1-U', 'Lic. Mariana Peralta', 'Base de Datos I', 5, 4, 5, 0)
    `, [estudianteId, estudianteId]);

    surveys = queryAll('SELECT * FROM encuestas_docentes WHERE estudiante_id = ?', [estudianteId]);
  }

  res.json({ ok: true, surveys });
}

export async function submitSurvey(req: Request, res: Response): Promise<void> {
  const session = (req as any).session;
  const estudianteId = getEstudianteId(session.userId);
  const { id } = req.params;
  const { puntaje_pedagogico, puntaje_puntualidad, puntaje_material, comentarios } = req.body;

  runQuery(`
    UPDATE encuestas_docentes
    SET puntaje_pedagogico = ?, puntaje_puntualidad = ?, puntaje_material = ?, comentarios = ?, completada = 1, updated_at = datetime('now')
    WHERE id = ? AND estudiante_id = ?
  `, [puntaje_pedagogico || 5, puntaje_puntualidad || 5, puntaje_material || 5, comentarios || '', id, estudianteId]);

  res.json({ ok: true, message: 'Encuesta docente enviada de forma anónima institucional' });
}

/**
 * 5. Acciones Administrativas de Bedelía
 */
export async function adminReallocateClassroom(req: Request, res: Response): Promise<void> {
  const { horarioId, aulaId, estadoAula, observaciones } = req.body;

  if (!horarioId) {
    res.status(400).json({ ok: false, message: 'ID de horario requerido' });
    return;
  }

  runQuery(`
    UPDATE horarios
    SET aula_id = COALESCE(?, aula_id),
        estado_aula = COALESCE(?, estado_aula),
        observaciones = COALESCE(?, observaciones),
        updated_at = datetime('now')
    WHERE id = ?
  `, [aulaId || null, estadoAula || 'MODIFICADA', observaciones || '', horarioId]);

  res.json({ ok: true, message: 'Reubicación de aula aplicada exitosamente' });
}

export async function adminResolveCertificate(req: Request, res: Response): Promise<void> {
  const { id } = req.params;
  const { estado, motivoRechazo } = req.body;

  if (!['LISTA', 'EN_PROCESO', 'RECHAZADA'].includes(estado)) {
    res.status(400).json({ ok: false, message: 'Estado inválido' });
    return;
  }

  runQuery(`
    UPDATE solicitudes_certificado
    SET estado = ?, motivo_rechazo = ?, fecha_resolucion = datetime('now'), updated_at = datetime('now')
    WHERE id = ?
  `, [estado, motivoRechazo || null, id]);

  res.json({ ok: true, message: `Certificado ${id} actualizado a estado ${estado}` });
}
