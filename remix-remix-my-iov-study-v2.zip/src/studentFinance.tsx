import React, { useState, useEffect } from 'react';
import { apiFetch } from './apiClient';
import {
  CreditCard,
  FileCheck,
  CheckCircle2,
  Clock,
  Download,
  AlertTriangle,
  RefreshCw,
  Receipt,
  FileText,
} from 'lucide-react';

interface FeeItem {
  id: string;
  periodo: string;
  concepto: string;
  monto: number;
  fecha_vencimiento: string;
  estado: 'PAGADA' | 'PENDIENTE' | 'VENCIDA';
  numero_comprobante?: string;
  fecha_pago?: string;
  medio_pago?: string;
  monto_abonado?: number;
  archivo_nombre?: string;
}

export function StudentFinancePage({ showComprobantesOnly = false }: { showComprobantesOnly?: boolean }) {
  const [fees, setFees] = useState<FeeItem[]>([]);
  const [resumen, setResumen] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [selectedReceipt, setSelectedReceipt] = useState<FeeItem | null>(null);

  const loadFinance = async () => {
    setLoading(true);
    try {
      const res = await apiFetch('/api/finance/fees');
      if (res.ok) {
        const d = await res.json();
        setFees(d.cuotas || []);
        setResumen(d.resumen || null);
      }
    } catch (err) {
      console.error('Error cargando aranceles:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadFinance();
  }, []);

  const formatMoney = (val: number) => {
    return new Intl.NumberFormat('es-AR', {
      style: 'currency',
      currency: 'ARS',
      maximumFractionDigits: 2,
    }).format(val);
  };

  const pagadas = fees.filter((f) => f.estado === 'PAGADA');
  const pendientes = fees.filter((f) => f.estado !== 'PAGADA');

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="iov-card iov-card-destacada">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="badge-vigente">Secretaría de Aranceles</span>
              <span className="text-xs text-slate-500 font-medium">Ciclo Lectivo 2026</span>
            </div>
            <h2 className="text-xl md:text-2xl font-black text-[var(--azul-900)] tracking-tight">
              {showComprobantesOnly ? 'Comprobantes Oficiales de Pago' : 'Cuotas y Estado Arancelario'}
            </h2>
            <p className="text-xs md:text-sm text-slate-600 mt-1 max-w-2xl">
              Detalle oficial de cuotas mensuales, vencimientos, importes y recibos digitales oficiales descargables.
            </p>
          </div>

          <button
            onClick={loadFinance}
            className="btn-secondary text-xs shrink-0 self-start md:self-auto"
            disabled={loading}
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            <span>Actualizar</span>
          </button>
        </div>
      </div>

      {/* Resumen de Cuenta Arancelaria */}
      {resumen && !showComprobantesOnly && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="iov-card p-4">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-bold text-slate-600">Estado de Cuenta</span>
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            </div>
            <div className="text-xl font-black text-emerald-700">
              {resumen.alDia ? 'AL DÍA' : 'PENDIENTE'}
            </div>
            <div className="text-[11px] text-slate-500 mt-0.5">
              Habilitado/a para rendir finales
            </div>
          </div>

          <div className="iov-card p-4">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-bold text-slate-600">Total Pendiente</span>
              <Clock className="w-4 h-4 text-amber-500" />
            </div>
            <div className="text-xl font-black text-[var(--azul-900)]">
              {formatMoney(resumen.totalPendiente)}
            </div>
            <div className="text-[11px] text-slate-500 mt-0.5">
              {pendientes.length} cuota(s) a vencer
            </div>
          </div>

          <div className="iov-card p-4">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-bold text-slate-600">Abonado en 2026</span>
              <FileCheck className="w-4 h-4 text-[var(--celeste-500)]" />
            </div>
            <div className="text-xl font-black text-slate-800">
              {formatMoney(resumen.totalAbonado)}
            </div>
            <div className="text-[11px] text-slate-500 mt-0.5">
              {pagadas.length} cuota(s) canceladas
            </div>
          </div>
        </div>
      )}

      {/* Listado de Cuotas Pendientes */}
      {!showComprobantesOnly && pendientes.length > 0 && (
        <div className="iov-card">
          <h3 className="text-base font-bold text-[var(--azul-900)] mb-3">
            Cuotas Próximas a Vencer
          </h3>

          <div className="space-y-3">
            {pendientes.map((fee) => (
              <div
                key={fee.id}
                className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
              >
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="badge-provisorio text-[10px]">{fee.periodo}</span>
                    <span className="font-mono text-[11px] font-bold text-slate-600">{fee.id}</span>
                  </div>
                  <h4 className="text-sm font-bold text-slate-900">{fee.concepto}</h4>
                  <div className="text-slate-600 mt-0.5">
                    Vencimiento: <strong>{fee.fecha_vencimiento}</strong>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <div className="text-base font-black text-[var(--azul-900)]">
                      {formatMoney(fee.monto)}
                    </div>
                    <span className="badge-critico text-[10px]">PENDIENTE DE PAGO</span>
                  </div>
                  <button
                    onClick={() => alert(`Acceso a pasarela de pago para la cuota ${fee.periodo}`)}
                    className="btn-primary text-xs"
                  >
                    <CreditCard className="w-3.5 h-3.5" />
                    <span>Abonar</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Comprobantes Pagados */}
      <div className="iov-card">
        <h3 className="text-base font-bold text-[var(--azul-900)] mb-1">
          Comprobantes y Recibos Oficiales ({pagadas.length})
        </h3>
        <p className="text-xs text-slate-600 mb-4">
          Descarga o visualiza tus recibos emitidos con código de control fiscal y validez universitaria.
        </p>

        <div className="table-container">
          <table className="iov-table">
            <thead>
              <tr>
                <th>Período</th>
                <th>Concepto</th>
                <th>Monto Abonado</th>
                <th>Fecha de Pago</th>
                <th>Medio de Pago</th>
                <th>N° Comprobante</th>
                <th>Acción</th>
              </tr>
            </thead>
            <tbody>
              {pagadas.map((fee) => (
                <tr key={fee.id}>
                  <td className="font-mono font-bold text-[var(--azul-700)] text-xs">
                    {fee.periodo}
                  </td>
                  <td className="font-semibold text-slate-800">{fee.concepto}</td>
                  <td className="font-bold text-emerald-700">{formatMoney(fee.monto_abonado || fee.monto)}</td>
                  <td className="text-xs font-mono">{fee.fecha_pago}</td>
                  <td className="text-xs text-slate-600">{fee.medio_pago}</td>
                  <td className="font-mono text-xs font-semibold text-slate-700">{fee.numero_comprobante}</td>
                  <td>
                    <button
                      onClick={() => setSelectedReceipt(fee)}
                      className="btn-secondary text-[11px] py-1 px-2.5"
                    >
                      <Receipt className="w-3 h-3" />
                      <span>Ver Recibo</span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal de Recibo Sintético */}
      {selectedReceipt && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 mb-4">
              <div className="flex items-center gap-2">
                <Receipt className="w-5 h-5 text-[var(--azul-700)]" />
                <h3 className="text-base font-bold text-[var(--azul-900)]">
                  Comprobante Oficial de Pago
                </h3>
              </div>
              <button
                onClick={() => setSelectedReceipt(null)}
                className="text-slate-400 hover:text-slate-700 font-bold text-lg"
              >
                ✕
              </button>
            </div>

            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-2 mb-4 font-mono">
              <div className="flex justify-between">
                <span className="text-slate-500">Institución:</span>
                <span className="font-bold text-slate-800">Universidad Católica de Santa Fe</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">N° Comprobante:</span>
                <span className="font-bold text-[var(--azul-700)]">{selectedReceipt.numero_comprobante}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Fecha y Hora:</span>
                <span className="text-slate-800">{selectedReceipt.fecha_pago}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Concepto:</span>
                <span className="text-slate-800">{selectedReceipt.concepto}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Medio de Pago:</span>
                <span className="text-slate-800">{selectedReceipt.medio_pago}</span>
              </div>
              <div className="flex justify-between pt-2 border-t border-slate-200 text-sm font-bold">
                <span>Total Abonado:</span>
                <span className="text-emerald-700">{formatMoney(selectedReceipt.monto_abonado || selectedReceipt.monto)}</span>
              </div>
            </div>

            <div className="flex justify-end gap-2">
              <button
                onClick={() => setSelectedReceipt(null)}
                className="btn-secondary text-xs"
              >
                Cerrar
              </button>
              <button
                onClick={() => {
                  alert(`Descarga de comprobante: ${selectedReceipt.archivo_nombre}`);
                  setSelectedReceipt(null);
                }}
                className="btn-primary text-xs"
              >
                <Download className="w-4 h-4" />
                <span>Descargar PDF</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
