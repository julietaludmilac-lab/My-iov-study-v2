import React, { useState, useEffect } from 'react';
import {
  Bell,
  CheckCircle2,
  Clock,
  BookOpen,
  Calendar,
  AlertTriangle,
  CreditCard,
  Check,
  CheckCheck,
} from 'lucide-react';
import { apiFetch } from './apiClient';

interface NotificationItem {
  id: string;
  tipo: string;
  referencia_id: string;
  titulo: string;
  cuerpo: string;
  leida: number;
  created_at: string;
  fecha_lectura: string | null;
}

export const StudentNotificationsPage: React.FC<{
  onNavigateToSection?: (hash: string) => void;
  onRefreshCount?: (count: number) => void;
}> = ({ onNavigateToSection, onRefreshCount }) => {
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(true);

  const fetchNotifications = async () => {
    try {
      setLoading(true);
      const res = await apiFetch('/api/notifications');
      if (res.ok) {
        const data = await res.json();
        setNotifications(data.notifications || []);
        setUnreadCount(data.unreadCount || 0);
        if (onRefreshCount) onRefreshCount(data.unreadCount || 0);
      }
    } catch (err) {
      console.error('Error al cargar notificaciones:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchNotifications();
  }, []);

  const handleMarkAsRead = async (id: string) => {
    try {
      const res = await apiFetch(`/api/notifications/${id}/read`, {
        method: 'PATCH',
      });
      if (res.ok) {
        const data = await res.json();
        setNotifications((prev) =>
          prev.map((n) => (n.id === id ? { ...n, leida: 1 } : n))
        );
        setUnreadCount(data.unreadCount);
        if (onRefreshCount) onRefreshCount(data.unreadCount);
      }
    } catch (err) {
      console.error('Error al marcar leída:', err);
    }
  };

  const handleMarkAllRead = async () => {
    try {
      const res = await apiFetch('/api/notifications/mark-all-read', {
        method: 'POST',
      });
      if (res.ok) {
        setNotifications((prev) => prev.map((n) => ({ ...n, leida: 1 })));
        setUnreadCount(0);
        if (onRefreshCount) onRefreshCount(0);
      }
    } catch (err) {
      console.error('Error al marcar todas leídas:', err);
    }
  };

  const handleClickNotification = (notif: NotificationItem) => {
    if (!notif.leida) {
      handleMarkAsRead(notif.id);
    }
    if (onNavigateToSection) {
      if (notif.tipo === 'AVISO') onNavigateToSection('avisos');
      else if (notif.tipo === 'PARCIAL') onNavigateToSection('parciales');
      else if (notif.tipo === 'CUOTA') onNavigateToSection('cuotas');
      else if (notif.tipo === 'HORARIO') onNavigateToSection('horarios');
    }
  };

  return (
    <div className="space-y-4 max-w-3xl mx-auto">
      <div className="iov-card flex items-center justify-between p-4">
        <div className="flex items-center gap-2">
          <Bell className="w-5 h-5 text-[var(--azul-700)]" />
          <h2 className="text-sm font-bold text-[var(--azul-900)]">
            Centro de Notificaciones ({unreadCount} sin leer)
          </h2>
        </div>

        {unreadCount > 0 && (
          <button
            onClick={handleMarkAllRead}
            className="btn-secondary text-xs py-1.5 px-3 flex items-center gap-1.5"
          >
            <CheckCheck className="w-4 h-4 text-emerald-600" />
            <span>Marcar todas como leídas</span>
          </button>
        )}
      </div>

      {loading ? (
        <div className="iov-card p-6 text-center text-xs text-slate-500">
          Cargando notificaciones del estudiante...
        </div>
      ) : notifications.length === 0 ? (
        <div className="iov-card p-8 text-center">
          <Bell className="w-8 h-8 text-slate-300 mx-auto mb-2" />
          <h3 className="text-sm font-bold text-slate-700">Sin notificaciones</h3>
          <p className="text-xs text-slate-500 mt-1">
            No tiene alertas ni notificaciones registradas actualmente.
          </p>
        </div>
      ) : (
        <div className="space-y-2.5">
          {notifications.map((notif) => {
            const isUnread = notif.leida === 0;

            return (
              <div
                key={notif.id}
                className={`iov-card p-4 transition-all flex items-start justify-between gap-3 ${
                  isUnread
                    ? 'border-l-4 border-l-[var(--azul-700)] bg-[var(--celeste-100)]/40'
                    : 'bg-white opacity-85'
                }`}
              >
                <div
                  className="flex-1 cursor-pointer"
                  onClick={() => handleClickNotification(notif)}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <span
                      className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                        notif.tipo === 'PARCIAL'
                          ? 'bg-red-100 text-[var(--rojo-600)]'
                          : notif.tipo === 'AVISO'
                          ? 'bg-blue-100 text-[var(--azul-700)]'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {notif.tipo}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {notif.created_at}
                    </span>
                    {isUnread && (
                      <span className="w-2 h-2 rounded-full bg-[var(--rojo-600)]" />
                    )}
                  </div>

                  <h3 className="text-xs font-bold text-[var(--azul-900)] mb-1">
                    {notif.titulo}
                  </h3>

                  <p className="text-xs text-slate-600 leading-relaxed">
                    {notif.cuerpo}
                  </p>
                </div>

                <div className="shrink-0 flex items-center gap-1">
                  {isUnread ? (
                    <button
                      onClick={() => handleMarkAsRead(notif.id)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-[var(--azul-700)] hover:bg-slate-100"
                      title="Marcar como leída"
                    >
                      <Check className="w-4 h-4" />
                    </button>
                  ) : (
                    <span className="text-[10px] text-slate-400 font-semibold px-2 py-1">
                      Leída
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
