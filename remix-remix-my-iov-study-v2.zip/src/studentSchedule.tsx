import React, { useState, useEffect } from 'react';
import { apiFetch } from './apiClient';
import {
  Clock,
  MapPin,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  Building,
  User,
  RefreshCw,
  Printer,
  ChevronRight,
} from 'lucide-react';

interface ScheduleItem {
  id: string;
  comision_id: string;
  materia_codigo: string;
  materia_nombre: string;
  anio_carrera: number;
  codigo_comision: string;
  docente_titular: string;
  turno: string;
  dia_semana: number;
  hora_inicio: string;
  hora_fin: string;
  aula_id: string;
  aula_nombre: string;
  aula_edificio: string;
  aula_piso: string;
  aula_tipo: string;
  estado_aula: 'OFICIAL' | 'MODIFICADA' | 'SIN_INFORMAR';
  observaciones: string | null;
}

const DIAS_SEMANA = [
  { id: 0, label: 'Toda la semana' },
  { id: 1, label: 'Lunes' },
  { id: 2, label: 'Martes' },
  { id: 3, label: 'Miércoles' },
  { id: 4, label: 'Jueves' },
  { id: 5, label: 'Viernes' },
  { id: 6, label: 'Sábado' },
];

export function StudentSchedulePage() {
  const [schedules, setSchedules] = useState<ScheduleItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedDay, setSelectedDay] = useState<number>(0);
  const [error, setError] = useState<string | null>(null);

  const fetchSchedule = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await apiFetch('/api/academic/schedule');
      if (res.ok) {
        const data = await res.json();
        setSchedules(data.schedules || []);
      } else {
        setError('No se pudo cargar el cronograma de horarios.');
      }
    } catch {
      setError('Error de conexión al cargar horarios.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSchedule();
  }, []);

  const filtered = selectedDay === 0
    ? schedules
    : schedules.filter((s) => s.dia_semana === selectedDay);

  const modifiedClassrooms = schedules.filter((s) => s.estado_aula === 'MODIFICADA');

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="iov-card iov-card-destacada">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="badge-vigente">Ciclo Lectivo 2026 — 1er Cuatrimestre</span>
              <span className="text-xs text-slate-500 font-medium">Sede Santa Fe</span>
            </div>
            <h2 className="text-xl md:text-2xl font-black text-[var(--azul-900)] tracking-tight">
              Horarios de Cursado y Asignación de Aulas
            </h2>
            <p className="text-xs md:text-sm text-slate-600 mt-1 max-w-2xl">
              Consulta oficial de días, horarios semanales, docentes titulares y aulas asignadas con verificación de estado en tiempo real.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => window.print()}
              className="btn-secondary text-xs"
              title="Imprimir cronograma"
            >
              <Printer className="w-4 h-4" />
              <span className="hidden sm:inline">Imprimir</span>
            </button>
            <button
              onClick={fetchSchedule}
              className="btn-primary text-xs"
              disabled={loading}
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
              <span>Actualizar</span>
            </button>
          </div>
        </div>
      </div>

      {/* Alerta de Aulas Reubicadas si las hay */}
      {modifiedClassrooms.length > 0 && (
        <div className="iov-card iov-card-critica bg-red-50/40">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-[var(--rojo-600)] shrink-0 mt-0.5" />
            <div>
              <h3 className="text-sm font-bold text-[var(--rojo-600)]">
                Aviso Oficial: {modifiedClassrooms.length} clase(s) con cambio provisorio de aula
              </h3>
              <p className="text-xs text-slate-700 mt-1">
                Bedelía informa modificaciones transitorias respecto a la distribución habitual. Verifica las observaciones antes de concurrir:
              </p>
              <div className="mt-2 space-y-1.5">
                {modifiedClassrooms.map((mc) => (
                  <div key={mc.id} className="text-xs bg-white p-2 rounded-lg border border-red-200 text-slate-800">
                    <strong>{mc.materia_nombre}</strong> ({DIAS_SEMANA.find((d) => d.id === mc.dia_semana)?.label} {mc.hora_inicio} a {mc.hora_fin} hs):{' '}
                    <span className="text-[var(--rojo-600)] font-semibold">{mc.aula_nombre} ({mc.aula_edificio})</span> — {mc.observaciones}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Filtro por Día */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
        {DIAS_SEMANA.map((dia) => (
          <button
            key={dia.id}
            onClick={() => setSelectedDay(dia.id)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
              selectedDay === dia.id
                ? 'bg-[var(--azul-700)] text-white shadow-sm'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            {dia.label}
          </button>
        ))}
      </div>

      {/* Listado de Clases */}
      {loading ? (
        <div className="iov-card text-center py-12 text-slate-500 text-xs">
          <RefreshCw className="w-6 h-6 animate-spin mx-auto text-[var(--celeste-500)] mb-2" />
          <span>Cargando horarios de cursado oficial...</span>
        </div>
      ) : error ? (
        <div className="iov-card text-center py-8 text-xs text-[var(--rojo-600)]">
          {error}
        </div>
      ) : filtered.length === 0 ? (
        <div className="iov-card text-center py-12 text-slate-500 text-xs">
          No hay clases asignadas para el día seleccionado.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filtered.map((item) => {
            const diaNombre = DIAS_SEMANA.find((d) => d.id === item.dia_semana)?.label;
            const esModificada = item.estado_aula === 'MODIFICADA';

            return (
              <div
                key={item.id}
                className={`iov-card relative transition-all ${
                  esModificada ? 'border-amber-300 bg-amber-50/20' : ''
                }`}
              >
                <div className="flex items-start justify-between gap-3 mb-2.5">
                  <div>
                    <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                      {item.materia_codigo} · {item.codigo_comision}
                    </span>
                    <h3 className="text-base font-bold text-[var(--azul-900)] leading-snug">
                      {item.materia_nombre}
                    </h3>
                  </div>

                  <span
                    className={
                      esModificada
                        ? 'badge-provisorio text-[10px] whitespace-nowrap'
                        : 'badge-vigente text-[10px] whitespace-nowrap'
                    }
                  >
                    {esModificada ? 'REUBICADA' : 'OFICIAL'}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 p-3 bg-slate-50 rounded-xl border border-slate-100 text-xs mb-3">
                  <div className="flex items-center gap-2 text-slate-700">
                    <Clock className="w-4 h-4 text-[var(--celeste-500)] shrink-0" />
                    <div>
                      <span className="font-semibold">{diaNombre}</span>
                      <div className="text-[11px] text-slate-500">{item.hora_inicio} a {item.hora_fin} hs</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 text-slate-700">
                    <MapPin className={`w-4 h-4 shrink-0 ${esModificada ? 'text-amber-600' : 'text-[var(--azul-700)]'}`} />
                    <div>
                      <span className="font-bold text-[var(--azul-900)]">{item.aula_nombre || 'Sin aula'}</span>
                      <div className="text-[11px] text-slate-500 truncate">{item.aula_edificio} · {item.aula_piso}</div>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs text-slate-600 pt-2 border-t border-slate-100">
                  <div className="flex items-center gap-1.5 truncate">
                    <User className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">{item.docente_titular}</span>
                  </div>

                  <span className="text-[11px] font-semibold text-slate-500 shrink-0">
                    Turno {item.turno}
                  </span>
                </div>

                {item.observaciones && (
                  <div className="mt-2.5 p-2 bg-amber-50 rounded border border-amber-200/70 text-[11px] text-amber-900">
                    <strong>Nota:</strong> {item.observaciones}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
