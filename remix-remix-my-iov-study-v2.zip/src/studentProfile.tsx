import React, { useState, useEffect } from 'react';
import { User, Lock, Mail, Phone, MapPin, CheckCircle, AlertCircle, Save } from 'lucide-react';
import { apiFetch } from './apiClient';

export const StudentProfilePage: React.FC = () => {
  const [profile, setProfile] = useState<any>(null);
  const [telefono, setTelefono] = useState('');
  const [domicilio, setDomicilio] = useState('');
  const [ciudad, setCiudad] = useState('');
  const [correoPersonal, setCorreoPersonal] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const fetchProfile = async () => {
    try {
      setLoading(true);
      const res = await apiFetch('/api/student/profile');
      if (!res.ok) throw new Error('No se pudo cargar el perfil.');
      const data = await res.json();
      setProfile(data.profile);
      setTelefono(data.profile.telefono || '');
      setDomicilio(data.profile.domicilio || '');
      setCiudad(data.profile.ciudad || '');
      setCorreoPersonal(data.profile.correo_personal || '');
    } catch (err: any) {
      setErrorMsg(err.message || 'Error al cargar perfil.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProfile();
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setSuccessMsg(null);
    setErrorMsg(null);

    try {
      const res = await apiFetch('/api/student/profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          telefono: telefono.trim(),
          domicilio: domicilio.trim(),
          ciudad: ciudad.trim(),
          correo_personal: correoPersonal.trim(),
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'No se pudieron guardar los cambios.');

      setSuccessMsg('Datos de contacto actualizados correctamente.');
      fetchProfile();
    } catch (err: any) {
      setErrorMsg(err.message || 'Error al guardar cambios.');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="iov-card p-6 text-center text-xs text-slate-500">
        Cargando expediente personal del estudiante...
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Alertas de Feedback */}
      {successMsg && (
        <div
          role="status"
          aria-live="polite"
          className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 flex items-center gap-2"
        >
          <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {errorMsg && (
        <div
          role="alert"
          aria-live="assertive"
          className="p-3 rounded-xl bg-[var(--rojo-100)] border border-red-200 text-xs text-[var(--rojo-600)] flex items-center gap-2"
        >
          <AlertCircle className="w-4 h-4 text-[var(--rojo-600)] shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Bloque 1: Datos Oficiales Institucionales (Solo Lectura) */}
      <div className="iov-card">
        <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <Lock className="w-4 h-4 text-[var(--azul-700)]" />
            <h3 className="text-sm font-bold text-[var(--azul-900)]">
              Datos Académicos Oficiales (Inmutables)
            </h3>
          </div>
          <span className="badge-vigente text-[11px]">ADMINISTRADOS POR BEDELÍA</span>
        </div>

        <p className="text-xs text-slate-500 mb-4">
          Estos datos forman parte de su legajo oficial. Toda corrección de nombre, carrera o condición debe ser solicitada formalmente a Bedelía mediante trámite administrativo.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 text-xs">
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
            <div className="text-slate-400 font-semibold text-[10px] uppercase">Nombre Completo</div>
            <div className="font-bold text-[var(--azul-900)] text-sm mt-0.5">
              {profile?.nombre_completo}
            </div>
          </div>

          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
            <div className="text-slate-400 font-semibold text-[10px] uppercase">Matrícula Universitaria</div>
            <div className="font-mono font-bold text-[var(--azul-700)] text-sm mt-0.5">
              {profile?.matricula}
            </div>
          </div>

          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
            <div className="text-slate-400 font-semibold text-[10px] uppercase">Condición Académica</div>
            <div className="font-bold text-emerald-700 text-sm mt-0.5">
              {profile?.condicion_academica}
            </div>
          </div>

          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
            <div className="text-slate-400 font-semibold text-[10px] uppercase">Carrera</div>
            <div className="font-semibold text-slate-800 mt-0.5">
              {profile?.carrera_nombre}
            </div>
          </div>

          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
            <div className="text-slate-400 font-semibold text-[10px] uppercase">Plan de Estudio / Año</div>
            <div className="font-semibold text-slate-800 mt-0.5">
              {profile?.codigo_plan} ({profile?.plan_version}) · {profile?.anio_cursado}° Año
            </div>
          </div>

          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
            <div className="text-slate-400 font-semibold text-[10px] uppercase">Correo Institucional</div>
            <div className="font-semibold text-slate-800 mt-0.5">
              {profile?.correo_institucional}
            </div>
          </div>
        </div>
      </div>

      {/* Bloque 2: Datos de Contacto Editables por el Estudiante */}
      <div className="iov-card">
        <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <User className="w-4 h-4 text-[var(--celeste-500)]" />
            <h3 className="text-sm font-bold text-[var(--azul-900)]">
              Datos Personales de Contacto (Editables)
            </h3>
          </div>
          <span className="badge-actualizado text-[11px]">ACTUALIZABLE POR EL ALUMNO</span>
        </div>

        <form onSubmit={handleSave} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="input-telefono" className="block text-xs font-semibold text-slate-700 mb-1">
                Teléfono de Contacto
              </label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  id="input-telefono"
                  type="text"
                  value={telefono}
                  onChange={(e) => setTelefono(e.target.value)}
                  placeholder="+54 342 1234567"
                  className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:border-[var(--azul-700)] outline-none"
                />
              </div>
            </div>

            <div>
              <label htmlFor="input-correo-personal" className="block text-xs font-semibold text-slate-700 mb-1">
                Correo Electrónico Personal Alternativo
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  id="input-correo-personal"
                  type="email"
                  value={correoPersonal}
                  onChange={(e) => setCorreoPersonal(e.target.value)}
                  placeholder="ejemplo@gmail.com"
                  className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:border-[var(--azul-700)] outline-none"
                />
              </div>
            </div>

            <div>
              <label htmlFor="input-domicilio" className="block text-xs font-semibold text-slate-700 mb-1">
                Domicilio Residencial
              </label>
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  id="input-domicilio"
                  type="text"
                  value={domicilio}
                  onChange={(e) => setDomicilio(e.target.value)}
                  placeholder="Calle, número, piso y depto"
                  className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:border-[var(--azul-700)] outline-none"
                />
              </div>
            </div>

            <div>
              <label htmlFor="input-ciudad" className="block text-xs font-semibold text-slate-700 mb-1">
                Ciudad / Localidad
              </label>
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  id="input-ciudad"
                  type="text"
                  value={ciudad}
                  onChange={(e) => setCiudad(e.target.value)}
                  placeholder="Santa Fe, Santo Tomé, etc."
                  className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:border-[var(--azul-700)] outline-none"
                />
              </div>
            </div>
          </div>

          <div className="flex justify-end pt-3 border-t border-slate-100">
            <button
              type="submit"
              disabled={saving}
              className="btn-primary text-xs py-2 px-4 font-semibold"
            >
              <Save className="w-4 h-4" />
              <span>{saving ? 'Guardando cambios...' : 'Guardar Datos de Contacto'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
