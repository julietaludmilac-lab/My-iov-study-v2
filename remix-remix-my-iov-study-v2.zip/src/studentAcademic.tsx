import React, { useState, useEffect } from 'react';
import { apiFetch } from './apiClient';
import {
  GraduationCap,
  BookOpen,
  Award,
  CheckCircle2,
  AlertTriangle,
  FileText,
  Calendar,
  Clock,
  ChevronDown,
  ChevronUp,
  Download,
  Info,
  Layers,
  Sparkles,
} from 'lucide-react';

export type AcademicSubSection =
  | 'planestudio'
  | 'correlatividades'
  | 'equivalencias'
  | 'asistencia'
  | 'parciales'
  | 'calificaciones'
  | 'documentacion';

interface StudentAcademicProps {
  currentSection: AcademicSubSection;
  onNavigateSubSection?: (section: AcademicSubSection) => void;
}

export function StudentAcademicPage({ currentSection, onNavigateSubSection }: StudentAcademicProps) {
  const [section, setSection] = useState<AcademicSubSection>(currentSection);

  // Estados de datos
  const [planData, setPlanData] = useState<any>(null);
  const [attendanceData, setAttendanceData] = useState<any[]>([]);
  const [evaluations, setEvaluations] = useState<any[]>([]);
  const [gradesData, setGradesData] = useState<any>(null);
  const [documents, setDocuments] = useState<any[]>([]);
  const [analyticsProgress, setAnalyticsProgress] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  // Estados de UI
  const [expandedEval, setExpandedEval] = useState<string | null>('EVAL-POO-P1');
  const [selectedCorrelatividadMateria, setSelectedCorrelatividadMateria] = useState<string>('TODAS');

  useEffect(() => {
    setSection(currentSection);
  }, [currentSection]);

  const loadAllAcademicData = async () => {
    setLoading(true);
    try {
      const [planRes, attRes, evalRes, gradeRes, docRes] = await Promise.all([
        apiFetch('/api/academic/study-plan'),
        apiFetch('/api/academic/attendance'),
        apiFetch('/api/academic/evaluations'),
        apiFetch('/api/academic/grades'),
        apiFetch('/api/academic/documents'),
      ]);

      if (planRes.ok) setPlanData(await planRes.json());
      if (attRes.ok) {
        const d = await attRes.json();
        setAttendanceData(d.resumen || []);
      }
      if (evalRes.ok) {
        const d = await evalRes.json();
        setEvaluations(d.evaluaciones || []);
      }
      if (gradeRes.ok) setGradesData(await gradeRes.json());
      if (docRes.ok) {
        const d = await docRes.json();
        setDocuments(d.documentos || []);
      }

      apiFetch('/api/analytics/student-progress')
        .then(r => r.ok ? r.json() : null)
        .then(data => { if (data?.ok) setAnalyticsProgress(data); })
        .catch(() => {});
    } catch (err) {
      console.error('Error loading academic data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAllAcademicData();
  }, []);

  const changeSub = (s: AcademicSubSection) => {
    setSection(s);
    if (onNavigateSubSection) onNavigateSubSection(s);
    window.location.hash = s;
  };

  return (
    <div className="space-y-6">
      {/* Barra de pestañas secundarias académicas */}
      <div className="iov-card p-2 overflow-x-auto">
        <div className="flex items-center gap-1.5 min-w-max">
          {[
            { id: 'planestudio', label: 'Plan de Estudio', icon: BookOpen },
            { id: 'correlatividades', label: 'Correlatividades', icon: Layers },
            { id: 'equivalencias', label: 'Equivalencias', icon: Award },
            { id: 'asistencia', label: 'Asistencia y Faltas', icon: CheckCircle2 },
            { id: 'parciales', label: 'Parciales y Temarios', icon: Calendar },
            { id: 'calificaciones', label: 'Calificaciones y Promedio', icon: GraduationCap },
            { id: 'documentacion', label: 'Programas Analíticos', icon: FileText },
          ].map((item) => {
            const Icon = item.icon;
            const active = section === item.id;
            return (
              <button
                key={item.id}
                onClick={() => changeSub(item.id as AcademicSubSection)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-bold transition-colors ${
                  active
                    ? 'bg-[var(--azul-700)] text-white shadow-sm'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 1. SECCIÓN: PLAN DE ESTUDIO */}
      {section === 'planestudio' && (
        <div className="space-y-4">
          <div className="iov-card iov-card-destacada">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
              <div>
                <span className="badge-vigente mb-1 inline-block">
                  {planData?.estudiante?.carrera_nombre || 'Licenciatura en Sistemas de Información'}
                </span>
                <h3 className="text-xl font-black text-[var(--azul-900)]">
                  Plan {planData?.estudiante?.plan_codigo} ({planData?.estudiante?.plan_version})
                </h3>
                <p className="text-xs text-slate-600 mt-0.5">
                  {planData?.estudiante?.plan_resolucion} · Condición:{' '}
                  <strong>{planData?.estudiante?.condicion_academica}</strong>
                </p>
              </div>

              {gradesData?.resumen && (
                <div className="flex items-center gap-3 p-3 bg-white/80 rounded-xl border border-blue-200">
                  <div className="text-center">
                    <div className="text-lg font-black text-[var(--azul-900)]">
                      {gradesData.resumen.materiasAprobadas}
                    </div>
                    <div className="text-[10px] text-slate-500 uppercase font-bold">Aprobadas</div>
                  </div>
                  <div className="w-px h-8 bg-slate-200" />
                  <div className="text-center">
                    <div className="text-lg font-black text-emerald-600">
                      {gradesData.resumen.promedioGeneral}
                    </div>
                    <div className="text-[10px] text-slate-500 uppercase font-bold">Promedio</div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Tarjeta Etapa 7: Avance de Carrera & Semáforo de Trayectoria */}
          {analyticsProgress?.resumen && (
            <div className="iov-card bg-linear-to-r from-blue-50/50 to-indigo-50/50 border border-blue-200">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-[var(--celeste-500)]" />
                  <span className="text-xs font-bold text-[var(--azul-900)] uppercase tracking-wider">
                    Avance de Carrera & Semáforo Académico Oficial
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                    analyticsProgress.resumen.estadoSemaforo === 'OPTIMO'
                      ? 'badge-vigente'
                      : analyticsProgress.resumen.estadoSemaforo === 'REGULAR'
                      ? 'badge-actualizado'
                      : 'badge-vencido'
                  }`}>
                    SEMÁFORO: {analyticsProgress.resumen.estadoSemaforo}
                  </span>
                  <span className="text-xs font-bold text-[var(--azul-700)]">
                    {analyticsProgress.resumen.porcentajeAvance}% Completado
                  </span>
                </div>
              </div>

              {/* Barra de Progreso */}
              <div className="w-full bg-slate-200 rounded-full h-2.5 mb-3 overflow-hidden">
                <div
                  className="bg-linear-to-r from-[var(--azul-700)] to-[var(--celeste-500)] h-2.5 rounded-full transition-all duration-500"
                  style={{ width: `${Math.min(100, Math.max(5, analyticsProgress.resumen.porcentajeAvance))}%` }}
                />
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs">
                <div className="p-2 bg-white rounded-lg border border-slate-200">
                  <div className="font-black text-emerald-600 text-sm">{analyticsProgress.resumen.cantidadAprobadas}</div>
                  <div className="text-[10px] text-slate-500 font-semibold">Aprobadas ({analyticsProgress.resumen.porcentajeAvance}%)</div>
                </div>
                <div className="p-2 bg-white rounded-lg border border-slate-200">
                  <div className="font-black text-[var(--azul-700)] text-sm">{analyticsProgress.resumen.cantidadCursando}</div>
                  <div className="text-[10px] text-slate-500 font-semibold">En Cursado</div>
                </div>
                <div className="p-2 bg-white rounded-lg border border-slate-200">
                  <div className="font-black text-slate-600 text-sm">{analyticsProgress.resumen.cantidadPendientes}</div>
                  <div className="text-[10px] text-slate-500 font-semibold">Pendientes</div>
                </div>
                <div className="p-2 bg-white rounded-lg border border-slate-200">
                  <div className="font-black text-purple-600 text-sm">~{analyticsProgress.resumen.cuatrimestresEstimadosRestantes}</div>
                  <div className="text-[10px] text-slate-500 font-semibold">Cuatrimestres Est.</div>
                </div>
              </div>

              <p className="text-[11px] text-slate-600 mt-2.5 italic">
                {analyticsProgress.resumen.mensajeSemaforo}
              </p>
            </div>
          )}

          {/* Agrupación por Años de Carrera */}
          {[1, 2, 3, 4].map((anio) => {
            const matsDelAnio = (planData?.materias || []).filter(
              (m: any) => m.anio_carrera === anio
            );
            if (matsDelAnio.length === 0) return null;

            return (
              <div key={anio} className="iov-card">
                <div className="flex items-center justify-between mb-3 border-b border-slate-100 pb-2">
                  <h4 className="text-sm font-black text-[var(--azul-900)] uppercase tracking-wider">
                    {anio}° Año de la Carrera
                  </h4>
                  <span className="text-xs text-slate-500 font-semibold">
                    {matsDelAnio.length} asignaturas
                  </span>
                </div>

                <div className="table-container">
                  <table className="iov-table">
                    <thead>
                      <tr>
                        <th>Código</th>
                        <th>Asignatura</th>
                        <th>Régimen</th>
                        <th>Horas</th>
                        <th>Estado Actual</th>
                        <th>Calificación / Detalle</th>
                      </tr>
                    </thead>
                    <tbody>
                      {matsDelAnio.map((m: any) => {
                        let badgeClass = 'badge-vencido';
                        if (m.estado === 'APROBADA') badgeClass = 'badge-pagada';
                        if (m.estado === 'CURSANDO') badgeClass = 'badge-vigente';
                        if (m.estado === 'REGULAR') badgeClass = 'badge-actualizado';

                        return (
                          <tr key={m.id}>
                            <td className="font-mono text-xs font-bold text-[var(--azul-700)]">
                              {m.codigo}
                            </td>
                            <td className="font-semibold text-slate-900">{m.nombre}</td>
                            <td>
                              <span className="text-xs text-slate-600">{m.regimen}</span>
                            </td>
                            <td>
                              <span className="text-xs text-slate-600">{m.carga_horaria} hs</span>
                            </td>
                            <td>
                              <span className={`${badgeClass} text-[11px]`}>{m.estado}</span>
                            </td>
                            <td>
                              {m.calificacion ? (
                                <span className="text-xs font-bold text-slate-800">
                                  Nota: {m.calificacion.nota} ({m.calificacion.condicion})
                                </span>
                              ) : m.cursandoComision ? (
                                <span className="text-xs text-slate-500">
                                  Comisión {m.cursandoComision} (1C 2026)
                                </span>
                              ) : (
                                <span className="text-xs text-slate-400">Sin cursar</span>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* 2. SECCIÓN: CORRELATIVIDADES */}
      {section === 'correlatividades' && (
        <div className="space-y-4">
          <div className="iov-card">
            <h3 className="text-base font-bold text-[var(--azul-900)] mb-1">
              Régimen de Correlatividades Oficiales
            </h3>
            <p className="text-xs text-slate-600 mb-4">
              Condiciones académicas reglamentadas por la Resolución del Consejo Directivo para la inscripción a cursado y examen final.
            </p>

            <div className="table-container">
              <table className="iov-table">
                <thead>
                  <tr>
                    <th>Materia a Cursar / Rendir</th>
                    <th>Tipo de Requisito</th>
                    <th>Materia Correlativa Exigida</th>
                    <th>Resolución Oficial</th>
                  </tr>
                </thead>
                <tbody>
                  {(planData?.correlatividades || []).map((c: any) => {
                    const materiaPrincipal = (planData?.materias || []).find(
                      (m: any) => m.id === c.materia_id
                    );
                    return (
                      <tr key={c.id}>
                        <td className="font-bold text-slate-900">
                          {materiaPrincipal?.nombre || c.materia_id}
                        </td>
                        <td>
                          <span className="badge-actualizado text-[11px]">
                            {c.tipo.replace(/_/g, ' ')}
                          </span>
                        </td>
                        <td className="font-semibold text-[var(--azul-700)]">
                          {c.materia_requisito_codigo} · {c.materia_requisito_nombre}
                        </td>
                        <td className="text-xs text-slate-500">{c.resolucion}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 3. SECCIÓN: EQUIVALENCIAS */}
      {section === 'equivalencias' && (
        <div className="space-y-4">
          <div className="iov-card">
            <h3 className="text-base font-bold text-[var(--azul-900)] mb-1">
              Equivalencias Otorgadas por Resolución
            </h3>
            <p className="text-xs text-slate-600 mb-4">
              Reconocimiento de asignaturas aprobadas en otras universidades u orígenes académicos vinculados al plan actual.
            </p>

            <div className="table-container">
              <table className="iov-table">
                <thead>
                  <tr>
                    <th>Materia UCSF Reconocida</th>
                    <th>Asignatura en Origen</th>
                    <th>Institución Universitaria</th>
                    <th>Resolución</th>
                    <th>% Reconocido</th>
                  </tr>
                </thead>
                <tbody>
                  {(planData?.equivalencias || []).map((eq: any) => (
                    <tr key={eq.id}>
                      <td className="font-bold text-[var(--azul-900)]">{eq.materia_nombre}</td>
                      <td className="font-semibold text-slate-800">{eq.materia_origen}</td>
                      <td className="text-xs text-slate-600">{eq.institucion_origen}</td>
                      <td className="font-mono text-xs text-slate-700">{eq.resolucion}</td>
                      <td>
                        <span className="badge-pagada text-[11px]">
                          {eq.porcentaje_reconocido}% TOTAL
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 4. SECCIÓN: ASISTENCIA Y FALTAS */}
      {section === 'asistencia' && (
        <div className="space-y-4">
          <div className="iov-card iov-card-destacada">
            <h3 className="text-base font-bold text-[var(--azul-900)] mb-1">
              Control Oficial de Asistencia y Límite de Faltas
            </h3>
            <p className="text-xs text-slate-600">
              Reglamentación UCSF Art. 44: El límite reglamentario máximo de inasistencias es del 25%.
              Las faltas registradas son de carácter provisorio hasta el cierre de actas de cursado.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {attendanceData.map((com) => {
              const alerta = com.condicionAlerta;
              return (
                <div key={com.comision_id} className="iov-card space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className="text-[11px] font-bold text-slate-500 uppercase">
                        {com.materia_codigo} · {com.codigo_comision}
                      </span>
                      <h4 className="text-base font-bold text-[var(--azul-900)] leading-tight">
                        {com.materia_nombre}
                      </h4>
                      <div className="text-xs text-slate-500 mt-0.5">{com.docente_titular}</div>
                    </div>

                    <span
                      className={
                        alerta === 'NORMAL'
                          ? 'badge-pagada text-[11px]'
                          : alerta === 'RIESGO'
                          ? 'badge-provisorio text-[11px]'
                          : 'badge-critico text-[11px]'
                      }
                    >
                      {alerta === 'NORMAL' ? 'REGULAR OK' : alerta === 'RIESGO' ? 'ALERTA' : 'EXCEDIDO'}
                    </span>
                  </div>

                  {/* Barra de progreso de inasistencias */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs font-semibold text-slate-700">
                      <span>Inasistencias computables</span>
                      <span>
                        {com.faltasComputables} de {com.regla.limite_faltas_directo} permitidas (
                        {com.porcentajeInasistencias}%)
                      </span>
                    </div>
                    <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden border border-slate-200">
                      <div
                        className={`h-full rounded-full transition-all ${
                          alerta === 'NORMAL'
                            ? 'bg-emerald-500'
                            : alerta === 'RIESGO'
                            ? 'bg-amber-500'
                            : 'bg-red-500'
                        }`}
                        style={{
                          width: `${Math.min(
                            100,
                            (com.faltasComputables / com.regla.limite_faltas_directo) * 100
                          )}%`,
                        }}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-center text-xs p-2.5 bg-slate-50 rounded-xl border border-slate-100">
                    <div>
                      <div className="font-bold text-emerald-700">{com.presentes}</div>
                      <div className="text-[10px] text-slate-500">Presentes</div>
                    </div>
                    <div>
                      <div className="font-bold text-red-600">{com.ausentes}</div>
                      <div className="text-[10px] text-slate-500">Ausentes</div>
                    </div>
                    <div>
                      <div className="font-bold text-[var(--azul-700)]">{com.faltasRestantes}</div>
                      <div className="text-[10px] text-slate-500">Faltas rest.</div>
                    </div>
                  </div>

                  {/* Historial de clases */}
                  <div>
                    <h5 className="text-xs font-bold text-slate-700 mb-1.5">
                      Registro de clases ({com.registros.length} fechas):
                    </h5>
                    <div className="space-y-1 max-h-40 overflow-y-auto pr-1">
                      {com.registros.map((reg: any) => (
                        <div
                          key={reg.id}
                          className="flex items-center justify-between text-xs p-1.5 rounded bg-white border border-slate-100 text-slate-700"
                        >
                          <span className="font-mono text-[11px]">{reg.fecha}</span>
                          <span
                            className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                              reg.estado === 'PRESENTE'
                                ? 'bg-emerald-50 text-emerald-700'
                                : reg.estado === 'JUSTIFICADA'
                                ? 'bg-blue-50 text-blue-700'
                                : 'bg-red-50 text-red-700'
                            }`}
                          >
                            {reg.estado}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 5. SECCIÓN: PARCIALES Y TEMARIOS */}
      {section === 'parciales' && (
        <div className="space-y-4">
          <div className="iov-card iov-card-destacada">
            <h3 className="text-base font-bold text-[var(--azul-900)] mb-1">
              Cronograma Oficial de Evaluaciones Parciales
            </h3>
            <p className="text-xs text-slate-600">
              Fechas estipuladas, aulas y temarios analíticos cargados por las cátedras para el 1er Cuatrimestre 2026.
            </p>
          </div>

          <div className="space-y-3">
            {evaluations.map((ev) => {
              const isExpanded = expandedEval === ev.id;
              return (
                <div key={ev.id} className="iov-card space-y-3">
                  <div
                    className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 cursor-pointer select-none"
                    onClick={() => setExpandedEval(isExpanded ? null : ev.id)}
                  >
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="badge-critico text-[10px]">{ev.tipo.replace('_', ' ')}</span>
                        <span className="text-xs text-slate-500 font-semibold">{ev.materia_codigo}</span>
                      </div>
                      <h4 className="text-base font-bold text-[var(--azul-900)]">{ev.titulo}</h4>
                      <p className="text-xs text-slate-600 mt-0.5">
                        {ev.materia_nombre} · Comisión {ev.codigo_comision}
                      </p>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      <div className="text-right">
                        <div className="text-xs font-bold text-[var(--azul-900)] flex items-center gap-1 justify-end">
                          <Calendar className="w-3.5 h-3.5 text-[var(--celeste-500)]" />
                          <span>{ev.fecha}</span>
                        </div>
                        <div className="text-[11px] text-slate-500">{ev.hora} hs · {ev.aula_nombre}</div>
                      </div>
                      <button className="text-slate-400 p-1">
                        {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  {/* Temario Desplegable */}
                  {isExpanded && (
                    <div className="pt-3 border-t border-slate-100 space-y-2">
                      <h5 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                        Contenidos Temáticos y Bibliografía Exigida:
                      </h5>
                      {ev.temas && ev.temas.length > 0 ? (
                        <div className="space-y-2">
                          {ev.temas.map((t: any) => (
                            <div key={t.id} className="p-3 bg-slate-50 rounded-xl border border-slate-100 text-xs">
                              <div className="font-bold text-[var(--azul-900)]">{t.tema}</div>
                              {t.bibliografia && (
                                <div className="text-[11px] text-slate-600 mt-1 italic">
                                  Bibliografía: {t.bibliografia}
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-xs text-slate-500">
                          La cátedra aún no ha ingresado los puntos específicos del temario.
                        </p>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 6. SECCIÓN: CALIFICACIONES Y PROMEDIO */}
      {section === 'calificaciones' && (
        <div className="space-y-4">
          {gradesData?.resumen && (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="iov-card text-center p-4">
                <div className="text-2xl font-black text-emerald-600">
                  {gradesData.resumen.promedioGeneral}
                </div>
                <div className="text-xs font-bold text-slate-700 mt-1">Promedio Aritmético</div>
                <div className="text-[10px] text-slate-500">Sin aplazos / Calificaciones oficiales</div>
              </div>

              <div className="iov-card text-center p-4">
                <div className="text-2xl font-black text-[var(--azul-900)]">
                  {gradesData.resumen.materiasAprobadas}
                </div>
                <div className="text-xs font-bold text-slate-700 mt-1">Materias Aprobadas</div>
                <div className="text-[10px] text-slate-500">Finales y equivalencias acreditadas</div>
              </div>

              <div className="iov-card text-center p-4">
                <div className="text-2xl font-black text-[var(--celeste-500)]">
                  {gradesData.resumen.totalHorasAcreditadas} hs
                </div>
                <div className="text-xs font-bold text-slate-700 mt-1">Carga Horaria Acreditada</div>
                <div className="text-[10px] text-slate-500">Créditos de materias del plan</div>
              </div>
            </div>
          )}

          <div className="iov-card">
            <h3 className="text-base font-bold text-[var(--azul-900)] mb-3">
              Certificado Analítico de Exámenes Aprobados
            </h3>

            <div className="table-container">
              <table className="iov-table">
                <thead>
                  <tr>
                    <th>Código</th>
                    <th>Asignatura</th>
                    <th>Instancia</th>
                    <th>Fecha</th>
                    <th>Nota</th>
                    <th>Condición</th>
                    <th>Acta / Tomo / Folio</th>
                  </tr>
                </thead>
                <tbody>
                  {(gradesData?.calificaciones || []).map((c: any) => (
                    <tr key={c.id}>
                      <td className="font-mono text-xs font-bold text-[var(--azul-700)]">
                        {c.materia_codigo}
                      </td>
                      <td className="font-semibold text-slate-900">{c.materia_nombre}</td>
                      <td>
                        <span className="badge-actualizado text-[11px]">{c.tipo_instancia}</span>
                      </td>
                      <td className="text-xs font-mono">{c.fecha}</td>
                      <td>
                        <span className="text-sm font-black text-emerald-700">{c.nota}</span>
                      </td>
                      <td>
                        <span className="badge-pagada text-[10px]">{c.condicion}</span>
                      </td>
                      <td className="text-xs font-mono text-slate-600">
                        {c.acta ? `${c.acta} (${c.tomo}-${c.folio})` : '—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 7. SECCIÓN: PROGRAMAS Y DOCUMENTACIÓN */}
      {section === 'documentacion' && (
        <div className="space-y-4">
          <div className="iov-card">
            <h3 className="text-base font-bold text-[var(--azul-900)] mb-1">
              Programas Analíticos y Reglamentos Oficiales
            </h3>
            <p className="text-xs text-slate-600 mb-4">
              Descarga o visualización de programas de estudio con validez académica para trámites de equivalencias o consulta curricular.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {documents.map((doc) => (
                <div key={doc.id} className="iov-card p-4 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <span className="badge-vigente text-[10px]">{doc.categoria}</span>
                      <span className="text-[11px] font-mono text-slate-500">
                        {(doc.tamano_bytes / 1024).toFixed(0)} KB
                      </span>
                    </div>
                    <h4 className="text-sm font-bold text-[var(--azul-900)] mb-1">
                      {doc.nombre}
                    </h4>
                    <p className="text-xs text-slate-600 mb-3">
                      {doc.materia_nombre ? `Asignatura: ${doc.materia_nombre}` : 'Documento Institucional UCSF'}
                    </p>
                    <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-100 text-[11px] text-slate-700 font-mono">
                      {doc.contenido_sintetico}
                    </div>
                  </div>

                  <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between">
                    <span className="text-[11px] text-slate-500">Fuente: {doc.fuente_nombre}</span>
                    <button
                      onClick={() => alert(`Descarga iniciada: ${doc.nombre}`)}
                      className="btn-secondary text-xs py-1 px-3"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Descargar</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
