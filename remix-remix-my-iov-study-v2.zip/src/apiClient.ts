/**
 * Cliente de API Unificado y Manejador de Sesión para My IOV Study v2
 * Asegura transmisión robusta de tokens en iframes, navegadores con bloqueo de cookies de terceros y recargas.
 */

const STORAGE_KEY_SESSION = 'iov_session_id';
const STORAGE_KEY_CSRF = 'iov_csrf_token';
const STORAGE_KEY_USER = 'iov_current_user';

export function getStoredSessionId(): string | null {
  try {
    return localStorage.getItem(STORAGE_KEY_SESSION) || sessionStorage.getItem(STORAGE_KEY_SESSION) || null;
  } catch {
    return null;
  }
}

export function getStoredCsrfToken(): string | null {
  try {
    const fromStorage = localStorage.getItem(STORAGE_KEY_CSRF) || sessionStorage.getItem(STORAGE_KEY_CSRF);
    if (fromStorage) return fromStorage;

    const cookieMatch = document.cookie.match(/iov_csrf=([^;]+)/);
    if (cookieMatch) return decodeURIComponent(cookieMatch[1]);
  } catch {}
  return null;
}

export function getStoredUser(): any | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_USER) || sessionStorage.getItem(STORAGE_KEY_USER);
    if (raw) return JSON.parse(raw);
  } catch {}
  return null;
}

export function saveSession(sessionId: string, csrfToken?: string, user?: any): void {
  try {
    if (sessionId) {
      localStorage.setItem(STORAGE_KEY_SESSION, sessionId);
      sessionStorage.setItem(STORAGE_KEY_SESSION, sessionId);
    }
    if (csrfToken) {
      localStorage.setItem(STORAGE_KEY_CSRF, csrfToken);
      sessionStorage.setItem(STORAGE_KEY_CSRF, csrfToken);
    }
    if (user) {
      localStorage.setItem(STORAGE_KEY_USER, JSON.stringify(user));
      sessionStorage.setItem(STORAGE_KEY_USER, JSON.stringify(user));
    }
  } catch (err) {
    console.warn('[apiClient] Could not save to localStorage:', err);
  }
}

export function clearSession(): void {
  try {
    localStorage.removeItem(STORAGE_KEY_SESSION);
    localStorage.removeItem(STORAGE_KEY_CSRF);
    localStorage.removeItem(STORAGE_KEY_USER);
    sessionStorage.removeItem(STORAGE_KEY_SESSION);
    sessionStorage.removeItem(STORAGE_KEY_CSRF);
    sessionStorage.removeItem(STORAGE_KEY_USER);
  } catch (err) {
    console.warn('[apiClient] Could not clear storage:', err);
  }
}

/**
 * Wrapper de fetch que inyecta automáticamente:
 * - Authorization: Bearer <sessionId>
 * - x-session-id: <sessionId>
 * - x-csrf-token: <csrfToken>
 * - credentials: 'include'
 */
export async function apiFetch(url: string, options: RequestInit = {}): Promise<Response> {
  const sessionId = getStoredSessionId();
  const csrfToken = getStoredCsrfToken();

  const headers = new Headers(options.headers || {});

  if (sessionId) {
    headers.set('Authorization', `Bearer ${sessionId}`);
    headers.set('x-session-id', sessionId);
  }

  if (csrfToken && !headers.has('x-csrf-token')) {
    headers.set('x-csrf-token', csrfToken);
  }

  if (!headers.has('Accept')) {
    headers.set('Accept', 'application/json, text/plain, */*');
  }

  const mergedOptions: RequestInit = {
    ...options,
    credentials: 'include',
    headers,
  };

  return fetch(url, mergedOptions);
}

/**
 * Función auxiliar para parsear respuestas JSON de manera segura
 * Evita la excepción "Unexpected token '<', <!doctype... is not valid JSON"
 */
export async function safeJson<T = any>(res: Response): Promise<T> {
  const contentType = res.headers.get('content-type') || '';
  if (contentType.includes('application/json')) {
    return res.json();
  }
  const text = await res.text();
  if (text.trim().startsWith('<')) {
    throw new Error(`Respuesta inválida del servidor (${res.status}). No se recibió formato JSON.`);
  }
  try {
    return JSON.parse(text);
  } catch {
    throw new Error(text || `Error en la respuesta del servidor (${res.status})`);
  }
}
