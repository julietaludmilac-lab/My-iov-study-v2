import React, { useState, useEffect } from 'react';
import {
  Shield,
  Lock,
  Mail,
  User,
  AlertCircle,
  ArrowRight,
  Clock,
  UserPlus,
  LogIn,
  CheckCircle2,
  Sparkles,
  GraduationCap,
  Building2,
  Briefcase,
} from 'lucide-react';
import { UserRole } from './routesRegistry';
import { apiFetch, saveSession } from './apiClient';

interface LoginProps {
  onLoginSuccess: (user: any) => void;
}

export const LoginPage: React.FC<LoginProps> = ({ onLoginSuccess }) => {
  const [activeTab, setActiveTab] = useState<'LOGIN' | 'REGISTER'>('LOGIN');

  // --- Estados de Login ---
  const [selectedRole, setSelectedRole] = useState<UserRole>('ESTUDIANTE');
  const [matricula, setMatricula] = useState('');
  const [correo, setCorreo] = useState('');
  const [password, setPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [autoCompletedName, setAutoCompletedName] = useState<string | null>(null);
  const [intentosRestantes, setIntentosRestantes] = useState<number | null>(null);
  const [minutosBloqueo, setMinutosBloqueo] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);

  // --- Estados de Registro ---
  const [regNombre, setRegNombre] = useState('');
  const [regMatricula, setRegMatricula] = useState('');
  const [regCorreo, setRegCorreo] = useState('');
  const [regRol, setRegRol] = useState<UserRole>('ESTUDIANTE');
  const [regCarrera, setRegCarrera] = useState('CAR-LSI');
  const [regPassword, setRegPassword] = useState('');
  const [regPasswordConf, setRegPasswordConf] = useState('');
  const [regLoading, setRegLoading] = useState(false);
  const [availableCareers, setAvailableCareers] = useState<any[]>([]);

  // Lista de cuentas registradas para autocompletar rápidamente
  const [registeredAccounts, setRegisteredAccounts] = useState<any[]>([]);

  // Cargar cuentas registradas y carreras disponibles en base de datos
  const loadAccounts = () => {
    apiFetch('/api/auth/registered-accounts')
      .then((res) => res.json())
      .then((data) => {
        if (data?.accounts) {
          setRegisteredAccounts(data.accounts);
        }
      })
      .catch(() => {});

    apiFetch('/api/carreras')
      .then((res) => res.json())
      .then((data) => {
        if (data?.carreras && data.carreras.length > 0) {
          setAvailableCareers(data.carreras);
          setRegCarrera(data.carreras[0].id);
        }
      })
      .catch(() => {});
  };

  useEffect(() => {
    loadAccounts();
  }, []);

  // Función para autocompletar datos según correo institucional
  const handleLookupEmail = async (emailToLookup: string) => {
    const cleanEmail = emailToLookup.trim().toLowerCase();
    if (!cleanEmail || !cleanEmail.includes('@')) return;

    try {
      const res = await apiFetch(`/api/auth/lookup-email?correo=${encodeURIComponent(cleanEmail)}`);
      const data = await res.json();
      if (data.exists) {
        setMatricula(data.matricula);
        setSelectedRole(data.rol);
        setAutoCompletedName(data.nombre);
        setErrorMsg(null);
      } else {
        setAutoCompletedName(null);
      }
    } catch {
      setAutoCompletedName(null);
    }
  };

  // Autocompletar al seleccionar de la lista rápida
  const handleSelectQuickAccount = (acc: any) => {
    setCorreo(acc.correo);
    setMatricula(acc.matricula);
    setSelectedRole(acc.rol);
    setAutoCompletedName(acc.nombre);
    setErrorMsg(null);
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!matricula.trim() || !correo.trim() || !password) {
      setErrorMsg('Debe completar la matrícula, el correo institucional y la contraseña.');
      return;
    }

    setLoading(true);
    try {
      const res = await apiFetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          matricula: matricula.trim(),
          correo: correo.trim(),
          password,
          rol: selectedRole,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        if (res.status === 429) {
          setMinutosBloqueo(data.minutosRestantes || 15);
          setErrorMsg(data.error || 'Cuenta bloqueada temporalmente.');
        } else {
          setErrorMsg(data.error || 'Credenciales inválidas.');
          if (data.intentosRestantes !== undefined) {
            setIntentosRestantes(data.intentosRestantes);
          }
        }
        return;
      }

      if (data.sessionId) {
        saveSession(data.sessionId, data.csrfToken, data.user);
      }

      onLoginSuccess(data.user);
    } catch {
      setErrorMsg('Error de conexión con el servidor. Verifique su red e intente nuevamente.');
    } finally {
      setLoading(false);
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!regNombre.trim() || !regMatricula.trim() || !regCorreo.trim() || !regPassword) {
      setErrorMsg('Todos los campos son obligatorios para el registro.');
      return;
    }

    if (regPassword !== regPasswordConf) {
      setErrorMsg('Las contraseñas no coinciden.');
      return;
    }

    if (regPassword.length < 8) {
      setErrorMsg('La contraseña debe tener al menos 8 caracteres.');
      return;
    }

    setRegLoading(true);
    try {
      const res = await apiFetch('/api/auth/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          nombreCompleto: regNombre.trim(),
          matricula: regMatricula.trim(),
          correo: regCorreo.trim(),
          password: regPassword,
          rol: regRol,
          carreraId: regCarrera,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        setErrorMsg(data.error || 'Error al registrar la cuenta.');
        return;
      }

      // Registro exitoso
      setSuccessMsg('¡Cuenta registrada exitosamente en la base de datos! Ya puedes iniciar sesión.');
      loadAccounts();
      // Autocompletar datos en la pestaña de login
      setCorreo(regCorreo.trim());
      setMatricula(regMatricula.trim().toUpperCase());
      setSelectedRole(regRol);
      setAutoCompletedName(regNombre.trim());
      setPassword('');

      // Limpiar formulario de registro
      setRegNombre('');
      setRegMatricula('');
      setRegCorreo('');
      setRegPassword('');
      setRegPasswordConf('');

      // Pasar a la pestaña de login
      setActiveTab('LOGIN');
    } catch {
      setErrorMsg('Error de conexión al intentar registrar.');
    } finally {
      setRegLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[var(--neutro-100)] flex items-center justify-center p-4 antialiased">
      <div className="w-full max-w-lg">
        {/* Encabezado Institucional */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl iov-header-gradient text-white font-black text-2xl shadow-lg mb-3">
            IOV
          </div>
          <h1 className="text-2xl font-black text-[var(--azul-900)] tracking-tight">
            My IOV Study v2
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Plataforma de Autogestión Universitaria UCSF — Sede Santa Fe
          </p>
        </div>

        {/* Tarjeta de Contenedor Principal */}
        <div className="iov-card p-6 md:p-8">
          {/* Pestañas de Alternancia: Iniciar Sesión / Registrarse */}
          <div className="flex border-b border-slate-200 mb-6">
            <button
              onClick={() => {
                setActiveTab('LOGIN');
                setErrorMsg(null);
              }}
              className={`flex-1 py-3 text-xs font-bold border-b-2 flex items-center justify-center gap-2 transition-colors ${
                activeTab === 'LOGIN'
                  ? 'border-[var(--azul-700)] text-[var(--azul-900)] font-extrabold'
                  : 'border-transparent text-slate-400 hover:text-slate-600'
              }`}
            >
              <LogIn className="w-4 h-4" />
              <span>Iniciar Sesión</span>
            </button>

            <button
              onClick={() => {
                setActiveTab('REGISTER');
                setErrorMsg(null);
                setSuccessMsg(null);
              }}
              className={`flex-1 py-3 text-xs font-bold border-b-2 flex items-center justify-center gap-2 transition-colors ${
                activeTab === 'REGISTER'
                  ? 'border-[var(--azul-700)] text-[var(--azul-900)] font-extrabold'
                  : 'border-transparent text-slate-400 hover:text-slate-600'
              }`}
            >
              <UserPlus className="w-4 h-4" />
              <span>Registrarse</span>
            </button>
          </div>

          {/* Mensajes de Éxito y Error */}
          {successMsg && (
            <div
              role="status"
              aria-live="polite"
              className="p-3 mb-4 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 flex items-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          {errorMsg && (
            <div
              role="alert"
              aria-live="assertive"
              className="p-3 mb-4 rounded-xl bg-[var(--rojo-100)] border border-red-200 text-xs text-[var(--rojo-600)] flex items-start gap-2"
            >
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <div>
                <div className="font-bold">{errorMsg}</div>
                {intentosRestantes !== null && intentosRestantes > 0 && (
                  <div className="mt-0.5 text-[11px] text-red-800">
                    Intentos restantes antes de bloqueo temporal: <strong>{intentosRestantes}</strong>.
                  </div>
                )}
                {minutosBloqueo && (
                  <div className="mt-0.5 text-[11px] text-red-800 flex items-center gap-1 font-semibold">
                    <Clock className="w-3 h-3" />
                    <span>Tiempo de espera: {minutosBloqueo} minutos.</span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* -------------------------------------------------------------
              PESTAÑA 1: INICIAR SESIÓN CON AUTOCOMPLETADO SEGÚN CORREO
              ------------------------------------------------------------- */}
          {activeTab === 'LOGIN' && (
            <div>
              {/* Cuentas registradas disponibles para autocompletado con un clic */}
              {registeredAccounts.length > 0 && (
                <div className="mb-5 p-3 bg-slate-50 rounded-xl border border-slate-200">
                  <div className="flex items-center justify-between text-[11px] font-bold text-slate-600 mb-2">
                    <span className="flex items-center gap-1.5 text-[var(--azul-900)]">
                      <Sparkles className="w-3.5 h-3.5 text-[var(--celeste-500)]" />
                      <span>Cuentas registradas en BD (Clic para autocompletar):</span>
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {registeredAccounts.map((acc) => (
                      <button
                        key={acc.matricula}
                        type="button"
                        onClick={() => handleSelectQuickAccount(acc)}
                        className={`text-[11px] px-2.5 py-1 rounded-lg border text-left transition-colors flex items-center gap-1.5 ${
                          correo === acc.correo
                            ? 'bg-[var(--celeste-100)] border-[var(--azul-700)] text-[var(--azul-900)] font-bold'
                            : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        <span className="font-mono text-[10px] text-slate-500">[{acc.rol}]</span>
                        <span>{acc.correo}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Selector de Perfil */}
              <div className="mb-4">
                <label className="block text-xs font-semibold text-slate-600 mb-1.5">
                  Rol de Acceso
                </label>
                <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-100 rounded-xl">
                  <button
                    type="button"
                    onClick={() => setSelectedRole('ESTUDIANTE')}
                    className={`py-2 text-xs font-semibold rounded-lg transition-all ${
                      selectedRole === 'ESTUDIANTE'
                        ? 'bg-white text-[var(--azul-900)] shadow-xs font-bold'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Estudiante
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedRole('BEDELIA')}
                    className={`py-2 text-xs font-semibold rounded-lg transition-all ${
                      selectedRole === 'BEDELIA'
                        ? 'bg-white text-[var(--azul-900)] shadow-xs font-bold'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Bedelía
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedRole('ADMINISTRACION')}
                    className={`py-2 text-xs font-semibold rounded-lg transition-all ${
                      selectedRole === 'ADMINISTRACION'
                        ? 'bg-white text-[var(--azul-900)] shadow-xs font-bold'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Administración
                  </button>
                </div>
              </div>

              {/* Formulario de Login */}
              <form onSubmit={handleLoginSubmit} className="space-y-4">
                {/* Correo institucional con autocompletado en tiempo real */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label
                      htmlFor="input-correo"
                      className="block text-xs font-semibold text-slate-700"
                    >
                      Correo Electrónico Institucional
                    </label>
                    {autoCompletedName && (
                      <span className="text-[11px] font-bold text-emerald-700 flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                        <span>{autoCompletedName}</span>
                      </span>
                    )}
                  </div>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input
                      id="input-correo"
                      type="email"
                      placeholder="usuario@ucsf.test"
                      value={correo}
                      onChange={(e) => {
                        setCorreo(e.target.value);
                        handleLookupEmail(e.target.value);
                      }}
                      onBlur={(e) => handleLookupEmail(e.target.value)}
                      className="w-full pl-9 pr-24 py-2 text-xs border border-slate-300 rounded-lg focus:border-[var(--azul-700)] focus:ring-1 focus:ring-[var(--azul-700)] outline-none"
                      autoComplete="email"
                      disabled={minutosBloqueo !== null}
                    />
                    <button
                      type="button"
                      onClick={() => handleLookupEmail(correo)}
                      className="absolute right-1.5 top-1/2 -translate-y-1/2 text-[10px] font-bold text-[var(--azul-700)] bg-[var(--celeste-100)] px-2 py-1 rounded hover:bg-blue-100"
                      title="Buscar matrícula asociada a este correo"
                    >
                      Autocompletar
                    </button>
                  </div>
                  <p className="text-[10px] text-slate-400 mt-0.5">
                    Al ingresar su correo, el sistema autocompleta la matrícula y el rol registrado en la BD.
                  </p>
                </div>

                {/* Matrícula Identificatoria */}
                <div>
                  <label
                    htmlFor="input-matricula"
                    className="block text-xs font-semibold text-slate-700 mb-1"
                  >
                    Matrícula Identificatoria
                  </label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input
                      id="input-matricula"
                      type="text"
                      placeholder="ej. A-2026-001"
                      value={matricula}
                      onChange={(e) => setMatricula(e.target.value)}
                      className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:border-[var(--azul-700)] focus:ring-1 focus:ring-[var(--azul-700)] outline-none"
                      autoComplete="off"
                      disabled={minutosBloqueo !== null}
                    />
                  </div>
                </div>

                {/* Contraseña */}
                <div>
                  <label
                    htmlFor="input-password"
                    className="block text-xs font-semibold text-slate-700 mb-1"
                  >
                    Contraseña
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input
                      id="input-password"
                      type="password"
                      placeholder="Ingrese su contraseña"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:border-[var(--azul-700)] focus:ring-1 focus:ring-[var(--azul-700)] outline-none"
                      autoComplete="current-password"
                      disabled={minutosBloqueo !== null}
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading || minutosBloqueo !== null}
                  className="w-full btn-primary text-xs py-2.5 font-bold shadow-sm"
                >
                  {loading ? (
                    <span>Validando credenciales...</span>
                  ) : (
                    <>
                      <span>Ingresar a Autogestión</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>
            </div>
          )}

          {/* -------------------------------------------------------------
              PESTAÑA 2: REGISTRO DE CUENTA EN LA BASE DE DATOS
              ------------------------------------------------------------- */}
          {activeTab === 'REGISTER' && (
            <form onSubmit={handleRegisterSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Nombre y Apellido Completo *
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    placeholder="ej. Santiago Martín Benítez"
                    value={regNombre}
                    onChange={(e) => setRegNombre(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:border-[var(--azul-700)] outline-none"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Matrícula Universitaria *
                  </label>
                  <input
                    type="text"
                    placeholder="ej. A-2026-002"
                    value={regMatricula}
                    onChange={(e) => setRegMatricula(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:border-[var(--azul-700)] outline-none uppercase font-mono"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Correo Institucional *
                  </label>
                  <input
                    type="email"
                    placeholder="alumno@ucsf.test"
                    value={regCorreo}
                    onChange={(e) => setRegCorreo(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:border-[var(--azul-700)] outline-none"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Rol de la Cuenta *
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setRegRol('ESTUDIANTE')}
                    className={`py-2 text-xs font-semibold rounded-lg border text-center ${
                      regRol === 'ESTUDIANTE'
                        ? 'bg-[var(--celeste-100)] border-[var(--azul-700)] text-[var(--azul-900)] font-bold'
                        : 'border-slate-200 text-slate-600'
                    }`}
                  >
                    Estudiante
                  </button>
                  <button
                    type="button"
                    onClick={() => setRegRol('BEDELIA')}
                    className={`py-2 text-xs font-semibold rounded-lg border text-center ${
                      regRol === 'BEDELIA'
                        ? 'bg-[var(--celeste-100)] border-[var(--azul-700)] text-[var(--azul-900)] font-bold'
                        : 'border-slate-200 text-slate-600'
                    }`}
                  >
                    Bedelía
                  </button>
                  <button
                    type="button"
                    onClick={() => setRegRol('ADMINISTRACION')}
                    className={`py-2 text-xs font-semibold rounded-lg border text-center ${
                      regRol === 'ADMINISTRACION'
                        ? 'bg-[var(--celeste-100)] border-[var(--azul-700)] text-[var(--azul-900)] font-bold'
                        : 'border-slate-200 text-slate-600'
                    }`}
                  >
                    Administración
                  </button>
                </div>
              </div>

              {regRol === 'ESTUDIANTE' && (
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Carrera Universitaria *
                  </label>
                  <select
                    value={regCarrera}
                    onChange={(e) => setRegCarrera(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:border-[var(--azul-700)] outline-none bg-white"
                  >
                    {availableCareers.length > 0 ? (
                      availableCareers.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.nombre} ({c.sede})
                        </option>
                      ))
                    ) : (
                      <>
                        <option value="CAR-LSI">Licenciatura en Sistemas de Información (Santa Fe)</option>
                        <option value="CAR-DER">Abogacía (Santa Fe)</option>
                      </>
                    )}
                  </select>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Contraseña (mínimo 8 caracteres) *
                  </label>
                  <input
                    type="password"
                    placeholder="Contraseña segura"
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:border-[var(--azul-700)] outline-none"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Confirmar Contraseña *
                  </label>
                  <input
                    type="password"
                    placeholder="Repita la contraseña"
                    value={regPasswordConf}
                    onChange={(e) => setRegPasswordConf(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:border-[var(--azul-700)] outline-none"
                    required
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={regLoading}
                className="w-full btn-primary text-xs py-2.5 font-bold shadow-sm"
              >
                {regLoading ? 'Registrando en base de datos...' : 'Guardar y Crear Cuenta Oficial'}
              </button>
            </form>
          )}

          {/* Pie de Seguridad */}
          <div className="mt-5 pt-4 border-t border-slate-100 text-center">
            <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-400">
              <Shield className="w-3.5 h-3.5 text-slate-400" />
              <span>Base de Datos Persistente SQLite · Claves Cifradas con bcrypt</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
