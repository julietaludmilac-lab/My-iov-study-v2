import React, { useState, useEffect } from 'react';
import {
  BookOpen,
  Eye,
  CheckCircle,
  AlertTriangle,
  History,
  RotateCcw,
  RotateCw,
  Send,
  Save,
  Clock,
  ShieldCheck,
  FileText,
  X,
  Edit,
  Trash2,
  Calendar,
} from 'lucide-react';
import { apiFetch, safeJson } from './apiClient';

interface BedeliaNoticesProps {
  mode: 'CREAR' | 'GESTION' | 'HISTORIAL';
  onNavigateToSection: (hash: string) => void;
}

export const BedeliaNoticesPage: React.FC<BedeliaNoticesProps> = ({ mode, onNavigateToSection }) => {
  // --- Estados de Creación / Edición ---
  const [titulo, setTitulo] = useState('');
  const [contenido, setContenido] = useState('');
  const [categoria, setCategoria] = useState('ACADEMICO');
  const [destinatarios, setDestinatarios] = useState('TODOS');
  const [carreraId, setCarreraId] = useState('CAR-LSI');
  const [anioCarrera, setAnioCarrera] = useState('2');
  const [fechaVencimiento, setFechaVencimiento] = useState('2026-06-30');
  const [adjuntoNombre, setAdjuntoNombre] = useState('');
  const [currentNoticeId, setCurrentNoticeId] = useState<string | null>(null);

  // Pila para Deshacer / Rehacer ({historial_4})
  const [historyStack, setHistoryStack] = useState<string[]>(['']);
  const [historyIndex, setHistoryIndex] = useState(0);

  // Estados de Flujo de Revisión ({funcion_nueva_5})
  const [noticeState, setNoticeState] = useState<'BORRADOR' | 'EN_REVISION' | 'PUBLICADO'>('BORRADOR');
  const [showPreviewModal, setShowPreviewModal] = useState(false);
  const [saving, setSaving] = useState(false);
  const [statusMsg, setStatusMsg] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  // Lista de avisos para Gestión e Historial
  const [allNotices, setAllNotices] = useState<any[]>([]);
  const [selectedNoticeForHistory, setSelectedNoticeForHistory] = useState<any | null>(null);
  const [noticeVersions, setNoticeVersions] = useState<any[]>([]);

  const getCsrfToken = () => {
    const match = document.cookie.match(/iov_csrf=([^;]+)/);
    return match ? match[1] : '';
  };

  // Cargar lista de avisos
  const loadNotices = async () => {
    try {
      const res = await apiFetch('/api/notices');
      if (res.ok) {
        const data = await safeJson(res);
        setAllNotices(data.notices || []);
        if (data.notices?.length > 0 && !selectedNoticeForHistory) {
          loadHistory(data.notices[0].id);
        }
      }
    } catch {}
  };

  useEffect(() => {
    loadNotices();
  }, [mode]);

  // Manejador de texto con registro en pila de Deshacer/Rehacer
  const handleContentChange = (newVal: string) => {
    setContenido(newVal);
    const newStack = historyStack.slice(0, historyIndex + 1);
    newStack.push(newVal);
    setHistoryStack(newStack);
    setHistoryIndex(newStack.length - 1);
  };

  const handleUndo = () => {
    if (historyIndex > 0) {
      const nextIdx = historyIndex - 1;
      setHistoryIndex(nextIdx);
      setContenido(historyStack[nextIdx]);
    }
  };

  const handleRedo = () => {
    if (historyIndex < historyStack.length - 1) {
      const nextIdx = historyIndex + 1;
      setHistoryIndex(nextIdx);
      setContenido(historyStack[nextIdx]);
    }
  };

  // Paso 1: Guardar Borrador
  const handleSaveDraft = async (): Promise<string | null> => {
    if (!titulo.trim() || !contenido.trim() || !fechaVencimiento) {
      setStatusMsg({ text: 'Debe ingresar título, contenido y fecha de vencimiento.', type: 'error' });
      return null;
    }

    setSaving(true);
    setStatusMsg(null);
    try {
      const res = await apiFetch('/api/notices/draft', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          id: currentNoticeId,
          titulo: titulo.trim(),
          contenido: contenido.trim(),
          categoria,
          destinatarios,
          carreraId,
          anioCarrera: parseInt(anioCarrera, 10),
          fechaVencimiento,
          documentoAdjuntoNombre: adjuntoNombre.trim() || null,
        }),
      });

      const contentType = res.headers.get('content-type') || '';
      let data: any = {};
      if (contentType.includes('application/json')) {
        data = await res.json();
      } else {
        const text = await res.text();
        throw new Error(`Respuesta no esperada del servidor (${res.status}): ${text.slice(0, 100)}`);
      }

      if (!res.ok) throw new Error(data.error || 'Error al guardar borrador');

      setCurrentNoticeId(data.noticeId);
      setNoticeState('BORRADOR');
      setStatusMsg({ text: 'Borrador guardado en la base de datos.', type: 'success' });
      loadNotices();
      return data.noticeId;
    } catch (err: any) {
      setStatusMsg({ text: err.message || 'Error al guardar borrador.', type: 'error' });
      return null;
    } finally {
      setSaving(false);
    }
  };

  // Paso 2: Previsualizar (Cambia a estado EN_REVISION)
  const handlePreview = async () => {
    let targetNoticeId = currentNoticeId;
    if (!targetNoticeId) {
      targetNoticeId = await handleSaveDraft();
      if (!targetNoticeId) return;
    }

    try {
      const res = await apiFetch(`/api/notices/${targetNoticeId}/preview`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ id: targetNoticeId }),
      });

      const contentType = res.headers.get('content-type') || '';
      let data: any = {};
      if (contentType.includes('application/json')) {
        data = await res.json();
      } else {
        const text = await res.text();
        throw new Error(`Respuesta del servidor (${res.status}): ${text.slice(0, 100)}`);
      }

      if (res.ok) {
        setCurrentNoticeId(targetNoticeId);
        setNoticeState('EN_REVISION');
        setShowPreviewModal(true);
      } else {
        setStatusMsg({ text: data.error || 'Error al iniciar previsualización.', type: 'error' });
      }
    } catch (err: any) {
      setStatusMsg({ text: err.message || 'Error al iniciar previsualización.', type: 'error' });
    }
  };

  // Paso 3: Confirmar y Publicar
  const handleConfirmPublish = async () => {
    let targetNoticeId = currentNoticeId;
    if (!targetNoticeId) {
      targetNoticeId = await handleSaveDraft();
      if (!targetNoticeId) return;
    }

    setSaving(true);
    try {
      const res = await apiFetch(`/api/notices/${targetNoticeId}/publish`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ id: targetNoticeId }),
      });

      const contentType = res.headers.get('content-type') || '';
      let data: any = {};
      if (contentType.includes('application/json')) {
        data = await res.json();
      } else {
        const text = await res.text();
        throw new Error(`Respuesta del servidor (${res.status}): ${text.slice(0, 100)}`);
      }

      if (!res.ok) throw new Error(data.error || 'Error al publicar aviso.');

      setCurrentNoticeId(targetNoticeId);
      setNoticeState('PUBLICADO');
      setShowPreviewModal(false);
      setStatusMsg({
        text: `¡Aviso publicado oficialmente con éxito! (${data.motivo || 'Publicación'}, Versión v${data.version}).`,
        type: 'success',
      });
      loadNotices();
    } catch (err: any) {
      setStatusMsg({ text: err.message || 'Error al publicar aviso.', type: 'error' });
    } finally {
      setSaving(false);
    }
  };

  // Publicar Directamente (solicitado por el usuario)
  const handleDirectPublish = async () => {
    if (!titulo.trim() || !contenido.trim() || !fechaVencimiento) {
      setStatusMsg({ text: 'Debe ingresar título, contenido y fecha de vencimiento.', type: 'error' });
      return;
    }

    setSaving(true);
    setStatusMsg(null);
    try {
      const res = await apiFetch('/api/notices/publish-direct', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          id: currentNoticeId,
          titulo: titulo.trim(),
          contenido: contenido.trim(),
          categoria,
          destinatarios,
          carreraId,
          anioCarrera: parseInt(anioCarrera, 10),
          fechaVencimiento,
          documentoAdjuntoNombre: adjuntoNombre.trim() || null,
        }),
      });

      const contentType = res.headers.get('content-type') || '';
      let data: any = {};
      if (contentType.includes('application/json')) {
        data = await res.json();
      } else {
        const text = await res.text();
        throw new Error(`Respuesta del servidor (${res.status}): ${text.slice(0, 100)}`);
      }

      if (!res.ok) throw new Error(data.error || 'Error al publicar aviso directamente.');

      setCurrentNoticeId(data.noticeId);
      setNoticeState('PUBLICADO');
      setStatusMsg({
        text: `¡Aviso publicado directamente en la cartelera oficial! (Versión v${data.version}).`,
        type: 'success',
      });
      loadNotices();
    } catch (err: any) {
      setStatusMsg({ text: err.message || 'Error al publicar aviso directamente.', type: 'error' });
    } finally {
      setSaving(false);
    }
  };

  // Borrar Aviso Definitivamente
  const handleDeleteNotice = async (id: string, noticeTitle?: string) => {
    const confirmMsg = noticeTitle
      ? `¿Confirma que desea eliminar el aviso "${noticeTitle}"? Se borrará de la base de datos.`
      : '¿Confirma que desea eliminar este aviso?';

    if (window.confirm && !window.confirm(confirmMsg)) return;

    try {
      const res = await apiFetch(`/api/notices/${id}`, {
        method: 'DELETE',
      });

      const data = await safeJson(res);
      if (!res.ok) throw new Error(data.error);

      setStatusMsg({ text: data.message || 'Aviso eliminado correctamente.', type: 'success' });
      if (currentNoticeId === id) {
        setCurrentNoticeId(null);
        setTitulo('');
        setContenido('');
        setNoticeState('BORRADOR');
      }
      loadNotices();
    } catch (err: any) {
      setStatusMsg({ text: err.message || 'Error al eliminar aviso.', type: 'error' });
    }
  };

  // Cargar historial de un aviso
  const loadHistory = async (noticeId: string) => {
    try {
      const res = await apiFetch(`/api/notices/${noticeId}`);
      if (res.ok) {
        const data = await safeJson(res);
        setSelectedNoticeForHistory(data.notice);
        setNoticeVersions(data.versions || []);
      }
    } catch {}
  };

  // Restaurar versión histórica ({historial_3})
  const handleRestoreVersion = async (noticeId: string, versionNumber: number) => {
    if (window.confirm && !window.confirm(`¿Confirma que desea restaurar la versión v${versionNumber}? Esta acción creará una nueva versión activa.`)) {
      return;
    }

    try {
      const res = await apiFetch(`/api/notices/${noticeId}/restore-version/${versionNumber}`, {
        method: 'POST',
      });
      const data = await safeJson(res);
      if (res.ok) {
        setStatusMsg({ text: data.message, type: 'success' });
        loadHistory(noticeId);
        loadNotices();
      } else {
        setStatusMsg({ text: data.error || 'Error al restaurar versión.', type: 'error' });
      }
    } catch (err: any) {
      setStatusMsg({ text: err.message || 'Error de conexión al restaurar versión.', type: 'error' });
    }
  };

  return (
    <div className="space-y-6">
      {statusMsg && (
        <div
          role="status"
          className={`p-3.5 rounded-xl border text-xs flex items-center gap-2 ${
            statusMsg.type === 'success'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : 'bg-red-50 border-red-200 text-red-700'
          }`}
        >
          {statusMsg.type === 'success' ? (
            <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
          ) : (
            <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
          )}
          <span>{statusMsg.text}</span>
        </div>
      )}

      {/* -------------------------------------------------------------
          MODO: CREAR AVISO CON FLUJO DE REVISIÓN OBLIGATORIO
          ------------------------------------------------------------- */}
      {mode === 'CREAR' && (
        <div className="iov-card space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-[var(--azul-700)]" />
              <div>
                <h2 className="text-sm font-bold text-[var(--azul-900)]">
                  Editor Oficial de Avisos Institucionales
                </h2>
                <p className="text-[11px] text-slate-500">
                  Flujo: Borrador → Previsualización obligatoria → Confirmación y Notificación.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              <span
                className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                  noticeState === 'PUBLICADO'
                    ? 'badge-vigente'
                    : noticeState === 'EN_REVISION'
                    ? 'badge-actualizado'
                    : 'bg-slate-100 text-slate-600'
                }`}
              >
                {noticeState}
              </span>
            </div>
          </div>

          {/* Formulario */}
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Título del Aviso *
              </label>
              <input
                type="text"
                placeholder="ej. Cronograma de Mesas de Examen Turno Especial"
                value={titulo}
                onChange={(e) => setTitulo(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:border-[var(--azul-700)] outline-none"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Categoría</label>
                <select
                  value={categoria}
                  onChange={(e) => setCategoria(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white outline-none"
                >
                  <option value="ACADEMICO">Académico</option>
                  <option value="ADMINISTRATIVO">Administrativo</option>
                  <option value="INSTITUCIONAL">Institucional</option>
                  <option value="URGENTE">Urgente</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Destinatarios</label>
                <select
                  value={destinatarios}
                  onChange={(e) => setDestinatarios(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white outline-none"
                >
                  <option value="TODOS">Todos los alumnos</option>
                  <option value="ESTUDIANTES">Carrera Específica</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Fecha de Vencimiento *
                </label>
                <input
                  type="date"
                  value={fechaVencimiento}
                  onChange={(e) => setFechaVencimiento(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg outline-none"
                />
              </div>
            </div>

            {/* Contenido con Deshacer y Rehacer */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-semibold text-slate-700">
                  Cuerpo del Aviso *
                </label>
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={handleUndo}
                    disabled={historyIndex === 0}
                    className="p-1 rounded text-slate-500 hover:bg-slate-100 disabled:opacity-30"
                    title="Deshacer (Ctrl+Z)"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={handleRedo}
                    disabled={historyIndex >= historyStack.length - 1}
                    className="p-1 rounded text-slate-500 hover:bg-slate-100 disabled:opacity-30"
                    title="Rehacer (Ctrl+Y)"
                  >
                    <RotateCw className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
              <textarea
                rows={5}
                placeholder="Escriba el contenido institucional detallado..."
                value={contenido}
                onChange={(e) => handleContentChange(e.target.value)}
                className="w-full p-3 text-xs border border-slate-300 rounded-lg focus:border-[var(--azul-700)] outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Documento Adjunto PDF (Opcional)
              </label>
              <input
                type="text"
                placeholder="ej. cronograma-examenes-mayo-2026.pdf"
                value={adjuntoNombre}
                onChange={(e) => setAdjuntoNombre(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg outline-none"
              />
            </div>

            {/* Botonera de Creación y Publicación */}
            <div className="flex flex-wrap items-center justify-between gap-2 pt-3 border-t border-slate-100">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleSaveDraft}
                  disabled={saving}
                  className="btn-secondary text-xs"
                >
                  <Save className="w-4 h-4" />
                  <span>Guardar Borrador</span>
                </button>

                {currentNoticeId && (
                  <button
                    type="button"
                    onClick={() => handleDeleteNotice(currentNoticeId, titulo)}
                    disabled={saving}
                    className="p-2 rounded-lg text-[var(--rojo-600)] hover:bg-red-50 text-xs font-semibold flex items-center gap-1"
                    title="Eliminar este aviso de la base de datos"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>Borrar</span>
                  </button>
                )}
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handlePreview}
                  className="btn-secondary text-xs border-[var(--azul-700)] text-[var(--azul-900)]"
                  title="Revisar antes de confirmar"
                >
                  <Eye className="w-4 h-4" />
                  <span>Previsualizar Aviso</span>
                </button>

                <button
                  type="button"
                  onClick={handleDirectPublish}
                  disabled={saving}
                  className="btn-primary text-xs bg-emerald-700 hover:bg-emerald-800"
                  title="Publicar directamente sin pasar por borrador"
                >
                  <Send className="w-4 h-4" />
                  <span>Publicar Directamente</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* -------------------------------------------------------------
          MODO: GESTIONAR AVISOS (INCLUYE VENCIDOS - {error_6})
          ------------------------------------------------------------- */}
      {mode === 'GESTION' && (
        <div className="space-y-4">
          <div className="iov-card flex items-center justify-between p-4">
            <div>
              <h2 className="text-sm font-bold text-[var(--azul-900)]">
                Bandeja de Gestión de Avisos ({allNotices.length})
              </h2>
              <p className="text-[11px] text-slate-500">
                Supervisión de estados, vigencias y control de vencidos.
              </p>
            </div>
            <button
              onClick={() => onNavigateToSection('crearaviso')}
              className="btn-primary text-xs"
            >
              + Nuevo Aviso
            </button>
          </div>

          <div className="table-container">
            <table className="iov-table">
              <thead>
                <tr>
                  <th>Título / Aviso</th>
                  <th>Categoría</th>
                  <th>Versión</th>
                  <th>Estado Oficial</th>
                  <th>Vigencia</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <tbody>
                {allNotices.map((n) => (
                  <tr key={n.id}>
                    <td>
                      <div className="font-bold text-slate-800 text-xs">{n.titulo}</div>
                      <div className="text-[10px] text-slate-400">ID: {n.id}</div>
                    </td>
                    <td>
                      <span className="text-xs text-slate-600">{n.categoria}</span>
                    </td>
                    <td>
                      <span className="font-mono text-xs font-bold text-[var(--azul-700)]">
                        v{n.version}
                      </span>
                    </td>
                    <td>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                          n.estado === 'PUBLICADO'
                            ? 'badge-vigente'
                            : n.estado === 'EN_REVISION'
                            ? 'badge-actualizado'
                            : n.estado === 'VENCIDO'
                            ? 'badge-vencido'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {n.estado}
                      </span>
                    </td>
                    <td>
                      <div className="text-xs text-slate-600">Hasta: {n.fecha_vencimiento}</div>
                      <div className="text-[10px] text-slate-400">
                        {n.es_vigente ? 'Vigente' : 'Vencido'}
                      </div>
                    </td>
                    <td>
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => {
                            loadHistory(n.id);
                            onNavigateToSection('historialavisos');
                          }}
                          className="btn-secondary text-[11px] py-1 px-2"
                          title="Ver historial de cambios"
                        >
                          Historial
                        </button>

                        <button
                          onClick={() => handleDeleteNotice(n.id, n.titulo)}
                          className="p-1 rounded text-red-600 hover:bg-red-50"
                          title="Eliminar este aviso de la base de datos"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* -------------------------------------------------------------
          MODO: HISTORIAL DE VERSIONES Y RESTAURACIÓN ({historial_1}, {historial_3})
          ------------------------------------------------------------- */}
      {mode === 'HISTORIAL' && (
        <div className="space-y-4">
          <div className="iov-card p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <History className="w-5 h-5 text-[var(--azul-700)]" />
                <h2 className="text-sm font-bold text-[var(--azul-900)]">
                  Línea de Tiempo de Versiones e Historial Inmutable
                </h2>
              </div>
            </div>
            <p className="text-xs text-slate-600">
              Cada actualización real genera una nueva versión snapshot. Al restaurar una versión histórica, se crea una nueva versión activa con motivo registrado.
            </p>
          </div>

          {selectedNoticeForHistory && (
            <div className="iov-card p-4">
              <div className="mb-4 pb-2 border-b border-slate-100 flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-[var(--azul-900)]">
                    {selectedNoticeForHistory.titulo}
                  </h3>
                  <div className="text-[11px] text-slate-500 font-mono">
                    ID: {selectedNoticeForHistory.id} · Versión actual activa: v{selectedNoticeForHistory.version}
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                {noticeVersions.map((v) => (
                  <div
                    key={v.id}
                    className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs flex flex-col md:flex-row md:items-center justify-between gap-3"
                  >
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="badge-actualizado text-[10px] font-mono">
                          v{v.version}
                        </span>
                        <span className="font-bold text-slate-800">{v.motivo_cambio}</span>
                        <span className="text-[10px] text-slate-400">{v.created_at}</span>
                      </div>
                      <p className="text-slate-600 line-clamp-2">{v.contenido}</p>
                    </div>

                    <div className="shrink-0 flex items-center gap-2">
                      <button
                        onClick={() => handleRestoreVersion(selectedNoticeForHistory.id, v.version)}
                        className="btn-secondary text-xs py-1.5 px-3"
                      >
                        Restaurar v{v.version}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Modal de Previsualización Obligatoria ({funcion_nueva_5}) */}
      {showPreviewModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <span className="badge-actualizado text-xs">PASO DE REVISIÓN OFICIAL</span>
                <span className="text-xs text-slate-500 font-bold">Previsualización de Aviso</span>
              </div>
              <button
                onClick={() => setShowPreviewModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3 bg-[var(--celeste-100)] rounded-xl border border-blue-200 text-xs text-[var(--azul-900)]">
              <strong>Atención Bedelía:</strong> Compruebe la redacción, categoría y fechas antes de confirmar la publicación. Al publicar, se emitirán notificaciones automáticas a los estudiantes.
            </div>

            <div>
              <div className="text-[10px] font-bold text-slate-400 uppercase">{categoria}</div>
              <h2 className="text-base font-bold text-[var(--azul-900)] mt-0.5">{titulo}</h2>
              <p className="text-xs text-slate-700 mt-2 whitespace-pre-wrap">{contenido}</p>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-1">
              <div>Vencimiento: <strong>{fechaVencimiento}</strong></div>
              <div>Destinatarios: <strong>{destinatarios}</strong></div>
              {adjuntoNombre && <div>Documento adjunto: <strong>{adjuntoNombre}</strong></div>}
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setShowPreviewModal(false)}
                className="btn-secondary text-xs py-2 px-4"
              >
                Volver a Editar
              </button>
              <button
                type="button"
                onClick={handleConfirmPublish}
                disabled={saving}
                className="btn-primary text-xs py-2 px-4 bg-emerald-700 hover:bg-emerald-800"
              >
                <Send className="w-4 h-4" />
                <span>Confirmar y Publicar Oficialmente</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
