/**
 * Registro Único de Rutas - My IOV Study v2
 * Fuente de verdad compartida entre Router, Navegación lateral/móvil y script check-routes.
 */

export type UserRole = 'ESTUDIANTE' | 'BEDELIA' | 'ADMINISTRACION' | 'PUBLICO';

export interface RouteDefinition {
  hash: string;
  label: string;
  group: 'Principal' | 'Usuario' | 'Académico' | 'Comisiones' | 'Exámenes' | 'Aranceles' | 'Trámites' | 'Avisos y Agenda' | 'Bedelía' | 'Administración' | 'Sistema';
  roles: UserRole[];
  inMenu: boolean;
  description: string;
  isAliasOf?: string;
  quickAccessMobile?: boolean;
}

export const APP_ROUTES: RouteDefinition[] = [
  // --- INICIO & COMUNES ---
  {
    hash: 'inicio',
    label: 'Inicio',
    group: 'Principal',
    roles: ['ESTUDIANTE', 'BEDELIA', 'ADMINISTRACION'],
    inMenu: true,
    description: 'Tablero principal con avisos, horarios del día, eventos y acceso rápido',
    quickAccessMobile: true,
  },

  // --- HORARIOS & CALENDARIO / AGENDA ---
  {
    hash: 'horarios',
    label: 'Horarios y Aulas',
    group: 'Académico',
    roles: ['ESTUDIANTE'],
    inMenu: true,
    description: 'Horarios de cursado semanal del estudiante con aulas oficiales y estados',
    quickAccessMobile: true,
  },
  {
    hash: 'calendario',
    label: 'Calendario y Agenda',
    group: 'Avisos y Agenda',
    roles: ['ESTUDIANTE'],
    inMenu: true,
    description: 'Calendario institucional para consulta con pestaña de agenda personal para notas y recordatorios',
    quickAccessMobile: true,
  },
  {
    hash: 'agenda',
    label: 'Mi agenda',
    group: 'Avisos y Agenda',
    roles: ['ESTUDIANTE'],
    inMenu: false,
    isAliasOf: 'calendario',
    description: 'Acceso directo a la pestaña personal dentro del Calendario unificado',
  },

  // --- AVISOS Y COMUNICACIÓN ---
  {
    hash: 'avisos',
    label: 'Avisos Institucionales',
    group: 'Avisos y Agenda',
    roles: ['ESTUDIANTE', 'BEDELIA', 'ADMINISTRACION'],
    inMenu: true,
    description: 'Cartelera digital unificada de avisos institucionales y académicos con filtros',
    quickAccessMobile: true,
  },
  {
    hash: 'novedadesavisos',
    label: 'Novedades de avisos',
    group: 'Avisos y Agenda',
    roles: ['ESTUDIANTE'],
    inMenu: false,
    isAliasOf: 'avisos',
    description: 'Avisos recientes y actualizaciones oficiales del estudiante',
  },
  {
    hash: 'notificaciones',
    label: 'Notificaciones',
    group: 'Usuario',
    roles: ['ESTUDIANTE', 'BEDELIA', 'ADMINISTRACION'],
    inMenu: true,
    description: 'Bandeja de avisos urgentes, parciales y recordatorios',
  },

  // --- PERFIL Y USUARIO ---
  {
    hash: 'datospersonales',
    label: 'Datos personales',
    group: 'Usuario',
    roles: ['ESTUDIANTE'],
    inMenu: true,
    description: 'Consulta y edición controlada de datos de contacto del estudiante',
  },
  {
    hash: 'cambioclave',
    label: 'Cambio de clave',
    group: 'Usuario',
    roles: ['ESTUDIANTE', 'BEDELIA', 'ADMINISTRACION'],
    inMenu: true,
    description: 'Actualización segura de contraseña con verificación de clave previa',
  },
  {
    hash: 'formapago',
    label: 'Forma de pago',
    group: 'Usuario',
    roles: ['ESTUDIANTE'],
    inMenu: false,
    description: 'Configuración sintética de medio de pago habitual',
  },
  {
    hash: 'fichasalud',
    label: 'Ficha de salud',
    group: 'Usuario',
    roles: ['ESTUDIANTE'],
    inMenu: true,
    description: 'Formulario sintético de antecedentes y aptitud física',
  },

  // --- PLAN DE ESTUDIO Y EXPEDIENTE ACADÉMICO (EXCLUSIVO ESTUDIANTE) ---
  {
    hash: 'planestudio',
    label: 'Plan de estudio',
    group: 'Académico',
    roles: ['ESTUDIANTE'],
    inMenu: true,
    description: 'Estructura curricular por año, materias aprobadas, regulares y pendientes',
  },
  {
    hash: 'correlatividades',
    label: 'Correlatividades',
    group: 'Académico',
    roles: ['ESTUDIANTE'],
    inMenu: true,
    description: 'Requisitos oficiales para cursar y rendir cada materia del plan',
  },
  {
    hash: 'equivalencias',
    label: 'Equivalencias',
    group: 'Académico',
    roles: ['ESTUDIANTE'],
    inMenu: false,
    description: 'Registro de equivalencias otorgadas por resolución oficial',
  },
  {
    hash: 'asistencia',
    label: 'Asistencia y Faltas',
    group: 'Académico',
    roles: ['ESTUDIANTE'],
    inMenu: true,
    description: 'Control de inasistencias, porcentaje de faltas y límite institucional',
  },
  {
    hash: 'parciales',
    label: 'Parciales y Contenidos',
    group: 'Académico',
    roles: ['ESTUDIANTE'],
    inMenu: true,
    description: 'Cronograma oficial de evaluaciones parciales y temarios detallados',
  },
  {
    hash: 'calificaciones',
    label: 'Calificaciones y Promedio',
    group: 'Académico',
    roles: ['ESTUDIANTE'],
    inMenu: true,
    description: 'Historial analítico de notas y cálculo aritmético de promedio general',
  },
  {
    hash: 'documentacion',
    label: 'Documentación y Programas',
    group: 'Académico',
    roles: ['ESTUDIANTE'],
    inMenu: false,
    description: 'Programas analíticos, guías académicas y reglamentos oficiales',
  },

  // --- COMISIONES & CURSADO (ESTUDIANTE) ---
  {
    hash: 'inscripcionescomisiones',
    label: 'Inscripción a comisiones',
    group: 'Comisiones',
    roles: ['ESTUDIANTE'],
    inMenu: true,
    description: 'Inscripción a materias y turnos habilitados del ciclo lectivo',
  },
  {
    hash: 'comisionesactuales',
    label: 'Comisiones actuales',
    group: 'Comisiones',
    roles: ['ESTUDIANTE'],
    inMenu: false,
    isAliasOf: 'inscripcionescomisiones',
    description: 'Materias en las que el estudiante se encuentra regularmente inscripto',
  },
  {
    hash: 'comisionescursadas',
    label: 'Comisiones cursadas',
    group: 'Comisiones',
    roles: ['ESTUDIANTE'],
    inMenu: false,
    isAliasOf: 'inscripcionescomisiones',
    description: 'Historial de cursados finalizados y regularidades obtenidas',
  },
  {
    hash: 'comisionesfaltantes',
    label: 'Comisiones faltantes',
    group: 'Comisiones',
    roles: ['ESTUDIANTE'],
    inMenu: false,
    isAliasOf: 'inscripcionescomisiones',
    description: 'Listado de asignaturas del plan aún pendientes de cursado',
  },

  // --- EXÁMENES (ESTUDIANTE) ---
  {
    hash: 'inscripcionesexamenes',
    label: 'Inscripción a exámenes',
    group: 'Exámenes',
    roles: ['ESTUDIANTE'],
    inMenu: true,
    description: 'Inscripción a mesas de examen final según períodos habilitados',
  },
  {
    hash: 'examenesactuales',
    label: 'Exámenes actuales',
    group: 'Exámenes',
    roles: ['ESTUDIANTE'],
    inMenu: false,
    isAliasOf: 'inscripcionesexamenes',
    description: 'Mesas de examen en las que el estudiante se encuentra inscripto',
  },
  {
    hash: 'examenesrendidos',
    label: 'Exámenes rendidos',
    group: 'Exámenes',
    roles: ['ESTUDIANTE'],
    inMenu: false,
    isAliasOf: 'inscripcionesexamenes',
    description: 'Histórico de exámenes finales rendidos con calificación y actas',
  },
  {
    hash: 'examenesfaltantes',
    label: 'Exámenes faltantes',
    group: 'Exámenes',
    roles: ['ESTUDIANTE'],
    inMenu: false,
    isAliasOf: 'inscripcionesexamenes',
    description: 'Materias regularizadas pendientes de rendir en examen final',
  },

  // --- ARANCELES Y TRÁMITES (ESTUDIANTE) ---
  {
    hash: 'cuotas',
    label: 'Cuotas y Aranceles',
    group: 'Aranceles',
    roles: ['ESTUDIANTE'],
    inMenu: true,
    description: 'Estado de cuotas mensuales, vencimientos e importes a abonar del estudiante',
  },
  {
    hash: 'comprobantes',
    label: 'Comprobantes de pago',
    group: 'Aranceles',
    roles: ['ESTUDIANTE'],
    inMenu: true,
    description: 'Recibos oficiales descargables de pagos realizados por el estudiante',
  },
  {
    hash: 'certificados',
    label: 'Solicitud de certificados',
    group: 'Trámites',
    roles: ['ESTUDIANTE'],
    inMenu: true,
    description: 'Gestión y pedido de certificados de alumno regular y analíticos con código QR',
  },
  {
    hash: 'solicitudes',
    label: 'Mis solicitudes',
    group: 'Trámites',
    roles: ['ESTUDIANTE'],
    inMenu: true,
    description: 'Bandeja de seguimiento del estado de trámites y solicitudes iniciadas',
  },
  {
    hash: 'tav',
    label: 'Académicos (TAV)',
    group: 'Trámites',
    roles: ['ESTUDIANTE'],
    inMenu: false,
    description: 'Trámite Académico Vinculado y equivalencias externas',
  },
  {
    hash: 'titulo',
    label: 'Trámite de título',
    group: 'Trámites',
    roles: ['ESTUDIANTE'],
    inMenu: false,
    description: 'Iniciación y seguimiento de colación y diploma universitario',
  },
  {
    hash: 'encuestas',
    label: 'Encuestas',
    group: 'Trámites',
    roles: ['ESTUDIANTE'],
    inMenu: false,
    description: 'Evaluación docente institucional y opinión estudiantil',
  },
  {
    hash: 'contacto',
    label: 'Contacto',
    group: 'Sistema',
    roles: ['ESTUDIANTE', 'BEDELIA', 'ADMINISTRACION'],
    inMenu: false,
    description: 'Información y canales institucionales de contacto y sedes',
  },
  {
    hash: 'ayuda',
    label: 'Ayuda y Contacto',
    group: 'Sistema',
    roles: ['ESTUDIANTE', 'BEDELIA', 'ADMINISTRACION'],
    inMenu: true,
    description: 'Guía de uso de la plataforma de autogestión My IOV Study v2 y canales oficiales',
  },

  // --- PANEL DE BEDELÍA (GESTIÓN OPERATIVA DE CURSADAS) ---
  {
    hash: 'panelbedelia',
    label: 'Panel de Bedelía',
    group: 'Bedelía',
    roles: ['BEDELIA'],
    inMenu: true,
    description: 'Consola operativa general de cursadas, ocupación de cupos y aulas',
  },
  {
    hash: 'admincomisiones',
    label: 'Comisiones, Aulas y Horarios',
    group: 'Bedelía',
    roles: ['BEDELIA'],
    inMenu: true,
    description: 'Creación, edición y asignación de comisiones a materias, fijar cupo según matrícula, horarios, aulas y reubicaciones',
  },
  {
    hash: 'adminexamenes',
    label: 'Mesas de Examen Final',
    group: 'Bedelía',
    roles: ['BEDELIA'],
    inMenu: true,
    description: 'Programación de tribunales docentes, fechas, aulas y apertura de inscripciones',
  },
  {
    hash: 'adminasistencia',
    label: 'Supervisión de Asistencia',
    group: 'Bedelía',
    roles: ['BEDELIA'],
    inMenu: true,
    description: 'Consulta de actas y porcentaje general de asistencia por comisión sin gestionar la trayectoria personal',
  },
  {
    hash: 'admincalendario',
    label: 'Calendario Institucional',
    group: 'Bedelía',
    roles: ['BEDELIA'],
    inMenu: true,
    description: 'Gestión oficial de feriados, asuetos, semanas de cursada y actividades académicas',
  },
  {
    hash: 'crearaviso',
    label: 'Crear aviso',
    group: 'Bedelía',
    roles: ['BEDELIA'],
    inMenu: true,
    description: 'Editor con previsualización obligatoria y flujo de publicación oficial',
  },
  {
    hash: 'gestionavisos',
    label: 'Gestionar avisos',
    group: 'Bedelía',
    roles: ['BEDELIA'],
    inMenu: true,
    description: 'Administración de avisos vigentes, revisión y vencidos',
  },
  {
    hash: 'historialavisos',
    label: 'Historial de avisos',
    group: 'Bedelía',
    roles: ['BEDELIA'],
    inMenu: true,
    description: 'Trazabilidad de versiones anteriores y restauración de contenido',
  },
  {
    hash: 'adminparciales',
    label: 'Gestión de Parciales y Temarios',
    group: 'Bedelía',
    roles: ['BEDELIA'],
    inMenu: false,
    description: 'Carga y publicación oficial de fechas y contenidos temáticos',
  },
  {
    hash: 'admincalificaciones',
    label: 'Gestión de Calificaciones',
    group: 'Bedelía',
    roles: ['BEDELIA'],
    inMenu: false,
    description: 'Carga de actas, notas de parciales y finales',
  },

  // --- ADMINISTRACIÓN (ESTRUCTURA INSTITUCIONAL, PLANES, USUARIOS Y ARANCELES) ---
  {
    hash: 'admincarreras',
    label: 'Carreras y Planes de Estudio',
    group: 'Administración',
    roles: ['ADMINISTRACION'],
    inMenu: true,
    description: 'Gestión de carreras, subida y lectura/parser de planes de estudio con materias y correlatividades',
  },
  {
    hash: 'adminmaterias',
    label: 'Materias y Correlatividades',
    group: 'Administración',
    roles: ['ADMINISTRACION'],
    inMenu: true,
    description: 'Malla curricular por carrera, carga de materias por año y requisitos oficiales',
  },
  {
    hash: 'adminusuarios',
    label: 'Padrón y Usuarios',
    group: 'Administración',
    roles: ['ADMINISTRACION'],
    inMenu: true,
    description: 'Registro de estudiantes por carrera, personal de bedelía, docentes y control de cuentas',
  },
  {
    hash: 'adminaranceles',
    label: 'Gestión de Aranceles',
    group: 'Administración',
    roles: ['ADMINISTRACION'],
    inMenu: true,
    description: 'Configuración de aranceles institucionales, emisión de cuotas y estado global de cobranzas',
  },
  {
    hash: 'adminsolicitudes',
    label: 'Bandeja de Solicitudes',
    group: 'Administración',
    roles: ['ADMINISTRACION'],
    inMenu: true,
    description: 'Atención y resolución oficial de pedidos de certificados de estudiantes',
  },
  {
    hash: 'auditoria',
    label: 'Auditoría y Seguridad',
    group: 'Administración',
    roles: ['ADMINISTRACION'],
    inMenu: true,
    description: 'Registro de accesos denegados, eventos del sistema y trazabilidad institucional',
  },

  // --- SISTEMA Y HERRAMIENTAS GLOBALES ---
  {
    hash: 'exportaciones',
    label: 'Exportaciones de Datos',
    group: 'Sistema',
    roles: ['BEDELIA', 'ADMINISTRACION'],
    inMenu: true,
    description: 'Descargas en formato seguro JSON y CSV neutralizado',
  },
  {
    hash: 'controlrutas',
    label: 'Control de Rutas',
    group: 'Sistema',
    roles: ['BEDELIA', 'ADMINISTRACION'],
    inMenu: true,
    description: 'Panel de verificación de consistencia de rutas y cobertura 100%',
  },
];

/**
 * Obtener rutas disponibles para un rol determinado
 */
export function getRoutesForRole(role: UserRole): RouteDefinition[] {
  return APP_ROUTES.filter((r) => r.roles.includes(role));
}

/**
 * Obtener mapa indexado por hash
 */
export const ROUTES_BY_HASH: Record<string, RouteDefinition> = APP_ROUTES.reduce(
  (acc, route) => {
    acc[route.hash] = route;
    return acc;
  },
  {} as Record<string, RouteDefinition>
);
