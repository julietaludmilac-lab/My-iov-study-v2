import React, { useState, useEffect } from 'react';
import { Shell } from './components/Shell';
import { APP_ROUTES, ROUTES_BY_HASH, UserRole } from './routesRegistry';
import { LoginPage } from './login';
import { StudentProfilePage } from './studentProfile';
import { ChangePasswordPage } from './changePassword';
import { StudentNoticesPage } from './studentNotices';
import { StudentNotificationsPage } from './studentNotifications';
import { BedeliaNoticesPage } from './bedeliaNotices';
import { StudentSchedulePage } from './studentSchedule';
import { StudentCalendarPage } from './studentCalendar';
import { StudentAcademicPage } from './studentAcademic';
import { StudentEnrollmentsPage } from './studentEnrollments';
import { StudentFinancePage } from './studentFinance';
import { StudentCertificatesPage } from './studentCertificates';
import { BedeliaAcademicPage } from './bedeliaAcademic';
import { AdminManagementPage } from './adminManagement';
import { StudentSpecialProceduresPage } from './studentSpecialProcedures';
import { Stage7AnalyticsRecordsPage } from './stage7AnalyticsRecords';
import { SystemInfoHelpPage } from './systemInfoHelp';
import { apiFetch, clearSession, getStoredUser, saveSession } from './apiClient';
import {
  Calendar,
  Clock,
  BookOpen,
  CreditCard,
  ShieldCheck,
  CheckCircle2,
  Database,
  ArrowRight,
  AlertTriangle,
  FileCheck,
  GraduationCap,
  Users,
  Award,
} from 'lucide-react';

export default function App() {
  const [currentHash, setCurrentHash] = useState<string>(() => {
    const hash = window.location.hash.replace('#', '').replace('/', '');
    return hash || 'inicio';
  });

  const [currentRole, setCurrentRole] = useState<UserRole>('ESTUDIANTE');
  const [systemHealth, setSystemHealth] = useState<any>(null);
  const [userSession, setUserSession] = useState<{
    id: string;
    matricula: string;
    correo: string;
    rol: UserRole;
    nombre: string;
  } | null>(null);
  const [checkingSession, setCheckingSession] = useState(true);

  // Escuchar cambios de hash en la ventana
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace('#', '').replace('/', '');
      setCurrentHash(hash || 'inicio');
    };

    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  // Consultar estado de salud de la base técnica
  useEffect(() => {
    fetch('/api/health')
      .then((res) => res.json())
      .then((data) => setSystemHealth(data))
      .catch((err) => console.error('Error al conectar con la API de salud:', err));
  }, []);

  // Verificar sesión existente en el servidor al cargar
  useEffect(() => {
    const cachedUser = getStoredUser();
    if (cachedUser) {
      setUserSession(cachedUser);
      setCurrentRole(cachedUser.rol);
    }

    apiFetch('/api/auth/me')
      .then((res) => {
        if (res.ok) return res.json();
        clearSession();
        setUserSession(null);
        return null;
      })
      .then((data) => {
        if (data?.user) {
          setUserSession(data.user);
          setCurrentRole(data.user.rol);
          if (data.csrfToken) {
            saveSession('', data.csrfToken, data.user);
          }
        }
      })
      .catch(() => {})
      .finally(() => setCheckingSession(false));
  }, []);

  const navigateTo = (hash: string) => {
    window.location.hash = hash;
    setCurrentHash(hash);
  };

  const handleLogout = async () => {
    try {
      await apiFetch('/api/auth/logout', { method: 'POST' });
    } catch {}
    clearSession();
    setUserSession(null);
    navigateTo('inicio');
  };

  const handleLoginSuccess = (user: any) => {
    setUserSession(user);
    setCurrentRole(user.rol);
    navigateTo('inicio');
  };

  // Si no hay sesión iniciada y ya terminó de verificar, mostrar pantalla de acceso
  if (!userSession && !checkingSession) {
    return <LoginPage onLoginSuccess={handleLoginSuccess} />;
  }

  // Usuario activo en sesión
  const currentUser = userSession || {
    matricula: currentRole === 'ESTUDIANTE' ? 'A-2026-001' : currentRole === 'BEDELIA' ? 'B-ADMIN-001' : 'C-ADMIN-002',
    nombre:
      currentRole === 'ESTUDIANTE'
        ? 'Lucía Belén Gómez'
        : currentRole === 'BEDELIA'
        ? 'Dra. María Elena Vázquez (Bedelía)'
        : 'Cdor. Carlos Méndez (Administración)',
    rol: currentRole,
    carrera: 'Licenciatura en Sistemas de Información',
  };

  return (
    <Shell
      currentHash={currentHash}
      onNavigate={navigateTo}
      currentUser={currentUser}
      unreadNotificationsCount={currentRole === 'ESTUDIANTE' ? 2 : 0}
      onLogout={handleLogout}
    >
      {/* VISTA: INICIO */}
      {currentHash === 'inicio' && (
        <div className="space-y-6">
          {/* Banner de Bienvenida Institucional */}
          <div className="iov-card iov-card-destacada">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 mb-1.5">
                  <span className="badge-vigente">Ciclo Lectivo 2026</span>
                  <span className="text-xs text-slate-500 font-medium">Sede Santa Fe</span>
                </div>
                <h2 className="text-xl md:text-2xl font-black text-[var(--azul-900)] tracking-tight">
                  Bienvenida, {currentUser.nombre}
                </h2>
                <p className="text-xs md:text-sm text-slate-600 mt-1 max-w-2xl">
                  {currentRole === 'ESTUDIANTE'
                    ? 'Consulta tus horarios de cursado, inscripciones, estado de asistencia, calendario académico unificado y cuotas de aranceles.'
                    : currentRole === 'BEDELIA'
                    ? 'Consola de Bedelía: Gestión de avisos con revisión obligatoria, planes, correlatividades, comisiones y exámenes.'
                    : 'Consola de Administración: Seguimiento de aranceles, cuotas, comprobantes y bandeja de solicitudes de certificados.'}
                </p>
              </div>

              <div className="shrink-0 flex flex-wrap gap-2">
                {currentRole === 'ESTUDIANTE' && (
                  <>
                    <button
                      onClick={() => navigateTo('horarios')}
                      className="btn-primary text-xs"
                    >
                      <Clock className="w-4 h-4" />
                      <span>Ver Mis Horarios</span>
                    </button>
                    <button
                      onClick={() => navigateTo('calendario')}
                      className="btn-secondary text-xs"
                    >
                      <Calendar className="w-4 h-4" />
                      <span>Calendario & Agenda</span>
                    </button>
                  </>
                )}
                {currentRole === 'BEDELIA' && (
                  <>
                    <button
                      onClick={() => navigateTo('admincomisiones')}
                      className="btn-primary text-xs"
                    >
                      <Users className="w-4 h-4" />
                      <span>Gestionar Comisiones</span>
                    </button>
                    <button
                      onClick={() => navigateTo('admincalendario')}
                      className="btn-secondary text-xs"
                    >
                      <Calendar className="w-4 h-4" />
                      <span>Calendario Oficial</span>
                    </button>
                    <button
                      onClick={() => navigateTo('exportaciones')}
                      className="btn-secondary text-xs"
                    >
                      <Award className="w-4 h-4 text-amber-600" />
                      <span>Actas & Métricas</span>
                    </button>
                  </>
                )}
                {currentRole === 'ADMINISTRACION' && (
                  <>
                    <button
                      onClick={() => navigateTo('admincarreras')}
                      className="btn-primary text-xs"
                    >
                      <GraduationCap className="w-4 h-4" />
                      <span>Carreras & Planes</span>
                    </button>
                    <button
                      onClick={() => navigateTo('adminusuarios')}
                      className="btn-secondary text-xs"
                    >
                      <Users className="w-4 h-4" />
                      <span>Padrón de Usuarios</span>
                    </button>
                    <button
                      onClick={() => navigateTo('exportaciones')}
                      className="btn-secondary text-xs"
                    >
                      <Award className="w-4 h-4 text-amber-600" />
                      <span>Actas & Reportes</span>
                    </button>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* DASHBOARD ROL: ESTUDIANTE */}
          {currentRole === 'ESTUDIANTE' && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {/* Widget 1: Dónde curso hoy */}
              <div className="iov-card">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2 text-xs font-bold text-[var(--azul-900)] uppercase tracking-wider">
                    <Clock className="w-4 h-4 text-[var(--celeste-500)]" />
                    <span>Dónde curso hoy</span>
                  </div>
                  <span className="text-[11px] font-semibold text-slate-500">Lunes</span>
                </div>
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 mb-3">
                  <div className="text-xs font-bold text-[var(--azul-900)]">
                    Programación Orientada a Objetos
                  </div>
                  <div className="text-[11px] text-slate-600 mt-0.5">
                    08:00 a 11:00 hs · Comisión A
                  </div>
                  <div className="mt-2 flex items-center justify-between text-xs font-bold">
                    <span className="text-[var(--azul-700)]">Aula 204</span>
                    <span className="badge-vigente text-[10px]">OFICIAL</span>
                  </div>
                </div>
                <button
                  onClick={() => navigateTo('horarios')}
                  className="w-full text-center text-xs font-semibold text-[var(--azul-700)] hover:underline flex items-center justify-center gap-1"
                >
                  <span>Ver cronograma semanal completo</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Widget 2: Próximos Parciales Críticos */}
              <div className="iov-card iov-card-critica">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2 text-xs font-bold text-[var(--rojo-600)] uppercase tracking-wider">
                    <AlertTriangle className="w-4 h-4" />
                    <span>Próximo Parcial</span>
                  </div>
                  <span className="badge-critico text-[10px]">PARCIAL 1</span>
                </div>
                <div className="p-3 bg-[var(--rojo-100)] rounded-xl border border-red-200/50 mb-3">
                  <div className="text-xs font-bold text-[var(--rojo-600)]">
                    Programación Orientada a Objetos
                  </div>
                  <div className="text-[11px] text-slate-700 mt-1">
                    Fecha: <strong>18 de Mayo de 2026</strong> a las 08:30 hs
                  </div>
                  <div className="text-[11px] text-slate-600 mt-0.5">
                    Aula: <strong>Aula 204</strong> · Temario cargado
                  </div>
                </div>
                <button
                  onClick={() => navigateTo('parciales')}
                  className="w-full text-center text-xs font-semibold text-[var(--rojo-600)] hover:underline flex items-center justify-center gap-1"
                >
                  <span>Consultar temarios y contenidos</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Widget 3: Control de Asistencia Provisorio */}
              <div className="iov-card">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2 text-xs font-bold text-[var(--azul-900)] uppercase tracking-wider">
                    <GraduationCap className="w-4 h-4 text-[var(--celeste-500)]" />
                    <span>Asistencia Regular</span>
                  </div>
                  <span className="badge-provisorio text-[10px]">PROVISORIO</span>
                </div>
                <div className="space-y-3 mb-3">
                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="font-semibold text-slate-700">POO (Comisión A)</span>
                      <span className="font-bold text-[var(--azul-900)]">16.6% faltas</span>
                    </div>
                    <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-[var(--celeste-500)] rounded-full"
                        style={{ width: '16.6%' }}
                      />
                    </div>
                    <div className="text-[10px] text-slate-500 mt-1">
                      2 faltas de 12 clases registradas (Límite: 25%)
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="font-semibold text-slate-700">Base de Datos I</span>
                      <span className="font-bold text-[var(--azul-900)]">10.0% faltas</span>
                    </div>
                    <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-[var(--celeste-500)] rounded-full"
                        style={{ width: '10%' }}
                      />
                    </div>
                    <div className="text-[10px] text-slate-500 mt-1">
                      1 falta de 10 clases registradas (Límite: 25%)
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => navigateTo('asistencia')}
                  className="w-full text-center text-xs font-semibold text-[var(--azul-700)] hover:underline flex items-center justify-center gap-1"
                >
                  <span>Detalle de cálculo de inasistencias</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {/* DASHBOARD ROL: BEDELÍA */}
          {currentRole === 'BEDELIA' && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              <div className="iov-card">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2 text-xs font-bold text-[var(--azul-900)] uppercase">
                    <BookOpen className="w-4 h-4 text-[var(--azul-700)]" />
                    <span>Avisos Institucionales</span>
                  </div>
                  <span className="badge-vigente text-[10px]">4 ACTIVOS</span>
                </div>
                <p className="text-xs text-slate-600 mb-3">
                  Publicación oficial con previsualización obligatoria y versionado trazable.
                </p>
                <div className="space-y-1.5 mb-3">
                  <button
                    onClick={() => navigateTo('crearaviso')}
                    className="w-full btn-primary text-xs py-2 justify-center"
                  >
                    Crear Nuevo Aviso
                  </button>
                  <button
                    onClick={() => navigateTo('gestionavisos')}
                    className="w-full btn-secondary text-xs py-2 justify-center"
                  >
                    Gestionar Avisos y Vencidos
                  </button>
                </div>
              </div>

              <div className="iov-card">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2 text-xs font-bold text-[var(--azul-900)] uppercase">
                    <Users className="w-4 h-4 text-[var(--celeste-500)]" />
                    <span>Comisiones & Aulas</span>
                  </div>
                  <span className="badge-actualizado text-[10px]">CICLO 2026</span>
                </div>
                <p className="text-xs text-slate-600 mb-3">
                  Asignación de turnos, cupos, docentes titulares y aulas con estado oficial.
                </p>
                <div className="space-y-1.5 mb-3">
                  <button
                    onClick={() => navigateTo('admincomisiones')}
                    className="w-full btn-primary text-xs py-2 justify-center"
                  >
                    Gestionar Comisiones
                  </button>
                  <button
                    onClick={() => navigateTo('adminexamenes')}
                    className="w-full btn-secondary text-xs py-2 justify-center"
                  >
                    Programar Mesas de Examen
                  </button>
                </div>
              </div>

              <div className="iov-card">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2 text-xs font-bold text-[var(--azul-900)] uppercase">
                    <Calendar className="w-4 h-4 text-purple-600" />
                    <span>Calendario & Asistencia</span>
                  </div>
                  <span className="badge-vigente text-[10px]">OFICIAL</span>
                </div>
                <p className="text-xs text-slate-600 mb-3">
                  Calendario oficial de cursadas y supervisión de regularidad por comisión.
                </p>
                <div className="space-y-1.5 mb-3">
                  <button
                    onClick={() => navigateTo('admincalendario')}
                    className="w-full btn-primary text-xs py-2 justify-center"
                  >
                    Calendario Institucional
                  </button>
                  <button
                    onClick={() => navigateTo('adminasistencia')}
                    className="w-full btn-secondary text-xs py-2 justify-center"
                  >
                    Supervisar Asistencia de Comisiones
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* DASHBOARD ROL: ADMINISTRACIÓN */}
          {currentRole === 'ADMINISTRACION' && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              <div className="iov-card">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2 text-xs font-bold text-[var(--azul-900)] uppercase">
                    <GraduationCap className="w-4 h-4 text-[var(--azul-700)]" />
                    <span>Carreras & Planes</span>
                  </div>
                  <span className="badge-vigente text-[10px]">ESTRUCTURA</span>
                </div>
                <p className="text-xs text-slate-600 mb-3">
                  Creación de carreras, subida de planes de estudio y lectura/parser de materias y correlatividades.
                </p>
                <div className="space-y-1.5">
                  <button
                    onClick={() => navigateTo('admincarreras')}
                    className="w-full btn-primary text-xs py-2 justify-center"
                  >
                    Gestionar Carreras y Lector de Plan
                  </button>
                  <button
                    onClick={() => navigateTo('adminmaterias')}
                    className="w-full btn-secondary text-xs py-2 justify-center"
                  >
                    Ver Malla Curricular y Correlatividades
                  </button>
                </div>
              </div>

              <div className="iov-card">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2 text-xs font-bold text-[var(--azul-900)] uppercase">
                    <Users className="w-4 h-4 text-[var(--celeste-500)]" />
                    <span>Padrón de Usuarios</span>
                  </div>
                  <span className="badge-actualizado text-[10px]">PADRÓN</span>
                </div>
                <p className="text-xs text-slate-600 mb-3">
                  Registro de estudiantes por carrera para dimensionamiento de cupos, control de cuentas y seguridad.
                </p>
                <button
                  onClick={() => navigateTo('adminusuarios')}
                  className="w-full btn-primary text-xs py-2 justify-center"
                >
                  Gestionar Usuarios y Padrón
                </button>
              </div>

              <div className="iov-card">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2 text-xs font-bold text-[var(--azul-900)] uppercase">
                    <CreditCard className="w-4 h-4 text-emerald-600" />
                    <span>Aranceles & Trámites</span>
                  </div>
                  <span className="badge-pagada text-[10px]">INSTITUCIONAL</span>
                </div>
                <p className="text-xs text-slate-600 mb-3">
                  Control global de cuotas, recaudación y atención de solicitudes de certificados.
                </p>
                <div className="space-y-1.5">
                  <button
                    onClick={() => navigateTo('adminaranceles')}
                    className="w-full btn-primary text-xs py-2 justify-center"
                  >
                    Gestión de Aranceles
                  </button>
                  <button
                    onClick={() => navigateTo('adminsolicitudes')}
                    className="w-full btn-secondary text-xs py-2 justify-center"
                  >
                    Bandeja de Certificados
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Estado de la Base Técnica / SQLite Persistente (Módulo 1 Fundaciones) */}
          <div className="iov-card bg-slate-50/70">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2 text-xs font-bold text-[var(--azul-900)] uppercase tracking-wider">
                <Database className="w-4 h-4 text-[var(--azul-700)]" />
                <span>Base Técnica & Persistencia Relacional (M1 a M8 Integral)</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="badge-pagada text-[10px]">
                  ETAPAS 1 A 8 INTEGRADAS
                </span>
                <span className="badge-actualizado text-[10px]">
                  {systemHealth ? 'SQLITE ONLINE' : 'INICIALIZANDO'}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs mb-3">
              <div className="p-2.5 bg-white rounded-lg border border-slate-200">
                <div className="text-slate-500 font-medium">Motor de Datos</div>
                <div className="font-bold text-[var(--azul-900)] mt-0.5">SQLite Relacional</div>
                <div className="text-[10px] text-slate-400">Persistente en disco</div>
              </div>
              <div className="p-2.5 bg-white rounded-lg border border-slate-200">
                <div className="text-slate-500 font-medium">Tablas Creadas</div>
                <div className="font-bold text-[var(--azul-900)] mt-0.5">
                  {systemHealth?.database?.tablesCount || 39} tablas oficiales
                </div>
                <div className="text-[10px] text-slate-400">Migraciones 001 a 004 aplicadas</div>
              </div>
              <div className="p-2.5 bg-white rounded-lg border border-slate-200">
                <div className="text-slate-500 font-medium">Semilla Sintética</div>
                <div className="font-bold text-[var(--azul-900)] mt-0.5">3 Cuentas / 1 Carrera</div>
                <div className="text-[10px] text-slate-400">12 Materias / 2 Comisiones</div>
              </div>
              <div className="p-2.5 bg-white rounded-lg border border-slate-200">
                <div className="text-slate-500 font-medium">Control de Rutas</div>
                <div className="font-bold text-[var(--azul-900)] mt-0.5">
                  {APP_ROUTES.length} Rutas Únicas
                </div>
                <div className="text-[10px] text-slate-400">Sin rutas huérfanas</div>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between text-xs text-slate-600 gap-2 pt-2 border-t border-slate-200">
              <div className="flex items-center gap-1.5 text-[11px]">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>Tokens visuales oficiales (celeste, azul, rojo) aplicados en todo el sistema.</span>
              </div>
              <button
                onClick={() => navigateTo('controlrutas')}
                className="font-bold text-[var(--azul-700)] hover:underline flex items-center gap-1"
              >
                <span>Inspeccionar panel de control de rutas</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* VISTA: CONTROL DE RUTAS */}
      {currentHash === 'controlrutas' && (
        <div className="space-y-4">
          <div className="iov-card">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-base font-bold text-[var(--azul-900)]">
                Registro Único de Rutas de la Aplicación ({APP_ROUTES.length} rutas verificadas)
              </h3>
              <span className="badge-pagada text-xs">COBERTURA 100% OK</span>
            </div>
            <p className="text-xs text-slate-600 mb-4">
              Cada ítem del menú lateral y de navegación móvil está vinculado de manera bidireccional
              con una ruta hash real y con el archivo de manifiesto público{' '}
              <code>public/manus-routes.json</code>, garantizando que no existen rutas rotas ni
              huérfanas (requisito <code>{'{funcion_nueva_18}'}</code> y corrección{' '}
              <code>{'{error_5}'}</code>).
            </p>

            <div className="table-container">
              <table className="iov-table">
                <thead>
                  <tr>
                    <th>Ruta Hash</th>
                    <th>Etiqueta en Menú</th>
                    <th>Grupo</th>
                    <th>Roles Autorizados</th>
                    <th>Estado de Enlace</th>
                    <th>Acción</th>
                  </tr>
                </thead>
                <tbody>
                  {APP_ROUTES.map((route) => (
                    <tr key={route.hash}>
                      <td className="font-mono text-xs font-bold text-[var(--azul-700)]">
                        /#{route.hash}
                      </td>
                      <td className="font-semibold text-slate-800">{route.label}</td>
                      <td>
                        <span className="text-xs text-slate-500">{route.group}</span>
                      </td>
                      <td>
                        <div className="flex flex-wrap gap-1">
                          {route.roles.map((r) => (
                            <span
                              key={r}
                              className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-100 text-slate-700"
                            >
                              {r}
                            </span>
                          ))}
                        </div>
                      </td>
                      <td>
                        <span className="badge-vigente text-[11px] inline-flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          <span>REGISTRADA</span>
                        </span>
                      </td>
                      <td>
                        <button
                          onClick={() => navigateTo(route.hash)}
                          className="btn-secondary text-[11px] py-1 px-2.5"
                        >
                          Ir a sección
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* VISTA: DATOS PERSONALES */}
      {currentHash === 'datospersonales' && <StudentProfilePage />}

      {/* VISTA: CAMBIO DE CONTRASEÑA */}
      {currentHash === 'cambioclave' && <ChangePasswordPage />}

      {/* VISTA: AVISOS Y NOVEDADES (ESTUDIANTE) */}
      {currentHash === 'avisos' && <StudentNoticesPage />}
      {currentHash === 'novedadesavisos' && <StudentNoticesPage novedadesOnly={true} />}

      {/* VISTA: NOTIFICACIONES */}
      {currentHash === 'notificaciones' && <StudentNotificationsPage onNavigateToSection={navigateTo} />}

      {/* VISTAS: GESTIÓN DE AVISOS E HISTORIAL (BEDELÍA) */}
      {currentHash === 'crearaviso' && <BedeliaNoticesPage mode="CREAR" onNavigateToSection={navigateTo} />}
      {currentHash === 'gestionavisos' && <BedeliaNoticesPage mode="GESTION" onNavigateToSection={navigateTo} />}
      {currentHash === 'historialavisos' && <BedeliaNoticesPage mode="HISTORIAL" onNavigateToSection={navigateTo} />}

      {/* VISTAS: HORARIOS Y AULAS */}
      {currentHash === 'horarios' && (
        currentRole === 'ESTUDIANTE' ? (
          <StudentSchedulePage />
        ) : (
          <BedeliaAcademicPage viewMode="admincomisiones" onNavigateToSection={navigateTo} />
        )
      )}

      {/* VISTAS: CALENDARIO Y AGENDA */}
      {currentHash === 'calendario' && (
        currentRole === 'ESTUDIANTE' ? (
          <StudentCalendarPage initialTab="CALENDARIO" />
        ) : (
          <BedeliaAcademicPage viewMode="admincalendario" onNavigateToSection={navigateTo} />
        )
      )}
      {currentHash === 'agenda' && <StudentCalendarPage initialTab="AGENDA" />}

      {/* VISTAS: PLAN DE ESTUDIO, ASISTENCIA, PARCIALES, NOTAS Y PROGRAMAS */}
      {(currentHash === 'planestudio' ||
        currentHash === 'correlatividades' ||
        currentHash === 'equivalencias' ||
        currentHash === 'asistencia' ||
        currentHash === 'parciales' ||
        currentHash === 'calificaciones' ||
        currentHash === 'documentacion') && (
        <StudentAcademicPage
          currentSection={currentHash as any}
          onNavigateSubSection={(s) => navigateTo(s)}
        />
      )}

      {/* VISTAS: COMISIONES */}
      {(currentHash === 'inscripcionescomisiones' ||
        currentHash === 'comisionesactuales' ||
        currentHash === 'comisionescursadas' ||
        currentHash === 'comisionesfaltantes') && (
        <StudentEnrollmentsPage mode="COMISIONES" subTab={currentHash} onNavigate={navigateTo} />
      )}

      {/* VISTAS: EXÁMENES */}
      {(currentHash === 'inscripcionesexamenes' ||
        currentHash === 'examenesactuales' ||
        currentHash === 'examenesrendidos' ||
        currentHash === 'examenesfaltantes') && (
        <StudentEnrollmentsPage mode="EXAMENES" subTab={currentHash} onNavigate={navigateTo} />
      )}

      {/* VISTAS: ARANCELES Y COMPROBANTES */}
      {currentHash === 'cuotas' && <StudentFinancePage showComprobantesOnly={false} />}
      {currentHash === 'comprobantes' && <StudentFinancePage showComprobantesOnly={true} />}

      {/* VISTAS: TRÁMITES Y CERTIFICADOS */}
      {currentHash === 'certificados' && <StudentCertificatesPage initialMode="SOLICITAR" />}
      {currentHash === 'solicitudes' && <StudentCertificatesPage initialMode="SEGUIMIENTO" />}

      {/* VISTAS: PROCEDIMIENTOS ESPECIALES Y SALUD */}
      {(currentHash === 'formapago' ||
        currentHash === 'fichasalud' ||
        currentHash === 'tav' ||
        currentHash === 'titulo' ||
        currentHash === 'encuestas') && (
        <StudentSpecialProceduresPage section={currentHash as any} />
      )}

      {/* VISTAS: CONTACTO Y AYUDA */}
      {(currentHash === 'contacto' || currentHash === 'ayuda') && (
        <SystemInfoHelpPage mode={currentHash as any} userRole={currentRole} />
      )}

      {/* VISTAS: ADMINISTRACIÓN (CARRERAS, PLANES, DOCUMENTOS, PADRÓN, ARANCELES, AUDITORÍA) */}
      {(currentHash === 'admincarreras' ||
        currentHash === 'adminmaterias' ||
        currentHash === 'adminusuarios' ||
        currentHash === 'adminaranceles' ||
        currentHash === 'adminsolicitudes' ||
        currentHash === 'auditoria') && (
        <AdminManagementPage viewMode={currentHash} onNavigate={navigateTo} />
      )}

      {/* VISTAS: PANEL BEDELÍA (GESTIÓN OPERATIVA DE COMISIONES, AULAS, HORARIOS Y EXÁMENES) */}
      {(currentHash === 'panelbedelia' ||
        currentHash === 'admincomisiones' ||
        currentHash === 'adminexamenes' ||
        currentHash === 'adminasistencia' ||
        currentHash === 'admincalendario' ||
        currentHash === 'adminparciales' ||
        currentHash === 'admincalificaciones') && (
        <BedeliaAcademicPage viewMode={currentHash} onNavigateToSection={navigateTo} />
      )}

      {/* VISTA: ETAPA 7 ANALÍTICA, ACTAS OFICIALES Y EXPORTACIONES */}
      {currentHash === 'exportaciones' && (
        <Stage7AnalyticsRecordsPage onNavigate={navigateTo} userRole={currentRole} />
      )}

      {/* OTRAS SECCIONES INFORMATIVAS */}
      {currentHash !== 'inicio' &&
        currentHash !== 'controlrutas' &&
        currentHash !== 'datospersonales' &&
        currentHash !== 'cambioclave' &&
        currentHash !== 'avisos' &&
        currentHash !== 'novedadesavisos' &&
        currentHash !== 'notificaciones' &&
        currentHash !== 'crearaviso' &&
        currentHash !== 'gestionavisos' &&
        currentHash !== 'historialavisos' &&
        currentHash !== 'horarios' &&
        currentHash !== 'calendario' &&
        currentHash !== 'agenda' &&
        currentHash !== 'planestudio' &&
        currentHash !== 'correlatividades' &&
        currentHash !== 'equivalencias' &&
        currentHash !== 'asistencia' &&
        currentHash !== 'parciales' &&
        currentHash !== 'calificaciones' &&
        currentHash !== 'documentacion' &&
        currentHash !== 'inscripcionescomisiones' &&
        currentHash !== 'comisionesactuales' &&
        currentHash !== 'comisionescursadas' &&
        currentHash !== 'comisionesfaltantes' &&
        currentHash !== 'inscripcionesexamenes' &&
        currentHash !== 'examenesactuales' &&
        currentHash !== 'examenesrendidos' &&
        currentHash !== 'examenesfaltantes' &&
        currentHash !== 'cuotas' &&
        currentHash !== 'comprobantes' &&
        currentHash !== 'certificados' &&
        currentHash !== 'solicitudes' &&
        currentHash !== 'formapago' &&
        currentHash !== 'fichasalud' &&
        currentHash !== 'tav' &&
        currentHash !== 'titulo' &&
        currentHash !== 'encuestas' &&
        currentHash !== 'contacto' &&
        currentHash !== 'ayuda' &&
        currentHash !== 'panelbedelia' &&
        currentHash !== 'admincarreras' &&
        currentHash !== 'adminmaterias' &&
        currentHash !== 'adminusuarios' &&
        currentHash !== 'admincomisiones' &&
        currentHash !== 'adminexamenes' &&
        currentHash !== 'adminasistencia' &&
        currentHash !== 'admincalendario' &&
        currentHash !== 'adminparciales' &&
        currentHash !== 'admincalificaciones' &&
        currentHash !== 'adminaranceles' &&
        currentHash !== 'adminsolicitudes' &&
        currentHash !== 'auditoria' &&
        currentHash !== 'exportaciones' && (
        <div className="space-y-4">
          <div className="iov-card">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <FileCheck className="w-5 h-5 text-[var(--celeste-500)]" />
                <h3 className="text-base font-bold text-[var(--azul-900)]">
                  {ROUTES_BY_HASH[currentHash]?.label || currentHash}
                </h3>
              </div>
              <span className="badge-actualizado text-xs font-semibold">
                Módulo Integrado — My IOV Study v2
              </span>
            </div>

            <div className="p-4 bg-[var(--celeste-100)] rounded-xl border border-blue-200/60 mb-4">
              <div className="text-xs font-bold text-[var(--azul-900)] mb-1">
                Información de la sección:
              </div>
              <p className="text-xs text-slate-700">
                {ROUTES_BY_HASH[currentHash]?.description ||
                  'Esta sección se encuentra registrada en la fuente única de rutas y conectada a la base de datos persistente SQLite.'}
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-600">
              <div className="p-3 bg-white rounded-lg border border-slate-200">
                <span className="font-bold text-slate-700">Ruta oficial:</span>{' '}
                <code>/#{currentHash}</code>
              </div>
              <div className="p-3 bg-white rounded-lg border border-slate-200">
                <span className="font-bold text-slate-700">Roles habilitados:</span>{' '}
                {ROUTES_BY_HASH[currentHash]?.roles.join(', ') || 'TODOS'}
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
              <span>Fuente: {ROUTES_BY_HASH[currentHash]?.group || 'Institucional'} UCSF</span>
              <button
                onClick={() => navigateTo('inicio')}
                className="btn-primary text-xs py-1.5 px-3"
              >
                Volver a Inicio
              </button>
            </div>
          </div>
        </div>
      )}
    </Shell>
  );
}
