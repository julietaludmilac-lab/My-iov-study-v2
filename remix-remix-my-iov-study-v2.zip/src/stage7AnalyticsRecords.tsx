import React, { useState, useEffect } from 'react';
import { apiFetch, safeJson } from './apiClient';
import {
  BarChart3,
  BookOpen,
  ShieldCheck,
  Download,
  CheckCircle2,
  AlertTriangle,
  FileCheck,
  Search,
  Filter,
  Users,
  Award,
  Layers,
  Sparkles,
  Lock,
  QrCode,
  Building2,
  Calendar,
  DollarSign,
  TrendingUp,
} from 'lucide-react';

interface Stage7Props {
  onNavigate?: (hash: string) => void;
  userRole?: string;
}

export const Stage7AnalyticsRecordsPage: React.FC<Stage7Props> = ({ onNavigate, userRole = 'BEDELIA' }) => {
  const [activeTab, setActiveTab] = useState<'KPIS' | 'ACTAS' | 'VERIFICADOR' | 'EXPORTACIONES'>('KPIS');

  // Datos de KPIs
  const [bedeliaKpis, setBedeliaKpis] = useState<any>(null);
  const [adminKpis, setAdminKpis] = useState<any>(null);
  const [loadingKpis, setLoadingKpis] = useState(false);

  // Datos de Actas Oficiales
  const [actas, setActas] = useState<any[]>([]);
  const [materias, setMaterias] = useState<any[]>([]);
  const [loadingActas, setLoadingActas] = useState(false);
  const [showGenerarActaModal, setShowGenerarActaModal] = useState(false);
  const [actionMsg, setActionMsg] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  // Formulario de Nueva Acta
  const [formTipo, setFormTipo] = useState<'EXAMEN_FINAL' | 'REGULARIDAD_CURSADA'>('EXAMEN_FINAL');
  const [formMateriaId, setFormMateriaId] = useState('');
  const [formLibro, setFormLibro] = useState('LIBRO-XXIV-SISTEMAS');
  const [formFolio, setFormFolio] = useState('');
  const [formPresidente, setFormPresidente] = useState('Dra. María Elena Vázquez');
  const [formVocal1, setFormVocal1] = useState('Ing. Martín Berro');
  const [formVocal2, setFormVocal2] = useState('Lic. Andrea Toledo');
  const [formInscriptos, setFormInscriptos] = useState(20);
  const [formAprobados, setFormAprobados] = useState(16);
  const [formDesaprobados, setFormDesaprobados] = useState(3);
  const [formAusentes, setFormAusentes] = useState(1);
  const [savingActa, setSavingActa] = useState(false);

  // Verificador Público
  const [searchCodigo, setSearchCodigo] = useState('UCSF-CERT-2026-8841');
  const [verifResultado, setVerifResultado] = useState<any>(null);
  const [verifError, setVerifError] = useState<string | null>(null);
  const [verifLoading, setVerifLoading] = useState(false);

  // Cargar datos según tab
  useEffect(() => {
    loadKpis();
    loadActas();
    loadMaterias();
  }, []);

  const loadKpis = async () => {
    setLoadingKpis(true);
    try {
      const [bRes, aRes] = await Promise.all([
        apiFetch('/api/analytics/bedelia-kpis'),
        apiFetch('/api/analytics/admin-finance-kpis'),
      ]);
      if (bRes.ok) setBedeliaKpis(await safeJson(bRes));
      if (aRes.ok) setAdminKpis(await safeJson(aRes));
    } catch {}
    setLoadingKpis(false);
  };

  const loadActas = async () => {
    setLoadingActas(true);
    try {
      const res = await apiFetch('/api/records/actas');
      if (res.ok) {
        const data = await safeJson(res);
        setActas(data.actas || []);
      }
    } catch {}
    setLoadingActas(false);
  };

  const loadMaterias = async () => {
    try {
      const res = await apiFetch('/api/academic/study-plan');
      if (res.ok) {
        const data = await safeJson(res);
        setMaterias(data.materias || []);
        if (data.materias?.length > 0 && !formMateriaId) {
          setFormMateriaId(data.materias[0].id);
        }
      }
    } catch {}
  };

  // Generar Acta Oficial
  const handleGenerarActa = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formMateriaId || !formLibro || !formFolio || !formPresidente) {
      setActionMsg({ text: 'Complete los campos obligatorios del acta.', type: 'error' });
      return;
    }

    setSavingActa(true);
    setActionMsg(null);
    try {
      const res = await apiFetch('/api/records/actas/generar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tipo: formTipo,
          materiaId: formMateriaId,
          libro: formLibro.trim(),
          folio: formFolio.trim(),
          presidenteTribunal: formPresidente.trim(),
          vocal1: formVocal1.trim(),
          vocal2: formVocal2.trim(),
          totalInscriptos: formInscriptos,
          totalAprobados: formAprobados,
          totalDesaprobados: formDesaprobados,
          totalAusentes: formAusentes,
        }),
      });

      const data = await safeJson(res);
      if (!res.ok) throw new Error(data.error);

      setActionMsg({ text: `¡Acta ${data.numeroActa} generada y registrada en libro con éxito! Código: ${data.codigoSeguridad}`, type: 'success' });
      setShowGenerarActaModal(false);
      setFormFolio('');
      loadActas();
    } catch (err: any) {
      setActionMsg({ text: err.message || 'Error al generar acta oficial.', type: 'error' });
    } finally {
      setSavingActa(false);
    }
  };

  // Firmar Acta Oficial
  const handleFirmarActa = async (actaId: string) => {
    try {
      const res = await apiFetch(`/api/records/actas/${actaId}/firmar`, {
        method: 'POST',
      });
      const data = await safeJson(res);
      if (!res.ok) throw new Error(data.error);

      setActionMsg({ text: data.message, type: 'success' });
      loadActas();
    } catch (err: any) {
      setActionMsg({ text: err.message || 'Error al firmar acta.', type: 'error' });
    }
  };

  // Consultar Verificación Pública
  const handleVerificarDocumento = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!searchCodigo.trim()) return;

    setVerifLoading(true);
    setVerifError(null);
    setVerifResultado(null);
    try {
      const res = await apiFetch(`/api/verify/${encodeURIComponent(searchCodigo.trim())}`);
      const data = await safeJson(res);
      if (!res.ok) {
        setVerifError(data.error || 'Documento no encontrado o no válido.');
      } else {
        setVerifResultado(data);
      }
    } catch (err: any) {
      setVerifError(err.message || 'Error de conexión con el servicio de verificación.');
    } finally {
      setVerifLoading(false);
    }
  };

  // Descarga de Exportaciones Seguras
  const handleDownloadExport = (tipo: 'actas' | 'estudiantes' | 'aranceles', formato: 'csv' | 'json') => {
    window.open(`/api/records/export/${tipo}?formato=${formato}`, '_blank');
  };

  return (
    <div className="space-y-6">
      {/* Mensaje de Acción */}
      {actionMsg && (
        <div
          role="status"
          className={`p-3.5 rounded-xl border text-xs flex items-center justify-between ${
            actionMsg.type === 'success'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : 'bg-red-50 border-red-200 text-red-700'
          }`}
        >
          <div className="flex items-center gap-2">
            {actionMsg.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
            )}
            <span>{actionMsg.text}</span>
          </div>
          <button onClick={() => setActionMsg(null)} className="font-bold text-xs hover:underline">
            Cerrar
          </button>
        </div>
      )}

      {/* Header Institucional Etapa 7 */}
      <div className="iov-card iov-card-destacada">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="badge-vigente">Etapa 7 Oficial</span>
              <span className="text-xs text-slate-500 font-medium">UCSF Santa Fe</span>
            </div>
            <h2 className="text-xl md:text-2xl font-black text-[var(--azul-900)] tracking-tight">
              Centro de Analítica, Actas Oficiales y Validación Digital
            </h2>
            <p className="text-xs md:text-sm text-slate-600 mt-1 max-w-2xl">
              Supervisión de métricas de ocupación, actas con libro y folio reglamentario, validación pública de autenticidad criptográfica SHA-256 y exportaciones oficiales.
            </p>
          </div>

          <div className="shrink-0 flex items-center gap-2">
            <button
              onClick={() => {
                setShowGenerarActaModal(true);
                setFormFolio(`FOLIO-${Math.floor(100 + Math.random() * 900)}`);
              }}
              className="btn-primary text-xs"
            >
              <Award className="w-4 h-4" />
              <span>Generar Acta Oficial</span>
            </button>
          </div>
        </div>
      </div>

      {/* Tabs de Navegación del Módulo */}
      <div className="flex items-center gap-2 border-b border-slate-200 overflow-x-auto pb-1 text-xs font-semibold">
        <button
          onClick={() => setActiveTab('KPIS')}
          className={`px-4 py-2 rounded-t-lg transition-colors flex items-center gap-2 ${
            activeTab === 'KPIS'
              ? 'bg-white border-t border-x border-slate-200 text-[var(--azul-700)] font-bold'
              : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          <span>Tablero de Métricas & KPIs</span>
        </button>

        <button
          onClick={() => setActiveTab('ACTAS')}
          className={`px-4 py-2 rounded-t-lg transition-colors flex items-center gap-2 ${
            activeTab === 'ACTAS'
              ? 'bg-white border-t border-x border-slate-200 text-[var(--azul-700)] font-bold'
              : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>Libro Oficial de Actas ({actas.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('VERIFICADOR')}
          className={`px-4 py-2 rounded-t-lg transition-colors flex items-center gap-2 ${
            activeTab === 'VERIFICADOR'
              ? 'bg-white border-t border-x border-slate-200 text-[var(--azul-700)] font-bold'
              : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <QrCode className="w-4 h-4" />
          <span>Verificador Público de Documentos</span>
        </button>

        <button
          onClick={() => setActiveTab('EXPORTACIONES')}
          className={`px-4 py-2 rounded-t-lg transition-colors flex items-center gap-2 ${
            activeTab === 'EXPORTACIONES'
              ? 'bg-white border-t border-x border-slate-200 text-[var(--azul-700)] font-bold'
              : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <Download className="w-4 h-4" />
          <span>Exportaciones Seguras</span>
        </button>
      </div>

      {/* =========================================================================
          TAB 1: TABLERO DE MÉTRICAS & KPIS
          ========================================================================= */}
      {activeTab === 'KPIS' && (
        <div className="space-y-6">
          {/* Tarjetas Superiores de Métricas de Bedelía */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="iov-card">
              <div className="text-[11px] font-bold text-slate-400 uppercase">Ocupación de Comisiones</div>
              <div className="text-2xl font-black text-[var(--azul-900)] mt-1">
                {bedeliaKpis?.resumen?.ocupacionPromedioGlobal || 65}%
              </div>
              <div className="text-[11px] text-slate-500 mt-1">
                {bedeliaKpis?.resumen?.totalInscriptos || 0} alumnos / {bedeliaKpis?.resumen?.totalCupos || 0} cupos
              </div>
            </div>

            <div className="iov-card">
              <div className="text-[11px] font-bold text-slate-400 uppercase">Alumnos en Riesgo (Asistencia)</div>
              <div className="text-2xl font-black text-[var(--rojo-600)] mt-1">
                {bedeliaKpis?.resumen?.cantidadAlumnosEnRiesgo || 0}
              </div>
              <div className="text-[11px] text-slate-500 mt-1">Superan el 25% reglamentario</div>
            </div>

            <div className="iov-card">
              <div className="text-[11px] font-bold text-slate-400 uppercase">Actas Asentadas en Libro</div>
              <div className="text-2xl font-black text-emerald-600 mt-1">
                {bedeliaKpis?.resumen?.actasFirmadas || 0} / {bedeliaKpis?.resumen?.totalActas || 0}
              </div>
              <div className="text-[11px] text-slate-500 mt-1">Con firma y hash SHA-256</div>
            </div>

            <div className="iov-card">
              <div className="text-[11px] font-bold text-slate-400 uppercase">Tasa de Cobranza Aranceles</div>
              <div className="text-2xl font-black text-[var(--azul-700)] mt-1">
                {adminKpis?.kpis?.tasaCobranza || 0}%
              </div>
              <div className="text-[11px] text-slate-500 mt-1">
                ${(adminKpis?.kpis?.recaudacionTotal || 0).toLocaleString()} recaudados
              </div>
            </div>
          </div>

          {/* Ocupación Detallada por Comisión */}
          <div className="iov-card">
            <h3 className="text-sm font-bold text-[var(--azul-900)] mb-3">
              Monitoreo de Cupos y Ocupación por Comisión
            </h3>
            <div className="table-container">
              <table className="iov-table">
                <thead>
                  <tr>
                    <th>Materia</th>
                    <th>Comisión</th>
                    <th>Turno</th>
                    <th>Cupo</th>
                    <th>Inscriptos</th>
                    <th>Ocupación %</th>
                    <th>Estado de Demanda</th>
                  </tr>
                </thead>
                <tbody>
                  {(bedeliaKpis?.comisiones || []).map((com: any) => (
                    <tr key={com.id}>
                      <td className="font-bold text-slate-800">{com.materia}</td>
                      <td className="font-mono text-xs">{com.comision}</td>
                      <td>{com.turno}</td>
                      <td>{com.cupoMaximo}</td>
                      <td className="font-bold">{com.inscriptos}</td>
                      <td>
                        <div className="flex items-center gap-2">
                          <div className="w-16 bg-slate-200 rounded-full h-1.5 overflow-hidden">
                            <div
                              className={`h-1.5 rounded-full ${
                                com.porcentajeOcupacion >= 90
                                  ? 'bg-red-500'
                                  : com.porcentajeOcupacion <= 30
                                  ? 'bg-amber-400'
                                  : 'bg-emerald-500'
                              }`}
                              style={{ width: `${Math.min(100, com.porcentajeOcupacion)}%` }}
                            />
                          </div>
                          <span className="text-[11px] font-bold">{com.porcentajeOcupacion}%</span>
                        </div>
                      </td>
                      <td>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                            com.estadoCupo === 'ALTA_DEMANDA'
                              ? 'badge-vencido'
                              : com.estadoCupo === 'BAJA_OCUPACION'
                              ? 'badge-provisorio'
                              : 'badge-vigente'
                          }`}
                        >
                          {com.estadoCupo}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Alumnos en Riesgo por Inasistencia */}
          {bedeliaKpis?.alumnosEnRiesgo && bedeliaKpis.alumnosEnRiesgo.length > 0 && (
            <div className="iov-card border-l-4 border-l-[var(--rojo-600)]">
              <div className="flex items-center gap-2 mb-2 text-red-700 font-bold text-sm">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>Atención Bedelía: Estudiantes con Alerta de Inasistencia (&gt; 25%)</span>
              </div>
              <div className="table-container">
                <table className="iov-table">
                  <thead>
                    <tr>
                      <th>Estudiante</th>
                      <th>Materia</th>
                      <th>Clases Dictadas</th>
                      <th>Ausencias</th>
                      <th>% Inasistencia</th>
                      <th>Acción Preventiva</th>
                    </tr>
                  </thead>
                  <tbody>
                    {bedeliaKpis.alumnosEnRiesgo.map((a: any, idx: number) => (
                      <tr key={idx}>
                        <td className="font-bold text-slate-800">{a.estudiante_nombre}</td>
                        <td>{a.materia_nombre}</td>
                        <td>{a.total_clases}</td>
                        <td className="font-bold text-red-600">{a.ausentes}</td>
                        <td className="font-mono font-bold text-red-700">{a.porcentajeInasistencia}%</td>
                        <td>
                          <button
                            onClick={() => alert(`Aviso preventivo enviado al estudiante ${a.estudiante_nombre}`)}
                            className="btn-secondary text-[11px] py-1 px-2.5"
                          >
                            Enviar Notificación Preventiva
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* =========================================================================
          TAB 2: LIBRO OFICIAL DE ACTAS
          ========================================================================= */}
      {activeTab === 'ACTAS' && (
        <div className="space-y-4">
          <div className="iov-card flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-base font-bold text-[var(--azul-900)]">
                Registro y Protocolización de Actas Oficiales
              </h3>
              <p className="text-xs text-slate-500">
                Cada acta cuenta con número correlativo único, Tomo, Folio, Libro reglamentario y hash criptográfico SHA-256.
              </p>
            </div>
            <button
              onClick={() => {
                setShowGenerarActaModal(true);
                setFormFolio(`FOLIO-${Math.floor(100 + Math.random() * 900)}`);
              }}
              className="btn-primary text-xs"
            >
              <Award className="w-4 h-4" />
              <span>+ Nueva Acta Oficial</span>
            </button>
          </div>

          <div className="table-container">
            <table className="iov-table">
              <thead>
                <tr>
                  <th>N° Acta / Tipo</th>
                  <th>Materia</th>
                  <th>Libro & Folio</th>
                  <th>Tribunal / Docente</th>
                  <th>Resultados</th>
                  <th>Hash SHA-256</th>
                  <th>Estado</th>
                  <th>Acción</th>
                </tr>
              </thead>
              <tbody>
                {actas.map((acta) => (
                  <tr key={acta.id}>
                    <td>
                      <div className="font-bold text-xs text-[var(--azul-900)] font-mono">{acta.numero_acta}</div>
                      <span className="badge-actualizado text-[9px] mt-0.5 inline-block">{acta.tipo}</span>
                    </td>
                    <td>
                      <div className="font-bold text-xs text-slate-800">{acta.materia_nombre}</div>
                      <div className="text-[10px] text-slate-400">{acta.materia_codigo} · Ciclo {acta.ciclo_lectivo}</div>
                    </td>
                    <td>
                      <div className="text-xs font-semibold text-slate-700">{acta.libro}</div>
                      <div className="text-[10px] font-mono text-slate-500">{acta.folio}</div>
                    </td>
                    <td>
                      <div className="text-xs font-semibold text-slate-800">{acta.presidente_tribunal}</div>
                      <div className="text-[10px] text-slate-400">
                        {acta.vocal_1 ? `${acta.vocal_1}` : 'Tribunal único'}
                      </div>
                    </td>
                    <td>
                      <div className="text-[11px] text-slate-700">
                        <span className="text-emerald-700 font-bold">{acta.total_aprobados} Aprob.</span> ·{' '}
                        <span className="text-red-700">{acta.total_desaprobados} Desap.</span> ·{' '}
                        <span className="text-slate-400">{acta.total_ausentes} Aus.</span>
                      </div>
                      <div className="text-[10px] text-slate-400">Total inscriptos: {acta.total_inscriptos}</div>
                    </td>
                    <td>
                      <div
                        className="font-mono text-[9px] text-slate-500 truncate max-w-[120px]"
                        title={acta.hash_verificacion}
                      >
                        {acta.hash_verificacion ? `${acta.hash_verificacion.slice(0, 12)}...` : '-'}
                      </div>
                    </td>
                    <td>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                          acta.estado === 'FIRMADA' || acta.estado === 'CERRADA'
                            ? 'badge-pagada'
                            : 'badge-provisorio'
                        }`}
                      >
                        {acta.estado}
                      </span>
                    </td>
                    <td>
                      {acta.estado === 'GENERADA' ? (
                        <button
                          onClick={() => handleFirmarActa(acta.id)}
                          className="btn-primary text-[10px] py-1 px-2.5"
                          title="Firmar digitalmente y protocolizar acta"
                        >
                          <FileCheck className="w-3.5 h-3.5" />
                          <span>Firmar</span>
                        </button>
                      ) : (
                        <span className="text-[11px] text-emerald-700 font-bold flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Asentada</span>
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB 3: VERIFICADOR PÚBLICO DE DOCUMENTOS (QR / HASH)
          ========================================================================= */}
      {activeTab === 'VERIFICADOR' && (
        <div className="space-y-6">
          <div className="iov-card">
            <h3 className="text-base font-bold text-[var(--azul-900)] mb-1">
              Servicio Oficial de Validación Digital Criptográfica
            </h3>
            <p className="text-xs text-slate-600 mb-4">
              Cualquier entidad, empleador o alumno puede comprobar la legitimidad de constancias, títulos, actas y certificados emitidos por la Universidad Católica de Santa Fe.
            </p>

            <form onSubmit={handleVerificarDocumento} className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Ingrese código de seguridad (ej. UCSF-CERT-2026-8841) o hash SHA-256..."
                  value={searchCodigo}
                  onChange={(e) => setSearchCodigo(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:border-[var(--azul-700)] outline-none"
                />
              </div>
              <button
                type="submit"
                disabled={verifLoading}
                className="btn-primary text-xs"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>Verificar Autenticidad</span>
              </button>
            </form>

            <div className="mt-3 flex items-center gap-2 text-[11px] text-slate-400">
              <span>Códigos de prueba rápidos:</span>
              <button
                type="button"
                onClick={() => {
                  setSearchCodigo('UCSF-CERT-2026-8841');
                  handleVerificarDocumento();
                }}
                className="font-mono text-[var(--azul-700)] hover:underline"
              >
                UCSF-CERT-2026-8841
              </button>
              <span>·</span>
              <button
                type="button"
                onClick={() => {
                  setSearchCodigo('UCSF-ACTA-2026-1049');
                  handleVerificarDocumento();
                }}
                className="font-mono text-[var(--azul-700)] hover:underline"
              >
                UCSF-ACTA-2026-1049
              </button>
            </div>
          </div>

          {/* Resultado de Verificación */}
          {verifResultado && (
            <div className="iov-card border-2 border-emerald-500 bg-emerald-50/20 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-emerald-200">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />
                  <div>
                    <h4 className="text-sm font-black text-emerald-900">
                      DOCUMENTO OFICIAL AUTÉNTICO Y VIGENTE
                    </h4>
                    <p className="text-[11px] text-emerald-700">
                      Emitido por la Universidad Católica de Santa Fe (UCSF)
                    </p>
                  </div>
                </div>
                <span className="badge-pagada text-xs font-bold font-mono">
                  ESTADO: {verifResultado.estado}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                <div className="p-3 bg-white rounded-xl border border-slate-200">
                  <div className="text-slate-400 text-[10px] uppercase font-bold">Código Oficial</div>
                  <div className="font-mono font-bold text-[var(--azul-900)] mt-0.5">{verifResultado.codigoSeguridad}</div>
                </div>

                <div className="p-3 bg-white rounded-xl border border-slate-200">
                  <div className="text-slate-400 text-[10px] uppercase font-bold">Tipo de Documento</div>
                  <div className="font-bold text-slate-800 mt-0.5">{verifResultado.tipoDocumento}</div>
                </div>

                <div className="p-3 bg-white rounded-xl border border-slate-200">
                  <div className="text-slate-400 text-[10px] uppercase font-bold">Autoridad Firmante</div>
                  <div className="font-bold text-slate-800 mt-0.5">{verifResultado.emisor?.nombre} ({verifResultado.emisor?.rol})</div>
                </div>

                <div className="p-3 bg-white rounded-xl border border-slate-200">
                  <div className="text-slate-400 text-[10px] uppercase font-bold">Fecha de Emisión</div>
                  <div className="font-bold text-slate-800 mt-0.5">{verifResultado.fechaEmision}</div>
                </div>
              </div>

              {verifResultado.detalles && (
                <div className="p-3.5 bg-white rounded-xl border border-slate-200 text-xs">
                  <div className="text-slate-500 font-bold mb-1.5 uppercase text-[10px]">Metadatos Institucionales Registrados:</div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-slate-700">
                    {Object.entries(verifResultado.detalles).map(([k, v]) => (
                      <div key={k} className="flex items-center gap-1.5">
                        <span className="font-semibold capitalize">{k}:</span>
                        <span className="text-slate-900 font-medium">{String(v)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="p-2.5 bg-slate-50 rounded-lg text-[10px] font-mono text-slate-500 break-all">
                Sello Criptográfico SHA-256: {verifResultado.hashSha256}
              </div>
            </div>
          )}

          {verifError && (
            <div className="iov-card border-2 border-red-400 bg-red-50/30 text-xs p-4 flex items-center gap-3 text-red-800">
              <AlertTriangle className="w-5 h-5 text-red-600 shrink-0" />
              <div>
                <strong>Aviso de Seguridad:</strong> {verifError}
              </div>
            </div>
          )}
        </div>
      )}

      {/* =========================================================================
          TAB 4: EXPORTACIONES SEGURAS
          ========================================================================= */}
      {activeTab === 'EXPORTACIONES' && (
        <div className="space-y-4">
          <div className="iov-card">
            <h3 className="text-base font-bold text-[var(--azul-900)] mb-1">
              Descargas y Archivo Digital Oficial
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Exportación en formatos abiertos estándar con protección contra inyección de fórmulas CSV (CWE-1236).
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 text-sm font-bold text-slate-900 mb-1">
                    <BookOpen className="w-4 h-4 text-[var(--azul-700)]" />
                    <span>Libro de Actas Oficiales</span>
                  </div>
                  <p className="text-slate-500 text-[11px]">
                    Actas de examen final y cursadas con Tomo, Folio, libro y hash de seguridad.
                  </p>
                </div>
                <div className="flex items-center gap-2 mt-4">
                  <button
                    onClick={() => handleDownloadExport('actas', 'csv')}
                    className="btn-primary text-xs flex-1 justify-center"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Descargar CSV</span>
                  </button>
                  <button
                    onClick={() => handleDownloadExport('actas', 'json')}
                    className="btn-secondary text-xs flex-1 justify-center"
                  >
                    <span>JSON</span>
                  </button>
                </div>
              </div>

              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 text-sm font-bold text-slate-900 mb-1">
                    <Users className="w-4 h-4 text-[var(--celeste-500)]" />
                    <span>Padrón de Estudiantes</span>
                  </div>
                  <p className="text-slate-500 text-[11px]">
                    Nómina general de alumnos matriculados por carrera, cohorte y estado de usuario.
                  </p>
                </div>
                <div className="flex items-center gap-2 mt-4">
                  <button
                    onClick={() => handleDownloadExport('estudiantes', 'csv')}
                    className="btn-primary text-xs flex-1 justify-center"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Descargar CSV</span>
                  </button>
                  <button
                    onClick={() => handleDownloadExport('estudiantes', 'json')}
                    className="btn-secondary text-xs flex-1 justify-center"
                  >
                    <span>JSON</span>
                  </button>
                </div>
              </div>

              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 text-sm font-bold text-slate-900 mb-1">
                    <DollarSign className="w-4 h-4 text-emerald-600" />
                    <span>Reporte de Aranceles</span>
                  </div>
                  <p className="text-slate-500 text-[11px]">
                    Consolidado de cuotas emitidas, estados de cobranza, fechas de vencimiento y pagos.
                  </p>
                </div>
                <div className="flex items-center gap-2 mt-4">
                  <button
                    onClick={() => handleDownloadExport('aranceles', 'csv')}
                    className="btn-primary text-xs flex-1 justify-center"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Descargar CSV</span>
                  </button>
                  <button
                    onClick={() => handleDownloadExport('aranceles', 'json')}
                    className="btn-secondary text-xs flex-1 justify-center"
                  >
                    <span>JSON</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Generar Nueva Acta Oficial */}
      {showGenerarActaModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Award className="w-5 h-5 text-[var(--azul-700)]" />
                <h3 className="text-sm font-bold text-[var(--azul-900)]">
                  Protocolizar y Generar Acta Oficial
                </h3>
              </div>
              <button
                onClick={() => setShowGenerarActaModal(false)}
                className="text-slate-400 hover:text-slate-700 font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleGenerarActa} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Tipo de Acta *</label>
                  <select
                    value={formTipo}
                    onChange={(e: any) => setFormTipo(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg outline-none bg-white"
                  >
                    <option value="EXAMEN_FINAL">Examen Final</option>
                    <option value="REGULARIDAD_CURSADA">Regularidad de Cursada</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Materia *</label>
                  <select
                    value={formMateriaId}
                    onChange={(e) => setFormMateriaId(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg outline-none bg-white"
                  >
                    {materias.map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.nombre} ({m.codigo})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Libro Oficial *</label>
                  <input
                    type="text"
                    value={formLibro}
                    onChange={(e) => setFormLibro(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg outline-none"
                    placeholder="ej. LIBRO-XXIV-SISTEMAS"
                    required
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Folio *</label>
                  <input
                    type="text"
                    value={formFolio}
                    onChange={(e) => setFormFolio(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg outline-none"
                    placeholder="ej. FOLIO-145"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Presidente del Tribunal *</label>
                <input
                  type="text"
                  value={formPresidente}
                  onChange={(e) => setFormPresidente(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-lg outline-none"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Vocal 1</label>
                  <input
                    type="text"
                    value={formVocal1}
                    onChange={(e) => setFormVocal1(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg outline-none"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Vocal 2</label>
                  <input
                    type="text"
                    value={formVocal2}
                    onChange={(e) => setFormVocal2(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-4 gap-2 pt-1 border-t border-slate-100">
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-0.5">Inscriptos</label>
                  <input
                    type="number"
                    value={formInscriptos}
                    onChange={(e) => setFormInscriptos(parseInt(e.target.value, 10) || 0)}
                    className="w-full p-1.5 border border-slate-300 rounded text-center"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-emerald-700 mb-0.5">Aprobados</label>
                  <input
                    type="number"
                    value={formAprobados}
                    onChange={(e) => setFormAprobados(parseInt(e.target.value, 10) || 0)}
                    className="w-full p-1.5 border border-slate-300 rounded text-center"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-red-700 mb-0.5">Desaprob.</label>
                  <input
                    type="number"
                    value={formDesaprobados}
                    onChange={(e) => setFormDesaprobados(parseInt(e.target.value, 10) || 0)}
                    className="w-full p-1.5 border border-slate-300 rounded text-center"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-0.5">Ausentes</label>
                  <input
                    type="number"
                    value={formAusentes}
                    onChange={(e) => setFormAusentes(parseInt(e.target.value, 10) || 0)}
                    className="w-full p-1.5 border border-slate-300 rounded text-center"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowGenerarActaModal(false)}
                  className="btn-secondary text-xs py-2 px-4"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={savingActa}
                  className="btn-primary text-xs py-2 px-4"
                >
                  {savingActa ? 'Generando...' : 'Asentar y Generar Hash SHA-256'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
