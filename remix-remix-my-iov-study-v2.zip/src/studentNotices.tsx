import React, { useState, useEffect } from 'react';
import {
  BookOpen,
  Calendar,
  FileText,
  Filter,
  Search,
  Download,
  AlertCircle,
  Clock,
  ChevronRight,
  ShieldCheck,
  CheckCircle2,
  X,
} from 'lucide-react';
import { apiFetch } from './apiClient';

interface NoticeItem {
  id: string;
  titulo: string;
  contenido: string;
  categoria: string;
  destinatarios: string;
  fecha_publicacion: string;
  fecha_vencimiento: string;
  estado: string;
  version: number;
  fuente_nombre: string;
  documento_adjunto_nombre?: string;
  es_vigente: number;
}

export const StudentNoticesPage: React.FC<{ novedadesOnly?: boolean }> = ({ novedadesOnly = false }) => {
  const [notices, setNotices] = useState<NoticeItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('TODAS');
  const [selectedVigencia, setSelectedVigencia] = useState<string>(novedadesOnly ? 'vigente' : 'todos');
  const [activeNotice, setActiveNotice] = useState<NoticeItem | null>(null);

  const fetchNotices = async () => {
    setLoading(true);
    try {
      let url = '/api/notices?';
      if (selectedCategory !== 'TODAS') url += `categoria=${selectedCategory}&`;
      if (selectedVigencia !== 'todos') url += `vigencia=${selectedVigencia}&`;

      const res = await apiFetch(url);
      if (res.ok) {
        const data = await res.json();
        setNotices(data.notices || []);
      }
    } catch (err) {
      console.error('Error al cargar avisos:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchNotices();
  }, [selectedCategory, selectedVigencia]);

  const filteredNotices = notices.filter(
    (n) =>
      n.titulo.toLowerCase().includes(searchQuery.toLowerCase()) ||
      n.contenido.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Barra de Filtros y Búsqueda */}
      <div className="iov-card p-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Buscar por título o contenido de aviso..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:border-[var(--azul-700)] outline-none"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Filtro por Categoría */}
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="text-xs border border-slate-300 rounded-lg px-2.5 py-2 bg-white outline-none"
            >
              <option value="TODAS">Todas las Categorías</option>
              <option value="ACADEMICO">Académico</option>
              <option value="ADMINISTRATIVO">Administrativo</option>
              <option value="INSTITUCIONAL">Institucional</option>
              <option value="URGENTE">Urgente</option>
            </select>

            {/* Filtro por Vigencia */}
            {!novedadesOnly && (
              <select
                value={selectedVigencia}
                onChange={(e) => setSelectedVigencia(e.target.value)}
                className="text-xs border border-slate-300 rounded-lg px-2.5 py-2 bg-white outline-none"
              >
                <option value="todos">Vigentes y Vencidos</option>
                <option value="vigente">Solo Vigentes</option>
                <option value="vencido">Solo Vencidos</option>
              </select>
            )}
          </div>
        </div>
      </div>

      {/* Listado de Avisos */}
      {loading ? (
        <div className="iov-card p-8 text-center text-xs text-slate-500">
          Cargando avisos institucionales oficiales...
        </div>
      ) : filteredNotices.length === 0 ? (
        <div className="iov-card p-8 text-center">
          <BookOpen className="w-8 h-8 text-slate-300 mx-auto mb-2" />
          <h3 className="text-sm font-bold text-slate-700">No se encontraron avisos</h3>
          <p className="text-xs text-slate-500 mt-1">
            No se encontró información institucional disponible para esta consulta o filtro seleccionado.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredNotices.map((notice) => {
            const esVencido = notice.es_vigente === 0;
            const tieneAdjunto = Boolean(notice.documento_adjunto_nombre);

            return (
              <div
                key={notice.id}
                className={`iov-card flex flex-col justify-between cursor-pointer hover:border-[var(--celeste-500)] ${
                  notice.categoria === 'URGENTE' ? 'border-red-300 bg-red-50/20' : ''
                }`}
                onClick={() => setActiveNotice(notice)}
              >
                <div>
                  {/* Encabezado de la Tarjeta con Badges con Texto ({salida_2}) */}
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="text-[10px] font-bold text-slate-500 uppercase">
                      {notice.categoria}
                    </span>

                    <div className="flex items-center gap-1.5">
                      {notice.version > 1 && (
                        <span className="badge-actualizado text-[10px]">
                          v{notice.version} ACTUALIZADO
                        </span>
                      )}
                      {esVencido ? (
                        <span className="badge-vencido text-[10px]">VENCIDO</span>
                      ) : (
                        <span className="badge-vigente text-[10px]">VIGENTE</span>
                      )}
                    </div>
                  </div>

                  <h3 className="text-sm font-bold text-[var(--azul-900)] mb-1.5 line-clamp-2">
                    {notice.titulo}
                  </h3>

                  <p className="text-xs text-slate-600 line-clamp-3 mb-3">
                    {notice.contenido}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                  <div className="flex items-center gap-1 truncate max-w-[200px]">
                    <ShieldCheck className="w-3.5 h-3.5 text-[var(--azul-700)] shrink-0" />
                    <span className="truncate">{notice.fuente_nombre || 'Bedelía UCSF'}</span>
                  </div>

                  {tieneAdjunto && (
                    <span className="text-[var(--azul-700)] font-semibold flex items-center gap-1">
                      <FileText className="w-3.5 h-3.5" />
                      <span>PDF Adjunto</span>
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Modal / Panel de Detalle del Aviso */}
      {activeNotice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-start justify-between gap-4 pb-3 border-b border-slate-100">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-[10px] font-bold text-slate-500 uppercase">
                    {activeNotice.categoria}
                  </span>
                  {activeNotice.es_vigente ? (
                    <span className="badge-vigente text-[10px]">VIGENTE</span>
                  ) : (
                    <span className="badge-vencido text-[10px]">VENCIDO</span>
                  )}
                  {activeNotice.version > 1 && (
                    <span className="badge-actualizado text-[10px]">
                      Versión v{activeNotice.version}
                    </span>
                  )}
                </div>
                <h2 className="text-base font-bold text-[var(--azul-900)]">
                  {activeNotice.titulo}
                </h2>
              </div>
              <button
                onClick={() => setActiveNotice(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="text-xs text-slate-700 leading-relaxed whitespace-pre-wrap">
              {activeNotice.contenido}
            </div>

            {/* Metadatos oficiales */}
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-1.5">
              <div className="flex justify-between">
                <span className="text-slate-500">Fuente Oficial:</span>
                <span className="font-bold text-[var(--azul-900)]">
                  {activeNotice.fuente_nombre || 'Bedelía Central'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Fecha de Publicación:</span>
                <span>{activeNotice.fecha_publicacion || 'No informada'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Válido hasta:</span>
                <span className={activeNotice.es_vigente ? 'text-slate-700' : 'text-[var(--rojo-600)] font-bold'}>
                  {activeNotice.fecha_vencimiento}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Destinatarios:</span>
                <span className="font-semibold">{activeNotice.destinatarios}</span>
              </div>
            </div>

            {/* Documento adjunto si existe */}
            {activeNotice.documento_adjunto_nombre && (
              <div className="p-3 bg-[var(--celeste-100)] rounded-xl border border-blue-200 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-[var(--azul-700)]" />
                  <div>
                    <div className="font-bold text-[var(--azul-900)]">
                      {activeNotice.documento_adjunto_nombre}
                    </div>
                    <div className="text-[10px] text-slate-500">Documento Oficial PDF</div>
                  </div>
                </div>
                <button
                  onClick={() => alert(`Descarga sintética iniciada: ${activeNotice.documento_adjunto_nombre}`)}
                  className="btn-primary text-xs py-1.5 px-3"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Descargar</span>
                </button>
              </div>
            )}

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setActiveNotice(null)}
                className="btn-secondary text-xs py-2 px-4"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
