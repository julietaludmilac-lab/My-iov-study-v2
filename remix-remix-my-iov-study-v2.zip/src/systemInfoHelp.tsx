import React, { useState, useEffect } from 'react';
import { apiFetch, safeJson } from './apiClient';
import {
  HelpCircle,
  Phone,
  Mail,
  MapPin,
  Clock,
  BookOpen,
  ShieldCheck,
  ChevronRight,
  ExternalLink,
  MessageSquare,
  FileText,
  Download,
  CheckCircle2,
  AlertCircle,
  Search,
  Send,
  Building2,
  Sparkles,
  Inbox,
  UserCheck,
} from 'lucide-react';

interface HelpProps {
  mode: 'contacto' | 'ayuda';
  userRole?: string;
}

export function SystemInfoHelpPage({ mode, userRole = 'ESTUDIANTE' }: HelpProps) {
  const [activeTab, setActiveTab] = useState<'FAQ' | 'TICKETS' | 'DOCUMENTOS'>('FAQ');

  // Estados de Tickets de Soporte
  const [tickets, setTickets] = useState<any[]>([]);
  const [loadingTickets, setLoadingTickets] = useState(false);
  const [showNewTicketModal, setShowNewTicketModal] = useState(false);
  const [ticketSuccessMsg, setTicketSuccessMsg] = useState<string | null>(null);
  const [ticketErrorMsg, setTicketErrorMsg] = useState<string | null>(null);

  // Formulario Nuevo Ticket
  const [formCategoria, setFormCategoria] = useState('ACADEMICA');
  const [formPrioridad, setFormPrioridad] = useState('MEDIA');
  const [formAsunto, setFormAsunto] = useState('');
  const [formMensaje, setFormMensaje] = useState('');
  const [submittingTicket, setSubmittingTicket] = useState(false);

  // Responder Ticket (Bedelía / Admin)
  const [selectedTicketToRespond, setSelectedTicketToRespond] = useState<any | null>(null);
  const [respuestaTexto, setRespuestaTexto] = useState('');
  const [respuestaEstado, setRespuestaEstado] = useState('RESPONDIDO');
  const [respondingTicket, setRespondingTicket] = useState(false);

  // Repositorio Documental
  const [documentos, setDocumentos] = useState<any[]>([]);
  const [loadingDocs, setLoadingDocs] = useState(false);

  // Buscador FAQ
  const [faqSearch, setFaqSearch] = useState('');

  useEffect(() => {
    if (mode === 'ayuda') {
      loadTickets();
      loadDocumentos();
    }
  }, [mode]);

  const loadTickets = async () => {
    setLoadingTickets(true);
    try {
      const res = await apiFetch('/api/support/tickets');
      if (res.ok) {
        const data = await safeJson(res);
        setTickets(data.tickets || []);
      }
    } catch {}
    setLoadingTickets(false);
  };

  const loadDocumentos = async () => {
    setLoadingDocs(true);
    try {
      const res = await apiFetch('/api/repository/documents');
      if (res.ok) {
        const data = await safeJson(res);
        setDocumentos(data.documentos || []);
      }
    } catch {}
    setLoadingDocs(false);
  };

  const handleCreateTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formAsunto.trim() || !formMensaje.trim()) {
      setTicketErrorMsg('Debe completar el asunto y la descripción de su consulta.');
      return;
    }

    setSubmittingTicket(true);
    setTicketErrorMsg(null);
    setTicketSuccessMsg(null);
    try {
      const res = await apiFetch('/api/support/tickets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          categoria: formCategoria,
          prioridad: formPrioridad,
          asunto: formAsunto.trim(),
          mensaje: formMensaje.trim(),
        }),
      });

      const data = await safeJson(res);
      if (!res.ok) throw new Error(data.error);

      setTicketSuccessMsg(data.message || 'Ticket registrado exitosamente.');
      setShowNewTicketModal(false);
      setFormAsunto('');
      setFormMensaje('');
      loadTickets();
    } catch (err: any) {
      setTicketErrorMsg(err.message || 'Error al enviar consulta.');
    } finally {
      setSubmittingTicket(false);
    }
  };

  const handleRespondTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTicketToRespond || !respuestaTexto.trim()) return;

    setRespondingTicket(true);
    try {
      const res = await apiFetch(`/api/support/tickets/${selectedTicketToRespond.id}/respond`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          respuesta: respuestaTexto.trim(),
          nuevoEstado: respuestaEstado,
        }),
      });

      const data = await safeJson(res);
      if (!res.ok) throw new Error(data.error);

      setTicketSuccessMsg(data.message || 'Ticket respondido.');
      setSelectedTicketToRespond(null);
      setRespuestaTexto('');
      loadTickets();
    } catch (err: any) {
      setTicketErrorMsg(err.message || 'Error al responder ticket.');
    } finally {
      setRespondingTicket(false);
    }
  };

  const handleDownloadDoc = (docId: string, nombreArchivo: string) => {
    window.open(`/api/repository/documents/${docId}/download`, '_blank');
  };

  // MODO: CONTACTO
  if (mode === 'contacto') {
    return (
      <div className="space-y-6">
        <div className="iov-card iov-card-destacada">
          <span className="badge-vigente mb-1 inline-block">Atención y Canales Institucionales</span>
          <h2 className="text-xl md:text-2xl font-black text-[var(--azul-900)]">
            Canales de Contacto Oficiales UCSF
          </h2>
          <p className="text-xs text-slate-600 mt-1 max-w-2xl">
            Sedes, secretarías académicas, aranceles y asistencia al estudiante universitario.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="iov-card space-y-3">
            <h3 className="text-sm font-bold text-[var(--azul-900)] uppercase tracking-wider border-b border-slate-100 pb-2">
              Sede Santa Fe (Campus San José)
            </h3>
            <div className="space-y-2 text-xs text-slate-700">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-[var(--celeste-500)] shrink-0 mt-0.5" />
                <span>Echagüe 7151, Ciudad de Santa Fe (C.P. 3000)</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-[var(--celeste-500)] shrink-0" />
                <span>+54 (0342) 460-3030 (Líneas rotativas)</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-[var(--celeste-500)] shrink-0" />
                <span>bedelia.santafe@ucsf.edu.ar</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-[var(--celeste-500)] shrink-0" />
                <span>Lunes a Viernes de 07:30 a 21:00 hs</span>
              </div>
            </div>
          </div>

          <div className="iov-card space-y-3">
            <h3 className="text-sm font-bold text-[var(--azul-900)] uppercase tracking-wider border-b border-slate-100 pb-2">
              Secretaría de Aranceles y Tesorería
            </h3>
            <div className="space-y-2 text-xs text-slate-700">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-[var(--celeste-500)] shrink-0 mt-0.5" />
                <span>Edificio Central, Planta Baja - Box 4</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-[var(--celeste-500)] shrink-0" />
                <span>Interno 118 / 119</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-[var(--celeste-500)] shrink-0" />
                <span>cobranzas@ucsf.edu.ar</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-[var(--celeste-500)] shrink-0" />
                <span>Atención presencial: 08:00 a 16:00 hs</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // MODO: AYUDA (Mesa de ayuda digital, FAQ y Repositorio Documental)
  const faqList = [
    {
      q: '¿Cómo me inscribo a comisiones de cursado?',
      a: 'Ingresa en la sección "Inscripción a comisiones" durante las fechas habilitadas. Selecciona la asignatura y turno deseado.',
      cat: 'Academica',
    },
    {
      q: '¿Cuál es el límite máximo de inasistencias?',
      a: 'Conforme al Art. 44 del Reglamento Académico, las inasistencias no pueden superar el 25% del total de clases programadas de la comisión.',
      cat: 'Reglamento',
    },
    {
      q: '¿Cómo solicito un certificado de alumno regular?',
      a: 'Dirígete a "Solicitud de certificados", completa el destino de presentación y el documento quedará emitido y validado digitalmente con código QR.',
      cat: 'Tramites',
    },
    {
      q: '¿Cuándo se acreditan los pagos de cuotas?',
      a: 'Los pagos vía débito automático o tarjeta se concilian en el acto. Las transferencias CBU demoran hasta 24 horas hábiles.',
      cat: 'Aranceles',
    },
    {
      q: '¿Cómo funciona la verificación pública de autenticidad?',
      a: 'Cualquier certificado o acta cuenta con un código alfanumérico único (ej. UCSF-CERT-2026-8841) y hash SHA-256 verificable en el portal sin login.',
      cat: 'Seguridad',
    },
  ].filter(
    (item) =>
      !faqSearch.trim() ||
      item.q.toLowerCase().includes(faqSearch.toLowerCase()) ||
      item.a.toLowerCase().includes(faqSearch.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Alertas */}
      {ticketSuccessMsg && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{ticketSuccessMsg}</span>
          </div>
          <button onClick={() => setTicketSuccessMsg(null)} className="font-bold text-xs hover:underline">
            Cerrar
          </button>
        </div>
      )}

      {ticketErrorMsg && (
        <div className="p-3.5 bg-red-50 border border-red-200 rounded-xl text-xs text-red-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
            <span>{ticketErrorMsg}</span>
          </div>
          <button onClick={() => setTicketErrorMsg(null)} className="font-bold text-xs hover:underline">
            Cerrar
          </button>
        </div>
      )}

      {/* Header Institucional */}
      <div className="iov-card iov-card-destacada">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <span className="badge-vigente mb-1 inline-block">Mesa de Ayuda & Repositorio</span>
            <h2 className="text-xl md:text-2xl font-black text-[var(--azul-900)] tracking-tight">
              Centro de Asistencia, Tickets y Documentación UCSF
            </h2>
            <p className="text-xs text-slate-600 mt-1 max-w-2xl">
              Respuestas oficiales, canal directo de tickets de soporte académico/arancelario y descarga de reglamentos homologados.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {userRole === 'ESTUDIANTE' && (
              <button
                onClick={() => setShowNewTicketModal(true)}
                className="btn-primary text-xs"
              >
                <MessageSquare className="w-4 h-4" />
                <span>+ Nueva Consulta / Ticket</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Selector de Pestañas */}
      <div className="flex items-center gap-2 border-b border-slate-200 overflow-x-auto pb-1 text-xs font-semibold">
        <button
          onClick={() => setActiveTab('FAQ')}
          className={`px-4 py-2 rounded-t-lg transition-colors flex items-center gap-2 ${
            activeTab === 'FAQ'
              ? 'bg-white border-t border-x border-slate-200 text-[var(--azul-700)] font-bold'
              : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <HelpCircle className="w-4 h-4" />
          <span>Preguntas Frecuentes (FAQ)</span>
        </button>

        <button
          onClick={() => setActiveTab('TICKETS')}
          className={`px-4 py-2 rounded-t-lg transition-colors flex items-center gap-2 ${
            activeTab === 'TICKETS'
              ? 'bg-white border-t border-x border-slate-200 text-[var(--azul-700)] font-bold'
              : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <Inbox className="w-4 h-4" />
          <span>Mesa de Tickets ({tickets.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('DOCUMENTOS')}
          className={`px-4 py-2 rounded-t-lg transition-colors flex items-center gap-2 ${
            activeTab === 'DOCUMENTOS'
              ? 'bg-white border-t border-x border-slate-200 text-[var(--azul-700)] font-bold'
              : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Repositorio de Normativas ({documentos.length})</span>
        </button>
      </div>

      {/* =========================================================================
          TAB 1: FAQ INTERACTIVO
          ========================================================================= */}
      {activeTab === 'FAQ' && (
        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Buscar en preguntas frecuentes (ej. inasistencias, cuotas, certificado)..."
              value={faqSearch}
              onChange={(e) => setFaqSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg outline-none bg-white focus:border-[var(--azul-700)]"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {faqList.map((item, idx) => (
              <div key={idx} className="iov-card space-y-2">
                <div className="flex items-center justify-between">
                  <span className="badge-actualizado text-[9px] uppercase font-bold">{item.cat}</span>
                </div>
                <h3 className="text-sm font-bold text-[var(--azul-900)] flex items-start gap-2">
                  <HelpCircle className="w-4 h-4 text-[var(--celeste-500)] shrink-0 mt-0.5" />
                  <span>{item.q}</span>
                </h3>
                <p className="text-xs text-slate-600 pl-6 leading-relaxed">
                  {item.a}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB 2: TICKETS DE SOPORTE Y MESA DE ENTRADAS
          ========================================================================= */}
      {activeTab === 'TICKETS' && (
        <div className="space-y-4">
          <div className="iov-card flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-bold text-[var(--azul-900)]">
                Bandeja de Consultas y Reclamos Académicos/Arancelarios
              </h3>
              <p className="text-xs text-slate-500">
                Trazabilidad oficial de pedidos con número correlativo y firma de la autoridad interviniente.
              </p>
            </div>
            {userRole === 'ESTUDIANTE' && (
              <button
                onClick={() => setShowNewTicketModal(true)}
                className="btn-primary text-xs"
              >
                + Nueva Consulta
              </button>
            )}
          </div>

          <div className="space-y-3">
            {tickets.map((t) => (
              <div key={t.id} className="iov-card space-y-3 border border-slate-200">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-xs text-[var(--azul-900)]">{t.numero_ticket}</span>
                    <span className="badge-actualizado text-[10px]">{t.categoria}</span>
                    <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded ${
                      t.prioridad === 'ALTA' || t.prioridad === 'URGENTE' ? 'bg-red-100 text-red-700' : 'bg-slate-100 text-slate-600'
                    }`}>
                      {t.prioridad}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] text-slate-400">{t.created_at}</span>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                      t.estado === 'RESPONDIDO' || t.estado === 'CERRADO'
                        ? 'badge-vigente'
                        : 'badge-provisorio'
                    }`}>
                      {t.estado}
                    </span>
                  </div>
                </div>

                <div>
                  <h4 className="text-sm font-bold text-slate-900">{t.asunto}</h4>
                  <p className="text-xs text-slate-600 mt-1">{t.mensaje}</p>
                </div>

                {t.respuesta && (
                  <div className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-xl text-xs space-y-1">
                    <div className="flex items-center justify-between text-emerald-800 font-bold">
                      <div className="flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Dictamen / Respuesta de {t.respondido_por}</span>
                      </div>
                      <span className="text-[10px] text-emerald-600">{t.fecha_respuesta}</span>
                    </div>
                    <p className="text-slate-700 text-xs pl-5">{t.respuesta}</p>
                  </div>
                )}

                {/* Acciones para Bedelía y Administración */}
                {(userRole === 'BEDELIA' || userRole === 'ADMINISTRACION') && t.estado !== 'CERRADO' && (
                  <div className="pt-2 border-t border-slate-100 flex justify-end">
                    <button
                      onClick={() => {
                        setSelectedTicketToRespond(t);
                        setRespuestaTexto(t.respuesta || '');
                      }}
                      className="btn-primary text-xs py-1 px-3"
                    >
                      {t.respuesta ? 'Modificar Respuesta' : 'Responder Ticket'}
                    </button>
                  </div>
                )}
              </div>
            ))}

            {tickets.length === 0 && (
              <div className="iov-card text-center py-8 text-xs text-slate-500">
                No hay tickets registrados en esta bandeja.
              </div>
            )}
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB 3: REPOSITORIO DE NORMATIVAS Y PROGRAMAS
          ========================================================================= */}
      {activeTab === 'DOCUMENTOS' && (
        <div className="space-y-4">
          <div className="iov-card">
            <h3 className="text-sm font-bold text-[var(--azul-900)] mb-1">
              Repositorio de Normativas, Reglamentos y Programas Homologados
            </h3>
            <p className="text-xs text-slate-500 mb-3">
              Documentos oficiales con firma electrónica institucional y verificación de integridad SHA-256.
            </p>

            <div className="table-container">
              <table className="iov-table">
                <thead>
                  <tr>
                    <th>Documento Oficial</th>
                    <th>Categoría</th>
                    <th>Tamaño</th>
                    <th>Hash SHA-256</th>
                    <th>Descarga</th>
                  </tr>
                </thead>
                <tbody>
                  {documentos.map((doc) => (
                    <tr key={doc.id}>
                      <td>
                        <div className="font-bold text-xs text-slate-800">{doc.titulo}</div>
                        <div className="font-mono text-[10px] text-slate-400">{doc.archivo_nombre}</div>
                      </td>
                      <td>
                        <span className="badge-actualizado text-[10px]">{doc.categoria}</span>
                      </td>
                      <td className="text-xs text-slate-600 font-mono">{doc.tamanio_kb} KB</td>
                      <td>
                        <div className="font-mono text-[9px] text-slate-400 truncate max-w-[120px]" title={doc.hash_sha256}>
                          {doc.hash_sha256.slice(0, 16)}...
                        </div>
                      </td>
                      <td>
                        <button
                          onClick={() => handleDownloadDoc(doc.id, doc.archivo_nombre)}
                          className="btn-secondary text-xs py-1 px-2.5 flex items-center gap-1.5"
                          title="Descargar documento oficial"
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span>Descargar</span>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Nuevo Ticket (Estudiante) */}
      {showNewTicketModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-[var(--azul-700)]" />
                <h3 className="text-sm font-bold text-[var(--azul-900)]">
                  Enviar Consulta a Mesa de Entradas
                </h3>
              </div>
              <button onClick={() => setShowNewTicketModal(false)} className="text-slate-400 hover:text-slate-700 font-bold">
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateTicket} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Categoría *</label>
                  <select
                    value={formCategoria}
                    onChange={(e) => setFormCategoria(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg outline-none bg-white"
                  >
                    <option value="ACADEMICA">Académica / Cursado</option>
                    <option value="ARANCELES">Aranceles y Pagos</option>
                    <option value="BEDELIA">Bedelía y Exámenes</option>
                    <option value="SOPORTE_TECNICO">Soporte Técnico / Portal</option>
                    <option value="TITULACION">Titulación y Grado</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Prioridad</label>
                  <select
                    value={formPrioridad}
                    onChange={(e) => setFormPrioridad(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg outline-none bg-white"
                  >
                    <option value="BAJA">Baja</option>
                    <option value="MEDIA">Media</option>
                    <option value="ALTA">Alta</option>
                    <option value="URGENTE">Urgente</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Asunto de la consulta *</label>
                <input
                  type="text"
                  placeholder="ej. Consulta sobre inscripción a mesa final de POO"
                  value={formAsunto}
                  onChange={(e) => setFormAsunto(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-lg outline-none"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Descripción detallada *</label>
                <textarea
                  rows={4}
                  placeholder="Escriba aquí los detalles de su pedido o inconveniente..."
                  value={formMensaje}
                  onChange={(e) => setFormMensaje(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-lg outline-none resize-none"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowNewTicketModal(false)}
                  className="btn-secondary text-xs py-2 px-4"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={submittingTicket}
                  className="btn-primary text-xs py-2 px-4"
                >
                  {submittingTicket ? 'Enviando...' : 'Registrar Ticket'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Responder Ticket (Bedelía / Admin) */}
      {selectedTicketToRespond && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-sm font-bold text-[var(--azul-900)]">
                  Dictamen / Respuesta Oficial: {selectedTicketToRespond.numero_ticket}
                </h3>
                <p className="text-[11px] text-slate-500 font-medium mt-0.5">
                  Estudiante: {selectedTicketToRespond.estudiante_nombre}
                </p>
              </div>
              <button onClick={() => setSelectedTicketToRespond(null)} className="text-slate-400 hover:text-slate-700 font-bold">
                ✕
              </button>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl text-xs space-y-1">
              <div className="font-bold text-slate-800">{selectedTicketToRespond.asunto}</div>
              <p className="text-slate-600">{selectedTicketToRespond.mensaje}</p>
            </div>

            <form onSubmit={handleRespondTicket} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Respuesta Oficial Institucional *</label>
                <textarea
                  rows={4}
                  placeholder="Redacte la respuesta o resolución oficial para el estudiante..."
                  value={respuestaTexto}
                  onChange={(e) => setRespuestaTexto(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-lg outline-none resize-none"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Nuevo Estado del Ticket</label>
                <select
                  value={respuestaEstado}
                  onChange={(e) => setRespuestaEstado(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-lg outline-none bg-white"
                >
                  <option value="RESPONDIDO">RESPONDIDO (Abierto a réplica)</option>
                  <option value="CERRADO">CERRADO (Trámite finalizado)</option>
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setSelectedTicketToRespond(null)}
                  className="btn-secondary text-xs py-2 px-4"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={respondingTicket}
                  className="btn-primary text-xs py-2 px-4"
                >
                  {respondingTicket ? 'Guardando...' : 'Asentar Dictamen'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
