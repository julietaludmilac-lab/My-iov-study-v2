import React, { useState, useEffect } from 'react';
import {
  Home,
  Clock,
  Calendar,
  Bell,
  Menu,
  X,
  Search,
  BookOpen,
  GraduationCap,
  FileText,
  CreditCard,
  User,
  Shield,
  HelpCircle,
  LogOut,
  ChevronRight,
  Layers,
  Award,
  ChevronDown,
  Sparkles,
} from 'lucide-react';
import { APP_ROUTES, RouteDefinition, UserRole } from '../routesRegistry';

interface ShellProps {
  currentHash: string;
  onNavigate: (hash: string) => void;
  currentUser: {
    matricula: string;
    nombre: string;
    rol: UserRole;
    carrera?: string;
  };
  unreadNotificationsCount?: number;
  onLogout?: () => void;
  onRoleSwitch?: (role: UserRole) => void;
  children: React.ReactNode;
}

export const Shell: React.FC<ShellProps> = ({
  currentHash,
  onNavigate,
  currentUser,
  unreadNotificationsCount = 2,
  onLogout,
  onRoleSwitch,
  children,
}) => {
  const [mobileDrawerOpen, setMobileDrawerOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [openGroups, setOpenGroups] = useState<Record<string, boolean>>({
    Principal: true,
    Académico: true,
    Comisiones: true,
    Exámenes: true,
    Aranceles: true,
    Trámites: true,
    Bedelía: true,
    Administración: true,
    Usuario: true,
    Sistema: true,
  });

  // Cerrar drawer al cambiar de hash
  useEffect(() => {
    setMobileDrawerOpen(false);
  }, [currentHash]);

  const toggleGroup = (group: string) => {
    setOpenGroups((prev) => ({ ...prev, [group]: !prev[group] }));
  };

  // Filtrar rutas permitidas para el rol
  const allowedRoutes = APP_ROUTES.filter(
    (r) => r.inMenu && r.roles.includes(currentUser.rol)
  );

  // Búsqueda rápida
  const filteredRoutes = searchQuery.trim()
    ? allowedRoutes.filter(
        (r) =>
          r.label.toLowerCase().includes(searchQuery.toLowerCase()) ||
          r.description.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : allowedRoutes;

  // Agrupar rutas
  const groupedRoutes = filteredRoutes.reduce((acc, route) => {
    if (!acc[route.group]) acc[route.group] = [];
    acc[route.group].push(route);
    return acc;
  }, {} as Record<string, RouteDefinition[]>);

  const currentRouteDef = APP_ROUTES.find((r) => r.hash === currentHash);

  return (
    <div className="min-h-screen bg-[var(--neutro-100)] text-[var(--neutro-900)] flex flex-col antialiased">
      {/* =========================================================================
          Top Bar Institucional (Móvil y Escritorio)
          ========================================================================= */}
      <header className="sticky top-0 z-40 iov-header-gradient shadow-md px-4 py-2.5 flex items-center justify-between gap-4">
        {/* Marca y Logo */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigate('inicio')}
            className="flex items-center gap-2.5 text-left text-white no-underline focus:outline-none"
            title="Ir a Inicio"
          >
            <div className="w-9 h-9 rounded-xl bg-white/15 border border-white/20 flex items-center justify-center font-black text-white text-base tracking-wider shadow-inner">
              IOV
            </div>
            <div>
              <div className="font-bold text-base tracking-tight leading-tight flex items-center gap-1.5">
                My IOV Study
                <span className="text-[10px] font-semibold bg-white/20 text-white px-1.5 py-0.2 rounded-md">
                  v2
                </span>
              </div>
              <div className="text-[11px] text-white/80 leading-tight">
                Autogestión UCSF (Demostración)
              </div>
            </div>
          </button>
        </div>

        {/* Buscador de secciones (Escritorio) */}
        <div className="hidden lg:flex items-center flex-1 max-w-md mx-4">
          <div className="relative w-full">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/60" />
            <input
              type="text"
              placeholder="Buscar sección o trámite (ej. Horarios, Cuotas)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white/15 text-white placeholder-white/60 border border-white/25 rounded-lg pl-9 pr-3 py-1.5 text-xs focus:bg-white focus:text-slate-900 focus:placeholder-slate-400 focus:outline-none transition-all"
            />
          </div>
        </div>

        {/* Acciones de usuario */}
        <div className="flex items-center gap-2">
          {/* Botón de Notificaciones */}
          <button
            onClick={() => onNavigate('notificaciones')}
            className="relative p-2 rounded-lg text-white hover:bg-white/15 transition-colors"
            title="Ver notificaciones"
            aria-label="Notificaciones"
          >
            <Bell className="w-5 h-5" />
            {unreadNotificationsCount > 0 && (
              <span className="absolute top-1 right-1 bg-[var(--rojo-600)] text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center border border-white">
                {unreadNotificationsCount}
              </span>
            )}
          </button>

          {/* Perfil Usuario (Escritorio) y Cerrar Sesión */}
          <div className="hidden md:flex items-center gap-2.5 pl-2 border-l border-white/20">
            <div className="text-right">
              <div className="text-xs font-bold text-white leading-tight">
                {currentUser.nombre}
              </div>
              <div className="text-[10px] text-white/75 font-mono leading-tight">
                {currentUser.matricula} · <span className="font-semibold text-white">{currentUser.rol}</span>
              </div>
            </div>
            <div className="w-8 h-8 rounded-full bg-white text-[var(--azul-900)] font-bold flex items-center justify-center text-xs shadow-xs">
              {currentUser.nombre.charAt(0)}
            </div>
            {onLogout && (
              <button
                onClick={onLogout}
                className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/15 transition-colors ml-1"
                title="Cerrar sesión e ir al login"
                aria-label="Cerrar sesión"
              >
                <LogOut className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Menú Móvil Trigger (Hamburguesa) */}
          <button
            onClick={() => setMobileDrawerOpen(true)}
            className="lg:hidden p-2 rounded-lg text-white hover:bg-white/15 transition-colors"
            aria-label="Abrir menú"
          >
            <Menu className="w-6 h-6" />
          </button>
        </div>
      </header>

      {/* =========================================================================
          Cuerpo Principal: Sidebar Escritorio + Contenido Dinámico
          ========================================================================= */}
      <div className="flex-1 flex max-w-[1600px] w-full mx-auto">
        {/* Sidebar Fijo de Escritorio */}
        <aside className="hidden lg:block w-72 bg-white border-r border-[var(--borde-suave)] p-4 shrink-0 overflow-y-auto max-h-[calc(100vh-60px)] sticky top-[57px]">
          <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-3 px-2">
            Navegación Autogestión
          </div>

          <div className="space-y-4">
            {Object.entries(groupedRoutes).map(([group, routes]) => (
              <div key={group} className="border-b border-slate-100 pb-3 last:border-none">
                <button
                  onClick={() => toggleGroup(group)}
                  className="w-full flex items-center justify-between text-xs font-bold text-[var(--azul-900)] py-1.5 px-2 rounded-md hover:bg-slate-50 transition-colors"
                >
                  <span>{group}</span>
                  <ChevronDown
                    className={`w-3.5 h-3.5 text-slate-400 transition-transform ${
                      openGroups[group] ? '' : '-rotate-90'
                    }`}
                  />
                </button>

                {openGroups[group] && (
                  <div className="mt-1 space-y-0.5">
                    {routes.map((route) => {
                      const isActive =
                        currentHash === route.hash ||
                        (route.hash === 'calendario' && currentHash === 'agenda');
                      return (
                        <button
                          key={route.hash}
                          onClick={() => onNavigate(route.hash)}
                          className={`w-full text-left px-3 py-2 rounded-lg text-xs font-medium transition-colors flex items-center justify-between ${
                            isActive
                              ? 'bg-[var(--celeste-100)] text-[var(--azul-900)] font-bold border-l-3 border-[var(--azul-700)]'
                              : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                          }`}
                        >
                          <span className="truncate">{route.label}</span>
                          {isActive && (
                            <ChevronRight className="w-3 h-3 text-[var(--azul-700)] shrink-0" />
                          )}
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Enlaces de pie de barra */}
          <div className="mt-6 pt-4 border-t border-slate-200 text-xs text-slate-500 space-y-2">
            <button
              onClick={() => onNavigate('controlrutas')}
              className="w-full text-left px-2 py-1.5 rounded hover:bg-slate-100 text-[11px] font-semibold text-[var(--azul-700)] flex items-center gap-1.5"
            >
              <Shield className="w-3.5 h-3.5" />
              Control de Rutas (100% OK)
            </button>
            {onLogout && (
              <button
                onClick={onLogout}
                className="w-full text-left px-2 py-1.5 rounded hover:bg-red-50 text-[11px] font-semibold text-[var(--rojo-600)] flex items-center gap-1.5"
              >
                <LogOut className="w-3.5 h-3.5" />
                Cerrar Sesión
              </button>
            )}
          </div>
        </aside>

        {/* Contenido Central */}
        <main className="flex-1 p-4 md:p-6 lg:p-8 pb-24 lg:pb-8 min-w-0">
          {/* Barra superior de contexto / Breadcrumb */}
          <div className="flex items-center justify-between gap-3 mb-6 pb-3 border-b border-slate-200">
            <div>
              <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
                <button
                  onClick={() => onNavigate('inicio')}
                  className="hover:text-[var(--azul-900)] font-medium"
                >
                  Inicio
                </button>
                <span>/</span>
                <span className="font-semibold text-slate-700">
                  {currentRouteDef?.group || 'Sección'}
                </span>
                <span>/</span>
                <span className="text-[var(--azul-900)] font-bold">
                  {currentRouteDef?.label || currentHash}
                </span>
              </div>
              <h1 className="text-xl md:text-2xl font-black text-[var(--azul-900)] tracking-tight">
                {currentRouteDef?.label || 'Sección Académica'}
              </h1>
              {currentRouteDef?.description && (
                <p className="text-xs md:text-sm text-slate-600 mt-0.5">
                  {currentRouteDef.description}
                </p>
              )}
            </div>

            {/* Botón rápido Volver a Inicio si no está en inicio */}
            {currentHash !== 'inicio' && (
              <button
                onClick={() => onNavigate('inicio')}
                className="btn-secondary text-xs py-1.5 px-3"
              >
                <Home className="w-3.5 h-3.5" />
                <span>Volver a Inicio</span>
              </button>
            )}
          </div>

          {/* Renderizado del módulo hijo */}
          {children}
        </main>
      </div>

      {/* =========================================================================
          Barra Inferior Móvil Fija (5 Accesos Rápidos según Rol)
          ========================================================================= */}
      <nav className="lg:hidden mobile-bottom-bar" aria-label="Navegación móvil inferior">
        <button
          onClick={() => onNavigate('inicio')}
          className={`mobile-bottom-item ${currentHash === 'inicio' ? 'active font-bold' : ''}`}
        >
          <Home className="w-5 h-5 mb-0.5" />
          <span>Inicio</span>
        </button>

        {currentUser.rol === 'ESTUDIANTE' && (
          <>
            <button
              onClick={() => onNavigate('horarios')}
              className={`mobile-bottom-item ${currentHash === 'horarios' ? 'active font-bold' : ''}`}
            >
              <Clock className="w-5 h-5 mb-0.5" />
              <span>Horarios</span>
            </button>
            <button
              onClick={() => onNavigate('calendario')}
              className={`mobile-bottom-item ${currentHash === 'calendario' || currentHash === 'agenda' ? 'active font-bold' : ''}`}
            >
              <Calendar className="w-5 h-5 mb-0.5" />
              <span>Calendario</span>
            </button>
          </>
        )}

        {currentUser.rol === 'BEDELIA' && (
          <>
            <button
              onClick={() => onNavigate('admincomisiones')}
              className={`mobile-bottom-item ${currentHash === 'admincomisiones' ? 'active font-bold' : ''}`}
            >
              <Layers className="w-5 h-5 mb-0.5" />
              <span>Comisiones</span>
            </button>
            <button
              onClick={() => onNavigate('adminexamenes')}
              className={`mobile-bottom-item ${currentHash === 'adminexamenes' ? 'active font-bold' : ''}`}
            >
              <Award className="w-5 h-5 mb-0.5" />
              <span>Mesas</span>
            </button>
          </>
        )}

        {currentUser.rol === 'ADMINISTRACION' && (
          <>
            <button
              onClick={() => onNavigate('admincarreras')}
              className={`mobile-bottom-item ${currentHash === 'admincarreras' ? 'active font-bold' : ''}`}
            >
              <GraduationCap className="w-5 h-5 mb-0.5" />
              <span>Carreras</span>
            </button>
            <button
              onClick={() => onNavigate('adminusuarios')}
              className={`mobile-bottom-item ${currentHash === 'adminusuarios' ? 'active font-bold' : ''}`}
            >
              <User className="w-5 h-5 mb-0.5" />
              <span>Usuarios</span>
            </button>
          </>
        )}

        <button
          onClick={() => onNavigate(currentUser.rol === 'BEDELIA' ? 'gestionavisos' : 'avisos')}
          className={`mobile-bottom-item ${currentHash === 'avisos' || currentHash === 'gestionavisos' ? 'active font-bold' : ''}`}
        >
          <BookOpen className="w-5 h-5 mb-0.5" />
          <span>Avisos</span>
        </button>

        <button
          onClick={() => setMobileDrawerOpen(true)}
          className="mobile-bottom-item"
        >
          <Menu className="w-5 h-5 mb-0.5 text-slate-700" />
          <span className="text-slate-800">Menú</span>
        </button>
      </nav>

      {/* =========================================================================
          Drawer Móvil Completo (Menú Lateral Completo de Mi UCSF)
          ========================================================================= */}
      {mobileDrawerOpen && (
        <div className="fixed inset-0 z-50 flex">
          <div
            className="fixed inset-0 bg-black/50 backdrop-blur-xs transition-opacity"
            onClick={() => setMobileDrawerOpen(false)}
          />

          <div className="relative w-5/6 max-w-sm bg-white h-full shadow-2xl flex flex-col z-10">
            {/* Header del Drawer */}
            <div className="iov-header-gradient p-4 flex items-center justify-between text-white">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center font-bold text-sm">
                  IOV
                </div>
                <div>
                  <div className="font-bold text-sm">My IOV Study v2</div>
                  <div className="text-[11px] text-white/80">{currentUser.matricula}</div>
                </div>
              </div>
              <button
                onClick={() => setMobileDrawerOpen(false)}
                className="p-1 rounded-lg text-white hover:bg-white/20"
                aria-label="Cerrar menú"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Listado de Rutas por Grupo */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {Object.entries(groupedRoutes).map(([group, routes]) => (
                <div key={group} className="border-b border-slate-100 pb-2">
                  <div className="text-[11px] font-bold text-[var(--azul-900)] mb-1 px-1">
                    {group}
                  </div>
                  <div className="space-y-0.5">
                    {routes.map((route) => (
                      <button
                        key={route.hash}
                        onClick={() => {
                          onNavigate(route.hash);
                          setMobileDrawerOpen(false);
                        }}
                        className={`w-full text-left px-2.5 py-2 rounded-lg text-xs font-medium flex items-center justify-between ${
                          currentHash === route.hash
                            ? 'bg-[var(--celeste-100)] text-[var(--azul-900)] font-bold'
                            : 'text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        <span>{route.label}</span>
                        <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            {/* Pie del Drawer */}
            <div className="p-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between text-xs">
              <span className="text-slate-500 text-[11px]">UCSF Autogestión v2</span>
              {onLogout && (
                <button
                  onClick={onLogout}
                  className="text-[var(--rojo-600)] font-bold hover:underline flex items-center gap-1"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  Salir
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
