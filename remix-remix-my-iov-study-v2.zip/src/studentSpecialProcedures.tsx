import React, { useState, useEffect } from 'react';
import { apiFetch } from './apiClient';
import {
  CreditCard,
  HeartPulse,
  Award,
  FileCheck,
  Star,
  Plus,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Send,
  Building,
  User,
  Phone,
  ShieldCheck,
} from 'lucide-react';

export type SpecialProcedureSection = 'formapago' | 'fichasalud' | 'tav' | 'titulo' | 'encuestas';

export function StudentSpecialProceduresPage({ section }: { section: SpecialProcedureSection }) {
  // Estado para Medios de Pago
  const [paymentMethods, setPaymentMethods] = useState<any[]>([]);
  const [newPayType, setNewPayType] = useState('DEBITO_AUTOMATICO');
  const [newPayTitular, setNewPayTitular] = useState('Lucía Belén Gómez');
  const [newPayDetalle, setNewPayDetalle] = useState('');
  const [newPayCbu, setNewPayCbu] = useState('');
  const [showAddPayModal, setShowAddPayModal] = useState(false);

  // Estado para Ficha de Salud
  const [healthRecord, setHealthRecord] = useState<any>(null);
  const [editingHealth, setEditingHealth] = useState(false);
  const [healthForm, setHealthForm] = useState({
    grupo_sanguineo: '0+',
    obra_social: '',
    numero_afiliado: '',
    contacto_emergencia: '',
    telefono_emergencia: '',
    observaciones: '',
  });

  // Estado para Trámites Especiales (TAV y Título)
  const [procedures, setProcedures] = useState<any[]>([]);
  const [newProcTitulo, setNewProcTitulo] = useState('');
  const [newProcDesc, setNewProcDesc] = useState('');
  const [showAddProcModal, setShowAddProcModal] = useState(false);

  // Estado para Encuestas Docentes
  const [surveys, setSurveys] = useState<any[]>([]);
  const [activeSurvey, setActiveSurvey] = useState<any | null>(null);
  const [surveyRatings, setSurveyRatings] = useState({
    pedagogico: 5,
    puntualidad: 5,
    material: 5,
    comentarios: '',
  });

  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  const loadData = async () => {
    setLoading(true);
    try {
      if (section === 'formapago') {
        const res = await apiFetch('/api/student/payment-methods');
        if (res.ok) setPaymentMethods((await res.json()).methods || []);
      } else if (section === 'fichasalud') {
        const res = await apiFetch('/api/student/health-record');
        if (res.ok) {
          const d = await res.json();
          setHealthRecord(d.record);
          if (d.record) {
            setHealthForm({
              grupo_sanguineo: d.record.grupo_sanguineo || '0+',
              obra_social: d.record.obra_social || '',
              numero_afiliado: d.record.numero_afiliado || '',
              contacto_emergencia: d.record.contacto_emergencia || '',
              telefono_emergencia: d.record.telefono_emergencia || '',
              observaciones: d.record.observaciones || '',
            });
          }
        }
      } else if (section === 'tav' || section === 'titulo') {
        const res = await apiFetch('/api/student/special-procedures');
        if (res.ok) setProcedures((await res.json()).procedures || []);
      } else if (section === 'encuestas') {
        const res = await apiFetch('/api/student/surveys');
        if (res.ok) setSurveys((await res.json()).surveys || []);
      }
    } catch {
      setMessage({ type: 'err', text: 'Error al conectar con el servidor.' });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
    setMessage(null);
  }, [section]);

  // Manejador: Formas de pago
  const handleAddPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPayDetalle.trim()) return;

    try {
      const res = await apiFetch('/api/student/payment-methods', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tipo: newPayType,
          titular: newPayTitular,
          detalle: newPayDetalle,
          cbu_alias: newPayCbu,
        }),
      });
      if (res.ok) {
        setShowAddPayModal(false);
        setNewPayDetalle('');
        setNewPayCbu('');
        setMessage({ type: 'ok', text: 'Medio de pago registrado correctamente.' });
        loadData();
      }
    } catch {
      setMessage({ type: 'err', text: 'Error al registrar medio de pago.' });
    }
  };

  const handleDeletePayment = async (id: string) => {
    try {
      const res = await apiFetch(`/api/student/payment-methods/${id}`, { method: 'DELETE' });
      if (res.ok) {
        setMessage({ type: 'ok', text: 'Medio de pago eliminado.' });
        loadData();
      }
    } catch {
      setMessage({ type: 'err', text: 'Error al eliminar medio de pago.' });
    }
  };

  // Manejador: Ficha de salud
  const handleUpdateHealth = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await apiFetch('/api/student/health-record', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(healthForm),
      });
      if (res.ok) {
        setEditingHealth(false);
        setMessage({ type: 'ok', text: 'Ficha médica actualizada con éxito.' });
        loadData();
      }
    } catch {
      setMessage({ type: 'err', text: 'Error al actualizar ficha de salud.' });
    }
  };

  // Manejador: Trámites Especiales
  const handleStartProcedure = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProcTitulo.trim()) return;

    try {
      const res = await apiFetch('/api/student/special-procedures', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tipo: section === 'tav' ? 'TAV' : 'TITULO',
          titulo: newProcTitulo,
          descripcion: newProcDesc,
          documentacion_adjunta: 'documento_solicitud.pdf',
        }),
      });
      if (res.ok) {
        setShowAddProcModal(false);
        setNewProcTitulo('');
        setNewProcDesc('');
        setMessage({ type: 'ok', text: 'Trámite presentado formalmente ante Secretaría Académica.' });
        loadData();
      }
    } catch {
      setMessage({ type: 'err', text: 'Error al iniciar trámite.' });
    }
  };

  // Manejador: Encuestas Docentes
  const handleSubmitSurvey = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeSurvey) return;

    try {
      const res = await apiFetch(`/api/student/surveys/${activeSurvey.id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          puntaje_pedagogico: surveyRatings.pedagogico,
          puntaje_puntualidad: surveyRatings.puntualidad,
          puntaje_material: surveyRatings.material,
          comentarios: surveyRatings.comentarios,
        }),
      });
      if (res.ok) {
        setActiveSurvey(null);
        setMessage({ type: 'ok', text: 'Encuesta docente remitida anónimamente.' });
        loadData();
      }
    } catch {
      setMessage({ type: 'err', text: 'Error al enviar encuesta.' });
    }
  };

  return (
    <div className="space-y-6">
      {/* 1. SECCIÓN: FORMA DE PAGO */}
      {section === 'formapago' && (
        <div className="space-y-4">
          <div className="iov-card iov-card-destacada">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <span className="badge-vigente mb-1 inline-block">Tesorería y Cobranzas</span>
                <h2 className="text-xl md:text-2xl font-black text-[var(--azul-900)]">
                  Configuración de Medios de Pago Habituales
                </h2>
                <p className="text-xs text-slate-600 mt-1">
                  Administra tus cuentas bancarias, tarjetas y adhesiones a débito automático para el cobro de aranceles mensuales.
                </p>
              </div>

              <button
                onClick={() => setShowAddPayModal(true)}
                className="btn-primary text-xs shrink-0"
              >
                <Plus className="w-4 h-4" />
                <span>Adherir Nuevo Medio</span>
              </button>
            </div>
          </div>

          {message && (
            <div className={`p-3 rounded-lg text-xs font-semibold ${message.type === 'ok' ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' : 'bg-red-50 text-red-800 border border-red-200'}`}>
              {message.text}
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {paymentMethods.map((pm) => (
              <div key={pm.id} className="iov-card flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-start mb-2">
                    <span className="badge-actualizado text-[10px]">{pm.tipo.replace('_', ' ')}</span>
                    <span className="badge-pagada text-[10px]">{pm.estado}</span>
                  </div>
                  <h4 className="text-sm font-bold text-[var(--azul-900)]">{pm.detalle}</h4>
                  <div className="text-xs text-slate-600 mt-1">Titular: <strong>{pm.titular}</strong></div>
                  {pm.cbu_alias && (
                    <div className="text-[11px] font-mono text-slate-500 mt-1">Alias / CBU: {pm.cbu_alias}</div>
                  )}
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 flex justify-end">
                  <button
                    onClick={() => handleDeletePayment(pm.id)}
                    className="text-xs text-red-600 hover:underline flex items-center gap-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Eliminar Adhesión</span>
                  </button>
                </div>
              </div>
            ))}
          </div>

          {showAddPayModal && (
            <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
              <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
                <h3 className="text-base font-bold text-[var(--azul-900)] mb-3">
                  Adherir Medio de Pago
                </h3>
                <form onSubmit={handleAddPayment} className="space-y-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Tipo de Instrumento</label>
                    <select
                      value={newPayType}
                      onChange={(e) => setNewPayType(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 text-xs text-slate-800"
                    >
                      <option value="DEBITO_AUTOMATICO">Débito Automático en Cuenta Bancaria</option>
                      <option value="TARJETA_CREDITO">Tarjeta de Crédito / Débito</option>
                      <option value="TRANSFERENCIA_CBU">Transferencia Inmediata (CBU/CVU)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Titular de la Cuenta</label>
                    <input
                      type="text"
                      required
                      value={newPayTitular}
                      onChange={(e) => setNewPayTitular(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 text-xs text-slate-800"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Descripción / Entidad</label>
                    <input
                      type="text"
                      required
                      placeholder="Ej: Banco Galicia · Caja de Ahorro"
                      value={newPayDetalle}
                      onChange={(e) => setNewPayDetalle(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 text-xs text-slate-800"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Alias / CBU (Opcional)</label>
                    <input
                      type="text"
                      placeholder="Ej: MI.ALIAS.BANCO"
                      value={newPayCbu}
                      onChange={(e) => setNewPayCbu(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 text-xs text-slate-800"
                    />
                  </div>
                  <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                    <button type="button" onClick={() => setShowAddPayModal(false)} className="btn-secondary text-xs">Cancelar</button>
                    <button type="submit" className="btn-primary text-xs">Guardar Medio</button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 2. SECCIÓN: FICHA DE SALUD */}
      {section === 'fichasalud' && (
        <div className="space-y-4">
          <div className="iov-card iov-card-destacada">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <span className="badge-vigente mb-1 inline-block">Servicio Médico Estudiantil</span>
                <h2 className="text-xl md:text-2xl font-black text-[var(--azul-900)]">
                  Ficha Médica y Antecedentes de Salud
                </h2>
                <p className="text-xs text-slate-600 mt-1">
                  Registro confidencial obligatorio para actividades deportivas, prácticas de laboratorio y emergencias sanitarias en campus.
                </p>
              </div>

              <button
                onClick={() => setEditingHealth(!editingHealth)}
                className="btn-primary text-xs shrink-0"
              >
                {editingHealth ? 'Cancelar Edición' : 'Actualizar Ficha'}
              </button>
            </div>
          </div>

          {message && (
            <div className={`p-3 rounded-lg text-xs font-semibold ${message.type === 'ok' ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' : 'bg-red-50 text-red-800 border border-red-200'}`}>
              {message.text}
            </div>
          )}

          {editingHealth ? (
            <div className="iov-card">
              <form onSubmit={handleUpdateHealth} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Grupo Sanguíneo y Factor</label>
                    <input
                      type="text"
                      required
                      value={healthForm.grupo_sanguineo}
                      onChange={(e) => setHealthForm({ ...healthForm, grupo_sanguineo: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 text-xs text-slate-800"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Obra Social / Prepaga</label>
                    <input
                      type="text"
                      required
                      value={healthForm.obra_social}
                      onChange={(e) => setHealthForm({ ...healthForm, obra_social: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 text-xs text-slate-800"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Número de Afiliado</label>
                    <input
                      type="text"
                      required
                      value={healthForm.numero_afiliado}
                      onChange={(e) => setHealthForm({ ...healthForm, numero_afiliado: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 text-xs text-slate-800"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Contacto de Emergencia</label>
                    <input
                      type="text"
                      required
                      value={healthForm.contacto_emergencia}
                      onChange={(e) => setHealthForm({ ...healthForm, contacto_emergencia: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 text-xs text-slate-800"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Teléfono de Emergencia</label>
                    <input
                      type="text"
                      required
                      value={healthForm.telefono_emergencia}
                      onChange={(e) => setHealthForm({ ...healthForm, telefono_emergencia: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 text-xs text-slate-800"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Observaciones Médicas / Alergias</label>
                  <textarea
                    rows={3}
                    value={healthForm.observaciones}
                    onChange={(e) => setHealthForm({ ...healthForm, observaciones: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 text-xs text-slate-800"
                  />
                </div>

                <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                  <button type="button" onClick={() => setEditingHealth(false)} className="btn-secondary text-xs">Cancelar</button>
                  <button type="submit" className="btn-primary text-xs">Guardar Cambios Médicos</button>
                </div>
              </form>
            </div>
          ) : (
            <div className="iov-card">
              <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <HeartPulse className="w-5 h-5 text-red-600" />
                  <h3 className="text-base font-bold text-[var(--azul-900)]">Estado de Ficha Médica</h3>
                </div>
                <span className="badge-pagada text-xs">APTO FÍSICO VIGENTE</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs mb-4">
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                  <span className="text-slate-500 font-medium">Grupo Sanguíneo:</span>
                  <div className="text-base font-black text-red-700 mt-0.5">{healthRecord?.grupo_sanguineo || '0+'}</div>
                </div>
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                  <span className="text-slate-500 font-medium">Cobertura Médica:</span>
                  <div className="text-sm font-bold text-slate-800 mt-0.5">{healthRecord?.obra_social || 'OSDE'}</div>
                  <div className="text-[11px] text-slate-500">{healthRecord?.numero_afiliado}</div>
                </div>
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                  <span className="text-slate-500 font-medium">Contacto de Emergencia:</span>
                  <div className="text-sm font-bold text-slate-800 mt-0.5">{healthRecord?.contacto_emergencia}</div>
                  <div className="text-[11px] text-slate-500">{healthRecord?.telefono_emergencia}</div>
                </div>
              </div>

              {healthRecord?.observaciones && (
                <div className="p-3 bg-amber-50 rounded-xl border border-amber-200/60 text-xs text-amber-900">
                  <strong>Alergias o Condiciones Clínicas:</strong> {healthRecord.observaciones}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* 3. SECCIÓN: TAV (TRÁMITE ACADÉMICO VINCULADO) & TÍTULO */}
      {(section === 'tav' || section === 'titulo') && (
        <div className="space-y-4">
          <div className="iov-card iov-card-destacada">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <span className="badge-vigente mb-1 inline-block">Secretaría Académica</span>
                <h2 className="text-xl md:text-2xl font-black text-[var(--azul-900)]">
                  {section === 'tav' ? 'Trámite Académico Vinculado (TAV)' : 'Trámite de Colación y Título'}
                </h2>
                <p className="text-xs text-slate-600 mt-1">
                  {section === 'tav'
                    ? 'Reconocimiento de créditos extracurriculares, pasantías, congresos y equivalencias especiales.'
                    : 'Seguimiento de emisión de diploma universitario, control de libre deuda y verificación de actas.'}
                </p>
              </div>

              <button
                onClick={() => setShowAddProcModal(true)}
                className="btn-primary text-xs shrink-0"
              >
                <Plus className="w-4 h-4" />
                <span>Iniciar Nuevo Trámite</span>
              </button>
            </div>
          </div>

          {message && (
            <div className={`p-3 rounded-lg text-xs font-semibold ${message.type === 'ok' ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' : 'bg-red-50 text-red-800 border border-red-200'}`}>
              {message.text}
            </div>
          )}

          <div className="iov-card">
            <h3 className="text-base font-bold text-[var(--azul-900)] mb-3">
              Expedientes y Solicitudes en Curso ({procedures.filter((p) => p.tipo === (section === 'tav' ? 'TAV' : 'TITULO')).length})
            </h3>

            <div className="space-y-3">
              {procedures
                .filter((p) => p.tipo === (section === 'tav' ? 'TAV' : 'TITULO'))
                .map((pr) => (
                  <div key={pr.id} className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-xs">
                    <div className="flex justify-between items-start mb-1">
                      <span className="font-mono font-bold text-[var(--azul-700)]">{pr.id}</span>
                      <span className="badge-pagada text-[10px]">{pr.estado}</span>
                    </div>
                    <h4 className="text-sm font-bold text-slate-900">{pr.titulo}</h4>
                    <p className="text-slate-600 mt-1">{pr.descripcion}</p>
                    {pr.resolucion_numero && (
                      <div className="mt-2 text-[11px] font-semibold text-emerald-700">
                        Resolución Oficial: {pr.resolucion_numero}
                      </div>
                    )}
                  </div>
                ))}
            </div>
          </div>

          {showAddProcModal && (
            <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
              <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
                <h3 className="text-base font-bold text-[var(--azul-900)] mb-3">
                  Iniciar {section === 'tav' ? 'Trámite TAV' : 'Trámite de Título'}
                </h3>
                <form onSubmit={handleStartProcedure} className="space-y-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Objeto del Trámite</label>
                    <input
                      type="text"
                      required
                      placeholder="Ej: Acreditación de horas de congreso o solicitud de colación..."
                      value={newProcTitulo}
                      onChange={(e) => setNewProcTitulo(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 text-xs text-slate-800"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Fundamentación / Detalle</label>
                    <textarea
                      rows={3}
                      required
                      placeholder="Indica la resolución de referencia o documentación aportada..."
                      value={newProcDesc}
                      onChange={(e) => setNewProcDesc(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 text-xs text-slate-800"
                    />
                  </div>
                  <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                    <button type="button" onClick={() => setShowAddProcModal(false)} className="btn-secondary text-xs">Cancelar</button>
                    <button type="submit" className="btn-primary text-xs">Presentar Solicitud</button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 4. SECCIÓN: ENCUESTAS DOCENTES */}
      {section === 'encuestas' && (
        <div className="space-y-4">
          <div className="iov-card iov-card-destacada">
            <span className="badge-vigente mb-1 inline-block">Evaluación Institucional</span>
            <h2 className="text-xl md:text-2xl font-black text-[var(--azul-900)]">
              Encuestas de Opinión y Evaluación Docente
            </h2>
            <p className="text-xs text-slate-600 mt-1">
              Tu valoración anónima permite a la Universidad mejorar la calidad académica y pedagógica del cuerpo docente.
            </p>
          </div>

          {message && (
            <div className={`p-3 rounded-lg text-xs font-semibold ${message.type === 'ok' ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' : 'bg-red-50 text-red-800 border border-red-200'}`}>
              {message.text}
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {surveys.map((s) => (
              <div key={s.id} className="iov-card flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-start mb-2">
                    <span className="font-mono text-xs font-bold text-[var(--azul-700)]">{s.comision_id}</span>
                    <span className={s.completada ? 'badge-pagada text-[10px]' : 'badge-provisorio text-[10px]'}>
                      {s.completada ? 'RESPONDIDA' : 'PENDIENTE'}
                    </span>
                  </div>
                  <h4 className="text-base font-bold text-[var(--azul-900)]">{s.materia_nombre}</h4>
                  <div className="text-xs text-slate-600 mt-1">Docente Titular: <strong>{s.docente_nombre}</strong></div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 flex justify-end">
                  {s.completada ? (
                    <span className="text-xs text-emerald-700 font-semibold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Encuesta completada</span>
                    </span>
                  ) : (
                    <button
                      onClick={() => setActiveSurvey(s)}
                      className="btn-primary text-xs"
                    >
                      <Star className="w-3.5 h-3.5" />
                      <span>Responder Encuesta</span>
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>

          {activeSurvey && (
            <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
              <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
                <h3 className="text-base font-bold text-[var(--azul-900)] mb-1">
                  Evaluación Docente: {activeSurvey.materia_nombre}
                </h3>
                <p className="text-xs text-slate-500 mb-4">{activeSurvey.docente_nombre}</p>

                <form onSubmit={handleSubmitSurvey} className="space-y-4 text-xs">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">
                      Claridad pedagógica y dominio de contenidos (1 a 5 estrellas):
                    </label>
                    <div className="flex gap-2">
                      {[1, 2, 3, 4, 5].map((val) => (
                        <button
                          type="button"
                          key={val}
                          onClick={() => setSurveyRatings({ ...surveyRatings, pedagogico: val })}
                          className={`w-9 h-9 rounded-lg font-bold border ${surveyRatings.pedagogico >= val ? 'bg-amber-100 border-amber-400 text-amber-800' : 'bg-slate-50 border-slate-200 text-slate-600'}`}
                        >
                          {val}★
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">
                      Puntualidad y cumplimiento de horarios de cátedra:
                    </label>
                    <div className="flex gap-2">
                      {[1, 2, 3, 4, 5].map((val) => (
                        <button
                          type="button"
                          key={val}
                          onClick={() => setSurveyRatings({ ...surveyRatings, puntualidad: val })}
                          className={`w-9 h-9 rounded-lg font-bold border ${surveyRatings.puntualidad >= val ? 'bg-amber-100 border-amber-400 text-amber-800' : 'bg-slate-50 border-slate-200 text-slate-600'}`}
                        >
                          {val}★
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Comentarios sugeridos:</label>
                    <textarea
                      rows={2}
                      value={surveyRatings.comentarios}
                      onChange={(e) => setSurveyRatings({ ...surveyRatings, comentarios: e.target.value })}
                      placeholder="Aportes constructivos anónimos..."
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 text-xs text-slate-800"
                    />
                  </div>

                  <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                    <button type="button" onClick={() => setActiveSurvey(null)} className="btn-secondary text-xs">Cancelar</button>
                    <button type="submit" className="btn-primary text-xs">Enviar Encuesta</button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
