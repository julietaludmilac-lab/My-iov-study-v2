import React, { useState } from 'react';
import { KeyRound, Lock, CheckCircle, AlertCircle, ShieldCheck } from 'lucide-react';
import { apiFetch, safeJson } from './apiClient';

export const ChangePasswordPage: React.FC = () => {
  const [passwordActual, setPasswordActual] = useState('');
  const [passwordNueva, setPasswordNueva] = useState('');
  const [passwordConfirmacion, setPasswordConfirmacion] = useState('');
  const [saving, setSaving] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSuccessMsg(null);
    setErrorMsg(null);

    if (!passwordActual || !passwordNueva || !passwordConfirmacion) {
      setErrorMsg('Debe completar todos los campos requeridos.');
      return;
    }

    if (passwordNueva !== passwordConfirmacion) {
      setErrorMsg('La nueva contraseña y su confirmación no coinciden.');
      return;
    }

    if (passwordNueva.length < 8) {
      setErrorMsg('La nueva contraseña debe tener al menos 8 caracteres.');
      return;
    }

    setSaving(true);

    try {
      const res = await apiFetch('/api/auth/change-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          passwordActual,
          passwordNueva,
          passwordConfirmacion,
        }),
      });

      const data = await safeJson(res);
      if (!res.ok) throw new Error(data.error || 'No se pudo actualizar la contraseña.');

      setSuccessMsg('Contraseña actualizada exitosamente. Recuerde utilizarla en su próximo inicio de sesión.');
      setPasswordActual('');
      setPasswordNueva('');
      setPasswordConfirmacion('');
    } catch (err: any) {
      setErrorMsg(err.message || 'Error al actualizar contraseña.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-xl mx-auto space-y-6">
      {successMsg && (
        <div
          role="status"
          aria-live="polite"
          className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 flex items-center gap-2"
        >
          <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {errorMsg && (
        <div
          role="alert"
          aria-live="assertive"
          className="p-3.5 rounded-xl bg-[var(--rojo-100)] border border-red-200 text-xs text-[var(--rojo-600)] flex items-center gap-2"
        >
          <AlertCircle className="w-4 h-4 text-[var(--rojo-600)] shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      <div className="iov-card">
        <div className="flex items-center gap-2.5 mb-4 pb-3 border-b border-slate-100">
          <div className="w-8 h-8 rounded-lg bg-[var(--celeste-100)] text-[var(--azul-900)] flex items-center justify-center">
            <KeyRound className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-[var(--azul-900)]">
              Cambio Seguro de Contraseña
            </h3>
            <p className="text-[11px] text-slate-500">
              Proteja su cuenta actualizando periódicamente su clave de acceso.
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label
              htmlFor="pwd-actual"
              className="block text-xs font-semibold text-slate-700 mb-1"
            >
              Contraseña Actual *
            </label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                id="pwd-actual"
                type="password"
                value={passwordActual}
                onChange={(e) => setPasswordActual(e.target.value)}
                placeholder="Ingrese su contraseña actual"
                className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:border-[var(--azul-700)] outline-none"
              />
            </div>
          </div>

          <div>
            <label
              htmlFor="pwd-nueva"
              className="block text-xs font-semibold text-slate-700 mb-1"
            >
              Nueva Contraseña (mínimo 8 caracteres) *
            </label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                id="pwd-nueva"
                type="password"
                value={passwordNueva}
                onChange={(e) => setPasswordNueva(e.target.value)}
                placeholder="Ingrese su nueva clave"
                className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:border-[var(--azul-700)] outline-none"
              />
            </div>
          </div>

          <div>
            <label
              htmlFor="pwd-confirm"
              className="block text-xs font-semibold text-slate-700 mb-1"
            >
              Confirmar Nueva Contraseña *
            </label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                id="pwd-confirm"
                type="password"
                value={passwordConfirmacion}
                onChange={(e) => setPasswordConfirmacion(e.target.value)}
                placeholder="Repita la nueva clave para verificar"
                className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:border-[var(--azul-700)] outline-none"
              />
            </div>
          </div>

          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-[11px] text-slate-600 space-y-1">
            <div className="font-semibold text-slate-800 flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>Requisitos de seguridad:</span>
            </div>
            <div>• Longitud mínima de 8 caracteres.</div>
            <div>• Cifrado robusto con salt dinámico bcrypt.</div>
            <div>• Es obligatorio ingresar la contraseña actual para autorizar la modificación.</div>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              disabled={saving}
              className="w-full btn-primary text-xs py-2.5 font-bold"
            >
              {saving ? 'Validando y actualizando...' : 'Confirmar Cambio de Contraseña'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
