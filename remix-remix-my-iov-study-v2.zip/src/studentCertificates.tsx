import React, { useState, useEffect } from 'react';
import { apiFetch } from './apiClient';
import {
  FileCheck,
  Plus,
  Clock,
  CheckCircle2,
  AlertCircle,
  Building,
  RefreshCw,
  Printer,
  Download,
  QrCode,
  FileText,
  ShieldCheck,
  Eye,
  X,
} from 'lucide-react';

interface CertificateRequest {
  id: string;
  tipo_certificado: string;
  lugar_presentacion: string;
  observacion: string;
  estado: 'PENDIENTE' | 'EN_PROCESO' | 'EMITIDO' | 'RECHAZADO' | 'LISTA';
  created_at: string;
  responsable_nombre?: string;
}

export function StudentCertificatesPage({
  initialMode = 'SOLICITAR',
}: {
  initialMode?: 'SOLICITAR' | 'SEGUIMIENTO';
}) {
  const [activeTab, setActiveTab] = useState<'SOLICITAR' | 'SEGUIMIENTO'>(initialMode);
  const [requests, setRequests] = useState<CertificateRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [tipo, setTipo] = useState('ALUMNO_REGULAR');
  const [lugar, setLugar] = useState('Transporte Público / Beca');
  const [obs, setObs] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [previewCert, setPreviewCert] = useState<CertificateRequest | null>(null);
  const [generatedCert, setGeneratedCert] = useState<{
    codigo: string;
    tipo: string;
    fecha: string;
    lugar: string;
  } | null>(null);
  const [message, setMessage] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  useEffect(() => {
    setActiveTab(initialMode);
  }, [initialMode]);

  const loadRequests = async () => {
    setLoading(true);
    try {
      const res = await apiFetch('/api/academic/certificates');
      if (res.ok) {
        const d = await res.json();
        setRequests(d.solicitudes || []);
      }
    } catch {
      setMessage({ type: 'err', text: 'Error al cargar solicitudes.' });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadRequests();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!lugar.trim()) return;

    setSubmitting(true);
    setMessage(null);

    try {
      const res = await apiFetch('/api/academic/certificates/request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tipoCertificado: tipo,
          lugarPresentacion: lugar,
          observacion: obs,
        }),
      });

      const d = await res.json();
      if (res.ok) {
        setGeneratedCert({
          codigo: d.id || `CERT-${Date.now().toString(36).toUpperCase()}`,
          tipo,
          fecha: new Date().toLocaleDateString('es-AR'),
          lugar,
        });
        setMessage({ type: 'ok', text: 'Solicitud de certificado ingresada y generada con éxito.' });
        loadRequests();
      } else {
        setMessage({ type: 'err', text: d.message || 'Error al enviar solicitud.' });
      }
    } catch {
      setMessage({ type: 'err', text: 'Error de conexión.' });
    } finally {
      setSubmitting(false);
    }
  };

  const getStatusBadge = (estado: string) => {
    switch (estado) {
      case 'LISTA':
      case 'EMITIDO':
      case 'APROBADA':
        return <span className="badge-pagada text-[10px]">APROBADO Y FIRMADO</span>;
      case 'EN_PROCESO':
        return <span className="badge-vigente text-[10px]">EN PROCESO</span>;
      case 'RECHAZADA':
      case 'RECHAZADO':
        return <span className="badge-critico text-[10px]">RECHAZADA</span>;
      default:
        return <span className="badge-provisorio text-[10px]">RECIBIDA</span>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="iov-card iov-card-destacada">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="badge-vigente">Autogestión de Trámites</span>
              <span className="text-xs text-slate-500 font-medium">UCSF</span>
            </div>
            <h2 className="text-xl md:text-2xl font-black text-[var(--azul-900)] tracking-tight">
              {activeTab === 'SOLICITAR'
                ? 'Solicitud de Certificados Académicos'
                : 'Bandeja de Mis Solicitudes y Trámites'}
            </h2>
            <p className="text-xs md:text-sm text-slate-600 mt-1 max-w-2xl">
              {activeTab === 'SOLICITAR'
                ? 'Genere y solicite certificados de alumno regular, analíticos parciales y constancias oficiales con firma digital y código de validación QR.'
                : 'Seguimiento del estado de resolución de expedientes, certificados y trámites institucionales solicitados.'}
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={loadRequests}
              className="btn-secondary text-xs"
              disabled={loading}
              title="Recargar trámites"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              <span>Actualizar</span>
            </button>
          </div>
        </div>
      </div>

      {/* Selector de Pestaña */}
      <div className="flex border-b border-slate-200">
        <button
          onClick={() => setActiveTab('SOLICITAR')}
          className={`py-2 px-4 text-xs font-bold border-b-2 transition-colors ${
            activeTab === 'SOLICITAR'
              ? 'border-[var(--azul-700)] text-[var(--azul-900)]'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Plus className="w-3.5 h-3.5 inline mr-1" />
          Solicitar Nuevo Certificado
        </button>
        <button
          onClick={() => setActiveTab('SEGUIMIENTO')}
          className={`py-2 px-4 text-xs font-bold border-b-2 transition-colors ${
            activeTab === 'SEGUIMIENTO'
              ? 'border-[var(--azul-700)] text-[var(--azul-900)]'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Clock className="w-3.5 h-3.5 inline mr-1" />
          Mis Solicitudes ({requests.length})
        </button>
      </div>

      {message && (
        <div
          className={`p-3 rounded-lg text-xs font-semibold ${
            message.type === 'ok'
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-red-50 text-red-800 border border-red-200'
          }`}
        >
          {message.text}
        </div>
      )}

      {/* PESTAÑA: SOLICITAR CERTIFICADO */}
      {activeTab === 'SOLICITAR' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 iov-card space-y-4">
            <h3 className="text-base font-bold text-[var(--azul-900)]">
              Formulario de Emisión y Solicitud
            </h3>

            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Tipo de Certificado Requerido *
                </label>
                <select
                  value={tipo}
                  onChange={(e) => setTipo(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white"
                >
                  <option value="ALUMNO_REGULAR">Certificado de Alumno Regular</option>
                  <option value="ANALITICO_PARCIAL">Certificado Analítico Parcial de Materias Aprobadas</option>
                  <option value="EXAMEN_RENDIDO">Constancia de Examen Final Rendido</option>
                  <option value="CONSTANCIA_MATRICULA">Constancia de Matrícula Universitaria 2026</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Organismo / Entidad ante quien se presenta *
                </label>
                <input
                  type="text"
                  placeholder="ej. Empresa de Transporte / Beca Progresar / Obra Social"
                  value={lugar}
                  onChange={(e) => setLugar(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Observaciones o Aclaraciones Adicionales
                </label>
                <textarea
                  rows={2}
                  placeholder="ej. Solicito inclusión de promedio ponderado..."
                  value={obs}
                  onChange={(e) => setObs(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300"
                />
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  disabled={submitting}
                  className="btn-primary text-xs py-2 px-4"
                >
                  <FileCheck className="w-4 h-4" />
                  <span>{submitting ? 'Emitiendo solicitud...' : 'Confirmar y Solicitar Certificado'}</span>
                </button>
              </div>
            </form>
          </div>

          {/* Tarjeta de Verificación QR */}
          <div className="iov-card space-y-3 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 text-xs font-bold text-[var(--azul-900)] mb-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Validez y Firma Digital</span>
              </div>
              <p className="text-slate-600 text-xs">
                Los certificados emitidos por My IOV Study v2 cuentan con firma institucional y código QR que permite a cualquier autoridad verificar la autenticidad en tiempo real.
              </p>
            </div>

            {generatedCert ? (
              <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-center space-y-2">
                <div className="font-mono text-xs font-bold text-emerald-900">
                  {generatedCert.codigo}
                </div>
                <div className="text-[11px] text-emerald-700 font-semibold">
                  Certificado emitido con éxito
                </div>
                <div className="flex justify-center py-2">
                  <div className="p-2 bg-white rounded-lg border border-emerald-300 shadow-xs">
                    <QrCode className="w-16 h-16 text-emerald-800" />
                  </div>
                </div>
                <button
                  onClick={() => window.print()}
                  className="btn-primary text-xs w-full justify-center bg-emerald-700 hover:bg-emerald-800"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Imprimir / Descargar PDF</span>
                </button>
              </div>
            ) : (
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-center text-slate-400 text-xs">
                <FileText className="w-8 h-8 mx-auto mb-1 opacity-50" />
                <span>Complete el formulario para generar su comprobante.</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* PESTAÑA: SEGUIMIENTO DE MIS SOLICITUDES */}
      {activeTab === 'SEGUIMIENTO' && (
        <div className="iov-card">
          <div className="flex items-center justify-between mb-4 border-b border-slate-100 pb-3">
            <h3 className="text-base font-bold text-[var(--azul-900)]">
              Bandeja de Trámites Solicitados ({requests.length})
            </h3>
            <span className="text-xs text-slate-500">Historial del ciclo 2026</span>
          </div>

          {requests.length === 0 ? (
            <p className="text-xs text-slate-500 py-8 text-center">
              No tienes solicitudes de certificado registradas actualmente.
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 text-slate-600 uppercase font-bold text-[10px] border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-3">N° Expediente</th>
                    <th className="py-2.5 px-3">Certificado</th>
                    <th className="py-2.5 px-3">Organismo Destino</th>
                    <th className="py-2.5 px-3">Fecha Solicitud</th>
                    <th className="py-2.5 px-3">Estado</th>
                    <th className="py-2.5 px-3 text-right">Acción</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {requests.map((r) => (
                    <tr key={r.id} className="hover:bg-slate-50/50">
                      <td className="py-2.5 px-3 font-mono font-bold text-[var(--azul-700)]">
                        {r.id}
                      </td>
                      <td className="py-2.5 px-3 font-semibold text-slate-900">
                        {r.tipo_certificado.replace(/_/g, ' ')}
                      </td>
                      <td className="py-2.5 px-3 text-slate-600">
                        {r.lugar_presentacion}
                      </td>
                      <td className="py-2.5 px-3 text-slate-500 font-mono text-[11px]">
                        {new Date(r.created_at).toLocaleDateString('es-AR')}
                      </td>
                      <td className="py-2.5 px-3">
                        {getStatusBadge(r.estado)}
                      </td>
                      <td className="py-2.5 px-3 text-right">
                        <button
                          onClick={() => setPreviewCert(r)}
                          className="btn-secondary text-[11px] py-1 px-2.5"
                        >
                          <Eye className="w-3 h-3" />
                          <span>Ver</span>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Modal de Detalle */}
      {previewCert && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 text-xs">
            <div className="flex justify-between items-start mb-3 border-b border-slate-100 pb-2">
              <div>
                <h4 className="font-bold text-base text-[var(--azul-900)]">
                  Detalle del Trámite {previewCert.id}
                </h4>
                <div className="text-[11px] text-slate-500">Universidad Católica de Santa Fe</div>
              </div>
              <button onClick={() => setPreviewCert(null)} className="p-1 text-slate-400 hover:text-slate-700">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2 py-2">
              <div>
                <span className="font-bold text-slate-700">Tipo de Documento:</span>{' '}
                <span>{previewCert.tipo_certificado.replace(/_/g, ' ')}</span>
              </div>
              <div>
                <span className="font-bold text-slate-700">Organismo:</span>{' '}
                <span>{previewCert.lugar_presentacion}</span>
              </div>
              <div>
                <span className="font-bold text-slate-700">Estado Oficial:</span>{' '}
                {getStatusBadge(previewCert.estado)}
              </div>
              <div>
                <span className="font-bold text-slate-700">Fecha de Inicio:</span>{' '}
                <span>{new Date(previewCert.created_at).toLocaleString('es-AR')}</span>
              </div>
              {previewCert.observacion && (
                <div>
                  <span className="font-bold text-slate-700">Observación:</span>{' '}
                  <span className="text-slate-600">{previewCert.observacion}</span>
                </div>
              )}
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 mt-3">
              <button onClick={() => setPreviewCert(null)} className="btn-secondary text-xs">
                Cerrar
              </button>
              <button onClick={() => window.print()} className="btn-primary text-xs">
                <Printer className="w-3.5 h-3.5" />
                <span>Imprimir Constancia</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
