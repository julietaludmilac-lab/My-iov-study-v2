import React, { useState, useEffect } from 'react';
import { apiFetch } from './apiClient';
import {
  Calendar as CalendarIcon,
  Clock,
  Plus,
  Trash2,
  CheckCircle2,
  AlertCircle,
  Tag,
  RefreshCw,
  Filter,
} from 'lucide-react';

interface CalendarEvent {
  id: string;
  titulo: string;
  descripcion: string;
  tipo: 'FERIADO' | 'PARCIAL' | 'FINAL' | 'INSCRIPCION' | 'ACADEMICO' | 'ASUETO';
  fecha_inicio: string;
  fecha_fin: string;
  carrera_nombre?: string;
  fuente_nombre?: string;
}

interface AgendaItem {
  id: string;
  origen: string;
  referencia_id: string | null;
  titulo: string;
  fecha: string;
  hora: string;
  nota: string;
  color: 'ROJO' | 'AZUL' | 'VERDE' | 'AMARILLO';
}

interface StudentCalendarProps {
  initialTab?: 'CALENDARIO' | 'AGENDA';
}

export function StudentCalendarPage({ initialTab = 'CALENDARIO' }: StudentCalendarProps) {
  const [activeTab, setActiveTab] = useState<'CALENDARIO' | 'AGENDA'>(initialTab);
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [agendaItems, setAgendaItems] = useState<AgendaItem[]>([]);
  const [loading, setLoading] = useState(true);

  // Formulario de nuevo item en agenda
  const [showAddModal, setShowAddModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDate, setNewDate] = useState('2026-05-15');
  const [newTime, setNewTime] = useState('09:00');
  const [newNote, setNewNote] = useState('');
  const [newColor, setNewColor] = useState<'ROJO' | 'AZUL' | 'VERDE' | 'AMARILLO'>('AZUL');
  const [submitting, setSubmitting] = useState(false);
  const [msg, setMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [eventsRes, agendaRes] = await Promise.all([
        apiFetch('/api/academic/calendar'),
        apiFetch('/api/academic/agenda'),
      ]);

      if (eventsRes.ok) {
        const d = await eventsRes.json();
        setEvents(d.events || []);
      }
      if (agendaRes.ok) {
        const d = await agendaRes.json();
        setAgendaItems(d.items || []);
      }
    } catch {
      setMsg({ type: 'err', text: 'Error al sincronizar datos del calendario.' });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleCreateAgendaItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newDate) return;

    setSubmitting(true);
    try {
      const res = await apiFetch('/api/academic/agenda', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          titulo: newTitle,
          fecha: newDate,
          hora: newTime,
          nota: newNote,
          color: newColor,
        }),
      });

      if (res.ok) {
        setShowAddModal(false);
        setNewTitle('');
        setNewNote('');
        setMsg({ type: 'ok', text: '¡Recordatorio agregado a tu agenda!' });
        fetchData();
      } else {
        const err = await res.json();
        setMsg({ type: 'err', text: err.message || 'Error al guardar recordatorio' });
      }
    } catch {
      setMsg({ type: 'err', text: 'Error de conexión.' });
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteAgendaItem = async (id: string) => {
    try {
      const res = await apiFetch(`/api/academic/agenda/${id}`, {
        method: 'DELETE',
      });
      if (res.ok) {
        setAgendaItems((prev) => prev.filter((i) => i.id !== id));
      }
    } catch {
      setMsg({ type: 'err', text: 'Error al eliminar el elemento.' });
    }
  };

  const getBadgeForType = (tipo: string) => {
    switch (tipo) {
      case 'FERIADO':
        return <span className="badge-vencido text-[10px]">FERIADO</span>;
      case 'PARCIAL':
        return <span className="badge-critico text-[10px]">PARCIALES</span>;
      case 'FINAL':
        return <span className="badge-vigente text-[10px]">FINALES</span>;
      case 'INSCRIPCION':
        return <span className="badge-actualizado text-[10px]">INSCRIPCIÓN</span>;
      case 'ASUETO':
        return <span className="badge-provisorio text-[10px]">ASUETO</span>;
      default:
        return <span className="badge-vigente text-[10px]">ACADÉMICO</span>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header institucional */}
      <div className="iov-card iov-card-destacada">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="badge-vigente">Calendario Unificado</span>
              <span className="text-xs text-slate-500 font-medium">Ciclo Lectivo 2026</span>
            </div>
            <h2 className="text-xl md:text-2xl font-black text-[var(--azul-900)] tracking-tight">
              Calendario Académico & Mi Agenda
            </h2>
            <p className="text-xs md:text-sm text-slate-600 mt-1 max-w-2xl">
              Vista unificada con los feriados nacionales, semanas de parciales, turnos de examen final y tus recordatorios personales sincronizados.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => setShowAddModal(true)}
              className="btn-primary text-xs"
            >
              <Plus className="w-4 h-4" />
              <span>Nuevo Recordatorio</span>
            </button>
            <button
              onClick={fetchData}
              className="btn-secondary text-xs"
              disabled={loading}
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>

        {/* Pestañas de navegación interna */}
        <div className="flex items-center gap-2 mt-4 pt-3 border-t border-slate-200/70">
          <button
            onClick={() => setActiveTab('CALENDARIO')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-colors ${
              activeTab === 'CALENDARIO'
                ? 'bg-[var(--azul-700)] text-white shadow-sm'
                : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            Calendario Oficial UCSF ({events.length})
          </button>
          <button
            onClick={() => setActiveTab('AGENDA')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-colors ${
              activeTab === 'AGENDA'
                ? 'bg-[var(--azul-700)] text-white shadow-sm'
                : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            Mi Agenda Personal ({agendaItems.length})
          </button>
        </div>
      </div>

      {msg && (
        <div
          className={`p-3 rounded-lg text-xs font-medium ${
            msg.type === 'ok'
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-red-50 text-red-800 border border-red-200'
          }`}
        >
          {msg.text}
        </div>
      )}

      {/* PESTAÑA: CALENDARIO INSTITUCIONAL */}
      {activeTab === 'CALENDARIO' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {events.map((evt) => (
              <div key={evt.id} className="iov-card">
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div>
                    <h3 className="text-sm font-bold text-[var(--azul-900)]">
                      {evt.titulo}
                    </h3>
                    <div className="text-[11px] text-slate-500 mt-0.5">
                      {evt.carrera_nombre ? evt.carrera_nombre : 'Toda la Universidad'}
                    </div>
                  </div>
                  {getBadgeForType(evt.tipo)}
                </div>

                <p className="text-xs text-slate-600 mb-3">
                  {evt.descripcion}
                </p>

                <div className="flex items-center justify-between text-xs font-semibold text-slate-700 p-2.5 bg-slate-50 rounded-lg border border-slate-100">
                  <div className="flex items-center gap-1.5">
                    <CalendarIcon className="w-3.5 h-3.5 text-[var(--celeste-500)]" />
                    <span>
                      {evt.fecha_inicio === evt.fecha_fin
                        ? evt.fecha_inicio
                        : `${evt.fecha_inicio} al ${evt.fecha_fin}`}
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-500 font-normal">
                    Fuente: {evt.fuente_nombre || 'Bedelía UCSF'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* PESTAÑA: MI AGENDA PERSONAL */}
      {activeTab === 'AGENDA' && (
        <div className="space-y-4">
          {agendaItems.length === 0 ? (
            <div className="iov-card text-center py-12 text-slate-500 text-xs">
              No tienes recordatorios personales cargados todavía. Agrega uno con el botón superior.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {agendaItems.map((item) => (
                <div
                  key={item.id}
                  className={`iov-card relative border-l-4 ${
                    item.color === 'ROJO'
                      ? 'border-l-red-500'
                      : item.color === 'VERDE'
                      ? 'border-l-emerald-500'
                      : item.color === 'AMARILLO'
                      ? 'border-l-amber-500'
                      : 'border-l-[var(--celeste-500)]'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <h3 className="text-sm font-bold text-[var(--azul-900)]">
                      {item.titulo}
                    </h3>
                    <button
                      onClick={() => handleDeleteAgendaItem(item.id)}
                      className="text-slate-400 hover:text-red-600 p-1 rounded"
                      title="Eliminar recordatorio"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {item.nota && (
                    <p className="text-xs text-slate-600 mb-3 bg-slate-50 p-2 rounded border border-slate-100">
                      {item.nota}
                    </p>
                  )}

                  <div className="flex items-center justify-between text-[11px] font-semibold text-slate-500 pt-2 border-t border-slate-100">
                    <div className="flex items-center gap-1">
                      <CalendarIcon className="w-3 h-3 text-[var(--celeste-500)]" />
                      <span>{item.fecha}</span>
                    </div>
                    {item.hora && (
                      <div className="flex items-center gap-1">
                        <Clock className="w-3 h-3 text-slate-400" />
                        <span>{item.hora} hs</span>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Modal para agregar recordatorio */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-5 shadow-2xl border border-slate-200">
            <h3 className="text-base font-bold text-[var(--azul-900)] mb-3">
              Nuevo Recordatorio en Mi Agenda
            </h3>

            <form onSubmit={handleCreateAgendaItem} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Título o Actividad *
                </label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="Ej: Entrega de Trabajo Práctico 1"
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 text-xs text-slate-800 focus:outline-none focus:border-[var(--celeste-500)]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Fecha *
                  </label>
                  <input
                    type="date"
                    required
                    value={newDate}
                    onChange={(e) => setNewDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 text-xs text-slate-800 focus:outline-none focus:border-[var(--celeste-500)]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Hora
                  </label>
                  <input
                    type="time"
                    value={newTime}
                    onChange={(e) => setNewTime(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 text-xs text-slate-800 focus:outline-none focus:border-[var(--celeste-500)]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Notas adicionales
                </label>
                <textarea
                  rows={2}
                  value={newNote}
                  onChange={(e) => setNewNote(e.target.value)}
                  placeholder="Temas prioritarios, material o compañeros de grupo..."
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 text-xs text-slate-800 focus:outline-none focus:border-[var(--celeste-500)]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Color de etiqueta
                </label>
                <div className="flex gap-2">
                  {(['AZUL', 'ROJO', 'VERDE', 'AMARILLO'] as const).map((c) => (
                    <button
                      type="button"
                      key={c}
                      onClick={() => setNewColor(c)}
                      className={`px-2.5 py-1 text-xs rounded font-semibold border ${
                        newColor === c
                          ? 'border-slate-800 ring-2 ring-slate-400'
                          : 'border-slate-200 text-slate-600'
                      }`}
                    >
                      {c}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="btn-secondary text-xs"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="btn-primary text-xs"
                >
                  {submitting ? 'Guardando...' : 'Guardar en Agenda'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
