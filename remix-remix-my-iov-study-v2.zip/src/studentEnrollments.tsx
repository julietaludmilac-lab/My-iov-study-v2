import React, { useState, useEffect } from 'react';
import { apiFetch } from './apiClient';
import {
  Calendar,
  Clock,
  CheckCircle2,
  AlertTriangle,
  FileCheck,
  User,
  Users,
  MapPin,
  RefreshCw,
  XCircle,
  Award,
  Layers,
  BookOpen,
  ArrowRight,
} from 'lucide-react';

interface StudentEnrollmentsProps {
  mode: 'COMISIONES' | 'EXAMENES';
  subTab?: string;
  onNavigate?: (hash: string) => void;
}

export function StudentEnrollmentsPage({ mode, subTab, onNavigate }: StudentEnrollmentsProps) {
  const [exams, setExams] = useState<any[]>([]);
  const [studyPlan, setStudyPlan] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [enrollingId, setEnrollingId] = useState<string | null>(null);
  const [message, setMessage] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  // Pestaña activa según subTab
  const [currentSubTab, setCurrentSubTab] = useState<string>(subTab || (mode === 'COMISIONES' ? 'inscripcionescomisiones' : 'inscripcionesexamenes'));

  useEffect(() => {
    if (subTab) {
      setCurrentSubTab(subTab);
    } else {
      setCurrentSubTab(mode === 'COMISIONES' ? 'inscripcionescomisiones' : 'inscripcionesexamenes');
    }
  }, [subTab, mode]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [examsRes, planRes] = await Promise.all([
        apiFetch('/api/academic/exams'),
        apiFetch('/api/academic/study-plan'),
      ]);

      if (examsRes.ok) {
        const d = await examsRes.json();
        setExams(d.examenes || []);
      }
      if (planRes.ok) {
        setStudyPlan(await planRes.json());
      }
    } catch {
      setMessage({ type: 'err', text: 'Error al cargar inscripciones y mesas.' });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [mode]);

  const handleEnrollExam = async (examenId: string) => {
    setEnrollingId(examenId);
    setMessage(null);
    try {
      const res = await apiFetch('/api/academic/exams/enroll', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ examenId }),
      });

      const data = await res.json();
      if (res.ok) {
        setMessage({ type: 'ok', text: data.message || 'Inscripción confirmada con éxito.' });
        loadData();
      } else {
        setMessage({ type: 'err', text: data.message || 'No se pudo completar la inscripción.' });
      }
    } catch {
      setMessage({ type: 'err', text: 'Error de conexión.' });
    } finally {
      setEnrollingId(null);
    }
  };

  const handleWithdrawExam = async (examenId: string) => {
    setEnrollingId(examenId);
    setMessage(null);
    try {
      const res = await apiFetch(`/api/academic/exams/withdraw/${examenId}`, {
        method: 'DELETE',
      });
      const data = await res.json();
      if (res.ok) {
        setMessage({ type: 'ok', text: 'Inscripción dada de baja correctamente.' });
        loadData();
      } else {
        setMessage({ type: 'err', text: data.message || 'Error al anular inscripción.' });
      }
    } catch {
      setMessage({ type: 'err', text: 'Error de conexión.' });
    } finally {
      setEnrollingId(null);
    }
  };

  // Filtrado de comisiones desde studyPlan
  const comisionesActuales = (studyPlan?.materias || []).filter(
    (m: any) => m.estado === 'CURSANDO'
  );
  const comisionesCursadas = (studyPlan?.materias || []).filter(
    (m: any) => m.estado === 'APROBADA' || m.estado === 'REGULAR'
  );
  const comisionesFaltantes = (studyPlan?.materias || []).filter(
    (m: any) => m.estado === 'PENDIENTE'
  );

  // Filtrado de exámenes
  const examenesInscriptos = exams.filter((e) => e.inscripto);
  const examenesDisponibles = exams;

  const handleSelectTab = (tab: string) => {
    setCurrentSubTab(tab);
    onNavigate?.(tab);
  };

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="iov-card iov-card-destacada">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="badge-vigente">Autogestión de Cursadas</span>
              <span className="text-xs text-slate-500 font-medium">Ciclo 2026</span>
            </div>
            <h2 className="text-xl md:text-2xl font-black text-[var(--azul-900)] tracking-tight">
              {mode === 'COMISIONES' ? (
                currentSubTab === 'comisionesactuales' ? 'Comisiones Actuales en Curso' :
                currentSubTab === 'comisionescursadas' ? 'Historial de Materias Cursadas' :
                currentSubTab === 'comisionesfaltantes' ? 'Materias Pendientes de Cursar' :
                'Inscripción a Comisiones de Cursado'
              ) : (
                currentSubTab === 'examenesactuales' ? 'Mesas de Examen Inscriptas' :
                currentSubTab === 'examenesrendidos' ? 'Exámenes Finales Rendidos' :
                currentSubTab === 'examenesfaltantes' ? 'Materias Pendientes de Examen Final' :
                'Inscripción a Mesas de Examen Final'
              )}
            </h2>
            <p className="text-xs md:text-sm text-slate-600 mt-1 max-w-2xl">
              {mode === 'COMISIONES'
                ? 'Gestiona tus asignaturas regulares del 1er y 2do cuatrimestre, turnos y cupos habilitados por Bedelía.'
                : 'Turno especial y ordinario de exámenes finales con tribunales docentes y períodos de inscripción.'}
            </p>
          </div>

          <button
            onClick={loadData}
            className="btn-secondary text-xs shrink-0 self-start md:self-auto"
            disabled={loading}
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            <span>Actualizar</span>
          </button>
        </div>
      </div>

      {/* Pestañas de Navegación Específicas */}
      <div className="flex border-b border-slate-200 overflow-x-auto">
        {mode === 'COMISIONES' ? (
          <>
            <button
              onClick={() => handleSelectTab('inscripcionescomisiones')}
              className={`py-2 px-4 text-xs font-bold border-b-2 whitespace-nowrap transition-colors ${
                currentSubTab === 'inscripcionescomisiones'
                  ? 'border-[var(--azul-700)] text-[var(--azul-900)]'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              Inscripción a Comisiones
            </button>
            <button
              onClick={() => handleSelectTab('comisionesactuales')}
              className={`py-2 px-4 text-xs font-bold border-b-2 whitespace-nowrap transition-colors ${
                currentSubTab === 'comisionesactuales'
                  ? 'border-[var(--azul-700)] text-[var(--azul-900)]'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              Comisiones Actuales ({comisionesActuales.length})
            </button>
            <button
              onClick={() => handleSelectTab('comisionescursadas')}
              className={`py-2 px-4 text-xs font-bold border-b-2 whitespace-nowrap transition-colors ${
                currentSubTab === 'comisionescursadas'
                  ? 'border-[var(--azul-700)] text-[var(--azul-900)]'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              Materias Cursadas ({comisionesCursadas.length})
            </button>
            <button
              onClick={() => handleSelectTab('comisionesfaltantes')}
              className={`py-2 px-4 text-xs font-bold border-b-2 whitespace-nowrap transition-colors ${
                currentSubTab === 'comisionesfaltantes'
                  ? 'border-[var(--azul-700)] text-[var(--azul-900)]'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              Materias Pendientes ({comisionesFaltantes.length})
            </button>
          </>
        ) : (
          <>
            <button
              onClick={() => handleSelectTab('inscripcionesexamenes')}
              className={`py-2 px-4 text-xs font-bold border-b-2 whitespace-nowrap transition-colors ${
                currentSubTab === 'inscripcionesexamenes'
                  ? 'border-[var(--azul-700)] text-[var(--azul-900)]'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              Inscripción a Mesas
            </button>
            <button
              onClick={() => handleSelectTab('examenesactuales')}
              className={`py-2 px-4 text-xs font-bold border-b-2 whitespace-nowrap transition-colors ${
                currentSubTab === 'examenesactuales'
                  ? 'border-[var(--azul-700)] text-[var(--azul-900)]'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              Mesas Inscriptas ({examenesInscriptos.length})
            </button>
            <button
              onClick={() => handleSelectTab('examenesrendidos')}
              className={`py-2 px-4 text-xs font-bold border-b-2 whitespace-nowrap transition-colors ${
                currentSubTab === 'examenesrendidos'
                  ? 'border-[var(--azul-700)] text-[var(--azul-900)]'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              Exámenes Rendidos
            </button>
            <button
              onClick={() => handleSelectTab('examenesfaltantes')}
              className={`py-2 px-4 text-xs font-bold border-b-2 whitespace-nowrap transition-colors ${
                currentSubTab === 'examenesfaltantes'
                  ? 'border-[var(--azul-700)] text-[var(--azul-900)]'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              Exámenes Pendientes
            </button>
          </>
        )}
      </div>

      {message && (
        <div
          className={`p-3 rounded-lg text-xs font-semibold ${
            message.type === 'ok'
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-red-50 text-red-800 border border-red-200'
          }`}
        >
          {message.text}
        </div>
      )}

      {/* MODO: COMISIONES */}
      {mode === 'COMISIONES' && (
        <div className="space-y-5">
          {/* 1. Comisiones Actuales */}
          {(currentSubTab === 'comisionesactuales' || currentSubTab === 'inscripcionescomisiones') && (
            <div className="iov-card">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-base font-bold text-[var(--azul-900)]">
                  Comisiones en las que estás inscripto/a (Activas)
                </h3>
                <span className="badge-pagada text-xs font-semibold">
                  {comisionesActuales.length} Materias Cursando
                </span>
              </div>

              {comisionesActuales.length === 0 ? (
                <p className="text-xs text-slate-500 py-4">No tienes comisiones cursando actualmente.</p>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {comisionesActuales.map((m: any) => (
                    <div key={m.id} className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs">
                      <div className="flex justify-between items-start mb-1">
                        <span className="font-mono text-[11px] font-bold text-[var(--azul-700)]">
                          {m.codigo} · Comisión {m.cursandoComision || 'A'}
                        </span>
                        <span className="badge-vigente text-[10px]">CURSANDO</span>
                      </div>
                      <div className="font-bold text-slate-900 text-sm">{m.nombre}</div>
                      <div className="text-slate-500 text-[11px] mt-1">
                        Régimen: {m.regimen} · Carga: {m.carga_horaria} horas reloj
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* 2. Comisiones Cursadas */}
          {(currentSubTab === 'comisionescursadas' || currentSubTab === 'inscripcionescomisiones') && (
            <div className="iov-card">
              <h3 className="text-sm font-bold text-[var(--azul-900)] mb-3">
                Historial de Materias Cursadas y Aprobadas ({comisionesCursadas.length})
              </h3>
              <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
                {comisionesCursadas.map((m: any) => (
                  <div key={m.id} className="flex justify-between items-center text-xs p-2 rounded bg-slate-50 border border-slate-100">
                    <span className="font-medium text-slate-800">{m.nombre}</span>
                    <span className="badge-pagada text-[10px]">{m.estado}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 3. Comisiones Faltantes */}
          {(currentSubTab === 'comisionesfaltantes' || currentSubTab === 'inscripcionescomisiones') && (
            <div className="iov-card">
              <h3 className="text-sm font-bold text-[var(--azul-900)] mb-3">
                Asignaturas Pendientes del Plan ({comisionesFaltantes.length})
              </h3>
              <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
                {comisionesFaltantes.map((m: any) => (
                  <div key={m.id} className="flex justify-between items-center text-xs p-2 rounded bg-slate-50 border border-slate-100">
                    <span className="font-medium text-slate-700">{m.nombre}</span>
                    <span className="text-[10px] text-slate-400 font-mono">{m.anio_carrera}° Año</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* MODO: EXÁMENES */}
      {mode === 'EXAMENES' && (
        <div className="space-y-5">
          {/* Mesas Inscriptas */}
          {(currentSubTab === 'examenesactuales' || currentSubTab === 'inscripcionesexamenes') && examenesInscriptos.length > 0 && (
            <div className="iov-card iov-card-destacada">
              <h3 className="text-base font-bold text-[var(--azul-900)] mb-2">
                Tus Inscripciones Confirmadas a Exámenes Finales
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {examenesInscriptos.map((ex) => (
                  <div key={ex.id} className="p-3 bg-white rounded-xl border border-emerald-200 shadow-xs">
                    <div className="flex justify-between items-center mb-1">
                      <span className="font-mono text-xs font-bold text-[var(--azul-700)]">
                        {ex.materia_codigo}
                      </span>
                      <span className="badge-pagada text-[10px]">CONFIRMADA</span>
                    </div>
                    <div className="font-bold text-slate-900">{ex.materia_nombre}</div>
                    <div className="text-xs text-slate-600 mt-1">
                      Fecha: <strong>{ex.fecha}</strong> a las {ex.hora} hs · Aula: {ex.aula_nombre}
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5">
                      Tribunal: {ex.tribunal}
                    </div>
                    <div className="mt-2 pt-2 border-t border-slate-100 flex justify-end">
                      <button
                        onClick={() => handleWithdrawExam(ex.id)}
                        disabled={enrollingId === ex.id}
                        className="btn-danger text-xs py-1 px-2.5"
                      >
                        Anular Inscripción
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Todas las Mesas Disponibles */}
          {(currentSubTab === 'inscripcionesexamenes') && (
            <div className="iov-card">
              <h3 className="text-base font-bold text-[var(--azul-900)] mb-1">
                Mesas de Examen Habilitadas por Bedelía
              </h3>
              <p className="text-xs text-slate-600 mb-4">
                Recuerda que la inscripción cierra 48 horas hábiles antes de la fecha fijada.
              </p>

              <div className="space-y-3">
                {examenesDisponibles.map((ex) => (
                  <div key={ex.id} className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="badge-actualizado text-[10px]">{ex.turno_examen} · Llamado {ex.llamado}</span>
                        <span className="font-mono font-bold text-slate-700">{ex.materia_codigo}</span>
                      </div>
                      <h4 className="text-sm font-bold text-[var(--azul-900)]">{ex.materia_nombre}</h4>
                      <div className="text-slate-600 mt-1 flex flex-wrap gap-x-4 gap-y-0.5">
                        <span><strong>Fecha:</strong> {ex.fecha} ({ex.hora} hs)</span>
                        <span><strong>Aula:</strong> {ex.aula_nombre}</span>
                        <span><strong>Inscripción hasta:</strong> {ex.periodo_inscripcion_hasta}</span>
                      </div>
                      <div className="text-[11px] text-slate-500 mt-0.5 italic">
                        Tribunal: {ex.tribunal}
                      </div>
                    </div>

                    <div className="shrink-0 flex items-center gap-2">
                      {ex.inscripto ? (
                        <span className="badge-pagada text-xs py-1.5 px-3 inline-flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Inscripto/a</span>
                        </span>
                      ) : (
                        <button
                          onClick={() => handleEnrollExam(ex.id)}
                          disabled={enrollingId === ex.id}
                          className="btn-primary text-xs"
                        >
                          {enrollingId === ex.id ? 'Inscribiendo...' : 'Inscribirme al Examen'}
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Exámenes Rendidos */}
          {currentSubTab === 'examenesrendidos' && (
            <div className="iov-card">
              <h3 className="text-sm font-bold text-[var(--azul-900)] mb-2">
                Historial de Exámenes Finales Rendidos
              </h3>
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-600">
                Consulte sus actas de examen final y calificaciones acreditadas en la sección <strong>Calificaciones y Promedio</strong>.
              </div>
            </div>
          )}

          {/* Exámenes Pendientes */}
          {currentSubTab === 'examenesfaltantes' && (
            <div className="iov-card">
              <h3 className="text-sm font-bold text-[var(--azul-900)] mb-2">
                Materias Regularizadas Pendientes de Examen Final
              </h3>
              <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
                {comisionesCursadas.map((m: any) => (
                  <div key={m.id} className="flex justify-between items-center text-xs p-2 rounded bg-slate-50 border border-slate-100">
                    <span className="font-medium text-slate-800">{m.nombre}</span>
                    <span className="badge-vigente text-[10px]">PENDIENTE FINAL</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
