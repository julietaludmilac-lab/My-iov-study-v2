import React, { useState, useEffect } from 'react';
import { apiFetch } from './apiClient';
import {
  Building,
  GraduationCap,
  Users,
  Calendar,
  Clock,
  BookOpen,
  FileCheck,
  Download,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Plus,
  MapPin,
  Check,
  X,
  Layers,
  Edit2,
  Trash2,
  Lock,
  Unlock,
  UserCheck,
  ArrowRight,
  Award,
  AlertCircle,
  FileSpreadsheet,
  Search,
} from 'lucide-react';

interface BedeliaAcademicProps {
  viewMode: string;
  onNavigateToSection?: (hash: string) => void;
}

export function BedeliaAcademicPage({ viewMode, onNavigateToSection }: BedeliaAcademicProps) {
  const [carreras, setCarreras] = useState<any[]>([]);
  const [selectedCarreraId, setSelectedCarreraId] = useState<string>('');
  const [comisiones, setComisiones] = useState<any[]>([]);
  const [materiasDisponibles, setMateriasDisponibles] = useState<any[]>([]);
  const [examenes, setExamenes] = useState<any[]>([]);
  const [calendarEvents, setCalendarEvents] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  // Modal: Crear Comisión
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [createMateriaId, setCreateMateriaId] = useState('');
  const [createCodigoComision, setCreateCodigoComision] = useState('COM-A');
  const [createDocente, setCreateDocente] = useState('');
  const [createTurno, setCreateTurno] = useState('MANANA');
  const [createCupo, setCreateCupo] = useState(35);
  const [createDia, setCreateDia] = useState(1);
  const [createHoraInicio, setCreateHoraInicio] = useState('08:00');
  const [createHoraFin, setCreateHoraFin] = useState('11:00');
  const [createAula, setCreateAula] = useState('AULA-204');
  const [createObs, setCreateObs] = useState('');

  // Modal: Editar Comisión
  const [editingComision, setEditingComision] = useState<any | null>(null);

  // Modal: Reubicación Rápida de Aula
  const [reallocHorarioId, setReallocHorarioId] = useState<string | null>(null);
  const [reallocAula, setReallocAula] = useState('AULA-101');
  const [reallocObs, setReallocObs] = useState('');

  // Modal: Crear Mesa de Examen
  const [showExamModal, setShowExamModal] = useState(false);
  const [newExmMateriaId, setNewExmMateriaId] = useState('');
  const [newExmFecha, setNewExmFecha] = useState('2026-07-15');
  const [newExmHora, setNewExmHora] = useState('08:30');
  const [newExmTurno, setNewExmTurno] = useState('JULIO_AGOSTO_2026');
  const [newExmLlamado, setNewExmLlamado] = useState(1);
  const [newExmAula, setNewExmAula] = useState('AULA-204');
  const [newExmTribunal, setNewExmTribunal] = useState('');
  const [newExmDesde, setNewExmDesde] = useState('2026-06-01');
  const [newExmHasta, setNewExmHasta] = useState('2026-07-10');

  // Modal: Crear Evento Calendario
  const [showCalModal, setShowCalModal] = useState(false);
  const [newCalTitulo, setNewCalTitulo] = useState('');
  const [newCalDesc, setNewCalDesc] = useState('');
  const [newCalTipo, setNewCalTipo] = useState<'FERIADO' | 'ASUETO' | 'PARCIAL' | 'FINAL' | 'INSCRIPCION' | 'ACADEMICO'>('ACADEMICO');
  const [newCalInicio, setNewCalInicio] = useState('2026-05-25');
  const [newCalFin, setNewCalFin] = useState('2026-05-25');

  // Estado de Asistencia Supervisada
  const [selectedComisionForAttendance, setSelectedComisionForAttendance] = useState<string>('');
  const [attendanceData, setAttendanceData] = useState<any | null>(null);
  const [loadingAttendance, setLoadingAttendance] = useState(false);

  const loadData = async () => {
    setLoading(true);
    try {
      const [carrerasRes, comisionesRes, planRes, examRes, calRes] = await Promise.all([
        apiFetch('/api/carreras'),
        apiFetch('/api/bedelia/comisiones'),
        apiFetch('/api/academic/study-plan'),
        apiFetch('/api/academic/exams'),
        apiFetch('/api/academic/calendar'),
      ]);

      if (carrerasRes.ok) {
        const d = await carrerasRes.json();
        setCarreras(d.carreras || []);
        if (d.carreras.length > 0 && !selectedCarreraId) {
          setSelectedCarreraId(d.carreras[0].id);
        }
      }

      if (comisionesRes.ok) {
        const c = await comisionesRes.json();
        setComisiones(c.comisiones || []);
        if (c.comisiones.length > 0 && !selectedComisionForAttendance) {
          setSelectedComisionForAttendance(c.comisiones[0].id);
        }
      }

      if (planRes.ok) {
        const p = await planRes.json();
        setMateriasDisponibles(p.materias || []);
        if (p.materias.length > 0) {
          if (!createMateriaId) setCreateMateriaId(p.materias[0].id);
          if (!newExmMateriaId) setNewExmMateriaId(p.materias[0].id);
        }
      }

      if (examRes.ok) {
        const ex = await examRes.json();
        setExamenes(ex.examenes || []);
      }

      if (calRes.ok) {
        const cl = await calRes.json();
        setCalendarEvents(cl.events || []);
      }
    } catch (err) {
      console.error('Error cargando datos de Bedelía:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
    setMessage(null);
  }, [viewMode]);

  // Cargar asistencia de la comisión seleccionada
  useEffect(() => {
    if (viewMode === 'adminasistencia' && selectedComisionForAttendance) {
      loadAttendance(selectedComisionForAttendance);
    }
  }, [viewMode, selectedComisionForAttendance]);

  const loadAttendance = async (comisionId: string) => {
    setLoadingAttendance(true);
    try {
      const res = await apiFetch(`/api/bedelia/comisiones/${comisionId}/asistencia`);
      if (res.ok) {
        const d = await res.json();
        setAttendanceData(d);
      }
    } catch {
      console.error('Error al cargar asistencia');
    } finally {
      setLoadingAttendance(false);
    }
  };

  // Carrera actualmente seleccionada
  const selectedCarrera = carreras.find((c) => c.id === selectedCarreraId) || carreras[0];
  const estudiantesRegistradosEnCarrera = selectedCarrera?.total_estudiantes || 0;

  // Comisiones filtradas
  const comisionesFiltradas = selectedCarreraId
    ? comisiones.filter((c) => c.carrera_id === selectedCarreraId)
    : comisiones;

  // Manejador: Crear Comisión
  const handleCreateComision = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!createMateriaId || !createCodigoComision || !createDocente) return;

    try {
      const res = await apiFetch('/api/bedelia/comisiones', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          materiaId: createMateriaId,
          codigoComision: createCodigoComision,
          cicloLectivo: 2026,
          cuatrimestre: '1C',
          docenteTitular: createDocente,
          turno: createTurno,
          cupoMaximo: createCupo,
          diaSemana: createDia,
          horaInicio: createHoraInicio,
          horaFin: createHoraFin,
          aulaId: createAula,
          observaciones: createObs,
        }),
      });

      const d = await res.json();
      if (res.ok) {
        setShowCreateModal(false);
        setCreateDocente('');
        setMessage({ type: 'ok', text: d.message });
        loadData();
      } else {
        setMessage({ type: 'err', text: d.message || 'Error al crear comisión.' });
      }
    } catch {
      setMessage({ type: 'err', text: 'Error de conexión.' });
    }
  };

  // Manejador: Editar Comisión
  const handleUpdateComision = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingComision) return;

    try {
      const res = await apiFetch(`/api/bedelia/comisiones/${editingComision.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          codigoComision: editingComision.codigo_comision,
          docenteTitular: editingComision.docente_titular,
          turno: editingComision.turno,
          cupoMaximo: editingComision.cupo_maximo,
          aulaId: editingComision.aula_id,
        }),
      });

      const d = await res.json();
      if (res.ok) {
        setEditingComision(null);
        setMessage({ type: 'ok', text: d.message });
        loadData();
      } else {
        setMessage({ type: 'err', text: d.message || 'Error al actualizar.' });
      }
    } catch {
      setMessage({ type: 'err', text: 'Error de conexión.' });
    }
  };

  // Manejador: Toggle Inscripción Comisión
  const handleToggleEstado = async (id: string) => {
    try {
      const res = await apiFetch(`/api/bedelia/comisiones/${id}/toggle-estado`, {
        method: 'PATCH',
      });
      const d = await res.json();
      if (res.ok) {
        setMessage({ type: 'ok', text: d.message });
        loadData();
      }
    } catch {
      setMessage({ type: 'err', text: 'Error al cambiar estado de inscripción.' });
    }
  };

  // Manejador: Reubicación de Aula
  const handleReallocateClassroom = async () => {
    if (!reallocHorarioId) return;

    try {
      const res = await apiFetch('/api/admin/reallocate-classroom', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          horarioId: reallocHorarioId,
          aulaId: reallocAula,
          observaciones: reallocObs,
        }),
      });

      const d = await res.json();
      if (res.ok) {
        setReallocHorarioId(null);
        setReallocObs('');
        setMessage({ type: 'ok', text: d.message });
        loadData();
      } else {
        setMessage({ type: 'err', text: d.message || 'Error al reubicar aula.' });
      }
    } catch {
      setMessage({ type: 'err', text: 'Error de conexión.' });
    }
  };

  // Manejador: Eliminar Comisión
  const handleDeleteComision = async (id: string, codigo: string) => {
    if (!window.confirm(`¿Está seguro de eliminar la comisión ${codigo}? Se eliminarán sus horarios e inscripciones asociadas.`)) {
      return;
    }

    try {
      const res = await apiFetch(`/api/bedelia/comisiones/${id}`, { method: 'DELETE' });
      const d = await res.json();
      if (res.ok) {
        setMessage({ type: 'ok', text: d.message });
        loadData();
      }
    } catch {
      setMessage({ type: 'err', text: 'Error al eliminar comisión.' });
    }
  };

  // Manejador: Crear Mesa de Examen
  const handleCreateExamen = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newExmMateriaId || !newExmFecha || !newExmHora) return;

    try {
      const res = await apiFetch('/api/bedelia/exams', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          materiaId: newExmMateriaId,
          fecha: newExmFecha,
          hora: newExmHora,
          turnoExamen: newExmTurno,
          llamado: newExmLlamado,
          aulaId: newExmAula,
          tribunal: newExmTribunal || 'Prof. Titular y Adjuntos',
          periodoDesde: newExmDesde,
          periodoHasta: newExmHasta,
        }),
      });

      const d = await res.json();
      if (res.ok) {
        setShowExamModal(false);
        setMessage({ type: 'ok', text: d.message });
        loadData();
      } else {
        setMessage({ type: 'err', text: d.message || 'Error al programar mesa.' });
      }
    } catch {
      setMessage({ type: 'err', text: 'Error de conexión.' });
    }
  };

  // Manejador: Toggle Mesa de Examen
  const handleToggleExamen = async (id: string) => {
    try {
      const res = await apiFetch(`/api/bedelia/exams/${id}/toggle-estado`, { method: 'PATCH' });
      const d = await res.json();
      if (res.ok) {
        setMessage({ type: 'ok', text: d.message });
        loadData();
      }
    } catch {
      setMessage({ type: 'err', text: 'Error al cambiar estado de la mesa.' });
    }
  };

  // Manejador: Eliminar Mesa de Examen
  const handleDeleteExamen = async (id: string) => {
    if (!window.confirm('¿Está seguro de eliminar esta mesa de examen?')) return;
    try {
      const res = await apiFetch(`/api/bedelia/exams/${id}`, { method: 'DELETE' });
      const d = await res.json();
      if (res.ok) {
        setMessage({ type: 'ok', text: d.message });
        loadData();
      }
    } catch {
      setMessage({ type: 'err', text: 'Error al eliminar mesa.' });
    }
  };

  // Manejador: Crear Evento Calendario
  const handleCreateCalendarEvent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCalTitulo.trim() || !newCalInicio) return;

    try {
      const res = await apiFetch('/api/bedelia/calendar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          titulo: newCalTitulo,
          descripcion: newCalDesc,
          tipo: newCalTipo,
          fechaInicio: newCalInicio,
          fechaFin: newCalFin,
          carreraId: selectedCarreraId,
        }),
      });

      const d = await res.json();
      if (res.ok) {
        setShowCalModal(false);
        setNewCalTitulo('');
        setNewCalDesc('');
        setMessage({ type: 'ok', text: d.message });
        loadData();
      } else {
        setMessage({ type: 'err', text: d.message || 'Error al crear evento.' });
      }
    } catch {
      setMessage({ type: 'err', text: 'Error de conexión.' });
    }
  };

  // Manejador: Eliminar Evento Calendario
  const handleDeleteCalendarEvent = async (id: string) => {
    if (!window.confirm('¿Desea eliminar este evento del calendario institucional?')) return;
    try {
      const res = await apiFetch(`/api/bedelia/calendar/${id}`, { method: 'DELETE' });
      const d = await res.json();
      if (res.ok) {
        setMessage({ type: 'ok', text: d.message });
        loadData();
      }
    } catch {
      setMessage({ type: 'err', text: 'Error al eliminar evento.' });
    }
  };

  // Exportar archivo sintético
  const handleExportData = (tipo: 'COMISIONES' | 'EXAMENES' | 'AULAS') => {
    const dataToExport = tipo === 'COMISIONES' ? comisiones : tipo === 'EXAMENES' ? examenes : [
      { id: 'AULA-204', nombre: 'Aula 204', edificio: 'Edificio Central, 2do Piso', capacidad: 50 },
      { id: 'AULA-101', nombre: 'Aula 101', edificio: 'Edificio Central, 1er Piso', capacidad: 45 },
      { id: 'LAB-01', nombre: 'Laboratorio de Informática 1', edificio: 'Edificio San José', capacidad: 30 },
      { id: 'AUD-01', nombre: 'Aula Magna San José', edificio: 'Campus Central', capacidad: 200 },
    ];

    const blob = new Blob([JSON.stringify(dataToExport, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `reporte_bedelia_${tipo.toLowerCase()}_2026.json`;
    a.click();
    URL.revokeObjectURL(url);
    setMessage({ type: 'ok', text: `Reporte de ${tipo} exportado con éxito en formato seguro JSON.` });
  };

  // Métricas generales de Bedelía
  const totalComisiones = comisiones.length;
  const comisionesAbiertas = comisiones.filter((c) => c.estado_inscripcion === 'ABIERTA' || !c.estado_inscripcion).length;
  const totalCupos = comisiones.reduce((acc, curr) => acc + (curr.cupo_maximo || 35), 0);
  const totalInscriptos = comisiones.reduce((acc, curr) => acc + (curr.estudiantes_inscriptos || 0), 0);
  const aulasReubicadas = comisiones.filter((c) => c.estado_aula === 'MODIFICADA').length;

  return (
    <div className="space-y-6">
      {/* =========================================================================
          BANNER OPERATIVO DE BEDELÍA
          ========================================================================= */}
      <div className="iov-card iov-card-destacada">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="badge-vigente">Consola Operativa</span>
              <span className="text-xs text-slate-500 font-medium">Bedelía Central · UCSF</span>
            </div>
            <h2 className="text-xl md:text-2xl font-black text-[var(--azul-900)] tracking-tight">
              {viewMode === 'panelbedelia' && 'Panel Operativo de Cursadas y Aulas'}
              {viewMode === 'admincomisiones' && 'Gestión de Comisiones, Horarios y Cupos'}
              {viewMode === 'adminexamenes' && 'Gestión de Mesas de Examen Final'}
              {viewMode === 'adminasistencia' && 'Supervisión de Asistencia de Comisiones'}
              {viewMode === 'admincalendario' && 'Calendario y Actividades Académicas'}
              {viewMode === 'exportaciones' && 'Exportaciones y Reportes de Bedelía'}
            </h2>
            <p className="text-xs md:text-sm text-slate-600 mt-1 max-w-2xl">
              {viewMode === 'panelbedelia' && 'Monitoreo de ocupación de cursadas, cupos asignados, aulas reubicadas y mesas de examen.'}
              {viewMode === 'admincomisiones' && 'Cree comisiones asignándolas a materias del plan, defina cupos según la matrícula y reubique aulas.'}
              {viewMode === 'adminexamenes' && 'Programe tribunales docentes, fechas, aulas y habilite períodos de inscripción a exámenes finales.'}
              {viewMode === 'adminasistencia' && 'Supervise actas y condición de regularidad por comisión sin interferir en la trayectoria personal de los estudiantes.'}
              {viewMode === 'admincalendario' && 'Establezca feriados, asuetos, semanas de parciales y actividades institucionales oficiales.'}
              {viewMode === 'exportaciones' && 'Descargue actas y padrones consolidados para archivo oficial.'}
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={loadData}
              className="btn-secondary text-xs"
              disabled={loading}
              title="Recargar datos"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              <span>Actualizar</span>
            </button>
          </div>
        </div>
      </div>

      {message && (
        <div
          className={`p-3 rounded-xl text-xs font-semibold flex items-center justify-between ${
            message.type === 'ok'
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-red-50 text-red-800 border border-red-200'
          }`}
        >
          <span>{message.text}</span>
          <button onClick={() => setMessage(null)} className="p-1 hover:opacity-75">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* =========================================================================
          VISTA 1: PANEL BEDELÍA (DASHBOARD GENERAL DE GESTIÓN)
          ========================================================================= */}
      {viewMode === 'panelbedelia' && (
        <div className="space-y-6">
          {/* Tarjetas KPI */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="iov-card">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-slate-500 uppercase">Comisiones Activas</span>
                <Layers className="w-4 h-4 text-[var(--celeste-500)]" />
              </div>
              <div className="text-2xl font-black text-[var(--azul-900)]">{totalComisiones}</div>
              <div className="text-[11px] text-emerald-600 font-semibold mt-1 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" />
                <span>{comisionesAbiertas} con inscripción habilitada</span>
              </div>
            </div>

            <div className="iov-card">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-slate-500 uppercase">Cupos Asignados</span>
                <Users className="w-4 h-4 text-[var(--azul-700)]" />
              </div>
              <div className="text-2xl font-black text-[var(--azul-900)]">
                {totalInscriptos} / {totalCupos}
              </div>
              <div className="text-[11px] text-slate-500 mt-1">
                {totalCupos > 0 ? `${Math.round((totalInscriptos / totalCupos) * 100)}% de ocupación global` : 'Sin cupos'}
              </div>
            </div>

            <div className="iov-card">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-slate-500 uppercase">Mesas de Examen</span>
                <Award className="w-4 h-4 text-amber-500" />
              </div>
              <div className="text-2xl font-black text-[var(--azul-900)]">{examenes.length}</div>
              <div className="text-[11px] text-slate-500 mt-1">
                {examenes.filter((e) => e.estado === 'ABIERTO').length} con período de inscripción abierto
              </div>
            </div>

            <div className="iov-card">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-slate-500 uppercase">Reubicaciones de Aula</span>
                <MapPin className="w-4 h-4 text-[var(--rojo-600)]" />
              </div>
              <div className="text-2xl font-black text-[var(--rojo-600)]">{aulasReubicadas}</div>
              <div className="text-[11px] text-slate-500 mt-1">
                Aulas marcadas temporalmente como MODIFICADA
              </div>
            </div>
          </div>

          {/* Accesos Rápidos de Bedelía */}
          <div className="iov-card">
            <h3 className="text-sm font-bold text-[var(--azul-900)] uppercase tracking-wider mb-3">
              Operaciones Rápidas de Bedelía
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
              <button
                onClick={() => onNavigateToSection?.('admincomisiones')}
                className="p-3 bg-slate-50 hover:bg-slate-100 rounded-xl border border-slate-200 text-left transition-colors flex items-center gap-3"
              >
                <div className="p-2 bg-[var(--celeste-100)] text-[var(--azul-900)] rounded-lg">
                  <Plus className="w-4 h-4" />
                </div>
                <div>
                  <div className="font-bold text-slate-900">Crear o Gestionar Comisiones</div>
                  <div className="text-[11px] text-slate-500">Asignar a materias y horarios</div>
                </div>
              </button>

              <button
                onClick={() => onNavigateToSection?.('adminexamenes')}
                className="p-3 bg-slate-50 hover:bg-slate-100 rounded-xl border border-slate-200 text-left transition-colors flex items-center gap-3"
              >
                <div className="p-2 bg-amber-50 text-amber-700 rounded-lg">
                  <Award className="w-4 h-4" />
                </div>
                <div>
                  <div className="font-bold text-slate-900">Mesas de Examen Final</div>
                  <div className="text-[11px] text-slate-500">Programar turnos y tribunales</div>
                </div>
              </button>

              <button
                onClick={() => onNavigateToSection?.('adminasistencia')}
                className="p-3 bg-slate-50 hover:bg-slate-100 rounded-xl border border-slate-200 text-left transition-colors flex items-center gap-3"
              >
                <div className="p-2 bg-emerald-50 text-emerald-700 rounded-lg">
                  <UserCheck className="w-4 h-4" />
                </div>
                <div>
                  <div className="font-bold text-slate-900">Supervisar Asistencia</div>
                  <div className="text-[11px] text-slate-500">Consultar actas de cursada</div>
                </div>
              </button>

              <button
                onClick={() => onNavigateToSection?.('admincalendario')}
                className="p-3 bg-slate-50 hover:bg-slate-100 rounded-xl border border-slate-200 text-left transition-colors flex items-center gap-3"
              >
                <div className="p-2 bg-purple-50 text-purple-700 rounded-lg">
                  <Calendar className="w-4 h-4" />
                </div>
                <div>
                  <div className="font-bold text-slate-900">Calendario Institucional</div>
                  <div className="text-[11px] text-slate-500">Feriados, asuetos y cursadas</div>
                </div>
              </button>
            </div>
          </div>

          {/* Listado de Comisiones Activas con Resumen */}
          <div className="iov-card">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-[var(--azul-900)]">
                Comisiones en Cursado (Ciclo Lectivo 2026)
              </h3>
              <button
                onClick={() => onNavigateToSection?.('admincomisiones')}
                className="text-xs font-semibold text-[var(--azul-700)] hover:underline flex items-center gap-1"
              >
                <span>Administrar todas ({comisiones.length})</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-2">
              {comisiones.slice(0, 5).map((com) => (
                <div key={com.id} className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <div className="font-bold text-slate-900 text-sm">
                      {com.materia_nombre} <span className="text-slate-500 font-normal">({com.codigo_comision})</span>
                    </div>
                    <div className="text-slate-600 text-[11px] mt-0.5">
                      Docente: {com.docente_titular || 'Por designar'} · Turno {com.turno} · Aula: {com.aula_nombre || 'Aula 204'}
                    </div>
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    <span className="text-slate-600 text-[11px]">
                      Inscriptos: <strong>{com.estudiantes_inscriptos || 0}</strong> / {com.cupo_maximo || 35}
                    </span>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      com.estado_inscripcion === 'CERRADA'
                        ? 'bg-red-100 text-red-800'
                        : 'bg-emerald-100 text-emerald-800'
                    }`}>
                      {com.estado_inscripcion === 'CERRADA' ? 'CERRADA' : 'ABIERTA'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          VISTA 2: GESTIÓN DE COMISIONES, HORARIOS Y CUPOS (admincomisiones)
          ========================================================================= */}
      {viewMode === 'admincomisiones' && (
        <div className="space-y-5">
          {/* Selector de Carrera y Dimensión de Cupo */}
          <div className="iov-card">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex-1">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Carrera del Plan de Estudios (Creada por Administración)
                </label>
                <select
                  value={selectedCarreraId}
                  onChange={(e) => setSelectedCarreraId(e.target.value)}
                  className="w-full md:max-w-md px-3 py-2 rounded-lg border border-slate-300 text-xs bg-white font-medium"
                >
                  {carreras.map((car) => (
                    <option key={car.id} value={car.id}>
                      {car.nombre} ({car.codigo}) — {car.total_materias || 0} materias en plan
                    </option>
                  ))}
                </select>
              </div>

              {/* Registro de matrícula como referencia operativa de Bedelía */}
              <div className="p-3 bg-[var(--celeste-100)] rounded-xl border border-blue-200/60 text-xs shrink-0">
                <div className="text-[11px] font-bold text-[var(--azul-900)]">
                  Referencia de Matrícula Registrada:
                </div>
                <div className="text-sm font-black text-[var(--azul-900)] mt-0.5">
                  {estudiantesRegistradosEnCarrera} Estudiantes registrados en la App
                </div>
                <div className="text-[10px] text-slate-600 mt-0.5">
                  Use esta cifra para definir el cupo máximo por comisión y turnos requeridos.
                </div>
              </div>

              <button
                onClick={() => setShowCreateModal(true)}
                className="btn-primary text-xs shrink-0 self-start md:self-auto"
              >
                <Plus className="w-4 h-4" />
                <span>Crear Comisión</span>
              </button>
            </div>
          </div>

          {/* Listado de Comisiones de la Carrera */}
          <div className="space-y-3">
            {comisionesFiltradas.length === 0 ? (
              <div className="iov-card text-center py-10">
                <Layers className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                <h4 className="text-sm font-bold text-slate-700">No hay comisiones creadas para esta carrera</h4>
                <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                  Utilice el botón "Crear Comisión" para habilitar el cursado de las materias del plan de estudios.
                </p>
                <button
                  onClick={() => setShowCreateModal(true)}
                  className="btn-primary text-xs mt-4"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Crear Primera Comisión</span>
                </button>
              </div>
            ) : (
              comisionesFiltradas.map((com) => {
                const estaAbierta = com.estado_inscripcion !== 'CERRADA';
                const esAulaModificada = com.estado_aula === 'MODIFICADA';

                return (
                  <div key={com.id} className="iov-card space-y-3">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs font-bold text-[var(--azul-700)]">
                            {com.materia_codigo || 'MAT'} · {com.codigo_comision}
                          </span>
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            estaAbierta ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
                          }`}>
                            {estaAbierta ? 'INSCRIPCIÓN ABIERTA' : 'INSCRIPCIÓN CERRADA'}
                          </span>
                          {esAulaModificada && (
                            <span className="badge-critico text-[10px]">AULA REUBICADA</span>
                          )}
                        </div>
                        <h4 className="font-bold text-slate-900 text-sm mt-0.5">{com.materia_nombre}</h4>
                        <div className="text-slate-500 text-xs">
                          Docente: <strong>{com.docente_titular || 'Por designar'}</strong> · Turno {com.turno}
                        </div>
                      </div>

                      {/* Botones de Acción Operativa */}
                      <div className="flex flex-wrap items-center gap-2">
                        {/* 1-Clic: Abrir / Cerrar */}
                        <button
                          onClick={() => handleToggleEstado(com.id)}
                          className={`text-xs font-bold px-2.5 py-1.5 rounded-lg flex items-center gap-1 transition-colors ${
                            estaAbierta
                              ? 'bg-red-50 text-red-700 hover:bg-red-100 border border-red-200'
                              : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200'
                          }`}
                          title={estaAbierta ? 'Cerrar inscripciones' : 'Abrir inscripciones'}
                        >
                          {estaAbierta ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
                          <span>{estaAbierta ? 'Cerrar' : 'Abrir'}</span>
                        </button>

                        {/* Reubicar Aula */}
                        <button
                          onClick={() => {
                            setReallocHorarioId(com.horario_id || com.id);
                            setReallocAula(com.aula_id || 'AULA-101');
                          }}
                          className="btn-secondary text-xs py-1.5 px-2.5"
                          title="Reubicar aula"
                        >
                          <MapPin className="w-3.5 h-3.5 text-[var(--celeste-500)]" />
                          <span>Reubicar</span>
                        </button>

                        {/* Editar Comisión */}
                        <button
                          onClick={() => setEditingComision(com)}
                          className="btn-secondary text-xs py-1.5 px-2.5"
                          title="Editar datos"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                          <span>Editar</span>
                        </button>

                        {/* Eliminar Comisión */}
                        <button
                          onClick={() => handleDeleteComision(com.id, com.codigo_comision)}
                          className="p-1.5 text-slate-400 hover:text-red-600 rounded"
                          title="Eliminar comisión"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {/* Detalle Operativo: Horario, Aula, Cupo */}
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 p-2.5 bg-slate-50 rounded-lg border border-slate-100 text-xs">
                      <div className="flex items-center gap-2">
                        <Clock className="w-3.5 h-3.5 text-[var(--celeste-500)]" />
                        <span>
                          Día {com.dia_semana || 1}: {com.hora_inicio || '08:00'} a {com.hora_fin || '11:00'} hs
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        <Building className="w-3.5 h-3.5 text-[var(--azul-700)]" />
                        <span>
                          <strong>{com.aula_nombre || 'Aula 204'}</strong> ({com.aula_edificio || 'Central'})
                        </span>
                      </div>

                      <div className="flex items-center justify-between sm:justify-end gap-2 text-slate-700">
                        <span>Inscriptos: <strong>{com.estudiantes_inscriptos || 0}</strong> de <strong>{com.cupo_maximo || 40}</strong></span>
                        <div className="w-16 bg-slate-200 h-2 rounded-full overflow-hidden">
                          <div
                            className="bg-emerald-500 h-full"
                            style={{
                              width: `${Math.min(100, ((com.estudiantes_inscriptos || 0) / (com.cupo_maximo || 40)) * 100)}%`,
                            }}
                          />
                        </div>
                      </div>
                    </div>

                    {com.horario_observaciones && (
                      <div className="text-[11px] text-amber-800 bg-amber-50 p-1.5 rounded border border-amber-200">
                        <strong>Observación de Bedelía:</strong> {com.horario_observaciones}
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* =========================================================================
          VISTA 3: MESAS DE EXAMEN FINAL (adminexamenes)
          ========================================================================= */}
      {viewMode === 'adminexamenes' && (
        <div className="space-y-5">
          <div className="iov-card flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-sm font-bold text-[var(--azul-900)]">
                Programación de Mesas de Examen Final
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Defina tribunales docentes, fechas, horarios y aulas oficiales para cada turno de examen.
              </p>
            </div>

            <button
              onClick={() => setShowExamModal(true)}
              className="btn-primary text-xs shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>Programar Mesa de Examen</span>
            </button>
          </div>

          <div className="space-y-3">
            {examenes.length === 0 ? (
              <div className="iov-card text-center py-10">
                <Award className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                <h4 className="text-sm font-bold text-slate-700">No hay mesas de examen programadas</h4>
                <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                  Agregue una nueva mesa de examen para abrir el período de inscripción.
                </p>
                <button onClick={() => setShowExamModal(true)} className="btn-primary text-xs mt-3">
                  <Plus className="w-3.5 h-3.5" />
                  <span>Programar Primera Mesa</span>
                </button>
              </div>
            ) : (
              examenes.map((ex) => {
                const abierta = ex.estado === 'ABIERTO';
                return (
                  <div key={ex.id} className="iov-card flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-mono font-bold text-[var(--azul-700)]">{ex.materia_codigo || 'EXM'}</span>
                        <span className="font-semibold text-slate-500">· Llamado {ex.llamado || 1}</span>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          abierta ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
                        }`}>
                          {abierta ? 'ABIERTA' : 'CERRADA'}
                        </span>
                      </div>
                      <div className="text-sm font-bold text-slate-900">{ex.materia_nombre}</div>
                      <div className="text-slate-600 mt-1 flex flex-wrap gap-x-4 gap-y-1">
                        <span>Fecha: <strong>{ex.fecha}</strong> a las <strong>{ex.hora} hs</strong></span>
                        <span>Aula: <strong>{ex.aula_nombre || 'Aula 204'}</strong></span>
                        <span>Tribunal: <strong>{ex.tribunal}</strong></span>
                      </div>
                      <div className="text-[11px] text-slate-500 mt-1">
                        Inscripciones: del {ex.periodo_inscripcion_desde} al {ex.periodo_inscripcion_hasta}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => handleToggleExamen(ex.id)}
                        className={`text-xs font-bold px-3 py-1.5 rounded-lg flex items-center gap-1.5 ${
                          abierta
                            ? 'bg-red-50 text-red-700 hover:bg-red-100 border border-red-200'
                            : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200'
                        }`}
                      >
                        {abierta ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
                        <span>{abierta ? 'Cerrar' : 'Abrir'}</span>
                      </button>

                      <button
                        onClick={() => handleDeleteExamen(ex.id)}
                        className="p-1.5 text-slate-400 hover:text-red-600 rounded"
                        title="Eliminar mesa"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* =========================================================================
          VISTA 4: SUPERVISIÓN DE ASISTENCIA (adminasistencia)
          ========================================================================= */}
      {viewMode === 'adminasistencia' && (
        <div className="space-y-5">
          <div className="iov-card">
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Seleccione la Comisión a Supervisar
            </label>
            <select
              value={selectedComisionForAttendance}
              onChange={(e) => setSelectedComisionForAttendance(e.target.value)}
              className="w-full md:max-w-md px-3 py-2 rounded-lg border border-slate-300 text-xs bg-white font-medium"
            >
              {comisiones.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.materia_nombre} ({c.codigo_comision}) — {c.docente_titular || 'Sin docente'}
                </option>
              ))}
            </select>
          </div>

          {loadingAttendance ? (
            <div className="iov-card text-center py-10">
              <RefreshCw className="w-6 h-6 animate-spin text-[var(--celeste-500)] mx-auto mb-2" />
              <div className="text-xs text-slate-500">Cargando actas de asistencia...</div>
            </div>
          ) : attendanceData ? (
            <div className="iov-card space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                <div>
                  <h3 className="text-base font-bold text-[var(--azul-900)]">
                    Acta de Asistencia: {attendanceData.comision?.materia_nombre}
                  </h3>
                  <div className="text-xs text-slate-600 mt-0.5">
                    Comisión: {attendanceData.comision?.codigo_comision} · Docente: {attendanceData.comision?.docente_titular} · Aula: {attendanceData.comision?.aula_nombre}
                  </div>
                </div>

                <div className="text-right text-xs">
                  <div className="font-bold text-[var(--azul-900)]">
                    {attendanceData.totalInscriptos} Estudiantes en nómina
                  </div>
                  <div className="text-slate-500 text-[11px]">
                    {attendanceData.totalClases} Clases computadas en el ciclo
                  </div>
                </div>
              </div>

              {/* Tabla de Alumnos y Asistencia */}
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left">
                  <thead className="bg-slate-50 text-slate-600 uppercase font-bold text-[10px] border-b border-slate-200">
                    <tr>
                      <th className="py-2.5 px-3">Estudiante</th>
                      <th className="py-2.5 px-3">Matrícula</th>
                      <th className="py-2.5 px-3">Presentes</th>
                      <th className="py-2.5 px-3">Inasistencias</th>
                      <th className="py-2.5 px-3">Asistencia %</th>
                      <th className="py-2.5 px-3 text-right">Condición</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {attendanceData.estudiantes?.map((est: any) => (
                      <tr key={est.estudiante_id} className="hover:bg-slate-50/50">
                        <td className="py-2.5 px-3 font-semibold text-slate-900">
                          {est.nombre_completo}
                        </td>
                        <td className="py-2.5 px-3 font-mono text-slate-600">
                          {est.matricula}
                        </td>
                        <td className="py-2.5 px-3 text-emerald-700 font-bold">
                          {est.presentes} clases
                        </td>
                        <td className="py-2.5 px-3 text-red-600 font-bold">
                          {est.faltas} faltas
                        </td>
                        <td className="py-2.5 px-3">
                          <div className="flex items-center gap-2">
                            <span className="font-bold">{est.porcentajeAsistencia}%</span>
                            <div className="w-16 bg-slate-100 h-1.5 rounded-full overflow-hidden">
                              <div
                                className={`h-full ${
                                  est.porcentajeAsistencia >= 75
                                    ? 'bg-emerald-500'
                                    : est.porcentajeAsistencia >= 60
                                    ? 'bg-amber-500'
                                    : 'bg-red-500'
                                }`}
                                style={{ width: `${Math.min(100, est.porcentajeAsistencia)}%` }}
                              />
                            </div>
                          </div>
                        </td>
                        <td className="py-2.5 px-3 text-right">
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            est.estadoCursada === 'REGULAR'
                              ? 'bg-emerald-100 text-emerald-800'
                              : est.estadoCursada === 'EN_RIESGO'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-red-100 text-red-800'
                          }`}>
                            {est.estadoCursada}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ) : null}
        </div>
      )}

      {/* =========================================================================
          VISTA 5: CALENDARIO INSTITUCIONAL (admincalendario)
          ========================================================================= */}
      {viewMode === 'admincalendario' && (
        <div className="space-y-5">
          <div className="iov-card flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-sm font-bold text-[var(--azul-900)]">
                Calendario Académico y Actividades Institucionales
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Defina fechas clave oficiales (inicio de cuatrimestre, semanas de finales, asuetos y feriados).
              </p>
            </div>

            <button
              onClick={() => setShowCalModal(true)}
              className="btn-primary text-xs shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>Agregar Evento Oficial</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {calendarEvents.map((ev) => (
              <div key={ev.id} className="iov-card text-xs flex justify-between items-start gap-3">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      ev.tipo === 'FERIADO' || ev.tipo === 'ASUETO'
                        ? 'bg-red-100 text-red-800'
                        : ev.tipo === 'PARCIAL' || ev.tipo === 'FINAL'
                        ? 'bg-purple-100 text-purple-800'
                        : 'bg-blue-100 text-blue-800'
                    }`}>
                      {ev.tipo}
                    </span>
                    <span className="text-slate-500 text-[11px] font-mono">
                      {ev.fecha_inicio} {ev.fecha_fin && ev.fecha_fin !== ev.fecha_inicio ? `al ${ev.fecha_fin}` : ''}
                    </span>
                  </div>
                  <h4 className="font-bold text-slate-900 text-sm">{ev.titulo}</h4>
                  {ev.descripcion && (
                    <p className="text-slate-600 text-xs mt-1">{ev.descripcion}</p>
                  )}
                </div>

                <button
                  onClick={() => handleDeleteCalendarEvent(ev.id)}
                  className="p-1.5 text-slate-400 hover:text-red-600 rounded shrink-0"
                  title="Eliminar evento"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* =========================================================================
          VISTA 6: EXPORTACIONES Y REPORTES (exportaciones)
          ========================================================================= */}
      {viewMode === 'exportaciones' && (
        <div className="space-y-5">
          <div className="iov-card">
            <h3 className="text-base font-bold text-[var(--azul-900)] mb-1">
              Exportación Oficial de Datos Académicos
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Descargue padrones de comisiones, cronogramas de horarios y actas en formatos JSON y CSV estándar.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 text-sm font-bold text-slate-900 mb-1">
                    <Layers className="w-4 h-4 text-[var(--azul-700)]" />
                    <span>Nómina de Comisiones</span>
                  </div>
                  <p className="text-slate-500 text-[11px]">
                    Exportar todas las comisiones, docentes, turnos, aulas asignadas y cupos del ciclo 2026.
                  </p>
                </div>
                <button
                  onClick={() => handleExportData('COMISIONES')}
                  className="btn-primary text-xs mt-4 w-full justify-center"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Descargar JSON</span>
                </button>
              </div>

              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 text-sm font-bold text-slate-900 mb-1">
                    <Award className="w-4 h-4 text-amber-600" />
                    <span>Mesas de Examen Final</span>
                  </div>
                  <p className="text-slate-500 text-[11px]">
                    Exportar mesas programadas, tribunales docentes, turnos y fechas oficiales.
                  </p>
                </div>
                <button
                  onClick={() => handleExportData('EXAMENES')}
                  className="btn-secondary text-xs mt-4 w-full justify-center"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Descargar JSON</span>
                </button>
              </div>

              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 text-sm font-bold text-slate-900 mb-1">
                    <Building className="w-4 h-4 text-emerald-600" />
                    <span>Padrón de Aulas</span>
                  </div>
                  <p className="text-slate-500 text-[11px]">
                    Listado de aulas físicas, capacidades y ubicaciones edilicias del campus.
                  </p>
                </div>
                <button
                  onClick={() => handleExportData('AULAS')}
                  className="btn-secondary text-xs mt-4 w-full justify-center"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Descargar JSON</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODALES
          ========================================================================= */}
      {/* Modal: Crear Comisión */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200">
            <h3 className="text-base font-bold text-[var(--azul-900)] mb-1">
              Crear Nueva Comisión de Cursado
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Asigne la comisión a una materia del plan de estudio de {selectedCarrera?.nombre}.
            </p>

            <form onSubmit={handleCreateComision} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Materia del Plan</label>
                <select
                  value={createMateriaId}
                  onChange={(e) => setCreateMateriaId(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300"
                >
                  {materiasDisponibles.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.codigo} — {m.nombre} ({m.anio_carrera}° Año, {m.regimen})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Código Comisión</label>
                  <input
                    type="text"
                    value={createCodigoComision}
                    onChange={(e) => setCreateCodigoComision(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono uppercase"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Turno</label>
                  <select
                    value={createTurno}
                    onChange={(e) => setCreateTurno(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300"
                  >
                    <option value="MANANA">Mañana</option>
                    <option value="TARDE">Tarde</option>
                    <option value="NOCHE">Noche</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Docente Titular</label>
                <input
                  type="text"
                  placeholder="ej. Dra. Claudia Morales"
                  value={createDocente}
                  onChange={(e) => setCreateDocente(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Cupo de Estudiantes
                    <span className="text-[10px] text-slate-500 font-normal ml-1">
                      (Matrícula: {estudiantesRegistradosEnCarrera})
                    </span>
                  </label>
                  <input
                    type="number"
                    value={createCupo}
                    onChange={(e) => setCreateCupo(parseInt(e.target.value, 10))}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Aula Asignada</label>
                  <select
                    value={createAula}
                    onChange={(e) => setCreateAula(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300"
                  >
                    <option value="AULA-204">Aula 204 (Central, 2do Piso)</option>
                    <option value="AULA-101">Aula 101 (Central, 1er Piso)</option>
                    <option value="LAB-01">Laboratorio de Informática 1</option>
                    <option value="AUD-01">Aula Magna San José</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Día de la Semana</label>
                  <select
                    value={createDia}
                    onChange={(e) => setCreateDia(parseInt(e.target.value, 10))}
                    className="w-full px-2 py-2 rounded-lg border border-slate-300"
                  >
                    <option value={1}>Lunes</option>
                    <option value={2}>Martes</option>
                    <option value={3}>Miércoles</option>
                    <option value={4}>Jueves</option>
                    <option value={5}>Viernes</option>
                    <option value={6}>Sábado</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Hora Inicio</label>
                  <input
                    type="time"
                    value={createHoraInicio}
                    onChange={(e) => setCreateHoraInicio(e.target.value)}
                    className="w-full px-2 py-2 rounded-lg border border-slate-300"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Hora Fin</label>
                  <input
                    type="time"
                    value={createHoraFin}
                    onChange={(e) => setCreateHoraFin(e.target.value)}
                    className="w-full px-2 py-2 rounded-lg border border-slate-300"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="btn-secondary text-xs"
                >
                  Cancelar
                </button>
                <button type="submit" className="btn-primary text-xs">
                  Guardar Comisión
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Editar Comisión */}
      {editingComision && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200">
            <h3 className="text-base font-bold text-[var(--azul-900)] mb-1">
              Editar Comisión: {editingComision.materia_nombre}
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Modifique docentes, cupo de estudiantes, horarios y aulas oficiales.
            </p>

            <form onSubmit={handleUpdateComision} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Código Comisión</label>
                  <input
                    type="text"
                    value={editingComision.codigo_comision}
                    onChange={(e) => setEditingComision({ ...editingComision, codigo_comision: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono uppercase"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Turno</label>
                  <select
                    value={editingComision.turno}
                    onChange={(e) => setEditingComision({ ...editingComision, turno: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300"
                  >
                    <option value="MANANA">Mañana</option>
                    <option value="TARDE">Tarde</option>
                    <option value="NOCHE">Noche</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Docente Titular</label>
                <input
                  type="text"
                  value={editingComision.docente_titular}
                  onChange={(e) => setEditingComision({ ...editingComision, docente_titular: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Cupo Máximo</label>
                <input
                  type="number"
                  value={editingComision.cupo_maximo}
                  onChange={(e) => setEditingComision({ ...editingComision, cupo_maximo: parseInt(e.target.value, 10) })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Aula Asignada</label>
                <select
                  value={editingComision.aula_id || 'AULA-204'}
                  onChange={(e) => setEditingComision({ ...editingComision, aula_id: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300"
                >
                  <option value="AULA-204">Aula 204 (Edificio Central, 2do Piso)</option>
                  <option value="AULA-101">Aula 101 (Edificio Central, 1er Piso)</option>
                  <option value="LAB-01">Laboratorio de Informática 1</option>
                  <option value="AUD-01">Aula Magna San José</option>
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditingComision(null)}
                  className="btn-secondary text-xs"
                >
                  Cancelar
                </button>
                <button type="submit" className="btn-primary text-xs">
                  Guardar Cambios
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Reubicación Rápida de Aula */}
      {reallocHorarioId && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <h3 className="text-base font-bold text-[var(--azul-900)] mb-2">
              Reubicar Aula de la Comisión
            </h3>
            <p className="text-xs text-slate-500 mb-3">
              Al reubicar el aula, el sistema marcará automáticamente el estado <strong>MODIFICADA</strong> y alertará a los alumnos en sus horarios.
            </p>
            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Nueva Aula de Cursado</label>
                <select
                  value={reallocAula}
                  onChange={(e) => setReallocAula(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300"
                >
                  <option value="AULA-101">Aula 101 (Edificio Central, 1er Piso)</option>
                  <option value="AULA-204">Aula 204 (Edificio Central, 2do Piso)</option>
                  <option value="LAB-01">Laboratorio de Informática 1</option>
                  <option value="AUD-01">Aula Magna San José</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Motivo / Observación Pública</label>
                <input
                  type="text"
                  placeholder="ej. Reubicado a Lab 1 por tareas de mantenimiento..."
                  value={reallocObs}
                  onChange={(e) => setReallocObs(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button onClick={() => setReallocHorarioId(null)} className="btn-secondary text-xs">Cancelar</button>
                <button onClick={handleReallocateClassroom} className="btn-primary text-xs">Guardar Reubicación</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Crear Mesa de Examen */}
      {showExamModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200">
            <h3 className="text-base font-bold text-[var(--azul-900)] mb-1">
              Programar Mesa de Examen Final
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Establezca los tribunales docentes, fecha y hora de la evaluación.
            </p>

            <form onSubmit={handleCreateExamen} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Materia</label>
                <select
                  value={newExmMateriaId}
                  onChange={(e) => setNewExmMateriaId(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300"
                >
                  {materiasDisponibles.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.codigo} — {m.nombre} ({m.anio_carrera}° Año)
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Fecha</label>
                  <input
                    type="date"
                    value={newExmFecha}
                    onChange={(e) => setNewExmFecha(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300"
                    required
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Hora</label>
                  <input
                    type="time"
                    value={newExmHora}
                    onChange={(e) => setNewExmHora(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Turno</label>
                  <select
                    value={newExmTurno}
                    onChange={(e) => setNewExmTurno(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300"
                  >
                    <option value="JULIO_AGOSTO_2026">Julio / Agosto 2026</option>
                    <option value="NOVIEMBRE_DICIEMBRE_2026">Noviembre / Diciembre 2026</option>
                    <option value="FEBRERO_MARZO_2027">Febrero / Marzo 2027</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Aula</label>
                  <select
                    value={newExmAula}
                    onChange={(e) => setNewExmAula(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300"
                  >
                    <option value="AULA-204">Aula 204 (Central)</option>
                    <option value="AULA-101">Aula 101 (Central)</option>
                    <option value="LAB-01">Laboratorio 1</option>
                    <option value="AUD-01">Aula Magna</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Tribunal Docente</label>
                <input
                  type="text"
                  placeholder="ej. Dra. Claudia Morales (Pres.), Ing. Roberto Díaz (Vocal)"
                  value={newExmTribunal}
                  onChange={(e) => setNewExmTribunal(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Inscripciones Desde</label>
                  <input
                    type="date"
                    value={newExmDesde}
                    onChange={(e) => setNewExmDesde(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Inscripciones Hasta</label>
                  <input
                    type="date"
                    value={newExmHasta}
                    onChange={(e) => setNewExmHasta(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowExamModal(false)}
                  className="btn-secondary text-xs"
                >
                  Cancelar
                </button>
                <button type="submit" className="btn-primary text-xs">
                  Guardar Mesa
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Crear Evento Calendario */}
      {showCalModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <h3 className="text-base font-bold text-[var(--azul-900)] mb-1">
              Agregar Evento Oficial al Calendario
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Este evento se publicará para todos los estudiantes en el calendario institucional.
            </p>

            <form onSubmit={handleCreateCalendarEvent} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Título del Evento</label>
                <input
                  type="text"
                  placeholder="ej. Feriado Nacional de Mayo / Inicio de Clases"
                  value={newCalTitulo}
                  onChange={(e) => setNewCalTitulo(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Tipo de Evento</label>
                <select
                  value={newCalTipo}
                  onChange={(e) => setNewCalTipo(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300"
                >
                  <option value="ACADEMICO">Actividad Académica General</option>
                  <option value="FERIADO">Feriado Nacional / Provincial</option>
                  <option value="ASUETO">Asueto Institucional</option>
                  <option value="PARCIAL">Período de Parciales</option>
                  <option value="FINAL">Turno de Exámenes Finales</option>
                  <option value="INSCRIPCION">Período de Inscripción</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Fecha Inicio</label>
                  <input
                    type="date"
                    value={newCalInicio}
                    onChange={(e) => setNewCalInicio(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300"
                    required
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Fecha Fin</label>
                  <input
                    type="date"
                    value={newCalFin}
                    onChange={(e) => setNewCalFin(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Descripción / Observación</label>
                <textarea
                  rows={2}
                  placeholder="Detalle o normativa asociada..."
                  value={newCalDesc}
                  onChange={(e) => setNewCalDesc(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowCalModal(false)}
                  className="btn-secondary text-xs"
                >
                  Cancelar
                </button>
                <button type="submit" className="btn-primary text-xs">
                  Guardar Evento
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
