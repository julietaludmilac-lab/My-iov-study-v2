import React, { useState, useEffect } from 'react';
import { apiFetch } from './apiClient';
import {
  Building2,
  BookOpen,
  FileText,
  Upload,
  Plus,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Users,
  Search,
  Sparkles,
  Layers,
  ArrowRight,
  ShieldAlert,
  FileSpreadsheet,
  Check,
  X,
  CreditCard,
  Shield,
  Key,
  Lock,
  Unlock,
  GraduationCap,
  Calendar,
  Clock,
  Filter,
} from 'lucide-react';

interface CarreraItem {
  id: string;
  codigo: string;
  nombre: string;
  sede: string;
  estado: string;
  plan_id: string;
  codigo_plan: string;
  plan_version: string;
  total_estudiantes: number;
  total_materias: number;
}

interface ParsedSubject {
  codigo: string;
  nombre: string;
  anio: number;
  regimen: '1C' | '2C' | 'ANUAL';
  cargaHoraria: number;
  condicion: 'OBLIGATORIA' | 'OPTATIVA';
  correlativas: string[];
}

export function AdminManagementPage({
  viewMode,
  onNavigate,
}: {
  viewMode: string;
  onNavigate?: (hash: string) => void;
}) {
  const [carreras, setCarreras] = useState<CarreraItem[]>([]);
  const [estudiantes, setEstudiantes] = useState<any[]>([]);
  const [usuarios, setUsuarios] = useState<any[]>([]);
  const [solicitudes, setSolicitudes] = useState<any[]>([]);
  const [arancelesSummary, setArancelesSummary] = useState<any | null>(null);
  const [auditoriaData, setAuditoriaData] = useState<{ logs: any[]; intentos: any[] } | null>(null);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  // Modal: Nueva Carrera
  const [showAddCarreraModal, setShowAddCarreraModal] = useState(false);
  const [newCarCodigo, setNewCarCodigo] = useState('');
  const [newCarNombre, setNewCarNombre] = useState('');
  const [newCarSede, setNewCarSede] = useState('Sede Santa Fe - Campus San José');
  const [newPlanCodigo, setNewPlanCodigo] = useState('');
  const [newPlanVersion, setNewPlanVersion] = useState('v1.0');
  const [newPlanResolucion, setNewPlanResolucion] = useState('');

  // Lector / Carga de Plan de Estudios
  const [selectedCarreraForPlan, setSelectedCarreraForPlan] = useState<string>('');
  const [planInputMode, setPlanInputMode] = useState<'DOCUMENTO' | 'MANUAL'>('DOCUMENTO');
  const [planDocumentText, setPlanDocumentText] = useState('');
  const [parsedSubjects, setParsedSubjects] = useState<ParsedSubject[]>([]);
  const [parsingLoading, setParsingLoading] = useState(false);
  const [importingLoading, setImportingLoading] = useState(false);

  // Formulario Manual de Materia
  const [manCodigo, setManCodigo] = useState('');
  const [manNombre, setManNombre] = useState('');
  const [manAnio, setManAnio] = useState(1);
  const [manRegimen, setManRegimen] = useState<'1C' | '2C' | 'ANUAL'>('1C');
  const [manHoras, setManHoras] = useState(80);

  // Alta de Estudiante por Administración
  const [showAddStudentModal, setShowAddStudentModal] = useState(false);
  const [newEstNombre, setNewEstNombre] = useState('');
  const [newEstMatricula, setNewEstMatricula] = useState('');
  const [newEstCorreo, setNewEstCorreo] = useState('');
  const [newEstPassword, setNewEstPassword] = useState('');
  const [newEstCarrera, setNewEstCarrera] = useState('');

  // Filtro de usuarios
  const [userRoleFilter, setUserRoleFilter] = useState<string>('TODOS');
  const [userSearchText, setUserSearchText] = useState<string>('');

  const loadData = async () => {
    setLoading(true);
    try {
      const [carRes, estRes, usrRes, solRes, finRes, audRes] = await Promise.all([
        apiFetch('/api/carreras'),
        apiFetch('/api/admin/estudiantes'),
        apiFetch('/api/admin/users'),
        apiFetch('/api/academic/certificates'),
        apiFetch('/api/admin/aranceles-summary'),
        apiFetch('/api/admin/auditoria'),
      ]);

      if (carRes.ok) {
        const d = await carRes.json();
        setCarreras(d.carreras || []);
        if (d.carreras.length > 0 && !selectedCarreraForPlan) {
          setSelectedCarreraForPlan(d.carreras[0].id);
          setNewEstCarrera(d.carreras[0].id);
        }
      }

      if (estRes.ok) {
        setEstudiantes((await estRes.json()).estudiantes || []);
      }

      if (usrRes.ok) {
        setUsuarios((await usrRes.json()).usuarios || []);
      }

      if (solRes.ok) {
        setSolicitudes((await solRes.json()).solicitudes || []);
      }

      if (finRes.ok) {
        setArancelesSummary(await finRes.json());
      }

      if (audRes.ok) {
        setAuditoriaData(await audRes.json());
      }
    } catch {
      setMessage({ type: 'err', text: 'Error al conectar con la base de datos.' });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
    setMessage(null);
  }, [viewMode]);

  // Manejador: Crear Carrera
  const handleCreateCarrera = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCarCodigo.trim() || !newCarNombre.trim()) return;

    try {
      const res = await apiFetch('/api/admin/carreras', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          codigo: newCarCodigo,
          nombre: newCarNombre,
          sede: newCarSede,
          codigoPlan: newPlanCodigo || `PLAN-${newCarCodigo.toUpperCase()}-2026`,
          version: newPlanVersion,
          resolucion: newPlanResolucion,
        }),
      });

      const d = await res.json();
      if (res.ok) {
        setShowAddCarreraModal(false);
        setNewCarCodigo('');
        setNewCarNombre('');
        setMessage({ type: 'ok', text: d.message });
        loadData();
      } else {
        setMessage({ type: 'err', text: d.message || 'Error al crear carrera.' });
      }
    } catch {
      setMessage({ type: 'err', text: 'Error de conexión.' });
    }
  };

  // Manejador: Eliminar Carrera
  const handleDeleteCarrera = async (car: CarreraItem) => {
    if (!window.confirm(`¿Está seguro de eliminar la carrera "${car.nombre}" y todos sus planes asociados?`)) {
      return;
    }

    try {
      const res = await apiFetch(`/api/admin/carreras/${car.id}`, { method: 'DELETE' });
      const d = await res.json();
      if (res.ok) {
        setMessage({ type: 'ok', text: d.message });
        loadData();
      } else {
        setMessage({ type: 'err', text: d.message || 'Error al eliminar carrera.' });
      }
    } catch {
      setMessage({ type: 'err', text: 'Error de conexión.' });
    }
  };

  // Manejador: Analizar / Parsear Documento del Plan de Estudios
  const handleParseDocument = async () => {
    if (!planDocumentText.trim() || !selectedCarreraForPlan) {
      setMessage({ type: 'err', text: 'Seleccione una carrera e ingrese el contenido del documento del plan.' });
      return;
    }

    setParsingLoading(true);
    setMessage(null);
    try {
      const res = await apiFetch(`/api/admin/carreras/${selectedCarreraForPlan}/parse-plan`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ documentText: planDocumentText }),
      });

      const d = await res.json();
      if (res.ok) {
        setParsedSubjects(d.materias || []);
        setMessage({
          type: 'ok',
          text: `Documento procesado con éxito: Se detectaron ${d.totalMaterias} materias organizadas en ${d.totalAnios} años de cursado. Revise la previsualización antes de guardar en la BD.`,
        });
      } else {
        setMessage({ type: 'err', text: d.message || 'Error al analizar documento.' });
      }
    } catch {
      setMessage({ type: 'err', text: 'Error al interpretar el archivo.' });
    } finally {
      setParsingLoading(false);
    }
  };

  // Manejador: Confirmar Importación del Plan Parseado
  const handleImportPlan = async () => {
    if (parsedSubjects.length === 0 || !selectedCarreraForPlan) return;

    setImportingLoading(true);
    try {
      const res = await apiFetch(`/api/admin/carreras/${selectedCarreraForPlan}/import-plan`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ materias: parsedSubjects }),
      });

      const d = await res.json();
      if (res.ok) {
        setMessage({ type: 'ok', text: d.message });
        setParsedSubjects([]);
        setPlanDocumentText('');
        loadData();
      } else {
        setMessage({ type: 'err', text: d.message || 'Error al importar materias.' });
      }
    } catch {
      setMessage({ type: 'err', text: 'Error al guardar materias en la base de datos.' });
    } finally {
      setImportingLoading(false);
    }
  };

  // Manejador: Agregar Materia Manual
  const handleAddMateriaManual = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!manCodigo.trim() || !manNombre.trim() || !selectedCarreraForPlan) return;

    try {
      const res = await apiFetch(`/api/admin/carreras/${selectedCarreraForPlan}/materias`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          codigo: manCodigo,
          nombre: manNombre,
          anio: manAnio,
          regimen: manRegimen,
          cargaHoraria: manHoras,
          condicion: 'OBLIGATORIA',
        }),
      });

      const d = await res.json();
      if (res.ok) {
        setManCodigo('');
        setManNombre('');
        setMessage({ type: 'ok', text: d.message });
        loadData();
      } else {
        setMessage({ type: 'err', text: d.message || 'Error al agregar materia.' });
      }
    } catch {
      setMessage({ type: 'err', text: 'Error al guardar materia.' });
    }
  };

  // Manejador: Registrar Estudiante por Administración
  const handleCreateStudent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEstNombre || !newEstMatricula || !newEstCorreo || !newEstPassword || !newEstCarrera) return;

    try {
      const res = await apiFetch('/api/admin/estudiantes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          nombreCompleto: newEstNombre,
          matricula: newEstMatricula,
          correo: newEstCorreo,
          password: newEstPassword,
          carreraId: newEstCarrera,
        }),
      });

      const d = await res.json();
      if (res.ok) {
        setShowAddStudentModal(false);
        setNewEstNombre('');
        setNewEstMatricula('');
        setNewEstCorreo('');
        setNewEstPassword('');
        setMessage({ type: 'ok', text: d.message });
        loadData();
      } else {
        setMessage({ type: 'err', text: d.message || 'Error al registrar estudiante.' });
      }
    } catch {
      setMessage({ type: 'err', text: 'Error de conexión.' });
    }
  };

  // Manejador: Toggle Estado Usuario (Activo/Suspendido)
  const handleToggleUserStatus = async (id: string) => {
    try {
      const res = await apiFetch(`/api/admin/users/${id}/toggle-status`, { method: 'PATCH' });
      const d = await res.json();
      if (res.ok) {
        setMessage({ type: 'ok', text: d.message });
        loadData();
      }
    } catch {
      setMessage({ type: 'err', text: 'Error al actualizar usuario.' });
    }
  };

  // Manejador: Resetear Password
  const handleResetPassword = async (id: string, correo: string) => {
    if (!window.confirm(`¿Desea restablecer la contraseña del usuario ${correo} a la clave temporal "Ucsf2026!"?`)) return;

    try {
      const res = await apiFetch(`/api/admin/users/${id}/reset-password`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ newPassword: 'Ucsf2026!' }),
      });
      const d = await res.json();
      if (res.ok) {
        setMessage({ type: 'ok', text: d.message });
      }
    } catch {
      setMessage({ type: 'err', text: 'Error de conexión.' });
    }
  };

  // Manejador: Resolver Certificado
  const handleResolveCertificado = async (id: string, accion: 'APROBADA' | 'RECHAZADA') => {
    try {
      const res = await apiFetch(`/api/admin/certificates/${id}/resolve`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ estado: accion }),
      });

      const d = await res.json();
      if (res.ok) {
        setMessage({ type: 'ok', text: d.message });
        loadData();
      }
    } catch {
      setMessage({ type: 'err', text: 'Error al resolver solicitud.' });
    }
  };

  // Plantillas de Ejemplo para Cargar Documentos
  const loadExamplePlan = (tipo: 'MEDICINA' | 'IA' | 'ABOGACIA') => {
    if (tipo === 'MEDICINA') {
      setPlanDocumentText(
`# PLAN DE ESTUDIOS: MEDICINA (UCSF)
Año 1
MED-101 | Anatomía General y del Desarrollo | ANUAL | 160 | OBLIGATORIA | -
MED-102 | Histología y Embriología Humana | 1C | 96 | OBLIGATORIA | -
MED-103 | Biología Celular y Genética | 1C | 80 | OBLIGATORIA | -
MED-104 | Bioquímica Médica | 2C | 96 | OBLIGATORIA | MED-103
MED-105 | Salud Comunitaria y Epidemiología | 2C | 80 | OBLIGATORIA | -

Año 2
MED-201 | Fisiología Humana y Biofísica | ANUAL | 160 | OBLIGATORIA | MED-101,MED-104
MED-202 | Microbiología, Parasitología e Inmunología | 1C | 96 | OBLIGATORIA | MED-103
MED-203 | Patología General | 2C | 96 | OBLIGATORIA | MED-101,MED-102
MED-204 | Farmacología Básica | 2C | 80 | OBLIGATORIA | MED-104`
      );
    } else if (tipo === 'IA') {
      setPlanDocumentText(
`# PLAN DE ESTUDIOS: LICENCIATURA EN INTELIGENCIA ARTIFICIAL
Año 1
LIA-101 | Fundamentos de Computación y Programación | 1C | 96 | OBLIGATORIA | -
LIA-102 | Álgebra Lineal y Geometría Computacional | 1C | 80 | OBLIGATORIA | -
LIA-103 | Cálculo Diferencial e Integral | 2C | 96 | OBLIGATORIA | -
LIA-104 | Estructuras de Datos y Algoritmos Complejos | 2C | 96 | OBLIGATORIA | LIA-101

Año 2
LIA-201 | Probabilidad, Estadística e Inferencia | 1C | 80 | OBLIGATORIA | LIA-103
LIA-202 | Aprendizaje Automático I (Machine Learning) | 1C | 96 | OBLIGATORIA | LIA-102,LIA-104
LIA-203 | Redes Neuronales y Aprendizaje Profundo | 2C | 96 | OBLIGATORIA | LIA-202`
      );
    } else {
      setPlanDocumentText(
`# PLAN DE ESTUDIOS: ABOGACÍA
Año 1
ABOG-101 | Introducción al Derecho | 1C | 80 | OBLIGATORIA | -
ABOG-102 | Historia del Derecho Argentino | 1C | 64 | OBLIGATORIA | -
ABOG-103 | Derecho Romano e Instituciones | 2C | 80 | OBLIGATORIA | -
ABOG-104 | Derecho Constitucional I | 2C | 96 | OBLIGATORIA | ABOG-101`
      );
    }
  };

  // Carrera seleccionada
  const selectedCarrera = carreras.find((c) => c.id === selectedCarreraForPlan) || carreras[0];

  // Filtrado de usuarios
  const usuariosFiltrados = usuarios.filter((u) => {
    const matchRole = userRoleFilter === 'TODOS' || u.rol === userRoleFilter;
    const matchText =
      !userSearchText ||
      u.correo.toLowerCase().includes(userSearchText.toLowerCase()) ||
      u.matricula.toLowerCase().includes(userSearchText.toLowerCase()) ||
      (u.nombre_completo && u.nombre_completo.toLowerCase().includes(userSearchText.toLowerCase()));
    return matchRole && matchText;
  });

  return (
    <div className="space-y-6">
      {/* Banner de Administración */}
      <div className="iov-card iov-card-destacada">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="badge-vigente">Gestión Institucional</span>
              <span className="text-xs text-slate-500 font-medium">Gobierno Académico y Financiero</span>
            </div>
            <h2 className="text-xl md:text-2xl font-black text-[var(--azul-900)] tracking-tight">
              {viewMode === 'admincarreras' && 'Gestión de Carreras y Lector de Planes de Estudio'}
              {viewMode === 'adminmaterias' && 'Malla Curricular y Correlatividades Oficiales'}
              {viewMode === 'adminusuarios' && 'Padrón de Estudiantes y Gestión de Usuarios'}
              {viewMode === 'adminaranceles' && 'Administración de Aranceles y Cuotas Institucionales'}
              {viewMode === 'adminsolicitudes' && 'Bandeja Oficial de Solicitudes y Certificados'}
              {viewMode === 'auditoria' && 'Auditoría del Sistema y Seguridad Institucional'}
            </h2>
            <p className="text-xs md:text-sm text-slate-600 mt-1 max-w-2xl">
              {viewMode === 'admincarreras' && 'Cree o elimine carreras. Suba o ingrese el archivo del plan de estudio para que el lector inteligente extraiga materias por año y correlatividades.'}
              {viewMode === 'adminmaterias' && 'Supervise el plan de estudio completo de cada carrera, agregue materias manuales y configure correlatividades para cursar y rendir.'}
              {viewMode === 'adminusuarios' && 'Controle el registro de estudiantes por carrera para dimensionar la matrícula, gestione estados de cuenta y restablezca credenciales.'}
              {viewMode === 'adminaranceles' && 'Seguimiento financiero global: total recaudado, cuotas pendientes por ciclo y conciliación institucional.'}
              {viewMode === 'adminsolicitudes' && 'Valide pedidos de certificados y emita constancias con firma digital y código QR.'}
              {viewMode === 'auditoria' && 'Monitoreo de trazabilidad, eventos de seguridad, intentos denegados y salud de la plataforma.'}
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={loadData}
              className="btn-secondary text-xs"
              disabled={loading}
              title="Recargar datos"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              <span>Actualizar</span>
            </button>
          </div>
        </div>
      </div>

      {message && (
        <div
          className={`p-3 rounded-xl text-xs font-semibold flex items-center justify-between ${
            message.type === 'ok'
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-red-50 text-red-800 border border-red-200'
          }`}
        >
          <span>{message.text}</span>
          <button onClick={() => setMessage(null)} className="p-1 hover:opacity-75">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* =========================================================================
          VISTA 1: GESTIÓN DE CARRERAS Y PLANES (admincarreras)
          ========================================================================= */}
      {viewMode === 'admincarreras' && (
        <div className="space-y-6">
          {/* Carreras Registradas en la Institución */}
          <div className="iov-card">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
              <div>
                <h3 className="text-base font-bold text-[var(--azul-900)]">
                  Carreras Registradas en la Plataforma ({carreras.length})
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Estas carreras aparecen en el registro de estudiantes y quedan disponibles para Bedelía para crear comisiones.
                </p>
              </div>

              <button
                onClick={() => setShowAddCarreraModal(true)}
                className="btn-primary text-xs shrink-0"
              >
                <Plus className="w-4 h-4" />
                <span>Nueva Carrera</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {carreras.map((car) => (
                <div
                  key={car.id}
                  className={`p-3.5 rounded-xl border text-xs transition-all ${
                    selectedCarreraForPlan === car.id
                      ? 'bg-[var(--celeste-100)] border-[var(--azul-700)] shadow-xs'
                      : 'bg-white border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex justify-between items-start mb-1.5">
                    <span className="font-mono text-xs font-bold text-[var(--azul-700)]">
                      {car.codigo}
                    </span>
                    <button
                      onClick={() => handleDeleteCarrera(car)}
                      className="p-1 text-slate-400 hover:text-red-600 rounded"
                      title="Eliminar carrera"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <h4 className="font-bold text-slate-900 text-sm leading-tight mb-2">
                    {car.nombre}
                  </h4>

                  <div className="space-y-1 text-slate-600 text-[11px] mb-3">
                    <div>Sede: {car.sede}</div>
                    <div>Plan: <strong>{car.codigo_plan || 'Sin plan'}</strong> ({car.plan_version || 'v1.0'})</div>
                    <div className="flex items-center gap-2 pt-1 font-semibold text-[var(--azul-900)]">
                      <span>{car.total_materias || 0} Materias</span>
                      <span>·</span>
                      <span>{car.total_estudiantes || 0} Estudiantes inscriptos</span>
                    </div>
                  </div>

                  <button
                    onClick={() => setSelectedCarreraForPlan(car.id)}
                    className={`w-full py-1.5 px-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1 transition-colors ${
                      selectedCarreraForPlan === car.id
                        ? 'bg-[var(--azul-900)] text-white'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    <span>{selectedCarreraForPlan === car.id ? 'Seleccionada para Plan' : 'Cargar / Gestionar Plan'}</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* LECTOR / PARSER INTELIGENTE DEL PLAN DE ESTUDIOS */}
          <div className="iov-card space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <Sparkles className="w-4 h-4 text-[var(--celeste-500)]" />
                  <h3 className="text-base font-bold text-[var(--azul-900)]">
                    Lector de Plan de Estudios para: {selectedCarrera?.nombre}
                  </h3>
                </div>
                <p className="text-xs text-slate-600">
                  Suba o pegue el contenido del plan de estudios. El sistema identificará automáticamente las materias por año, régimen, horas y correlatividades.
                </p>
              </div>

              {/* Botones de plantillas */}
              <div className="flex items-center gap-1.5 shrink-0">
                <span className="text-[11px] text-slate-400 font-bold uppercase">Ejemplos:</span>
                <button
                  type="button"
                  onClick={() => loadExamplePlan('MEDICINA')}
                  className="px-2 py-1 rounded bg-slate-100 hover:bg-slate-200 text-[11px] font-semibold text-slate-700"
                >
                  Medicina
                </button>
                <button
                  type="button"
                  onClick={() => loadExamplePlan('IA')}
                  className="px-2 py-1 rounded bg-slate-100 hover:bg-slate-200 text-[11px] font-semibold text-slate-700"
                >
                  Lic. en IA
                </button>
                <button
                  type="button"
                  onClick={() => loadExamplePlan('ABOGACIA')}
                  className="px-2 py-1 rounded bg-slate-100 hover:bg-slate-200 text-[11px] font-semibold text-slate-700"
                >
                  Abogacía
                </button>
              </div>
            </div>

            {/* Selector de modo: Documento vs Manual */}
            <div className="flex border-b border-slate-200">
              <button
                type="button"
                onClick={() => setPlanInputMode('DOCUMENTO')}
                className={`py-2 px-4 text-xs font-bold border-b-2 transition-colors ${
                  planInputMode === 'DOCUMENTO'
                    ? 'border-[var(--azul-700)] text-[var(--azul-900)]'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                <Upload className="w-3.5 h-3.5 inline mr-1.5" />
                Lector de Archivo / Documento
              </button>
              <button
                type="button"
                onClick={() => setPlanInputMode('MANUAL')}
                className={`py-2 px-4 text-xs font-bold border-b-2 transition-colors ${
                  planInputMode === 'MANUAL'
                    ? 'border-[var(--azul-700)] text-[var(--azul-900)]'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                <Plus className="w-3.5 h-3.5 inline mr-1.5" />
                Carga Manual de Materia
              </button>
            </div>

            {/* MODO 1: LECTOR DE DOCUMENTO */}
            {planInputMode === 'DOCUMENTO' && (
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Pegue o cargue el texto del documento del Plan de Estudios
                  </label>
                  <textarea
                    rows={7}
                    placeholder="Formato reconocido:&#10;Año 1&#10;COD-101 | Nombre de la Materia | 1C | 96 | OBLIGATORIA | -&#10;COD-102 | Segunda Materia | 2C | 96 | OBLIGATORIA | COD-101"
                    value={planDocumentText}
                    onChange={(e) => setPlanDocumentText(e.target.value)}
                    className="w-full p-3 font-mono text-xs rounded-xl border border-slate-300 focus:outline-none focus:border-[var(--azul-700)] bg-slate-50/50"
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="text-[11px] text-slate-500">
                    Soporta años de cursado, régimen 1C/2C/Anual, horas reloj y correlatividades separadas por coma.
                  </div>
                  <button
                    type="button"
                    onClick={handleParseDocument}
                    disabled={parsingLoading || !planDocumentText.trim()}
                    className="btn-primary text-xs"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>{parsingLoading ? 'Analizando documento...' : 'Analizar y Extraer Materias'}</span>
                  </button>
                </div>

                {/* Previsualización de Materias Detectadas */}
                {parsedSubjects.length > 0 && (
                  <div className="mt-4 p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200 pb-2">
                      <div>
                        <div className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                          <span>Previsualización: {parsedSubjects.length} Materias Detectadas</span>
                        </div>
                        <div className="text-[11px] text-slate-500">
                          Revise las materias extraídas antes de confirmar la importación definitiva a SQLite.
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={handleImportPlan}
                        disabled={importingLoading}
                        className="btn-primary text-xs py-1.5 px-3 bg-emerald-700 hover:bg-emerald-800"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>{importingLoading ? 'Guardando en BD...' : 'Guardar e Importar Plan a BD'}</span>
                      </button>
                    </div>

                    <div className="max-h-60 overflow-y-auto space-y-1.5 pr-1">
                      {parsedSubjects.map((s, idx) => (
                        <div
                          key={idx}
                          className="p-2 bg-white rounded-lg border border-slate-100 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                        >
                          <div className="flex items-center gap-2">
                            <span className="font-mono font-bold text-[var(--azul-700)] text-[11px]">
                              {s.codigo}
                            </span>
                            <span className="font-semibold text-slate-900">{s.nombre}</span>
                          </div>

                          <div className="flex items-center gap-2 text-[11px] text-slate-600 shrink-0">
                            <span className="px-1.5 py-0.5 rounded bg-slate-100 font-bold">{s.anio}° Año</span>
                            <span>{s.regimen}</span>
                            <span>{s.cargaHoraria} hs</span>
                            {s.correlativas.length > 0 && (
                              <span className="text-[10px] text-amber-800 bg-amber-50 px-1 rounded">
                                Req: {s.correlativas.join(', ')}
                              </span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* MODO 2: CARGA MANUAL DE MATERIA */}
            {planInputMode === 'MANUAL' && (
              <form onSubmit={handleAddMateriaManual} className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3 text-xs">
                <div className="font-bold text-slate-900">
                  Agregar Asignatura Manual al Plan de {selectedCarrera?.nombre}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Código Asignatura</label>
                    <input
                      type="text"
                      placeholder="ej. LSI-301"
                      value={manCodigo}
                      onChange={(e) => setManCodigo(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono uppercase bg-white"
                      required
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Nombre Oficial</label>
                    <input
                      type="text"
                      placeholder="ej. Inteligencia Artificial Aplicada"
                      value={manNombre}
                      onChange={(e) => setManNombre(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Año de Carrera</label>
                    <select
                      value={manAnio}
                      onChange={(e) => setManAnio(parseInt(e.target.value, 10))}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white"
                    >
                      <option value={1}>1° Año</option>
                      <option value={2}>2° Año</option>
                      <option value={3}>3° Año</option>
                      <option value={4}>4° Año</option>
                      <option value={5}>5° Año</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Régimen</label>
                    <select
                      value={manRegimen}
                      onChange={(e) => setManRegimen(e.target.value as any)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white"
                    >
                      <option value="1C">1er Cuatrimestre</option>
                      <option value="2C">2do Cuatrimestre</option>
                      <option value="ANUAL">Anual</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Carga Horaria (Hs)</label>
                    <input
                      type="number"
                      value={manHoras}
                      onChange={(e) => setManHoras(parseInt(e.target.value, 10))}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white"
                    />
                  </div>
                </div>

                <div className="flex justify-end pt-2">
                  <button type="submit" className="btn-primary text-xs">
                    <Plus className="w-3.5 h-3.5" />
                    <span>Agregar Asignatura</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* =========================================================================
          VISTA 2: MALLA CURRICULAR Y CORRELATIVIDADES (adminmaterias)
          ========================================================================= */}
      {viewMode === 'adminmaterias' && (
        <div className="space-y-5">
          <div className="iov-card">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Seleccione Carrera a Inspeccionar
                </label>
                <select
                  value={selectedCarreraForPlan}
                  onChange={(e) => setSelectedCarreraForPlan(e.target.value)}
                  className="w-full sm:max-w-md px-3 py-2 rounded-lg border border-slate-300 text-xs bg-white font-medium"
                >
                  {carreras.map((car) => (
                    <option key={car.id} value={car.id}>
                      {car.nombre} ({car.codigo}) — {car.total_materias || 0} materias
                    </option>
                  ))}
                </select>
              </div>

              <button
                onClick={() => {
                  setPlanInputMode('MANUAL');
                  onNavigate?.('admincarreras');
                }}
                className="btn-primary text-xs shrink-0 self-start sm:self-auto"
              >
                <Plus className="w-4 h-4" />
                <span>Agregar Materia a este Plan</span>
              </button>
            </div>
          </div>

          <div className="iov-card">
            <div className="flex items-center justify-between mb-4 border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-base font-bold text-[var(--azul-900)]">
                  Malla Curricular Oficial: {selectedCarrera?.nombre}
                </h3>
                <div className="text-xs text-slate-500">
                  Plan: {selectedCarrera?.codigo_plan || 'PLAN-2026'} ({selectedCarrera?.plan_version || 'v1.0'})
                </div>
              </div>
              <span className="badge-pagada text-xs font-semibold">
                {selectedCarrera?.total_materias || 0} Asignaturas en Plan
              </span>
            </div>

            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-600">
              <p>
                Este plan de estudios define los requisitos que el estudiante consulta en su sección de autogestión y suministra la lista oficial de materias a partir de la cual <strong>Bedelía</strong> crea y asigna las comisiones de cursado.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          VISTA 3: PADRÓN Y GESTIÓN DE USUARIOS (adminusuarios)
          ========================================================================= */}
      {viewMode === 'adminusuarios' && (
        <div className="space-y-5">
          <div className="iov-card flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h3 className="text-base font-bold text-[var(--azul-900)]">
                Padrón General de Usuarios ({usuarios.length})
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Controle estudiantes por carrera, personal de bedelía, docentes y administradores.
              </p>
            </div>

            <button
              onClick={() => setShowAddStudentModal(true)}
              className="btn-primary text-xs shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>Registrar Estudiante</span>
            </button>
          </div>

          {/* Filtros de Padrón */}
          <div className="iov-card flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-slate-400" />
              <span className="font-semibold text-slate-700">Rol:</span>
              <select
                value={userRoleFilter}
                onChange={(e) => setUserRoleFilter(e.target.value)}
                className="px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-medium"
              >
                <option value="TODOS">Todos los roles</option>
                <option value="ESTUDIANTE">Estudiantes</option>
                <option value="BEDELIA">Bedelía</option>
                <option value="ADMINISTRACION">Administración</option>
              </select>
            </div>

            <div className="relative w-full sm:max-w-xs">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Buscar por matrícula o correo..."
                value={userSearchText}
                onChange={(e) => setUserSearchText(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 rounded-lg border border-slate-300 text-xs"
              />
            </div>
          </div>

          {/* Tabla de Usuarios */}
          <div className="iov-card overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 text-slate-600 uppercase font-bold text-[10px] border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-3">Usuario / Nombre</th>
                    <th className="py-2.5 px-3">Matrícula</th>
                    <th className="py-2.5 px-3">Correo Institucional</th>
                    <th className="py-2.5 px-3">Rol</th>
                    <th className="py-2.5 px-3">Carrera</th>
                    <th className="py-2.5 px-3">Estado</th>
                    <th className="py-2.5 px-3 text-right">Acciones</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {usuariosFiltrados.map((u) => {
                    const activo = u.estado === 'ACTIVO';
                    return (
                      <tr key={u.id} className="hover:bg-slate-50/50">
                        <td className="py-2.5 px-3 font-semibold text-slate-900">
                          {u.nombre_completo || 'Personal Institucional'}
                        </td>
                        <td className="py-2.5 px-3 font-mono text-slate-600 font-bold">
                          {u.matricula}
                        </td>
                        <td className="py-2.5 px-3 text-slate-600">
                          {u.correo}
                        </td>
                        <td className="py-2.5 px-3">
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            u.rol === 'ADMINISTRACION'
                              ? 'bg-purple-100 text-purple-800'
                              : u.rol === 'BEDELIA'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-blue-100 text-blue-800'
                          }`}>
                            {u.rol}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-slate-500">
                          {u.carrera_nombre || '—'}
                        </td>
                        <td className="py-2.5 px-3">
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            activo ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
                          }`}>
                            {u.estado}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-right space-x-1">
                          <button
                            onClick={() => handleToggleUserStatus(u.id)}
                            className={`p-1.5 rounded text-[11px] font-bold ${
                              activo
                                ? 'text-amber-700 hover:bg-amber-50'
                                : 'text-emerald-700 hover:bg-emerald-50'
                            }`}
                            title={activo ? 'Suspender cuenta' : 'Reactivar cuenta'}
                          >
                            {activo ? <Lock className="w-3.5 h-3.5 inline" /> : <Unlock className="w-3.5 h-3.5 inline" />}
                          </button>
                          <button
                            onClick={() => handleResetPassword(u.id, u.correo)}
                            className="p-1.5 text-slate-500 hover:text-[var(--azul-700)] rounded"
                            title="Resetear contraseña"
                          >
                            <Key className="w-3.5 h-3.5 inline" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          VISTA 4: ARANCELES INSTITUCIONALES (adminaranceles)
          ========================================================================= */}
      {viewMode === 'adminaranceles' && (
        <div className="space-y-5">
          {arancelesSummary ? (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="iov-card">
                  <div className="text-xs font-bold text-slate-500 uppercase mb-1">Total Recaudado</div>
                  <div className="text-2xl font-black text-emerald-700">
                    ${arancelesSummary.resumen?.montoRecaudado?.toLocaleString('es-AR') || '0'}
                  </div>
                  <div className="text-[11px] text-slate-500 mt-1">
                    {arancelesSummary.resumen?.totalPagadas || 0} Cuotas abonadas
                  </div>
                </div>

                <div className="iov-card">
                  <div className="text-xs font-bold text-slate-500 uppercase mb-1">Monto Pendiente</div>
                  <div className="text-2xl font-black text-[var(--rojo-600)]">
                    ${arancelesSummary.resumen?.montoPendiente?.toLocaleString('es-AR') || '0'}
                  </div>
                  <div className="text-[11px] text-slate-500 mt-1">
                    {arancelesSummary.resumen?.totalPendientes || 0} Cuotas a cobrar
                  </div>
                </div>

                <div className="iov-card">
                  <div className="text-xs font-bold text-slate-500 uppercase mb-1">Cuotas Emitidas</div>
                  <div className="text-2xl font-black text-[var(--azul-900)]">
                    {arancelesSummary.resumen?.totalCuotas || 0}
                  </div>
                  <div className="text-[11px] text-slate-500 mt-1">Ciclo lectivo 2026</div>
                </div>

                <div className="iov-card">
                  <div className="text-xs font-bold text-slate-500 uppercase mb-1">Cobranza Global</div>
                  <div className="text-2xl font-black text-[var(--azul-700)]">
                    {arancelesSummary.resumen?.totalCuotas > 0
                      ? `${Math.round(((arancelesSummary.resumen?.totalPagadas || 0) / arancelesSummary.resumen.totalCuotas) * 100)}%`
                      : '0%'}
                  </div>
                  <div className="text-[11px] text-slate-500 mt-1">Índice de cumplimiento</div>
                </div>
              </div>

              {/* Detalle por Período */}
              <div className="iov-card">
                <h3 className="text-sm font-bold text-[var(--azul-900)] mb-3">
                  Balance de Emisión por Cuota / Concepto
                </h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-slate-50 text-slate-600 uppercase font-bold text-[10px] border-b border-slate-200">
                      <tr>
                        <th className="py-2.5 px-3">Período</th>
                        <th className="py-2.5 px-3">Concepto</th>
                        <th className="py-2.5 px-3">Total Cuotas</th>
                        <th className="py-2.5 px-3">Pagadas</th>
                        <th className="py-2.5 px-3">Pendientes</th>
                        <th className="py-2.5 px-3 text-right">Recaudado</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {arancelesSummary.periodos?.map((p: any, idx: number) => (
                        <tr key={idx} className="hover:bg-slate-50/50">
                          <td className="py-2.5 px-3 font-bold font-mono text-[var(--azul-700)]">
                            {p.periodo}
                          </td>
                          <td className="py-2.5 px-3 font-semibold text-slate-900">{p.concepto}</td>
                          <td className="py-2.5 px-3">{p.total}</td>
                          <td className="py-2.5 px-3 text-emerald-700 font-bold">{p.pagadas}</td>
                          <td className="py-2.5 px-3 text-red-600 font-bold">{p.pendientes}</td>
                          <td className="py-2.5 px-3 text-right font-bold text-slate-900">
                            ${p.monto_recaudado?.toLocaleString('es-AR') || '0'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          ) : (
            <div className="iov-card text-center py-10">
              <CreditCard className="w-8 h-8 text-slate-300 mx-auto mb-2" />
              <div className="text-xs text-slate-500">Cargando métricas financieras...</div>
            </div>
          )}
        </div>
      )}

      {/* =========================================================================
          VISTA 5: BANDEJA DE SOLICITUDES Y CERTIFICADOS (adminsolicitudes)
          ========================================================================= */}
      {viewMode === 'adminsolicitudes' && (
        <div className="space-y-5">
          <div className="iov-card">
            <h3 className="text-base font-bold text-[var(--azul-900)] mb-1">
              Bandeja de Validación de Trámites y Certificados
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Atienda y resuelva los certificados solicitados por los estudiantes con verificación institucional.
            </p>

            <div className="space-y-3">
              {solicitudes.length === 0 ? (
                <div className="text-center py-8 text-slate-400 text-xs">
                  No hay solicitudes pendientes de resolución.
                </div>
              ) : (
                solicitudes.map((sol) => (
                  <div
                    key={sol.id}
                    className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-mono font-bold text-[var(--azul-700)]">{sol.id}</span>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          sol.estado === 'APROBADA'
                            ? 'bg-emerald-100 text-emerald-800'
                            : sol.estado === 'RECHAZADA'
                            ? 'bg-red-100 text-red-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}>
                          {sol.estado}
                        </span>
                      </div>
                      <div className="text-sm font-bold text-slate-900">
                        {sol.tipo_certificado}
                      </div>
                      <div className="text-slate-600 mt-0.5">
                        Presentación: {sol.lugar_presentacion} {sol.observacion ? `· Obs: ${sol.observacion}` : ''}
                      </div>
                      <div className="text-[11px] text-slate-400 mt-1">
                        Ingresada: {new Date(sol.created_at).toLocaleDateString('es-AR')}
                      </div>
                    </div>

                    {sol.estado === 'RECIBIDA' && (
                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          onClick={() => handleResolveCertificado(sol.id, 'APROBADA')}
                          className="btn-primary text-xs py-1.5 px-3 bg-emerald-700 hover:bg-emerald-800"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Aprobar y Emitir</span>
                        </button>
                        <button
                          onClick={() => handleResolveCertificado(sol.id, 'RECHAZADA')}
                          className="p-1.5 text-slate-400 hover:text-red-600 rounded"
                          title="Rechazar solicitud"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          VISTA 6: AUDITORÍA Y SEGURIDAD INSTITUCIONAL (auditoria)
          ========================================================================= */}
      {viewMode === 'auditoria' && (
        <div className="space-y-5">
          <div className="iov-card">
            <h3 className="text-base font-bold text-[var(--azul-900)] mb-1">
              Registro de Auditoría y Trazabilidad del Sistema
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Monitoreo en tiempo real de accesos, denegaciones 403 e intentos de autenticación en SQLite.
            </p>

            {auditoriaData?.logs && auditoriaData.logs.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left">
                  <thead className="bg-slate-50 text-slate-600 uppercase font-bold text-[10px] border-b border-slate-200">
                    <tr>
                      <th className="py-2.5 px-3">Fecha y Hora</th>
                      <th className="py-2.5 px-3">Actor / Rol</th>
                      <th className="py-2.5 px-3">Acción</th>
                      <th className="py-2.5 px-3">Recurso</th>
                      <th className="py-2.5 px-3 text-right">Resultado</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {auditoriaData.logs.map((log) => (
                      <tr key={log.id} className="hover:bg-slate-50/50">
                        <td className="py-2.5 px-3 text-slate-500 font-mono text-[11px]">
                          {log.created_at}
                        </td>
                        <td className="py-2.5 px-3 font-semibold text-slate-900">
                          {log.actor_id} ({log.actor_rol})
                        </td>
                        <td className="py-2.5 px-3 font-mono text-[var(--azul-700)]">
                          {log.accion}
                        </td>
                        <td className="py-2.5 px-3 text-slate-600">
                          {log.recurso}
                        </td>
                        <td className="py-2.5 px-3 text-right">
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            log.resultado === 'DENEGADO'
                              ? 'bg-red-100 text-red-800'
                              : 'bg-emerald-100 text-emerald-800'
                          }`}>
                            {log.resultado}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-6 text-slate-400 text-xs">
                No hay registros de auditoría recientes.
              </div>
            )}
          </div>
        </div>
      )}

      {/* =========================================================================
          MODALES DE ADMINISTRACIÓN
          ========================================================================= */}
      {/* Modal: Crear Carrera */}
      {showAddCarreraModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200">
            <h3 className="text-base font-bold text-[var(--azul-900)] mb-1">
              Crear Nueva Carrera y Plan de Estudios
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              La carrera quedará registrada inmediatamente en la base de datos y disponible para Bedelía.
            </p>

            <form onSubmit={handleCreateCarrera} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Código de Carrera</label>
                  <input
                    type="text"
                    placeholder="ej. CAR-MED"
                    value={newCarCodigo}
                    onChange={(e) => setNewCarCodigo(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono uppercase"
                    required
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Sede</label>
                  <input
                    type="text"
                    value={newCarSede}
                    onChange={(e) => setNewCarSede(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Nombre Completo de la Carrera</label>
                <input
                  type="text"
                  placeholder="ej. Medicina / Licenciatura en Inteligencia Artificial"
                  value={newCarNombre}
                  onChange={(e) => setNewCarNombre(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Código Plan</label>
                  <input
                    type="text"
                    placeholder="ej. PLAN-MED-2026"
                    value={newPlanCodigo}
                    onChange={(e) => setNewPlanCodigo(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono uppercase"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Versión</label>
                  <input
                    type="text"
                    value={newPlanVersion}
                    onChange={(e) => setNewPlanVersion(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Resolución del Consejo Superior</label>
                <input
                  type="text"
                  placeholder="ej. Res. CS N° 45/2026"
                  value={newPlanResolucion}
                  onChange={(e) => setNewPlanResolucion(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddCarreraModal(false)}
                  className="btn-secondary text-xs"
                >
                  Cancelar
                </button>
                <button type="submit" className="btn-primary text-xs">
                  Guardar Carrera
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Registrar Estudiante */}
      {showAddStudentModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200">
            <h3 className="text-base font-bold text-[var(--azul-900)] mb-1">
              Registrar Nuevo Estudiante
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Crea la credencial de acceso y matriculación en la carrera seleccionada.
            </p>

            <form onSubmit={handleCreateStudent} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Nombre Completo</label>
                <input
                  type="text"
                  placeholder="ej. Santiago Martín Benítez"
                  value={newEstNombre}
                  onChange={(e) => setNewEstNombre(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Matrícula</label>
                  <input
                    type="text"
                    placeholder="ej. A-2026-050"
                    value={newEstMatricula}
                    onChange={(e) => setNewEstMatricula(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono uppercase"
                    required
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Carrera a Asignar</label>
                  <select
                    value={newEstCarrera}
                    onChange={(e) => setNewEstCarrera(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white"
                  >
                    {carreras.map((car) => (
                      <option key={car.id} value={car.id}>
                        {car.nombre} ({car.codigo})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Correo Electrónico</label>
                  <input
                    type="email"
                    placeholder="ej. santiago.benitez@ucsf.test"
                    value={newEstCorreo}
                    onChange={(e) => setNewEstCorreo(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300"
                    required
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Contraseña Inicial</label>
                  <input
                    type="password"
                    placeholder="ej. Ucsf2026!"
                    value={newEstPassword}
                    onChange={(e) => setNewEstPassword(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300"
                    required
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddStudentModal(false)}
                  className="btn-secondary text-xs"
                >
                  Cancelar
                </button>
                <button type="submit" className="btn-primary text-xs">
                  Crear Estudiante
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
