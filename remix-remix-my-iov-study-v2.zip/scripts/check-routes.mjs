import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT_DIR = path.resolve(__dirname, '..');
const MANIFEST_PATH = path.join(ROOT_DIR, 'public', 'manus-routes.json');
const REGISTRY_PATH = path.join(ROOT_DIR, 'src', 'routesRegistry.ts');

console.log('[CHECK-ROUTES] Validating route registry consistency...');

if (!fs.existsSync(REGISTRY_PATH)) {
  console.error(`ERROR: Route registry not found at ${REGISTRY_PATH}`);
  process.exit(1);
}

const registryContent = fs.readFileSync(REGISTRY_PATH, 'utf-8');

// Extraer hashes del registry
const hashMatches = [...registryContent.matchAll(/hash:\s*['"]([a-zA-Z0-9_-]+)['"]/g)];
const hashes = hashMatches.map((m) => m[1]);

if (hashes.length === 0) {
  console.error('ERROR: No routes detected in registry');
  process.exit(1);
}

// Verificar que no haya hashes duplicados
const seen = new Set();
const duplicates = [];
for (const h of hashes) {
  if (seen.has(h)) duplicates.push(h);
  seen.add(h);
}

if (duplicates.length > 0) {
  console.error(`ERROR: Duplicate route hashes found: ${duplicates.join(', ')}`);
  process.exit(1);
}

// Leer o sincronizar manus-routes.json
let manifestData = { routes: [] };
if (fs.existsSync(MANIFEST_PATH)) {
  try {
    manifestData = JSON.parse(fs.readFileSync(MANIFEST_PATH, 'utf-8'));
  } catch (err) {
    console.warn('WARNING: Failed to parse existing manus-routes.json, recreating...');
  }
}

// Sincronizar manifiesto
const manifestRoutes = hashes.map((h) => ({
  path: `/#${h}`,
  name: h,
}));

fs.mkdirSync(path.dirname(MANIFEST_PATH), { recursive: true });
fs.writeFileSync(MANIFEST_PATH, JSON.stringify({ routes: manifestRoutes }, null, 2) + '\n');

console.log(`[CHECK-ROUTES] OK: ${hashes.length} routes registered, verified, and synchronized with manus-routes.json.`);
